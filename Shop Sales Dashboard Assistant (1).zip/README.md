
  # Shop Sales Dashboard Assistant

  This is a code bundle for Shop Sales Dashboard Assistant. The original project is available at https://www.figma.com/design/MqtbiBIkWmtV5ZkIyFb3Lp/Shop-Sales-Dashboard-Assistant.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  