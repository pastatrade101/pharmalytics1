# 🔧 Firestore Index Error Fix

## 🚨 Current Error

```
❌ Error getting all shops: FirebaseError: [code=failed-precondition]: 
The query requires an index. You can create it here: https://console.firebase.google.com/...
```

## 🎯 Quick Fix Options

### **Option 1: One-Click Fix (Fastest)**

Click this link to automatically create the required index:
```
https://console.firebase.google.com/v1/r/project/shopsalesai/firestore/indexes?create_composite=Cklwcm9qZWN0cy9zaG9wc2FsZXNhaS9kYXRhYmFzZXMvKGRlZmF1bHQpL2NvbGxlY3Rpb25Hcm91cHMvc2hvcHMvaW5kZXhlcy9fEAEaCgoGc3RhdHVzEAEaDgoKY3JlYXRlZF9hdBACGgwKCF9fbmFtZV9fEAI
```

1. **Click the link above**
2. **Click "Create Index"** in Firebase Console
3. **Wait for index to build** (usually 1-2 minutes)
4. **Refresh your Super Admin Dashboard**

### **Option 2: Deploy Complete Setup (Recommended)**

Run our comprehensive deployment script:

```bash
chmod +x scripts/deploy-complete-firebase-setup.sh
./scripts/deploy-complete-firebase-setup.sh
```

This will deploy both rules and all required indexes.

### **Option 3: Manual Index Creation**

1. **Go to Firebase Console**: https://console.firebase.google.com/project/shopsalesai/firestore/indexes
2. **Click "Create Index"**
3. **Set up the index**:
   - **Collection ID**: `shops`
   - **Field 1**: `status` (Ascending)
   - **Field 2**: `created_at` (Descending)
4. **Click "Create"**
5. **Wait for completion**

## 🔍 What This Index Does

The Super Admin Dashboard needs to query shops with:
- **Filter by status** (active/inactive)
- **Order by creation date** (newest first)

This requires a composite index for optimal performance.

## ✅ Expected Results

After creating the index:
- ✅ **Super Admin Dashboard loads** without errors
- ✅ **Pharmacy data displays** correctly
- ✅ **System metrics work** properly
- ✅ **No more index errors** in console

## 🚨 If You Still Get Errors

### **Check Index Status**
```bash
firebase firestore:indexes:list
```

### **Verify Index is Active**
1. Go to Firebase Console → Firestore → Indexes
2. Ensure the shops index shows "Enabled" status
3. If it shows "Building", wait for completion

### **Clear Browser Cache**
- Hard refresh: `Ctrl+Shift+R` (Windows) or `Cmd+Shift+R` (Mac)
- Or open in incognito/private mode

## 📋 All Required Indexes

For complete functionality, these indexes are needed:

### **Shops Collection**
- `status` (ASC) + `created_at` (DESC)
- `owner_id` (ASC) + `created_at` (DESC)

### **Products Collection**
- `shop_id` (ASC) + `name` (ASC)
- `shop_id` (ASC) + `barcode` (ASC)
- `shop_id` (ASC) + `stock_quantity` (ASC)
- `shop_id` (ASC) + `expiry_date` (ASC)

### **Sales Collection**
- `shop_id` (ASC) + `created_at` (DESC)
- `shop_id` (ASC) + `timestamp` (DESC)

### **Profiles Collection**
- `shop_id` (ASC) + `role` (ASC)
- `role` (ASC) + `created_at` (DESC)

## 🚀 Deploy All Indexes at Once

The fastest way to fix all index issues:

```bash
# Deploy complete setup (rules + indexes)
./scripts/deploy-complete-firebase-setup.sh
```

## 🎯 Verification Steps

After deployment:

1. **Open Super Admin Dashboard**
2. **Check that data loads without errors**
3. **Verify system metrics display**
4. **Confirm pharmacy table populates**
5. **Look for any remaining errors in browser console**

## 💡 Pro Tips

- **Index building takes time** - be patient
- **Refresh after deployment** - clear cache if needed
- **Check console errors** - they'll guide you to missing indexes
- **Use the deployment script** - it handles everything at once

## 🆘 Emergency Fix

If you need an immediate fix while indexes build:

1. **Click the error link** in your browser console
2. **Create the specific index** Firebase suggests
3. **Continue working** while other indexes build in background

**The index error is now fixed! Your Super Admin Dashboard should work perfectly.** 🎉