import { collection, getDocs, updateDoc, doc, writeBatch, query, where } from 'firebase/firestore';
import { db } from './firebase-config';
import { Product } from './firebase-types';
import { handleFirebaseError } from './firebase-errors';

// Default prices for common pharmaceutical products (in TZS)
const PHARMACEUTICAL_PRICE_DEFAULTS = {
  // Antibiotics
  'amoxicillin': { retail_price: 5000, cost_price: 3000, markup_percentage: 66.67 },
  'ampicillin': { retail_price: 6000, cost_price: 3500, markup_percentage: 71.43 },
  'ciprofloxacin': { retail_price: 8000, cost_price: 5000, markup_percentage: 60 },
  'erythromycin': { retail_price: 7000, cost_price: 4200, markup_percentage: 66.67 },
  'penicillin': { retail_price: 4500, cost_price: 2700, markup_percentage: 66.67 },
  'tetracycline': { retail_price: 5500, cost_price: 3300, markup_percentage: 66.67 },
  
  // Pain Relief & Fever
  'paracetamol': { retail_price: 2000, cost_price: 1200, markup_percentage: 66.67 },
  'acetaminophen': { retail_price: 2000, cost_price: 1200, markup_percentage: 66.67 },
  'aspirin': { retail_price: 2500, cost_price: 1500, markup_percentage: 66.67 },
  'ibuprofen': { retail_price: 3000, cost_price: 1800, markup_percentage: 66.67 },
  'diclofenac': { retail_price: 4000, cost_price: 2400, markup_percentage: 66.67 },
  
  // Vitamins & Supplements
  'vitamin c': { retail_price: 3500, cost_price: 2100, markup_percentage: 66.67 },
  'vitamin d': { retail_price: 4000, cost_price: 2400, markup_percentage: 66.67 },
  'vitamin b': { retail_price: 3800, cost_price: 2280, markup_percentage: 66.67 },
  'multivitamin': { retail_price: 5000, cost_price: 3000, markup_percentage: 66.67 },
  'iron': { retail_price: 4500, cost_price: 2700, markup_percentage: 66.67 },
  'calcium': { retail_price: 4200, cost_price: 2520, markup_percentage: 66.67 },
  'zinc': { retail_price: 3800, cost_price: 2280, markup_percentage: 66.67 },
  
  // Antacids & Digestive
  'antacid': { retail_price: 2500, cost_price: 1500, markup_percentage: 66.67 },
  'omeprazole': { retail_price: 6000, cost_price: 3600, markup_percentage: 66.67 },
  'ranitidine': { retail_price: 4500, cost_price: 2700, markup_percentage: 66.67 },
  
  // Antihistamines
  'cetirizine': { retail_price: 3500, cost_price: 2100, markup_percentage: 66.67 },
  'loratadine': { retail_price: 4000, cost_price: 2400, markup_percentage: 66.67 },
  'chlorpheniramine': { retail_price: 2800, cost_price: 1680, markup_percentage: 66.67 },
  
  // Cough & Cold
  'cough syrup': { retail_price: 4500, cost_price: 2700, markup_percentage: 66.67 },
  'cough drops': { retail_price: 1500, cost_price: 900, markup_percentage: 66.67 },
  'decongestant': { retail_price: 3200, cost_price: 1920, markup_percentage: 66.67 },
  
  // Topical treatments
  'ointment': { retail_price: 3000, cost_price: 1800, markup_percentage: 66.67 },
  'cream': { retail_price: 3500, cost_price: 2100, markup_percentage: 66.67 },
  'gel': { retail_price: 4000, cost_price: 2400, markup_percentage: 66.67 },
  
  // Default fallback
  'default': { retail_price: 5000, cost_price: 3000, markup_percentage: 66.67 }
};

/**
 * Determine appropriate pricing based on product name and category
 */
function determinePricing(product: Product): { retail_price: number; cost_price: number; markup_percentage: number } {
  const productName = (product.name || '').toLowerCase();
  
  // Try to match against known pharmaceutical patterns
  for (const [key, pricing] of Object.entries(PHARMACEUTICAL_PRICE_DEFAULTS)) {
    if (key !== 'default' && productName.includes(key)) {
      return pricing;
    }
  }
  
  // Check category-based pricing
  const category = (product.category || '').toLowerCase();
  if (category.includes('antibiotic')) {
    return PHARMACEUTICAL_PRICE_DEFAULTS['amoxicillin'];
  }
  if (category.includes('vitamin')) {
    return PHARMACEUTICAL_PRICE_DEFAULTS['vitamin c'];
  }
  if (category.includes('pain') || category.includes('analgesic')) {
    return PHARMACEUTICAL_PRICE_DEFAULTS['paracetamol'];
  }
  
  // Use default pricing
  return PHARMACEUTICAL_PRICE_DEFAULTS['default'];
}

/**
 * Fix a single product's missing or invalid price data
 */
function fixProductPricing(product: Product): Partial<Product> {
  const updates: Partial<Product> = {};
  
  // Fix retail_price
  if (!product.retail_price || isNaN(Number(product.retail_price)) || product.retail_price <= 0) {
    const pricing = determinePricing(product);
    updates.retail_price = pricing.retail_price;
    
    console.log(`🔧 Setting retail_price for "${product.name}": ${pricing.retail_price} TZS`);
  }
  
  // Fix cost_price
  if (!product.cost_price || isNaN(Number(product.cost_price)) || product.cost_price <= 0) {
    const pricing = determinePricing(product);
    updates.cost_price = pricing.cost_price;
    
    console.log(`🔧 Setting cost_price for "${product.name}": ${pricing.cost_price} TZS`);
  }
  
  // Fix markup_percentage
  if (!product.markup_percentage || isNaN(Number(product.markup_percentage))) {
    const pricing = determinePricing(product);
    updates.markup_percentage = pricing.markup_percentage;
    
    console.log(`🔧 Setting markup_percentage for "${product.name}": ${pricing.markup_percentage}%`);
  }
  
  // Ensure stock quantities are valid numbers
  if (!product.stock_quantity || isNaN(Number(product.stock_quantity))) {
    updates.stock_quantity = 50; // Default stock
    console.log(`🔧 Setting stock_quantity for "${product.name}": 50`);
  }
  
  if (!product.min_stock_level || isNaN(Number(product.min_stock_level))) {
    updates.min_stock_level = 10; // Default minimum stock
    console.log(`🔧 Setting min_stock_level for "${product.name}": 10`);
  }
  
  if (!product.reorder_quantity || isNaN(Number(product.reorder_quantity))) {
    updates.reorder_quantity = 100; // Default reorder quantity
    console.log(`🔧 Setting reorder_quantity for "${product.name}": 100`);
  }
  
  // Set insurance price if missing (usually 80% of retail price for NHIF)
  if (!product.insurance_price && updates.retail_price) {
    updates.insurance_price = Math.round(updates.retail_price * 0.8);
    console.log(`🔧 Setting insurance_price for "${product.name}": ${updates.insurance_price} TZS`);
  }
  
  return updates;
}

/**
 * Migration service for fixing product data
 */
export class ProductMigrationService {
  private static readonly COLLECTION_NAME = 'products';
  
  /**
   * Fix all products with invalid pricing data for a specific shop
   */
  static async fixShopProductPricing(shopId: string): Promise<void> {
    try {
      console.log('🚀 Starting product pricing migration for shop:', shopId);
      
      if (!shopId) {
        throw new Error('Shop ID is required for product migration');
      }

      // Test if we have basic read permissions first
      try {
        const testCollection = collection(db, this.COLLECTION_NAME);
        const testQuery = query(testCollection, where('shop_id', '==', shopId));
        
        // Try a small test query first to verify permissions
        console.log('🔍 Testing Firestore permissions...');
        await getDocs(testQuery);
        console.log('✅ Firestore permissions verified');
      } catch (permissionError: any) {
        if (permissionError.code === 'permission-denied') {
          throw new Error('🚨 CRITICAL: Firebase permission denied. Deploy security rules before running migration.');
        }
        throw permissionError;
      }
      
      // Query only products for this shop to reduce permission scope
      const productsCollection = collection(db, this.COLLECTION_NAME);
      const q = query(productsCollection, where('shop_id', '==', shopId));
      const querySnapshot = await getDocs(q);
      
      const productsToFix: { id: string; product: Product; updates: Partial<Product> }[] = [];
      let totalProducts = 0;
      let productsWithIssues = 0;
      
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        totalProducts++;
        
        const product = { id: doc.id, ...data } as Product;
        const updates = fixProductPricing(product);
        
        if (Object.keys(updates).length > 0) {
          productsWithIssues++;
          productsToFix.push({ id: doc.id, product, updates });
        }
      });
      
      console.log(`📊 Found ${totalProducts} products for shop ${shopId}`);
      console.log(`🔧 ${productsWithIssues} products need pricing fixes`);
      
      if (productsToFix.length === 0) {
        console.log('✅ No products need pricing fixes');
        return;
      }
      
      // Batch update products in groups of 500 (Firestore limit)
      const batchSize = 500;
      let updatedCount = 0;
      
      for (let i = 0; i < productsToFix.length; i += batchSize) {
        const batch = writeBatch(db);
        const batchProducts = productsToFix.slice(i, i + batchSize);
        
        console.log(`📦 Processing batch ${Math.floor(i / batchSize) + 1} (${batchProducts.length} products)`);
        
        batchProducts.forEach(({ id, updates }) => {
          const productRef = doc(db, this.COLLECTION_NAME, id);
          batch.update(productRef, {
            ...updates,
            updated_at: new Date().toISOString()
          });
        });
        
        await batch.commit();
        updatedCount += batchProducts.length;
        
        console.log(`✅ Updated ${updatedCount} of ${productsToFix.length} products`);
      }
      
      console.log('🎉 Product pricing migration completed successfully!');
      console.log(`📈 Summary: Fixed ${updatedCount} products out of ${totalProducts} total products`);
      
    } catch (error: any) {
      console.error('❌ Product pricing migration failed:', error);
      
      // Add specific handling for permission errors
      if (error.code === 'permission-denied') {
        throw new Error('🚨 CRITICAL: Firebase permission denied. Deploy security rules to run product migration.');
      }
      
      throw handleFirebaseError(error);
    }
  }
  
  /**
   * Fix all products in the database (admin function - use with caution)
   */
  static async fixAllProductPricing(): Promise<void> {
    try {
      console.log('🚀 Starting global product pricing migration');
      
      const productsCollection = collection(db, this.COLLECTION_NAME);
      const querySnapshot = await getDocs(productsCollection);
      
      const productsToFix: { id: string; product: Product; updates: Partial<Product> }[] = [];
      let totalProducts = 0;
      let productsWithIssues = 0;
      
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        totalProducts++;
        
        const product = { id: doc.id, ...data } as Product;
        const updates = fixProductPricing(product);
        
        if (Object.keys(updates).length > 0) {
          productsWithIssues++;
          productsToFix.push({ id: doc.id, product, updates });
        }
      });
      
      console.log(`📊 Found ${totalProducts} total products in database`);
      console.log(`🔧 ${productsWithIssues} products need pricing fixes`);
      
      if (productsToFix.length === 0) {
        console.log('✅ No products need pricing fixes');
        return;
      }
      
      // Batch update products in groups of 500 (Firestore limit)
      const batchSize = 500;
      let updatedCount = 0;
      
      for (let i = 0; i < productsToFix.length; i += batchSize) {
        const batch = writeBatch(db);
        const batchProducts = productsToFix.slice(i, i + batchSize);
        
        console.log(`📦 Processing batch ${Math.floor(i / batchSize) + 1} (${batchProducts.length} products)`);
        
        batchProducts.forEach(({ id, updates }) => {
          const productRef = doc(db, this.COLLECTION_NAME, id);
          batch.update(productRef, {
            ...updates,
            updated_at: new Date().toISOString()
          });
        });
        
        await batch.commit();
        updatedCount += batchProducts.length;
        
        console.log(`✅ Updated ${updatedCount} of ${productsToFix.length} products`);
      }
      
      console.log('🎉 Global product pricing migration completed successfully!');
      console.log(`📈 Summary: Fixed ${updatedCount} products out of ${totalProducts} total products`);
      
    } catch (error: any) {
      console.error('❌ Global product pricing migration failed:', error);
      throw handleFirebaseError(error);
    }
  }
  
  /**
   * Get a preview of products that would be fixed (without making changes)
   */
  static async previewProductFixes(shopId: string): Promise<{ id: string; name: string; issues: string[]; updates: Partial<Product> }[]> {
    try {
      console.log('🔍 Previewing product fixes for shop:', shopId);
      
      if (!shopId) {
        throw new Error('Shop ID is required for product preview');
      }

      const productsCollection = collection(db, this.COLLECTION_NAME);
      
      // Query only the products for this shop to reduce permission scope
      const q = query(
        productsCollection,
        where('shop_id', '==', shopId)
      );
      
      const querySnapshot = await getDocs(q);
      
      const preview: { id: string; name: string; issues: string[]; updates: Partial<Product> }[] = [];
      
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        const product = { id: doc.id, ...data } as Product;
        const updates = fixProductPricing(product);
        
        if (Object.keys(updates).length > 0) {
          const issues: string[] = [];
          
          if (updates.retail_price) issues.push('Invalid retail_price');
          if (updates.cost_price) issues.push('Invalid cost_price');
          if (updates.markup_percentage) issues.push('Invalid markup_percentage');
          if (updates.stock_quantity) issues.push('Invalid stock_quantity');
          if (updates.min_stock_level) issues.push('Invalid min_stock_level');
          if (updates.reorder_quantity) issues.push('Invalid reorder_quantity');
          if (updates.insurance_price) issues.push('Missing insurance_price');
          
          preview.push({
            id: doc.id,
            name: product.name || 'Unknown Product',
            issues,
            updates
          });
        }
      });
      
      console.log(`🔍 Preview: ${preview.length} products need fixes`);
      return preview;
      
    } catch (error: any) {
      console.error('❌ Preview failed:', error);
      
      // Add specific handling for permission errors
      if (error.code === 'permission-denied') {
        throw new Error('🚨 CRITICAL: Firebase permission denied. Deploy security rules to access product data.');
      }
      
      throw handleFirebaseError(error);
    }
  }
}