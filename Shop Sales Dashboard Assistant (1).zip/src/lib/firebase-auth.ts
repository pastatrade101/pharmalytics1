import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut as firebaseSignOut,
  onAuthStateChanged,
  sendPasswordResetEmail,
  User
} from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from './firebase-config';

// Enhanced error handling for Firebase auth errors
const enhanceAuthError = (error: any) => {
  // Add more context to common auth errors
  const enhancedError = { ...error };
  
  switch (error.code) {
    case 'auth/invalid-credential':
      enhancedError.userMessage = 'Invalid email or password. Please check your credentials and try again.';
      enhancedError.suggestions = [
        'Double-check your email address',
        'Verify your password is correct',
        'Try resetting your password if needed'
      ];
      break;
      
    case 'auth/user-not-found':
      enhancedError.userMessage = 'No account found with this email address.';
      enhancedError.suggestions = [
        'Check your email address for typos',
        'Create a new account if you haven\'t registered',
        'Contact your administrator if you should have access'
      ];
      break;
      
    case 'auth/wrong-password':
      enhancedError.userMessage = 'Incorrect password.';
      enhancedError.suggestions = [
        'Check that Caps Lock is not enabled',
        'Try typing your password again',
        'Reset your password if forgotten'
      ];
      break;
      
    case 'auth/too-many-requests':
      enhancedError.userMessage = 'Too many failed attempts. Account temporarily locked.';
      enhancedError.suggestions = [
        'Wait 15-30 minutes before trying again',
        'Reset your password to unlock immediately',
        'Contact support if the issue persists'
      ];
      break;
      
    case 'auth/network-request-failed':
      enhancedError.userMessage = 'Network connection failed.';
      enhancedError.suggestions = [
        'Check your internet connection',
        'Try refreshing the page',
        'Verify firewall settings'
      ];
      break;
      
    default:
      enhancedError.userMessage = error.message || 'Authentication failed.';
      enhancedError.suggestions = [
        'Try again in a moment',
        'Check your internet connection',
        'Contact support if the problem persists'
      ];
  }
  
  return enhancedError;
};

export const signIn = async (email: string, password: string) => {
  try {
    console.log('🔑 Attempting sign in with:', email);
    
    // Validate inputs
    if (!email || !password) {
      throw {
        code: 'auth/missing-credentials',
        message: 'Email and password are required',
        userMessage: 'Please enter both email and password.'
      };
    }
    
    if (!email.includes('@')) {
      throw {
        code: 'auth/invalid-email',
        message: 'Invalid email format',
        userMessage: 'Please enter a valid email address.'
      };
    }
    
    const result = await signInWithEmailAndPassword(auth, email, password);
    console.log('✅ Sign in successful for user:', result.user.uid);
    
    return result;
  } catch (error: any) {
    console.error('❌ Sign in failed:', error);
    
    // Enhance the error with user-friendly information
    const enhancedError = enhanceAuthError(error);
    
    // Log the enhanced error for debugging
    console.error('Enhanced auth error:', {
      code: enhancedError.code,
      message: enhancedError.userMessage,
      originalMessage: error.message
    });
    
    throw enhancedError;
  }
};

export const signUp = async (email: string, password: string, fullName: string, role: string) => {
  try {
    console.log('📝 Attempting sign up with:', email, role);
    
    // Validate inputs
    if (!email || !password || !fullName) {
      throw {
        code: 'auth/missing-information',
        message: 'Email, password, and full name are required',
        userMessage: 'Please fill in all required fields.'
      };
    }
    
    if (!email.includes('@')) {
      throw {
        code: 'auth/invalid-email',
        message: 'Invalid email format',
        userMessage: 'Please enter a valid email address.'
      };
    }
    
    if (password.length < 6) {
      throw {
        code: 'auth/weak-password',
        message: 'Password should be at least 6 characters',
        userMessage: 'Password must be at least 6 characters long.'
      };
    }
    
    const result = await createUserWithEmailAndPassword(auth, email, password);
    console.log('✅ Sign up successful for user:', result.user.uid);
    
    // Create user profile
    const userProfile = {
      email: email,
      full_name: fullName,
      role: role,
      shop_id: null,
      created_at: serverTimestamp(),
      updated_at: serverTimestamp()
    };

    const userRef = doc(db, 'profiles', result.user.uid);
    await setDoc(userRef, userProfile);
    console.log('✅ User profile created successfully');
    
    return result;
  } catch (error: any) {
    console.error('❌ Sign up failed:', error);
    
    // Enhance the error with user-friendly information
    const enhancedError = enhanceAuthError(error);
    
    // Add signup-specific error messages
    if (error.code === 'auth/email-already-in-use') {
      enhancedError.userMessage = 'An account with this email already exists.';
      enhancedError.suggestions = [
        'Try signing in instead',
        'Use a different email address',
        'Reset your password if you\'ve forgotten it'
      ];
    }
    
    console.error('Enhanced signup error:', {
      code: enhancedError.code,
      message: enhancedError.userMessage,
      originalMessage: error.message
    });
    
    throw enhancedError;
  }
};

/**
 * Sign up function specifically for super admin - only creates auth account, not profile
 * Used by createSuperAdminAccount to handle profile creation separately
 */
export const signUpAuthOnly = async (email: string, password: string) => {
  try {
    console.log('🛡️ Creating auth account only for super admin:', email);
    
    // Validate inputs
    if (!email || !password) {
      throw {
        code: 'auth/missing-credentials',
        message: 'Email and password are required',
        userMessage: 'Email and password are required for super admin account.'
      };
    }
    
    const result = await createUserWithEmailAndPassword(auth, email, password);
    console.log('✅ Auth account created successfully for user:', result.user.uid);
    
    // Return just the auth result - profile creation will be handled separately
    return {
      uid: result.user.uid,
      email: result.user.email,
      user: result.user
    };
  } catch (error: any) {
    console.error('❌ Super admin auth account creation failed:', error);
    
    const enhancedError = enhanceAuthError(error);
    enhancedError.context = 'super_admin_creation';
    
    throw enhancedError;
  }
};

export const resetPassword = async (email: string) => {
  try {
    console.log('🔐 Sending password reset email to:', email);
    
    if (!email || !email.includes('@')) {
      throw {
        code: 'auth/invalid-email',
        message: 'Invalid email format',
        userMessage: 'Please enter a valid email address.'
      };
    }
    
    await sendPasswordResetEmail(auth, email);
    console.log('✅ Password reset email sent successfully');
    
    return {
      success: true,
      message: 'Password reset email sent successfully'
    };
  } catch (error: any) {
    console.error('❌ Password reset failed:', error);
    
    const enhancedError = enhanceAuthError(error);
    
    // Special handling for password reset errors
    if (error.code === 'auth/user-not-found') {
      enhancedError.userMessage = 'If an account exists with this email, you will receive a password reset link.';
      enhancedError.suggestions = [
        'Check your email inbox and spam folder',
        'Verify you entered the correct email address',
        'Contact support if you don\'t receive the email'
      ];
    }
    
    throw enhancedError;
  }
};

export const signOut = async () => {
  try {
    console.log('🚪 Signing out user...');
    await firebaseSignOut(auth);
    console.log('✅ Sign out successful');
  } catch (error: any) {
    console.error('❌ Sign out failed:', error);
    
    // Sign out errors are usually not critical, but enhance them anyway
    const enhancedError = enhanceAuthError(error);
    enhancedError.userMessage = 'Failed to sign out properly. You may need to refresh the page.';
    
    throw enhancedError;
  }
};

export const getCurrentUser = async () => {
  return auth.currentUser;
};

export const onAuthStateChange = (callback: (user: User | null) => void) => {
  return onAuthStateChanged(auth, (user) => {
    console.log('🔄 Auth state changed:', user?.uid || 'null');
    callback(user);
  });
};