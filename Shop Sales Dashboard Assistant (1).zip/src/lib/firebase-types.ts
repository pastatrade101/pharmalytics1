// Firebase type definitions for the Pharmacy Management System

export interface Shop {
  id: string;
  name: string;
  owner_id: string;
  description: string;
  category: 'pharmacy';
  address: string;
  phone: string;
  status: 'pending' | 'active' | 'inactive'; // Shop activation status
  created_at: string;
  updated_at: string;
  settings: {
    timezone: string;
    currency: string;
    report_time: string;
    tax_rate?: number;
    receipt_footer?: string;
    low_stock_threshold?: number;
  };
}

export interface UserProfile {
  uid: string;
  id: string;
  email: string;
  full_name: string;
  role: 'owner' | 'admin' | 'product_manager' | 'salesman' | 'super_admin';
  shop_id?: string;
  created_at: string;
  updated_at: string;
  last_login?: string;
  phone?: string;
  
  // Professional credentials for licensed roles
  license_number?: string;
  certification_number?: string;
  experience_years?: number;
  
  // Populated shop information (when shop_id is present)
  shop?: Shop;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  category: string;
  manufacturer: string;
  barcode?: string;
  sku: string;
  retail_price: number;
  cost_price: number;
  wholesale_price?: number;
  insurance_price?: number;
  markup_percentage?: number;
  stock_quantity: number;
  min_stock_level: number;
  max_stock_level?: number;
  reorder_quantity: number;
  reorder_level: number;
  shop_id: string;
  created_at: string;
  updated_at: string;
  
  // Pharmacy-specific fields
  dosage_form?: string;
  strength?: string;
  active_ingredient?: string;
  requires_prescription?: boolean;
  storage_requirements?: string;
  unit_of_measure?: string;
  
  // Batch tracking
  batch_number?: string;
  expiry_date?: string;
  supplier?: string;
  
  // Additional metadata
  status: 'active' | 'inactive' | 'deleted';
  is_active?: boolean;
  tags?: string[];
}

export interface Sale {
  id: string;
  shop_id: string;
  user_id: string;
  customer_name?: string;
  customer_phone?: string;
  total_amount: number;
  tax_amount: number;
  discount_amount: number;
  payment_method: 'cash' | 'card' | 'mobile-money' | 'insurance' | 'credit';
  payment_status: 'completed' | 'pending' | 'failed' | 'refunded';
  created_at: string;
  updated_at: string;
  
  // Insurance details (if applicable)
  insurance_provider?: string;
  insurance_number?: string;
  insurance_coverage_amount?: number;
  
  // Prescription details (if applicable)
  prescription_number?: string;
  prescriber_name?: string;
  
  // Line items
  items: SaleItem[];
  
  // Receipt details
  receipt_number: string;
  notes?: string;
}

export interface SaleItem {
  id: string;
  sale_id: string;
  product_id: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  discount_amount?: number;
  
  // Product snapshot at time of sale
  product_name: string;
  product_sku: string;
  batch_number?: string;
  expiry_date?: string;
}

export interface StockMovement {
  id: string;
  shop_id: string;
  product_id: string;
  user_id: string;
  type: 'purchase' | 'sale' | 'adjustment' | 'transfer' | 'return' | 'expiry' | 'damage';
  quantity_change: number;
  previous_quantity: number;
  new_quantity: number;
  reference_id?: string; // Links to sale_id, purchase_id, etc.
  notes?: string;
  created_at: string;
}

export interface Supplier {
  id: string;
  name: string;
  contact_person: string;
  email: string;
  phone: string;
  address: string;
  shop_id: string;
  created_at: string;
  updated_at: string;
  is_active: boolean;
}

export interface Customer {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  address?: string;
  shop_id: string;
  created_at: string;
  updated_at: string;
  
  // Customer account details
  credit_limit?: number;
  outstanding_balance?: number;
  loyalty_points?: number;
  
  // Insurance information
  insurance_provider?: string;
  insurance_number?: string;
  insurance_expiry?: string;
}

export interface Prescription {
  id: string;
  prescription_number: string;
  patient_name: string;
  patient_phone?: string;
  prescriber_name: string;
  prescriber_license: string;
  issue_date: string;
  shop_id: string;
  user_id: string;
  status: 'pending' | 'in-progress' | 'completed' | 'cancelled';
  created_at: string;
  updated_at: string;
  
  // Prescription items
  items: PrescriptionItem[];
  
  // Processing details
  dispensed_by?: string;
  dispensed_at?: string;
  notes?: string;
}

export interface PrescriptionItem {
  id: string;
  prescription_id: string;
  product_id: string;
  product_name: string;
  quantity_prescribed: number;
  quantity_dispensed: number;
  dosage_instructions: string;
  duration_days?: number;
}

export interface Notification {
  id: string;
  shop_id?: string;
  user_id?: string;
  type: 'low-stock' | 'expiry-warning' | 'expiry-critical' | 'sales-target' | 'system-maintenance' | 'user-activity';
  title: string;
  message: string;
  is_read: boolean;
  created_at: string;
  
  // Notification metadata
  related_id?: string; // Product ID, Sale ID, etc.
  action_url?: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
}

export interface AuditLog {
  id: string;
  shop_id?: string;
  user_id: string;
  action: string;
  entity_type: 'product' | 'sale' | 'user' | 'shop' | 'prescription' | 'customer';
  entity_id: string;
  changes?: Record<string, any>;
  ip_address?: string;
  user_agent?: string;
  created_at: string;
}

// API Response types
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T = any> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

// Filter and search types
export interface ProductFilter {
  category?: string;
  manufacturer?: string;
  is_active?: boolean;
  low_stock_only?: boolean;
  expiring_soon?: boolean;
  search?: string;
}

export interface SaleFilter {
  start_date?: string;
  end_date?: string;
  payment_method?: string;
  payment_status?: string;
  user_id?: string;
  search?: string;
}

// Dashboard analytics types
export interface SalesAnalytics {
  total_sales: number;
  total_revenue: number;
  total_transactions: number;
  average_transaction_value: number;
  top_products: Array<{
    product_id: string;
    product_name: string;
    quantity_sold: number;
    revenue: number;
  }>;
  sales_by_day: Array<{
    date: string;
    sales_count: number;
    revenue: number;
  }>;
  payment_method_breakdown: Array<{
    method: string;
    count: number;
    total_amount: number;
  }>;
}

export interface InventoryAnalytics {
  total_products: number;
  total_value: number;
  low_stock_count: number;
  expired_products_count: number;
  expiring_soon_count: number;
  top_categories: Array<{
    category: string;
    product_count: number;
    total_value: number;
  }>;
  stock_movements: Array<{
    date: string;
    movements: number;
    type: string;
  }>;
}

// Error types
export interface AppError {
  type: 'validation' | 'permission' | 'network' | 'server' | 'client';
  message: string;
  description?: string;
  context?: string;
  timestamp: string;
  isPermissionError?: boolean;
  code?: string;
}

// Firestore collection names (for consistency)
export const COLLECTIONS = {
  SHOPS: 'shops',
  USERS: 'users',
  PRODUCTS: 'products',
  SALES: 'sales',
  SALE_ITEMS: 'sale_items',
  STOCK_MOVEMENTS: 'stock_movements',
  SUPPLIERS: 'suppliers',
  CUSTOMERS: 'customers',
  PRESCRIPTIONS: 'prescriptions',
  PRESCRIPTION_ITEMS: 'prescription_items',
  NOTIFICATIONS: 'notifications',
  AUDIT_LOGS: 'audit_logs'
} as const;