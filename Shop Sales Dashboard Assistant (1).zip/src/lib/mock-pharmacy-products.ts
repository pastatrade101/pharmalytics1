import { Product } from './firebase';

export const MOCK_PHARMACY_PRODUCTS: Omit<Product, 'id' | 'created_at' | 'updated_at' | 'pharmacy_id'>[] = [
  // Prescription Medicines
  {
    name: 'Amoxicillin 500mg Capsules',
    generic_name: 'Amoxicillin',
    brand_name: 'Amoxil',
    description: 'Broad-spectrum antibiotic for bacterial infections',
    category: 'Prescription Medicines',
    strength: '500mg',
    manufacturer: 'GSK',
    sku: 'AMX500',
    cost_price: 2500,
    retail_price: 3500,
    stock_quantity: 45,
    min_stock_level: 20,
    status: 'active'
  },
  {
    name: 'Metformin 500mg Tablets',
    generic_name: 'Metformin',
    brand_name: 'Glucophage',
    description: 'Diabetes medication for blood sugar control',
    category: 'Prescription Medicines',
    strength: '500mg',
    manufacturer: 'Merck',
    sku: 'MET500',
    cost_price: 1800,
    retail_price: 2800,
    stock_quantity: 120,
    min_stock_level: 30,
    status: 'active'
  },
  {
    name: 'Lisinopril 10mg Tablets',
    generic_name: 'Lisinopril',
    brand_name: 'Prinivil',
    description: 'ACE inhibitor for high blood pressure',
    category: 'Prescription Medicines',
    strength: '10mg',
    manufacturer: 'Pfizer',
    sku: 'LIS10',
    cost_price: 3200,
    retail_price: 4500,
    stock_quantity: 8,
    min_stock_level: 15,
    status: 'active'
  },
  {
    name: 'Omeprazole 20mg Capsules',
    generic_name: 'Omeprazole',
    brand_name: 'Prilosec',
    description: 'Proton pump inhibitor for acid reflux',
    category: 'Prescription Medicines',
    strength: '20mg',
    manufacturer: 'AstraZeneca',
    sku: 'OME20',
    cost_price: 2800,
    retail_price: 4200,
    stock_quantity: 65,
    min_stock_level: 25,
    status: 'active'
  },

  // Pain Relief
  {
    name: 'Paracetamol 500mg Tablets',
    generic_name: 'Paracetamol',
    brand_name: 'Panadol',
    description: 'Effective pain relief and fever reducer',
    category: 'Pain Relief',
    strength: '500mg',
    manufacturer: 'GSK',
    sku: 'PAR500',
    cost_price: 800,
    retail_price: 1500,
    stock_quantity: 200,
    min_stock_level: 50,
    status: 'active'
  },
  {
    name: 'Ibuprofen 400mg Tablets',
    generic_name: 'Ibuprofen',
    brand_name: 'Advil',
    description: 'Anti-inflammatory pain reliever',
    category: 'Pain Relief',
    strength: '400mg',
    manufacturer: 'Johnson & Johnson',
    sku: 'IBU400',
    cost_price: 1200,
    retail_price: 2000,
    stock_quantity: 150,
    min_stock_level: 40,
    status: 'active'
  },
  {
    name: 'Aspirin 75mg Tablets',
    generic_name: 'Aspirin',
    brand_name: 'Disprin',
    description: 'Low-dose aspirin for cardiovascular protection',
    category: 'Pain Relief',
    strength: '75mg',
    manufacturer: 'Bayer',
    sku: 'ASP75',
    cost_price: 600,
    retail_price: 1200,
    stock_quantity: 180,
    min_stock_level: 30,
    status: 'active'
  },

  // Antibiotics
  {
    name: 'Azithromycin 250mg Tablets',
    generic_name: 'Azithromycin',
    brand_name: 'Zithromax',
    description: 'Macrolide antibiotic for respiratory infections',
    category: 'Antibiotics',
    strength: '250mg',
    manufacturer: 'Pfizer',
    sku: 'AZI250',
    cost_price: 4500,
    retail_price: 6800,
    stock_quantity: 35,
    min_stock_level: 20,
    status: 'active'
  },
  {
    name: 'Ciprofloxacin 500mg Tablets',
    generic_name: 'Ciprofloxacin',
    brand_name: 'Cipro',
    description: 'Fluoroquinolone antibiotic for bacterial infections',
    category: 'Antibiotics',
    strength: '500mg',
    manufacturer: 'Bayer',
    sku: 'CIP500',
    cost_price: 3800,
    retail_price: 5500,
    stock_quantity: 12,
    min_stock_level: 15,
    status: 'active'
  },
  {
    name: 'Doxycycline 100mg Capsules',
    generic_name: 'Doxycycline',
    brand_name: 'Vibramycin',
    description: 'Tetracycline antibiotic for various infections',
    category: 'Antibiotics',
    strength: '100mg',
    manufacturer: 'Pfizer',
    sku: 'DOX100',
    cost_price: 2200,
    retail_price: 3500,
    stock_quantity: 28,
    min_stock_level: 20,
    status: 'active'
  },

  // Over-the-Counter
  {
    name: 'Cetirizine 10mg Tablets',
    generic_name: 'Cetirizine',
    brand_name: 'Zyrtec',
    description: 'Non-drowsy antihistamine for allergies',
    category: 'Over-the-Counter',
    strength: '10mg',
    manufacturer: 'Johnson & Johnson',
    sku: 'CET10',
    cost_price: 1500,
    retail_price: 2500,
    stock_quantity: 85,
    min_stock_level: 25,
    status: 'active'
  },
  {
    name: 'Loperamide 2mg Capsules',
    generic_name: 'Loperamide',
    brand_name: 'Imodium',
    description: 'Anti-diarrheal medication',
    category: 'Over-the-Counter',
    strength: '2mg',
    manufacturer: 'Johnson & Johnson',
    sku: 'LOP2',
    cost_price: 2800,
    retail_price: 4200,
    stock_quantity: 42,
    min_stock_level: 20,
    status: 'active'
  },

  // Vitamins & Supplements
  {
    name: 'Vitamin D3 1000IU Tablets',
    generic_name: 'Cholecalciferol',
    brand_name: 'Nature Made',
    description: 'Essential vitamin for bone health',
    category: 'Vitamins & Supplements',
    strength: '1000IU',
    manufacturer: 'Nature Made',
    sku: 'VD1000',
    cost_price: 2200,
    retail_price: 3800,
    stock_quantity: 95,
    min_stock_level: 30,
    status: 'active'
  },
  {
    name: 'Multivitamin Complex Tablets',
    generic_name: 'Multivitamin',
    brand_name: 'Centrum',
    description: 'Complete daily multivitamin supplement',
    category: 'Vitamins & Supplements',
    strength: 'Adult Formula',
    manufacturer: 'Pfizer',
    sku: 'MUL001',
    cost_price: 3500,
    retail_price: 5500,
    stock_quantity: 78,
    min_stock_level: 25,
    status: 'active'
  },
  {
    name: 'Omega-3 Fish Oil 1000mg',
    generic_name: 'Omega-3 Fatty Acids',
    brand_name: 'Nordic Naturals',
    description: 'Heart and brain health supplement',
    category: 'Vitamins & Supplements',
    strength: '1000mg',
    manufacturer: 'Nordic Naturals',
    sku: 'OME1000',
    cost_price: 4200,
    retail_price: 6500,
    stock_quantity: 55,
    min_stock_level: 20,
    status: 'active'
  },

  // Cold & Flu
  {
    name: 'Loratadine 10mg Tablets',
    generic_name: 'Loratadine',
    brand_name: 'Claritin',
    description: '24-hour allergy relief',
    category: 'Cold & Flu',
    strength: '10mg',
    manufacturer: 'Bayer',
    sku: 'LOR10',
    cost_price: 1800,
    retail_price: 3000,
    stock_quantity: 90,
    min_stock_level: 30,
    status: 'active'
  },
  {
    name: 'Pseudoephedrine 60mg Tablets',
    generic_name: 'Pseudoephedrine',
    brand_name: 'Sudafed',
    description: 'Nasal decongestant',
    category: 'Cold & Flu',
    strength: '60mg',
    manufacturer: 'Johnson & Johnson',
    sku: 'PSE60',
    cost_price: 2500,
    retail_price: 4000,
    stock_quantity: 3,
    min_stock_level: 15,
    status: 'active'
  },

  // Digestive Health
  {
    name: 'Simethicone 40mg Tablets',
    generic_name: 'Simethicone',
    brand_name: 'Gas-X',
    description: 'Anti-gas medication for bloating relief',
    category: 'Digestive Health',
    strength: '40mg',
    manufacturer: 'Novartis',
    sku: 'SIM40',
    cost_price: 1500,
    retail_price: 2800,
    stock_quantity: 65,
    min_stock_level: 25,
    status: 'active'
  },
  {
    name: 'Lactase Enzyme Tablets',
    generic_name: 'Lactase',
    brand_name: 'Lactaid',
    description: 'Lactose intolerance relief',
    category: 'Digestive Health',
    strength: '9000 FCC',
    manufacturer: 'Johnson & Johnson',
    sku: 'LAC9000',
    cost_price: 3200,
    retail_price: 5000,
    stock_quantity: 38,
    min_stock_level: 20,
    status: 'active'
  },

  // Dermatological
  {
    name: 'Hydrocortisone 1% Cream',
    generic_name: 'Hydrocortisone',
    brand_name: 'Cortaid',
    description: 'Topical anti-inflammatory for skin conditions',
    category: 'Dermatological',
    strength: '1%',
    manufacturer: 'Johnson & Johnson',
    sku: 'HYD1',
    cost_price: 2800,
    retail_price: 4500,
    stock_quantity: 45,
    min_stock_level: 15,
    status: 'active'
  },
  {
    name: 'Calamine Lotion',
    generic_name: 'Calamine',
    brand_name: 'Caladryl',
    description: 'Soothing lotion for insect bites and rashes',
    category: 'Dermatological',
    strength: '8%',
    manufacturer: 'Johnson & Johnson',
    sku: 'CAL8',
    cost_price: 1200,
    retail_price: 2200,
    stock_quantity: 72,
    min_stock_level: 20,
    status: 'active'
  },

  // Baby & Child Care
  {
    name: 'Children\'s Paracetamol Syrup',
    generic_name: 'Paracetamol',
    brand_name: 'Calpol',
    description: 'Fever and pain relief for children',
    category: 'Baby & Child Care',
    strength: '120mg/5ml',
    manufacturer: 'GSK',
    sku: 'CPAR120',
    cost_price: 1800,
    retail_price: 3200,
    stock_quantity: 85,
    min_stock_level: 25,
    status: 'active'
  },
  {
    name: 'Baby Diaper Rash Cream',
    generic_name: 'Zinc Oxide',
    brand_name: 'Desitin',
    description: 'Protective barrier cream for diaper rash',
    category: 'Baby & Child Care',
    strength: '40%',
    manufacturer: 'Johnson & Johnson',
    sku: 'ZIN40',
    cost_price: 2500,
    retail_price: 4000,
    stock_quantity: 92,
    min_stock_level: 20,
    status: 'active'
  },

  // Medical Devices
  {
    name: 'Digital Thermometer',
    generic_name: 'Thermometer',
    brand_name: 'Omron',
    description: 'Fast and accurate digital thermometer',
    category: 'Medical Devices',
    strength: 'Digital',
    manufacturer: 'Omron',
    sku: 'THERM001',
    cost_price: 15000,
    retail_price: 25000,
    stock_quantity: 18,
    min_stock_level: 10,
    status: 'active'
  },
  {
    name: 'Blood Pressure Monitor',
    generic_name: 'BP Monitor',
    brand_name: 'Omron',
    description: 'Automatic upper arm blood pressure monitor',
    category: 'Medical Devices',
    strength: 'Automatic',
    manufacturer: 'Omron',
    sku: 'BP001',
    cost_price: 45000,
    retail_price: 75000,
    stock_quantity: 5,
    min_stock_level: 8,
    status: 'active'
  },

  // First Aid
  {
    name: 'Adhesive Bandages Pack',
    generic_name: 'Bandages',
    brand_name: 'Band-Aid',
    description: 'Sterile adhesive bandages assorted sizes',
    category: 'First Aid',
    strength: 'Assorted',
    manufacturer: 'Johnson & Johnson',
    sku: 'BAND001',
    cost_price: 800,
    retail_price: 1500,
    stock_quantity: 125,
    min_stock_level: 30,
    status: 'active'
  },
  {
    name: 'Antiseptic Solution 500ml',
    generic_name: 'Povidone Iodine',
    brand_name: 'Betadine',
    description: 'Antiseptic solution for wound cleaning',
    category: 'First Aid',
    strength: '10%',
    manufacturer: 'Mundipharma',
    sku: 'PVD500',
    cost_price: 2200,
    retail_price: 3800,
    stock_quantity: 48,
    min_stock_level: 20,
    status: 'active'
  },

  // Personal Care
  {
    name: 'Antibacterial Hand Sanitizer',
    generic_name: 'Ethyl Alcohol',
    brand_name: 'Purell',
    description: '70% alcohol hand sanitizer',
    category: 'Personal Care',
    strength: '70%',
    manufacturer: 'GOJO',
    sku: 'ALCO70',
    cost_price: 1500,
    retail_price: 2800,
    stock_quantity: 98,
    min_stock_level: 25,
    status: 'active'
  },
  {
    name: 'Moisturizing Lotion 500ml',
    generic_name: 'Body Lotion',
    brand_name: 'Cetaphil',
    description: 'Daily facial moisturizer for sensitive skin',
    category: 'Personal Care',
    strength: '500ml',
    manufacturer: 'Galderma',
    sku: 'MOIST500',
    cost_price: 3200,
    retail_price: 5500,
    stock_quantity: 62,
    min_stock_level: 20,
    status: 'active'
  },

  // Additional high-value items to reach the total shown in the image
  {
    name: 'Insulin Glargine 100 units/ml',
    generic_name: 'Insulin Glargine',
    brand_name: 'Lantus',
    description: 'Long-acting insulin for diabetes management',
    category: 'Prescription Medicines',
    strength: '100 units/ml',
    manufacturer: 'Sanofi',
    sku: 'INS100',
    cost_price: 45000,
    retail_price: 75000,
    stock_quantity: 0,
    min_stock_level: 5,
    status: 'active'
  },
  {
    name: 'Rosuvastatin 20mg Tablets',
    generic_name: 'Rosuvastatin',
    brand_name: 'Crestor',
    description: 'HMG-CoA reductase inhibitor for cholesterol',
    category: 'Prescription Medicines',
    strength: '20mg',
    manufacturer: 'AstraZeneca',
    sku: 'ROS20',
    cost_price: 5200,
    retail_price: 8500,
    stock_quantity: 2,
    min_stock_level: 15,
    status: 'active'
  },
  {
    name: 'Amlodipine 5mg Tablets',
    generic_name: 'Amlodipine',
    brand_name: 'Norvasc',
    description: 'Calcium channel blocker for hypertension',
    category: 'Prescription Medicines',
    strength: '5mg',
    manufacturer: 'Pfizer',
    sku: 'AML5',
    cost_price: 2800,
    retail_price: 4500,
    stock_quantity: 0,
    min_stock_level: 20,
    status: 'active'
  },
  {
    name: 'Levothyroxine 50mcg Tablets',
    generic_name: 'Levothyroxine',
    brand_name: 'Synthroid',
    description: 'Thyroid hormone replacement therapy',
    category: 'Prescription Medicines',
    strength: '50mcg',
    manufacturer: 'Abbott',
    sku: 'LEV50',
    cost_price: 3500,
    retail_price: 5800,
    stock_quantity: 0,
    min_stock_level: 25,
    status: 'active'
  },
  {
    name: 'Atorvastatin 40mg Tablets',
    generic_name: 'Atorvastatin',
    brand_name: 'Lipitor',
    description: 'Statin for cholesterol management',
    category: 'Prescription Medicines',
    strength: '40mg',
    manufacturer: 'Pfizer',
    sku: 'ATO40',
    cost_price: 4200,
    retail_price: 7000,
    stock_quantity: 0,
    min_stock_level: 18,
    status: 'active'
  }
];

export const getMockPharmacyStats = () => {
  const totalProducts = MOCK_PHARMACY_PRODUCTS.length;
  const lowStockItems = MOCK_PHARMACY_PRODUCTS.filter(p => p.stock_quantity <= p.min_stock_level);
  const outOfStockItems = MOCK_PHARMACY_PRODUCTS.filter(p => p.stock_quantity === 0);
  const totalValue = MOCK_PHARMACY_PRODUCTS.reduce((sum, p) => sum + (p.stock_quantity * p.cost_price), 0);
  
  // Calculate expiring soon (mock 12 items)
  const expiringSoonCount = 12;
  
  return {
    totalProducts,
    lowStockCount: lowStockItems.length,
    outOfStockCount: outOfStockItems.length,
    expiringSoonCount,
    totalValue,
    lowStockItems,
    outOfStockItems
  };
};