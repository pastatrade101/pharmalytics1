// Barcode and SKU utilities for pharmacy products

export interface ProductBarcode {
  code: string;
  type: 'UPC' | 'EAN' | 'CODE128' | 'CODE39' | 'QR' | 'UNKNOWN';
  isValid: boolean;
}

export interface SkuGenerationOptions {
  productName: string;
  category: string;
  manufacturer?: string;
  barcode?: string;
  timestamp?: number;
  prefix?: string;
}

/**
 * Generate auto SKU based on product information
 */
export function generateAutoSku(options: SkuGenerationOptions): string {
  const {
    productName,
    category,
    manufacturer,
    barcode,
    timestamp = Date.now(),
    prefix = 'SKU'
  } = options;

  // Clean and extract meaningful parts
  const categoryCode = category
    .replace(/[^a-zA-Z0-9]/g, '')
    .substring(0, 3)
    .toUpperCase();

  const nameCode = productName
    .replace(/[^a-zA-Z0-9]/g, '')
    .substring(0, 4)
    .toUpperCase();

  const manufacturerCode = manufacturer
    ? manufacturer.replace(/[^a-zA-Z0-9]/g, '').substring(0, 2).toUpperCase()
    : '';

  // Use barcode hash if available, otherwise random string
  const identifierCode = barcode
    ? barcode.slice(-3)
    : Math.random().toString(36).substr(2, 3).toUpperCase();

  // Last 4 digits of timestamp for uniqueness
  const timeCode = timestamp.toString().slice(-4);

  // Construct SKU: PREFIX-CATEGORY-NAME-IDENTIFIER-TIME
  const parts = [prefix, categoryCode, nameCode, identifierCode, timeCode].filter(Boolean);
  return parts.join('').toUpperCase();
}

/**
 * Generate multiple SKU suggestions
 */
export function generateSkuSuggestions(options: SkuGenerationOptions): string[] {
  const suggestions: string[] = [];
  
  // Primary suggestion
  suggestions.push(generateAutoSku(options));
  
  // Alternative with manufacturer
  if (options.manufacturer) {
    suggestions.push(generateAutoSku({
      ...options,
      prefix: options.manufacturer.substring(0, 3).toUpperCase()
    }));
  }
  
  // Simple sequential suggestion
  const simpleCode = `${options.category.substring(0, 3).toUpperCase()}${Date.now().toString().slice(-6)}`;
  suggestions.push(simpleCode);
  
  // Barcode-based if available
  if (options.barcode) {
    suggestions.push(`BC${options.barcode.slice(-8)}`);
  }
  
  return [...new Set(suggestions)]; // Remove duplicates
}

/**
 * Validate barcode format
 */
export function validateBarcode(code: string): ProductBarcode {
  if (!code || code.trim().length === 0) {
    return { code, type: 'UNKNOWN', isValid: false };
  }

  const cleanCode = code.trim();
  
  // UPC-A (12 digits)
  if (/^\d{12}$/.test(cleanCode)) {
    return { 
      code: cleanCode, 
      type: 'UPC', 
      isValid: validateUPCChecksum(cleanCode) 
    };
  }
  
  // EAN-13 (13 digits)
  if (/^\d{13}$/.test(cleanCode)) {
    return { 
      code: cleanCode, 
      type: 'EAN', 
      isValid: validateEANChecksum(cleanCode) 
    };
  }
  
  // EAN-8 (8 digits)
  if (/^\d{8}$/.test(cleanCode)) {
    return { 
      code: cleanCode, 
      type: 'EAN', 
      isValid: validateEAN8Checksum(cleanCode) 
    };
  }
  
  // CODE128 (variable length alphanumeric)
  if (/^[A-Za-z0-9\-_+]+$/.test(cleanCode) && cleanCode.length >= 4) {
    return { code: cleanCode, type: 'CODE128', isValid: true };
  }
  
  // CODE39 (alphanumeric with specific characters)
  if (/^[A-Z0-9\-. $/+%*]+$/.test(cleanCode.toUpperCase())) {
    return { code: cleanCode.toUpperCase(), type: 'CODE39', isValid: true };
  }
  
  // QR Code (any text/URL)
  if (cleanCode.length > 20 || cleanCode.includes('http') || cleanCode.includes('://')) {
    return { code: cleanCode, type: 'QR', isValid: true };
  }
  
  // Unknown format but might be valid
  return { code: cleanCode, type: 'UNKNOWN', isValid: cleanCode.length >= 4 };
}

/**
 * Validate UPC checksum
 */
function validateUPCChecksum(code: string): boolean {
  if (code.length !== 12) return false;
  
  const digits = code.split('').map(Number);
  let sum = 0;
  
  for (let i = 0; i < 11; i++) {
    sum += digits[i] * (i % 2 === 0 ? 3 : 1);
  }
  
  const checkDigit = (10 - (sum % 10)) % 10;
  return checkDigit === digits[11];
}

/**
 * Validate EAN-13 checksum
 */
function validateEANChecksum(code: string): boolean {
  if (code.length !== 13) return false;
  
  const digits = code.split('').map(Number);
  let sum = 0;
  
  for (let i = 0; i < 12; i++) {
    sum += digits[i] * (i % 2 === 0 ? 1 : 3);
  }
  
  const checkDigit = (10 - (sum % 10)) % 10;
  return checkDigit === digits[12];
}

/**
 * Validate EAN-8 checksum
 */
function validateEAN8Checksum(code: string): boolean {
  if (code.length !== 8) return false;
  
  const digits = code.split('').map(Number);
  let sum = 0;
  
  for (let i = 0; i < 7; i++) {
    sum += digits[i] * (i % 2 === 0 ? 3 : 1);
  }
  
  const checkDigit = (10 - (sum % 10)) % 10;
  return checkDigit === digits[7];
}

/**
 * Extract product information from common barcode formats
 */
export function extractProductInfoFromBarcode(code: string): {
  countryCode?: string;
  manufacturerCode?: string;
  productCode?: string;
  checkDigit?: string;
  type: string;
} {
  const barcode = validateBarcode(code);
  
  if (barcode.type === 'EAN' && code.length === 13) {
    return {
      countryCode: code.substring(0, 3),
      manufacturerCode: code.substring(3, 7),
      productCode: code.substring(7, 12),
      checkDigit: code.substring(12, 13),
      type: 'EAN-13'
    };
  }
  
  if (barcode.type === 'UPC' && code.length === 12) {
    return {
      manufacturerCode: code.substring(0, 6),
      productCode: code.substring(6, 11),
      checkDigit: code.substring(11, 12),
      type: 'UPC-A'
    };
  }
  
  return { type: barcode.type };
}

/**
 * Generate barcode suggestions for manual entry
 */
export function generateBarcodePattern(productName: string, category: string): string {
  // Generate a simple barcode pattern for products without real barcodes
  const nameHash = hashString(productName);
  const categoryHash = hashString(category);
  const timestamp = Date.now().toString().slice(-4);
  
  // Create a 12-digit UPC-like code
  const code = `${categoryHash}${nameHash}${timestamp}`.padStart(11, '0');
  
  // Calculate checksum for UPC
  const digits = code.split('').map(Number);
  let sum = 0;
  for (let i = 0; i < 11; i++) {
    sum += digits[i] * (i % 2 === 0 ? 3 : 1);
  }
  const checkDigit = (10 - (sum % 10)) % 10;
  
  return code + checkDigit;
}

/**
 * Simple hash function for strings
 */
function hashString(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32-bit integer
  }
  return Math.abs(hash).toString().slice(-3).padStart(3, '0');
}

/**
 * Check if barcode might contain product information
 */
export function mightContainProductInfo(code: string): boolean {
  const barcode = validateBarcode(code);
  
  // UPC and EAN codes often contain manufacturer and product information
  if (barcode.type === 'UPC' || barcode.type === 'EAN') {
    return true;
  }
  
  // QR codes might contain JSON or structured data
  if (barcode.type === 'QR') {
    try {
      JSON.parse(code);
      return true;
    } catch {
      return code.includes('http') || code.includes('name') || code.includes('product');
    }
  }
  
  return false;
}