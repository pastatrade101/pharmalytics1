// DEPRECATED: This file is no longer used. We have switched to Gemini MCP.
// See /lib/gemini-mcp.ts for the current AI integration.
// This file is kept for reference only and should not be imported anywhere.

// OpenAI MCP Integration for Sales Analytics (DEPRECATED)
interface OpenAIConfig {
  apiKey: string;
  model: string;
  fallbackModel?: string;
  temperature: number;
}

interface SalesAnalysisPrompt {
  salesData: any[];
  dateRange: string;
  previousPeriodData?: any[];
}

// Environment variable helper
const getEnvVar = (key: string, fallback: string) => {
  if (typeof window !== 'undefined') {
    return fallback; // Client-side fallback
  }
  try {
    return process?.env?.[key] || fallback;
  } catch {
    return fallback;
  }
};

// Available OpenAI models in order of preference (most accessible first)
const OPENAI_MODELS = [
  'gpt-4o-mini',        // Most cost-effective GPT-4 class model
  'gpt-3.5-turbo',      // Widely available fallback
  'gpt-4o',             // Latest GPT-4 model (if available)
  'gpt-3.5-turbo-1106', // Additional fallback
  'gpt-4'               // Original GPT-4 (least accessible)
];

export class OpenAIMCPConnector {
  private config: OpenAIConfig;
  private workingModel: string | null = null;
  private quotaExceeded: boolean = false; // Track quota status
  private lastQuotaCheck: number = 0; // Track last quota check

  constructor(config: OpenAIConfig) {
    this.config = config;
  }

  async generateSalesSummary(prompt: SalesAnalysisPrompt): Promise<any> {
    console.log('🤖 OpenAI MCP: Generating sales summary with AI');
    
    // Check if we recently hit quota limits (avoid repeated API calls)
    const now = Date.now();
    if (this.quotaExceeded && (now - this.lastQuotaCheck) < 300000) { // 5 minutes cooldown
      console.log('💰 Recently hit quota limits, using enhanced mock analysis immediately');
      return await this.enhancedMockAnalysisWithQuotaNotice(prompt);
    }

    const systemPrompt = `You are an expert sales analyst AI specializing in small business retail analytics. Analyze the provided sales data and generate actionable insights for shop owners.

Your response should be a JSON object with this exact structure:
{
  "summary": "Brief overview of sales performance focusing on key achievements and concerns",
  "keyMetrics": {
    "totalRevenue": number,
    "totalTransactions": number,
    "averageTransactionValue": number,
    "topProduct": "product name"
  },
  "insights": [
    "Specific insight about sales patterns or customer behavior",
    "Analysis of product performance and trends",
    "Time-based patterns and seasonality observations"
  ],
  "recommendations": [
    "Specific actionable recommendation to improve sales",
    "Inventory or staffing suggestion based on data",
    "Marketing or operational improvement idea"
  ],
  "trends": {
    "salesTrend": "increasing|decreasing|stable",
    "peakHours": "specific time ranges when sales peak",
    "slowPeriods": "specific time ranges when sales are slow"
  },
  "alerts": [
    "Any urgent concerns or opportunities that need immediate attention"
  ]
}

Focus on:
- Practical, actionable insights
- Real business impact
- Specific recommendations the shop owner can implement today
- Alert them to any concerning patterns or opportunities`;

    const userPrompt = `Analyze this sales data for ${prompt.dateRange}:

Current Period Sales Data:
${JSON.stringify(prompt.salesData, null, 2)}

${prompt.previousPeriodData ? `Previous Period Comparison Data:
${JSON.stringify(prompt.previousPeriodData, null, 2)}` : ''}

Please provide detailed analysis focusing on:
1. Revenue performance and transaction patterns
2. Product performance and customer preferences  
3. Time-based sales patterns and peak hours
4. Actionable recommendations for immediate implementation
5. Any alerts or concerns that require attention

Return valid JSON only.`;

    try {
      // Use real OpenAI API if API key is available and valid
      if (this.config.apiKey && this.config.apiKey.startsWith('sk-') && !this.config.apiKey.includes('mock')) {
        console.log('🤖 Attempting to use real OpenAI API...');
        return await this.callOpenAIWithFallback(systemPrompt, userPrompt);
      } else {
        console.log('🤖 Invalid/missing API key, using enhanced mock analysis...');
        return await this.enhancedMockAnalysis(prompt);
      }
    } catch (error: any) {
      console.error('🤖 OpenAI MCP Error:', error);
      
      const errorMessage = error?.message || String(error);
      
      // Enhanced quota exceeded handling
      if (error.name === 'QuotaExceededError' || errorMessage.includes('quota') || errorMessage.includes('429') || errorMessage.includes('insufficient_quota')) {
        console.log('💰 OpenAI quota exceeded - marking for cooldown period');
        this.quotaExceeded = true;
        this.lastQuotaCheck = now;
        return await this.enhancedMockAnalysisWithQuotaNotice(prompt);
      } else if (error.name === 'AuthenticationError' || errorMessage.includes('authentication') || errorMessage.includes('401')) {
        console.log('🔑 OpenAI authentication failed - API key issue');
        const mockResult = await this.enhancedMockAnalysis(prompt);
        mockResult.alerts = mockResult.alerts || [];
        mockResult.alerts.unshift('AI Analysis unavailable: Authentication failed. Please verify your OpenAI API key configuration.');
        return mockResult;
      } else if (errorMessage.includes('network') || errorMessage.includes('fetch')) {
        console.log('🌐 Network connectivity issues detected');
        const mockResult = await this.enhancedMockAnalysis(prompt);
        mockResult.alerts = mockResult.alerts || [];
        mockResult.alerts.unshift('AI Analysis temporarily unavailable due to network connectivity issues. Using intelligent fallback analysis.');
        return mockResult;
      } else {
        console.log('❌ General OpenAI error, falling back to enhanced mock analysis...');
        const mockResult = await this.enhancedMockAnalysis(prompt);
        mockResult.alerts = mockResult.alerts || [];
        mockResult.alerts.unshift('AI Analysis temporarily unavailable due to service issues. Using intelligent fallback analysis.');
        return mockResult;
      }
    }
  }

  private async enhancedMockAnalysisWithQuotaNotice(prompt: SalesAnalysisPrompt): Promise<any> {
    const mockResult = await this.enhancedMockAnalysis(prompt);
    mockResult.alerts = mockResult.alerts || [];
    mockResult.alerts.unshift('OpenAI API quota exceeded. Using intelligent fallback analysis until quota is restored. Please check your OpenAI billing plan at https://platform.openai.com/account/billing');
    mockResult.quotaExceeded = true; // Mark as quota exceeded
    return mockResult;
  }

  private async callOpenAIWithFallback(systemPrompt: string, userPrompt: string): Promise<any> {
    // Try the configured model first, then fallback models
    const modelsToTry = [
      this.workingModel, // Previously working model (if any)
      this.config.model,
      this.config.fallbackModel,
      ...OPENAI_MODELS
    ].filter((model, index, array) => 
      model && array.indexOf(model) === index // Remove duplicates and null values
    );

    let lastError: any = null;

    for (const model of modelsToTry) {
      try {
        console.log(`🤖 Trying OpenAI model: ${model}`);
        const result = await this.callOpenAI(systemPrompt, userPrompt, model);
        
        // Success! Remember this model for future calls and reset quota flag
        this.workingModel = model;
        this.quotaExceeded = false; // Reset quota exceeded flag on success
        console.log(`✅ Successfully used model: ${model}`);
        return result;
        
      } catch (error: any) {
        console.log(`❌ Model ${model} failed:`, error.message);
        lastError = error;
        
        // If it's a quota error, don't try other models
        if (error.name === 'QuotaExceededError' || 
            error.message?.includes('quota') || 
            error.message?.includes('429') || 
            error.message?.includes('insufficient_quota')) {
          console.log('💰 Quota exceeded error - stopping model attempts');
          break;
        }
        
        // If it's a model access error, try the next model
        if (error.message?.includes('model') && error.message?.includes('does not exist')) {
          continue;
        }
        
        // If it's a different error (auth, etc.), don't try other models
        break;
      }
    }

    // All models failed, throw the last error
    throw lastError || new Error('All OpenAI models failed');
  }

  private async callOpenAI(systemPrompt: string, userPrompt: string, model: string): Promise<any> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout

    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.config.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: model,
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userPrompt }
          ],
          temperature: this.config.temperature,
          max_tokens: 2000,
          response_format: { type: "json_object" }
        }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorText = await response.text();
        let errorData;
        try {
          errorData = JSON.parse(errorText);
        } catch {
          errorData = { error: { message: errorText } };
        }
        
        console.error(`OpenAI API Error (${model}):`, response.status, errorData);
        
        // Enhanced error handling for different status codes
        if (response.status === 429) {
          const quotaError = new Error(`OpenAI API quota exceeded: ${errorData.error?.message || 'You exceeded your current quota, please check your plan and billing details.'}`);
          quotaError.name = 'QuotaExceededError';
          throw quotaError;
        } else if (response.status === 401) {
          const authError = new Error(`OpenAI API authentication failed: ${errorData.error?.message || 'Invalid authentication credentials'}`);
          authError.name = 'AuthenticationError';
          throw authError;
        } else if (response.status === 403) {
          const permError = new Error(`OpenAI API access denied: ${errorData.error?.message || 'Check API permissions'}`);
          permError.name = 'PermissionError';
          throw permError;
        } else if (response.status >= 500) {
          const serverError = new Error(`OpenAI API server error: ${response.status} - Please try again later`);
          serverError.name = 'ServerError';
          throw serverError;
        } else {
          throw new Error(`OpenAI API error: ${response.status} ${errorData.error?.message || response.statusText}`);
        }
      }

      const data = await response.json();
      const content = data.choices[0].message.content;
      
      try {
        const parsedContent = JSON.parse(content);
        console.log('✅ Successfully parsed OpenAI JSON response');
        return parsedContent;
      } catch (parseError) {
        console.error('Failed to parse OpenAI response as JSON:', content);
        throw new Error('Invalid JSON response from OpenAI - response was not valid JSON format');
      }

    } catch (error: any) {
      clearTimeout(timeoutId);
      
      if (error.name === 'AbortError') {
        throw new Error('OpenAI API request timed out after 30 seconds');
      }
      
      throw error;
    }
  }

  private async enhancedMockAnalysis(prompt: SalesAnalysisPrompt): Promise<any> {
    // Simulate API call delay for realism
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    try {
      const salesData = prompt.salesData || [];
      const totalRevenue = salesData.reduce((sum, sale) => sum + (sale.totalPrice || 0), 0);
      const totalTransactions = salesData.length;
      const averageTransactionValue = totalTransactions > 0 ? totalRevenue / totalTransactions : 0;
      
      // Analyze products safely
      const productCounts: Record<string, number> = {};
      salesData.forEach(sale => {
        if (sale && sale.item) {
          productCounts[sale.item] = (productCounts[sale.item] || 0) + (sale.quantity || 1);
        }
      });
      
      const topProduct = Object.keys(productCounts).length > 0 ? 
        Object.keys(productCounts).reduce((a, b) => 
          productCounts[a] > productCounts[b] ? a : b
        ) : 'No sales';

      // Analyze time patterns safely
      const hours = salesData.map(sale => {
        try {
          if (sale && sale.timestamp) {
            const hour = new Date(sale.timestamp).getHours();
            return !isNaN(hour) && hour >= 0 && hour <= 23 ? hour : null;
          }
        } catch {
          return null;
        }
        return null;
      }).filter(hour => hour !== null);

      const peakHour = hours.length > 0 ? 
        hours.reduce((a, b, i, arr) => 
          arr.filter(v => v === a).length >= arr.filter(v => v === b).length ? a : b
        ) : null;

      // Generate insights based on actual data
      const insights = [];
      const recommendations = [];
      const alerts = [];

      if (totalTransactions === 0) {
        insights.push("No sales activity recorded today - this requires immediate investigation and action");
        recommendations.push("Check POS system functionality, verify staff availability, and review store hours");
        recommendations.push("Consider running promotional activities or customer outreach campaigns");
        alerts.push("URGENT: Zero sales detected - immediate management attention required");
      } else {
        // Revenue performance analysis
        if (totalRevenue > 500) {
          insights.push(`Exceptional sales performance with $${totalRevenue.toFixed(2)} revenue - this represents strong market engagement and effective sales execution`);
          recommendations.push("Analyze what drove today's success and implement strategies to replicate this performance");
        } else if (totalRevenue > 300) {
          insights.push(`Strong sales performance with $${totalRevenue.toFixed(2)} revenue showing healthy business momentum`);
          recommendations.push("Build on today's solid performance by identifying opportunities for incremental growth");
        } else if (totalRevenue > 150) {
          insights.push(`Moderate revenue performance at $${totalRevenue.toFixed(2)} with clear opportunities for improvement`);
          recommendations.push("Focus on upselling strategies and promotional activities to boost daily revenue");
        } else {
          insights.push(`Below-target revenue performance at $${totalRevenue.toFixed(2)} indicating need for immediate action`);
          recommendations.push("Implement aggressive promotional pricing and increase customer acquisition efforts");
          alerts.push("Low daily revenue - requires strategic intervention to meet business targets");
        }

        // Transaction value insights
        if (averageTransactionValue > 40) {
          insights.push(`Outstanding average transaction value of $${averageTransactionValue.toFixed(2)} demonstrates exceptional customer engagement and successful premium positioning`);
          recommendations.push("Maintain premium product mix and continue training staff on high-value selling techniques");
        } else if (averageTransactionValue > 25) {
          insights.push(`Good average transaction value of $${averageTransactionValue.toFixed(2)} shows healthy customer spending patterns with room for growth`);
          recommendations.push("Introduce complementary product suggestions and seasonal bundles to increase basket size");
        } else if (averageTransactionValue > 15) {
          insights.push(`Moderate transaction values averaging $${averageTransactionValue.toFixed(2)} indicate potential for strategic upselling initiatives`);
          recommendations.push("Train staff on cross-selling techniques and create attractive product bundle offers");
        } else {
          insights.push(`Lower average transaction value of $${averageTransactionValue.toFixed(2)} suggests significant opportunities for revenue optimization through strategic pricing and bundling`);
          recommendations.push("Implement comprehensive upselling training, create value-added bundles, and review pricing strategy");
        }

        // Product diversity and performance analysis
        const uniqueProducts = Object.keys(productCounts).length;
        if (uniqueProducts === 1) {
          insights.push("Sales concentrated entirely on single product line - this creates significant business risk and missed revenue opportunities");
          recommendations.push("Aggressively promote product variety through strategic displays, staff recommendations, and targeted promotions");
          alerts.push("Product concentration risk - diversify sales mix to reduce business vulnerability");
        } else if (uniqueProducts > totalTransactions * 0.6) {
          insights.push(`Excellent product diversity with ${uniqueProducts} different items sold, demonstrating broad customer appeal and effective merchandising`);
          recommendations.push("Continue promoting product variety while identifying opportunities to increase quantity per transaction");
        } else if (uniqueProducts > totalTransactions * 0.3) {
          insights.push(`Good product mix diversity with ${uniqueProducts} items contributing to sales, showing balanced customer preferences`);
          recommendations.push("Analyze top-performing products and create strategic bundles to increase overall transaction value");
        }

        // Time-based performance insights
        if (peakHour !== null) {
          if (peakHour >= 7 && peakHour <= 9) {
            insights.push("Morning rush period (7-9 AM) drives peak sales - capitalize on commuter and early-riser traffic patterns");
            recommendations.push("Ensure optimal morning inventory, consider breakfast promotions, and evaluate extended early hours");
          } else if (peakHour >= 12 && peakHour <= 14) {
            insights.push("Lunch period (12-2 PM) represents primary sales driver - strong positioning for midday customer needs");
            recommendations.push("Optimize lunch menu offerings, ensure adequate staffing, and consider lunch-specific promotions");
          } else if (peakHour >= 15 && peakHour <= 17) {
            insights.push("Afternoon period (3-5 PM) shows strong performance - excellent capture of after-work and snack traffic");
            recommendations.push("Promote afternoon beverages and snacks, ensure fresh inventory for peak period");
          } else if (peakHour >= 18 && peakHour <= 20) {
            insights.push("Evening sales (6-8 PM) indicate strong dinner and after-work market penetration");
            recommendations.push("Consider extended evening hours and dinner-focused product offerings");
          }
        }

        // Operational recommendations
        recommendations.push("Monitor inventory levels for top-selling products to prevent stockouts during peak periods");
        recommendations.push("Implement systematic customer feedback collection to identify service improvement opportunities");
        
        if (totalTransactions < 20) {
          recommendations.push("Increase customer traffic through social media marketing, local partnerships, and community engagement");
          recommendations.push("Consider implementing a customer loyalty program to encourage repeat business");
        }
        
        if (totalTransactions > 30) {
          insights.push("High transaction volume demonstrates strong customer traffic and operational efficiency");
          recommendations.push("Focus on maintaining service quality during busy periods and consider capacity optimization");
        }
      }

      // Determine sales trends
      let salesTrend = "stable";
      if (prompt.previousPeriodData && prompt.previousPeriodData.length > 0) {
        const prevRevenue = prompt.previousPeriodData.reduce((sum, day) => sum + (day.revenue || 0), 0);
        if (prevRevenue > 0) {
          const changePercent = ((totalRevenue - prevRevenue) / prevRevenue) * 100;
          if (changePercent > 15) salesTrend = "increasing";
          else if (changePercent < -15) salesTrend = "decreasing";
        }
      } else {
        // Base trend assessment on current performance
        if (totalRevenue > 400) salesTrend = "increasing";
        else if (totalRevenue < 100) salesTrend = "decreasing";
      }

      // Generate performance-based alerts
      if (totalRevenue < 100 && totalTransactions > 0) {
        alerts.push("Low revenue per transaction - review pricing strategy and product mix");
      }
      if (totalTransactions > 50 && averageTransactionValue < 10) {
        alerts.push("High volume but low value transactions - implement value-addition strategies");
      }

      console.log('✅ Enhanced mock analysis completed successfully');

      return {
        summary: totalTransactions > 0 
          ? `Comprehensive analysis of ${prompt.dateRange} sales shows ${totalTransactions} transactions generating $${totalRevenue.toFixed(2)} in revenue. ${topProduct} emerged as the top-performing product, with ${salesTrend} trend indicators suggesting ${salesTrend === 'increasing' ? 'positive' : salesTrend === 'decreasing' ? 'concerning' : 'stable'} business momentum. Key focus areas include ${averageTransactionValue < 20 ? 'transaction value optimization' : 'maintaining strong performance'} and ${uniqueProducts < 5 ? 'product diversification' : 'inventory management'}.`
          : `No sales activity recorded for ${prompt.dateRange}, representing a critical business situation requiring immediate management intervention. This could indicate system failures, operational issues, or external factors affecting business operations.`,
        keyMetrics: {
          totalRevenue: Math.round(totalRevenue * 100) / 100,
          totalTransactions,
          averageTransactionValue: Math.round(averageTransactionValue * 100) / 100,
          topProduct: topProduct
        },
        insights,
        recommendations,
        trends: {
          salesTrend,
          peakHours: peakHour !== null ? `${peakHour}:00 - ${peakHour + 1}:00` : "Insufficient data for pattern analysis",
          slowPeriods: totalTransactions < 5 ? "Most operational hours showing low activity" : "Early morning and late evening typically slower"
        },
        alerts,
        isMockData: true, // Mark as mock data
        isEnhancedFallback: true
      };

    } catch (error) {
      console.error('🚨 Error in enhanced mock analysis:', error);
      
      // Ultra-safe fallback
      return {
        summary: `Analysis system experiencing technical difficulties. Basic performance data: ${prompt.salesData?.length || 0} transactions recorded.`,
        keyMetrics: {
          totalRevenue: 0,
          totalTransactions: prompt.salesData?.length || 0,
          averageTransactionValue: 0,
          topProduct: 'Analysis Error'
        },
        insights: [
          'Analysis system temporarily unavailable due to technical issues.',
          'Manual review of sales data recommended.',
          'System recovery procedures are in progress.'
        ],
        recommendations: [
          'Continue normal business operations.',
          'Manually monitor key performance indicators.',
          'Contact technical support if issues persist.'
        ],
        trends: {
          salesTrend: 'analysis unavailable',
          peakHours: 'System error',
          slowPeriods: 'System error'
        },
        alerts: [
          'Analysis system error - immediate technical review required.'
        ],
        isMockData: true,
        systemError: true
      };
    }
  }

  async generateReportText(analysisData: any): Promise<string> {
    try {
      const reportDate = new Date().toLocaleDateString();
      const isQuotaExceeded = analysisData.quotaExceeded || false;
      
      return `
🏪 ${isQuotaExceeded ? 'INTELLIGENT FALLBACK' : 'AI-POWERED'} DAILY SALES REPORT - ${reportDate}

${isQuotaExceeded ? `
🔄 QUOTA NOTICE: OpenAI API quota exceeded. This report uses intelligent fallback analysis.
Please check your OpenAI billing plan at: https://platform.openai.com/account/billing

` : ''}📊 EXECUTIVE SUMMARY
${analysisData.summary}

📈 KEY PERFORMANCE METRICS
• Total Revenue: $${analysisData.keyMetrics.totalRevenue.toFixed(2)}
• Total Transactions: ${analysisData.keyMetrics.totalTransactions}
• Average Transaction Value: $${analysisData.keyMetrics.averageTransactionValue.toFixed(2)}
• Best Performing Product: ${analysisData.keyMetrics.topProduct}

💡 ${isQuotaExceeded ? 'INTELLIGENT FALLBACK' : 'AI-POWERED'} INSIGHTS
${analysisData.insights.map((insight: string, index: number) => `${index + 1}. ${insight}`).join('\n')}

🎯 STRATEGIC RECOMMENDATIONS
${analysisData.recommendations.map((rec: string, index: number) => `${index + 1}. ${rec}`).join('\n')}

📊 SALES TRENDS ANALYSIS
• Overall Trend: ${analysisData.trends.salesTrend.toUpperCase()}
• Peak Sales Hours: ${analysisData.trends.peakHours}
• Slower Periods: ${analysisData.trends.slowPeriods}

${analysisData.alerts.length > 0 ? `
⚠️ IMMEDIATE ATTENTION REQUIRED
${analysisData.alerts.map((alert: string, index: number) => `${index + 1}. ${alert}`).join('\n')}
` : ''}

---
Generated by Shop Sales Dashboard AI
${isQuotaExceeded ? 'Powered by Intelligent Fallback Analysis' : 'Powered by OpenAI MCP Integration'} • ${new Date().toLocaleString()}
${isQuotaExceeded ? 'Note: Real AI analysis will resume when OpenAI quota is restored.' : ''}
      `.trim();
      
    } catch (error) {
      console.error('Error generating report text:', error);
      return `
❌ Report Generation Error - ${new Date().toLocaleDateString()}

An error occurred while formatting the daily report.
Please check the system logs and try again.

Error: ${error?.message || 'Unknown error'}
Time: ${new Date().toLocaleString()}
      `.trim();
    }
  }

  // Daily report generation for automated scheduling
  async generateDailyReport(salesData: any[], shopName: string): Promise<string> {
    try {
      const analysis = await this.generateSalesSummary({
        salesData,
        dateRange: 'today',
        previousPeriodData: []
      });

      const isQuotaExceeded = analysis.quotaExceeded || false;

      return `
🏪 ${shopName.toUpperCase()} - DAILY PERFORMANCE REPORT
${new Date().toLocaleDateString()}

${await this.generateReportText(analysis)}

📧 This automated report has been generated and ${isQuotaExceeded ? 'uses fallback analysis due to API limits' : 'sent to configured recipients'}.
📱 ${isQuotaExceeded ? 'WhatsApp notifications use fallback data' : 'WhatsApp notifications have been dispatched to management'}.
📊 Data has been synchronized with Google Sheets for record keeping.

${isQuotaExceeded ? '🔄 Real AI analysis will resume when OpenAI quota is restored.' : ''}

Next automated report: ${new Date(Date.now() + 24 * 60 * 60 * 1000).toLocaleDateString()}
      `.trim();
    } catch (error) {
      console.error('Error generating daily report:', error);
      return `
❌ Daily Report Generation Failed - ${new Date().toLocaleDateString()}

An error occurred while generating the automated daily report for ${shopName}.
Please check the system logs and contact technical support if the issue persists.

Error: ${error?.message || 'Unknown error'}
Time: ${new Date().toLocaleString()}
      `.trim();
    }
  }
}

// Initialize OpenAI MCP connector with updated API key
const openaiApiKey = getEnvVar('OPENAI_API_KEY', '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');
const openaiModel = getEnvVar('OPENAI_MODEL', 'gpt-4o-mini');
const openaiFallbackModel = getEnvVar('OPENAI_FALLBACK_MODEL', 'gpt-3.5-turbo');
const openaiTemperature = parseFloat(getEnvVar('OPENAI_TEMPERATURE', '0.7'));

export const openaiConnector = new OpenAIMCPConnector({
  apiKey: openaiApiKey,
  model: openaiModel,
  fallbackModel: openaiFallbackModel,
  temperature: openaiTemperature,
});

console.log(`🤖 OpenAI MCP Connector initialized with enhanced quota handling`);
console.log(`🔑 API Key Status: ${openaiApiKey.startsWith('sk-') ? '✅ Valid format' : '❌ Invalid format'}`);
console.log(`🤖 Primary model: ${openaiModel}, fallback: ${openaiFallbackModel}`);
console.log(`💰 Quota exceeded protection: ✅ Enabled with 5-minute cooldown`);