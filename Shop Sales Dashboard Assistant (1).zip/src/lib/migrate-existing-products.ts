/**
 * One-time migration script to fix existing products with undefined prices
 * This can be called directly from the browser console or triggered via a UI button
 */

import { ProductMigrationService } from './firebase-products-migration';

/**
 * Run the product price migration for the current user's shop
 * This function can be called from the browser console to fix existing products
 */
export async function migrateProductPricing(shopId?: string): Promise<void> {
  try {
    console.log('🚀 Starting product pricing migration...');
    
    if (!shopId) {
      console.error('❌ Shop ID is required. Please provide the shop ID as a parameter.');
      console.log('Example: migrateProductPricing("your-shop-id-here")');
      return;
    }

    // Add permission check before proceeding
    console.log('🔍 Checking Firebase permissions...');
    
    // Simple permission test
    try {
      await ProductMigrationService.previewProductFixes(shopId);
      console.log('✅ Firebase permissions verified');
    } catch (permError: any) {
      if (permError.code === 'permission-denied' || permError.message?.includes('permission')) {
        console.log('');
        console.log('🚨 FIREBASE PERMISSION ERROR DETECTED:');
        console.log('Cannot run migration - Firebase security rules are not deployed.');
        console.log('');
        console.log('📋 TO FIX:');
        console.log('1. Go to: https://console.firebase.google.com/project/shopsalesai/firestore/rules');
        console.log('2. Copy the rules from one of the FIREBASE_RULES files in your project');
        console.log('3. Click "Publish" and wait for confirmation');
        console.log('4. Try running the migration again');
        console.log('');
        return;
      }
      throw permError;
    }
    
    // Preview first
    console.log('🔍 Checking products that need fixes...');
    const preview = await ProductMigrationService.previewProductFixes(shopId);
    
    if (preview.length === 0) {
      console.log('✅ All products already have valid pricing data!');
      return;
    }
    
    console.log(`📊 Found ${preview.length} products that need fixes:`);
    preview.forEach((product, index) => {
      console.log(`${index + 1}. ${product.name} - Issues: ${product.issues.join(', ')}`);
    });
    
    // Ask for confirmation
    const confirmed = confirm(`Found ${preview.length} products with pricing issues. Do you want to fix them now?`);
    
    if (!confirmed) {
      console.log('❌ Migration cancelled by user');
      return;
    }
    
    // Run the migration
    console.log('🔧 Starting migration...');
    await ProductMigrationService.fixShopProductPricing(shopId);
    
    console.log('🎉 Migration completed successfully!');
    console.log('💡 Refresh the page to see the updated prices in the POS system.');
    
  } catch (error: any) {
    console.error('❌ Migration failed:', error);
    
    // Provide specific guidance for permission errors
    if (error.code === 'permission-denied' || error.message?.includes('permission')) {
      console.log('');
      console.log('🚨 FIREBASE PERMISSION ERROR DETECTED:');
      console.log('This means your Firebase security rules are not deployed.');
      console.log('');
      console.log('📋 TO FIX:');
      console.log('1. Go to: https://console.firebase.google.com/project/shopsalesai/firestore/rules');
      console.log('2. Copy the rules from one of the FIREBASE_RULES files in your project');
      console.log('3. Click "Publish" and wait for confirmation');
      console.log('4. Try running the migration again');
      console.log('');
      return;
    }
    
    throw error;
  }
}

/**
 * Quick function to run migration for all products (admin only)
 */
export async function migrateAllProductPricing(): Promise<void> {
  try {
    console.log('🚀 Starting global product pricing migration...');
    console.warn('⚠️ This will update ALL products in the database!');
    
    const confirmed = confirm('This will update ALL products in the database. Are you sure?');
    
    if (!confirmed) {
      console.log('❌ Global migration cancelled by user');
      return;
    }
    
    await ProductMigrationService.fixAllProductPricing();
    
    console.log('🎉 Global migration completed successfully!');
    console.log('💡 All users should refresh their applications to see updated prices.');
    
  } catch (error) {
    console.error('❌ Global migration failed:', error);
    throw error;
  }
}

// Make functions available globally for console access (only in development or when Firebase is working)
if (typeof window !== 'undefined') {
  (window as any).migrateProductPricing = migrateProductPricing;
  (window as any).migrateAllProductPricing = migrateAllProductPricing;
  
  // Only show instructions if likely to work (not in production mode)
  const isDev = process.env.NODE_ENV === 'development';
  if (isDev) {
    console.log('🔧 Product migration utilities loaded!');
    console.log('Usage:');
    console.log('  migrateProductPricing("your-shop-id") - Fix products for a specific shop');
    console.log('  migrateAllProductPricing() - Fix all products (admin only)');
    console.log('');
    console.log('⚠️ Note: These functions require Firebase security rules to be deployed.');
    console.log('If you get permission errors, deploy the rules first.');
  }
}