// AI Business Intelligence Service for React SPA
// This replaces the Next.js API route for client-side AI analysis

export interface BusinessMetrics {
  totalRevenue: number;
  totalTransactions: number;
  totalProducts: number;
  activeProducts: number;
  lowStockItems: number;
  expiringItems: number;
  expiredItems: number;
  averageTransactionValue: number;
  monthlyGrowth: number;
  topSellingProducts: Array<{
    name: string;
    sales: number;
    revenue: number;
  }>;
  recentSales: Array<{
    date: string;
    amount: number;
    customer: string;
  }>;
}

export interface AIInsight {
  type: 'opportunity' | 'risk' | 'trend' | 'recommendation';
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  actionable: boolean;
  metrics?: string[];
}

export interface AIReport {
  summary: string;
  insights: AIInsight[];
  recommendations: string[];
  predictions: string[];
  generatedAt: string;
  source: string;
}

export interface UserContext {
  role: string;
  pharmacyType: string;
}

// Client-side AI Business Intelligence Service
export class AIBusinessIntelligenceService {
  private static instance: AIBusinessIntelligenceService;

  static getInstance(): AIBusinessIntelligenceService {
    if (!AIBusinessIntelligenceService.instance) {
      AIBusinessIntelligenceService.instance = new AIBusinessIntelligenceService();
    }
    return AIBusinessIntelligenceService.instance;
  }

  async generateBusinessIntelligenceReport(
    businessData: BusinessMetrics,
    userContext: UserContext
  ): Promise<AIReport> {
    console.log('🤖 Generating AI business intelligence report (client-side)...');
    console.log('📊 Business data:', businessData);
    console.log('👤 User context:', userContext);

    try {
      // In a React SPA environment, we'll use intelligent fallback analysis
      // This provides comprehensive business insights without requiring server-side AI
      const report = this.generateIntelligentFallbackReport(businessData, userContext);
      
      console.log('✅ AI business intelligence report generated successfully');
      return report;
    } catch (error) {
      console.error('❌ Error generating AI report:', error);
      
      // Always provide a fallback report
      return this.generateBasicFallbackReport(businessData);
    }
  }

  private generateIntelligentFallbackReport(
    data: BusinessMetrics,
    userContext: UserContext
  ): AIReport {
    console.log('🧠 Generating intelligent fallback analysis...');

    const summary = this.generateFallbackSummary(data, userContext);
    const insights = this.generateFallbackInsights(data);
    const recommendations = this.generateFallbackRecommendations(data, userContext);
    const predictions = this.generateFallbackPredictions(data);

    return {
      summary,
      insights,
      recommendations,
      predictions,
      generatedAt: new Date().toISOString(),
      source: 'intelligent-fallback'
    };
  }

  private generateBasicFallbackReport(data: BusinessMetrics): AIReport {
    return {
      summary: `Your pharmacy has generated TZS ${data.totalRevenue.toLocaleString()} in total revenue from ${data.totalTransactions} transactions. Basic analysis shows ${data.activeProducts} active products with operational areas requiring attention.`,
      insights: [
        {
          type: 'trend',
          title: 'Business Overview',
          description: `Current performance shows ${data.totalTransactions} transactions with average value of TZS ${data.averageTransactionValue.toLocaleString()}.`,
          impact: 'medium',
          actionable: true,
          metrics: ['Revenue', 'Transactions']
        }
      ],
      recommendations: [
        'Review inventory levels regularly',
        'Monitor product expiration dates',
        'Track sales performance trends'
      ],
      predictions: [
        'Continued monitoring will help identify optimization opportunities'
      ],
      generatedAt: new Date().toISOString(),
      source: 'basic-fallback'
    };
  }

  private generateFallbackSummary(data: BusinessMetrics, userContext: UserContext): string {
    const growthText = data.monthlyGrowth > 0 ? 'growing' : 
                     data.monthlyGrowth < 0 ? 'declining' : 'stable';
    
    const pharmacyType = userContext.pharmacyType === 'community_pharmacy' ? 'community pharmacy' : 'pharmacy';
    
    return `Your ${pharmacyType} has generated TZS ${data.totalRevenue.toLocaleString()} in total revenue from ${data.totalTransactions} transactions. Monthly performance is ${growthText} with ${data.monthlyGrowth > 0 ? '+' : ''}${data.monthlyGrowth.toFixed(1)}% change. You have ${data.activeProducts} active products, with ${data.lowStockItems} items running low and ${data.expiringItems} items expiring soon, presenting both operational risks and optimization opportunities for your Tanzania-based operation.`;
  }

  private generateFallbackInsights(data: BusinessMetrics): AIInsight[] {
    const insights: AIInsight[] = [];

    // Growth analysis with Tanzania context
    if (data.monthlyGrowth > 15) {
      insights.push({
        type: 'opportunity',
        title: 'Exceptional Growth Momentum',
        description: `Revenue is growing at ${data.monthlyGrowth.toFixed(1)}% monthly, significantly above the typical pharmacy industry average in Tanzania. This indicates strong market position and customer satisfaction in your local community.`,
        impact: 'high',
        actionable: true,
        metrics: ['Monthly Growth', 'Revenue']
      });
    } else if (data.monthlyGrowth > 5) {
      insights.push({
        type: 'opportunity',
        title: 'Strong Growth Trend',
        description: `Steady growth of ${data.monthlyGrowth.toFixed(1)}% monthly shows healthy business trajectory. Consider expanding services or extending hours to capitalize on this momentum.`,
        impact: 'high',
        actionable: true,
        metrics: ['Monthly Growth']
      });
    } else if (data.monthlyGrowth > 0) {
      insights.push({
        type: 'trend',
        title: 'Positive Growth Trend',
        description: `Growth of ${data.monthlyGrowth.toFixed(1)}% monthly shows healthy business development. Consider strategies to accelerate growth through improved customer service or product diversification.`,
        impact: 'medium',
        actionable: true,
        metrics: ['Monthly Growth']
      });
    } else if (data.monthlyGrowth < -5) {
      insights.push({
        type: 'risk',
        title: 'Revenue Decline Alert',
        description: `Revenue is declining at ${Math.abs(data.monthlyGrowth).toFixed(1)}% monthly. This requires immediate attention to identify root causes such as increased competition, supply issues, or customer service problems.`,
        impact: 'high',
        actionable: true,
        metrics: ['Monthly Growth', 'Revenue']
      });
    }

    // Inventory management with tropical climate considerations
    if (data.lowStockItems > data.activeProducts * 0.15) {
      insights.push({
        type: 'risk',
        title: 'Critical Inventory Shortage',
        description: `${data.lowStockItems} products (${(data.lowStockItems / data.activeProducts * 100).toFixed(1)}%) are running low. This high percentage indicates systemic inventory management issues that could lead to customer dissatisfaction and lost sales.`,
        impact: 'high',
        actionable: true,
        metrics: ['Low Stock Items', 'Inventory Turnover']
      });
    } else if (data.lowStockItems > 10) {
      insights.push({
        type: 'risk',
        title: 'Inventory Restocking Required',
        description: `${data.lowStockItems} products require immediate reordering to prevent stockouts. Consider establishing automated reorder points to maintain consistent availability.`,
        impact: 'medium',
        actionable: true,
        metrics: ['Low Stock Items']
      });
    }

    // Expiry management with Tanzania climate context
    if (data.expiringItems > 0) {
      const expiryRatio = data.expiringItems / data.activeProducts;
      const impact = expiryRatio > 0.05 ? 'high' : 'medium';
      
      insights.push({
        type: 'risk',
        title: 'Product Expiry Management Critical',
        description: `${data.expiringItems} products are expiring soon (${(expiryRatio * 100).toFixed(1)}% of active inventory). Tanzania's tropical climate accelerates product degradation, making proper FEFO (First Expired, First Out) rotation essential for regulatory compliance and profitability.`,
        impact,
        actionable: true,
        metrics: ['Expiring Products', 'Inventory Management']
      });
    }

    // Transaction value analysis
    if (data.averageTransactionValue > 25000) { // TZS 25,000
      insights.push({
        type: 'opportunity',
        title: 'High-Value Customer Base',
        description: `Average transaction value of TZS ${data.averageTransactionValue.toLocaleString()} indicates strong customer trust and potentially premium product mix. Consider loyalty programs to retain these valuable customers.`,
        impact: 'high',
        actionable: true,
        metrics: ['Average Transaction Value', 'Customer Loyalty']
      });
    } else if (data.averageTransactionValue < 8000) { // TZS 8,000
      insights.push({
        type: 'opportunity',
        title: 'Transaction Value Optimization',
        description: `Average transaction value of TZS ${data.averageTransactionValue.toLocaleString()} suggests opportunity for upselling and cross-selling. Consider training staff on product recommendations and creating product bundles.`,
        impact: 'medium',
        actionable: true,
        metrics: ['Average Transaction Value', 'Sales Training']
      });
    }

    // Product portfolio analysis
    if (data.activeProducts < 50) {
      insights.push({
        type: 'opportunity',
        title: 'Product Range Expansion Opportunity',
        description: `With ${data.activeProducts} active products, there's opportunity to expand your product range to meet more customer needs and increase transaction frequency.`,
        impact: 'medium',
        actionable: true,
        metrics: ['Product Range', 'Customer Needs']
      });
    }

    return insights;
  }

  private generateFallbackRecommendations(data: BusinessMetrics, userContext: UserContext): string[] {
    const recommendations: string[] = [];

    // Inventory management recommendations
    if (data.lowStockItems > 0) {
      recommendations.push(`Implement automated reorder points for ${data.lowStockItems} low-stock items to prevent future stockouts and maintain customer satisfaction`);
      recommendations.push('Establish relationships with multiple suppliers to ensure consistent product availability and better pricing negotiations');
    }

    // Expiry management with Tanzania context
    if (data.expiringItems > 0) {
      recommendations.push(`Create immediate promotional campaigns for ${data.expiringItems} expiring products to minimize waste and recover costs`);
      recommendations.push('Implement strict FEFO (First Expired, First Out) inventory rotation system to manage Tanzania\'s climate challenges');
      recommendations.push('Consider climate-controlled storage solutions for temperature-sensitive medications');
    }

    // Growth strategies
    if (data.monthlyGrowth > 5) {
      recommendations.push('Leverage current growth momentum by expanding successful product categories and considering extended operating hours');
      recommendations.push('Investigate opening additional locations or expanding delivery services in your catchment area');
    } else if (data.monthlyGrowth < 0) {
      recommendations.push('Conduct customer satisfaction survey to identify service gaps and competitive disadvantages');
      recommendations.push('Review pricing strategy and consider promotional activities to regain market share');
    }

    // Transaction value optimization
    if (data.averageTransactionValue < 15000) { // TZS 15,000
      recommendations.push('Implement customer loyalty programs and staff training on upselling techniques to increase average transaction value');
      recommendations.push('Create product bundles and seasonal promotions to encourage larger purchases');
    }

    // Technology and payment recommendations for Tanzania market
    recommendations.push('Consider offering mobile money payment options (M-Pesa, Tigo Pesa, Airtel Money) to attract more customers and improve convenience');
    recommendations.push('Install pharmacy management software to track sales patterns, automate inventory management, and generate regulatory reports');

    // Customer service and compliance
    recommendations.push('Ensure all staff are trained on pharmaceutical regulations and customer service excellence');
    recommendations.push('Establish partnerships with local healthcare providers to increase prescription referrals');

    // Operational efficiency
    if (data.totalTransactions > 100) {
      recommendations.push('Consider implementing a queue management system during peak hours to improve customer experience');
    }

    return recommendations.slice(0, 8); // Return top 8 recommendations
  }

  private generateFallbackPredictions(data: BusinessMetrics): string[] {
    const predictions: string[] = [];

    // Revenue projections
    if (data.monthlyGrowth > 0) {
      const projectedRevenue = data.totalRevenue * (1 + data.monthlyGrowth / 100);
      predictions.push(`Based on current ${data.monthlyGrowth.toFixed(1)}% growth rate, next month's revenue may reach TZS ${projectedRevenue.toLocaleString()}, representing continued business expansion`);
    } else if (data.monthlyGrowth < 0) {
      const projectedRevenue = data.totalRevenue * (1 + data.monthlyGrowth / 100);
      predictions.push(`Without intervention, revenue may decline to TZS ${projectedRevenue.toLocaleString()} next month. Immediate action required to reverse this trend`);
    }

    // Inventory predictions
    if (data.lowStockItems > 0) {
      const reorderQuantity = Math.floor(data.lowStockItems * 1.4);
      predictions.push(`Inventory analysis suggests reordering ${reorderQuantity} items within the next week to maintain optimal stock levels and prevent customer disappointment`);
    }

    // Expiry predictions
    if (data.expiringItems > 0) {
      const potentialLoss = data.expiringItems * 18000; // Average estimated value
      predictions.push(`Without immediate action, approximately TZS ${potentialLoss.toLocaleString()} worth of inventory may expire, significantly impacting profitability`);
    }

    // Customer behavior predictions
    if (data.totalTransactions > 50) {
      predictions.push('Customer visit patterns suggest potential for extending operating hours or adding weekend services to capture additional sales');
    }

    // Seasonal predictions for Tanzania
    predictions.push('Seasonal demand changes typical in Tanzania suggest stocking up on cold and flu medications before the rainy season');

    // Business development predictions
    if (data.monthlyGrowth > 10) {
      predictions.push('Strong growth trajectory indicates readiness for business expansion, such as additional services or locations within 6-12 months');
    }

    return predictions.slice(0, 5); // Return top 5 predictions
  }

  // Utility method to format currency for display
  static formatTZS(amount: number): string {
    return `TZS ${amount.toLocaleString()}`;
  }

  // Utility method to calculate growth percentage
  static calculateGrowthPercentage(current: number, previous: number): number {
    if (previous === 0) return current > 0 ? 100 : 0;
    return ((current - previous) / previous) * 100;
  }

  // Method to validate business data
  static validateBusinessData(data: Partial<BusinessMetrics>): BusinessMetrics {
    return {
      totalRevenue: data.totalRevenue || 0,
      totalTransactions: data.totalTransactions || 0,
      totalProducts: data.totalProducts || 0,
      activeProducts: data.activeProducts || 0,
      lowStockItems: data.lowStockItems || 0,
      expiringItems: data.expiringItems || 0,
      expiredItems: data.expiredItems || 0,
      averageTransactionValue: data.averageTransactionValue || 0,
      monthlyGrowth: data.monthlyGrowth || 0,
      topSellingProducts: data.topSellingProducts || [],
      recentSales: data.recentSales || []
    };
  }
}

// Export convenience functions
export const generateBusinessIntelligenceReport = (
  businessData: BusinessMetrics,
  userContext: UserContext
): Promise<AIReport> => {
  return AIBusinessIntelligenceService.getInstance().generateBusinessIntelligenceReport(
    businessData,
    userContext
  );
};

export const formatTZS = AIBusinessIntelligenceService.formatTZS;
export const calculateGrowthPercentage = AIBusinessIntelligenceService.calculateGrowthPercentage;
export const validateBusinessData = AIBusinessIntelligenceService.validateBusinessData;