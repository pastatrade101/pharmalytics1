// Application constants for Shop Sales AI - Enhanced Pharmacy Management System
export const APP_NAME = 'Pharmacy Management System';
export const APP_VERSION = '2.1.0';
export const APP_DESCRIPTION = 'Complete pharmacy management solution with AI-powered insights for inventory, sales, and business intelligence.';

// Environment detection - PRODUCTION MODE
export const isDevelopment = false; // Set to false to disable development mode

// Enhanced User Roles with Super Admin - Simplified to only 2 roles plus admin roles
export type UserRole = 'super_admin' | 'admin' | 'owner' | 'product_manager' | 'salesman';

// Enhanced View Types with Super Admin Views
export type View = 
  // Super Admin Views
  | 'super-admin-dashboard'
  | 'all-pharmacies'
  | 'pharmacy-analytics' 
  | 'system-overview'
  | 'software-settings'
  
  // Standard Views
  | 'home'
  | 'pos-system'
  | 'sales-history'
  | 'returns-refunds'
  | 'prescriptions'
  | 'customer-accounts'
  | 'product-management'
  | 'batch-tracking'
  | 'expiry-management'
  | 'stock-transfers'
  | 'reorder-management'
  | 'sales-reports'
  | 'inventory-reports'
  | 'financial-reports'
  | 'customer-reports'
  | 'supplier-reports'
  | 'user-management'
  | 'branch-management'
  | 'audit-logs'
  | 'ai-business-intelligence'
  | 'notifications'
  | 'mobile-manager'
  | 'profile'
  | 'settings';

// Role-based permissions with Super Admin - Updated for simplified roles
export const RolePermissions: Record<UserRole, View[]> = {
  super_admin: [
    'super-admin-dashboard',
    'all-pharmacies', 
    'pharmacy-analytics',
    'system-overview',
    'software-settings',
    'profile'
  ],
  admin: [
    'home',
    'pos-system',
    'sales-history',
    'returns-refunds',
    'prescriptions',
    'customer-accounts',
    'product-management',
    'batch-tracking',
    'expiry-management',
    'stock-transfers', 
    'reorder-management',
    'sales-reports',
    'inventory-reports',
    'financial-reports',
    'customer-reports',
    'supplier-reports',
    'user-management',
    'branch-management',
    'audit-logs',
    'ai-business-intelligence',
    'notifications',
    'mobile-manager',
    'profile',
    'settings'
  ],
  owner: [
    'home',
    'sales-reports',
    'inventory-reports', 
    'financial-reports',
    'customer-reports',
    'supplier-reports',
    'user-management',
    'branch-management',
    'audit-logs',
    'ai-business-intelligence',
    'notifications',
    'mobile-manager',
    'profile',
    'settings'
  ],
  product_manager: [
    'home',
    'pos-system',
    'sales-history',
    'returns-refunds',
    'prescriptions',
    'customer-accounts',
    'product-management',
    'batch-tracking',
    'expiry-management',
    'stock-transfers',
    'reorder-management',
    'sales-reports',
    'inventory-reports',
    'financial-reports',
    'customer-reports',
    'notifications',
    'mobile-manager',
    'profile'
  ],
  salesman: [
    'home',
    'pos-system',
    'sales-history',
    'returns-refunds',
    'prescriptions',
    'customer-accounts',
    'profile'
  ]
};

// Legacy export for backward compatibility
export const ROLE_PERMISSIONS = RolePermissions;

// Role Colors for UI styling - Updated for simplified roles
export const ROLE_COLORS: Record<UserRole, string> = {
  super_admin: 'bg-purple-100 text-purple-800 border-purple-200',
  admin: 'bg-red-100 text-red-800 border-red-200',
  owner: 'bg-blue-100 text-blue-800 border-blue-200',
  product_manager: 'bg-orange-100 text-orange-800 border-orange-200',
  salesman: 'bg-cyan-100 text-cyan-800 border-cyan-200'
};

// Licensed Roles (roles that may require professional licensing) - Updated
export const LICENSED_ROLES: UserRole[] = ['owner', 'product_manager'];

// Role Requirements and Qualifications - Updated for simplified roles
export const ROLE_REQUIREMENTS: Record<UserRole, string[]> = {
  super_admin: [
    'System administration experience',
    'Full platform oversight',
    'Software development background preferred'
  ],
  admin: [
    'Pharmacy management experience',
    'Staff supervision skills',
    'Knowledge of pharmaceutical regulations',
    'Computer proficiency'
  ],
  owner: [
    'Pharmacy license (where required)',
    'Business management experience',
    'Knowledge of pharmaceutical regulations',
    'Strategic planning skills'
  ],
  product_manager: [
    'Product catalog management experience',
    'Supplier relationship management',
    'Pricing strategy knowledge',
    'Inventory optimization skills',
    'Pharmaceutical knowledge required'
  ],
  salesman: [
    'Customer service skills',
    'Basic pharmaceutical knowledge',
    'Sales experience preferred',
    'Communication skills'
  ]
};

// Enhanced Payment Methods for POS System - Clean structure for pharmacy operations
export const PAYMENT_METHODS = [
  // Cash Payment
  { 
    value: 'cash',
    label: 'Cash Payment',
    category: 'cash',
    icon: '💵',
    requiresChange: true,
    requiresReference: false,
    description: 'Physical cash payment with change calculation',
    fee: 0
  },

  // Mobile Money Options
  { 
    value: 'mpesa',
    label: 'M-PESA',
    category: 'mobile-money',
    icon: '📱',
    requiresChange: false,
    requiresReference: true,
    description: 'M-PESA mobile money transfer',
    fee: 0.01 // 1% transaction fee
  },
  { 
    value: 'tigo-pesa',
    label: 'Tigo Pesa',
    category: 'mobile-money',
    icon: '💰',
    requiresChange: false,
    requiresReference: true,
    description: 'Tigo Pesa mobile payment',
    fee: 0.01
  },
  { 
    value: 'halopesa',
    label: 'HaloPesa',
    category: 'mobile-money',
    icon: '🏦',
    requiresChange: false,
    requiresReference: true,
    description: 'HaloPesa mobile wallet',
    fee: 0.01
  },
  { 
    value: 'airtel-money',
    label: 'Airtel Money',
    category: 'mobile-money',
    icon: '📞',
    requiresChange: false,
    requiresReference: true,
    description: 'Airtel Money mobile payment',
    fee: 0.01
  },

  // Card Payments
  { 
    value: 'card',
    label: 'Card Payment',
    category: 'card',
    icon: '💳',
    requiresChange: false,
    requiresReference: true,
    description: 'Debit or credit card payment',
    fee: 0.025 // 2.5% processing fee
  },

  // Bank Transfer
  { 
    value: 'bank-transfer',
    label: 'Bank Transfer',
    category: 'bank',
    icon: '🏛️',
    requiresChange: false,
    requiresReference: true,
    description: 'Direct bank account transfer',
    fee: 0.005 // 0.5% transfer fee
  },

  // Insurance
  { 
    value: 'insurance',
    label: 'Health Insurance',
    category: 'insurance',
    icon: '🛡️',
    requiresChange: false,
    requiresReference: true,
    description: 'Health insurance coverage payment',
    fee: 0
  },

  // Store Credit
  { 
    value: 'store-credit',
    label: 'Store Credit',
    category: 'credit',
    icon: '🎫',
    requiresChange: false,
    requiresReference: false,
    description: 'Customer store credit balance',
    fee: 0
  }
] as const;

export type PaymentMethodValue = typeof PAYMENT_METHODS[number]['value'];

// AI Status Messages for System Display
export const AI_STATUS_MESSAGES = {
  connecting: {
    label: 'Connecting',
    description: 'Establishing connection to AI services...',
    icon: '🔄',
    bgColor: 'bg-yellow-50',
    textColor: 'text-yellow-800',
    borderColor: 'border-yellow-200'
  },
  ready: {
    label: 'AI Ready',
    description: 'AI analytics and insights are fully operational',
    icon: '🤖',
    bgColor: 'bg-green-50',
    textColor: 'text-green-800',
    borderColor: 'border-green-200'
  },
  fallback: {
    label: 'Fallback Mode',
    description: 'Using local analytics while AI services reconnect',
    icon: '⚡',
    bgColor: 'bg-blue-50',
    textColor: 'text-blue-800',
    borderColor: 'border-blue-200'
  },
  'quota-exceeded': {
    label: 'Quota Exceeded',
    description: 'AI service limits reached. Using fallback analytics',
    icon: '📊',
    bgColor: 'bg-orange-50',
    textColor: 'text-orange-800',
    borderColor: 'border-orange-200'
  },
  'auth-error': {
    label: 'Auth Error',
    description: 'AI service authentication issue. Check configuration',
    icon: '🔐',
    bgColor: 'bg-red-50',
    textColor: 'text-red-800',
    borderColor: 'border-red-200'
  },
  offline: {
    label: 'Offline',
    description: 'AI services unavailable. Operating in offline mode',
    icon: '📱',
    bgColor: 'bg-gray-50',
    textColor: 'text-gray-800',
    borderColor: 'border-gray-200'
  }
} as const;

export type AIStatusMessage = typeof AI_STATUS_MESSAGES[keyof typeof AI_STATUS_MESSAGES];

// Quick Actions for Dashboard - Updated for simplified roles
export const QUICK_ACTIONS = [
  {
    id: 'pos-system',
    title: 'Point of Sale',
    description: 'Process sales and transactions',
    icon: 'ShoppingCart',
    color: 'bg-blue-500',
    roles: ['salesman', 'product_manager', 'admin']
  },
  {
    id: 'product-management',
    title: 'Manage Products',
    description: 'Add, edit, and organize inventory',
    icon: 'Package',
    color: 'bg-green-500',
    roles: ['product_manager', 'admin']
  },
  {
    id: 'sales-reports',
    title: 'Sales Reports',
    description: 'View sales analytics and reports',
    icon: 'TrendingUp',
    color: 'bg-purple-500',
    roles: ['owner', 'product_manager', 'admin']
  },
  {
    id: 'inventory-reports',
    title: 'Inventory Reports',
    description: 'Monitor stock levels and inventory',
    icon: 'BarChart3',
    color: 'bg-orange-500',
    roles: ['owner', 'product_manager', 'admin']
  },
  {
    id: 'user-management',
    title: 'Manage Users',
    description: 'Add and manage pharmacy staff',
    icon: 'Users',
    color: 'bg-indigo-500',
    roles: ['owner', 'admin']
  },
  {
    id: 'expiry-management',
    title: 'Expiry Management',
    description: 'Track and manage product expiration dates',
    icon: 'Calendar',
    color: 'bg-red-500',
    roles: ['product_manager', 'admin']
  }
];

// Roles that owners can create when managing users - Updated to only include the 2 main roles
export const OWNER_CREATABLE_ROLES: UserRole[] = ['product_manager', 'salesman'];

// Role display names - Updated for simplified roles
export const ROLE_DISPLAY_NAMES: Record<UserRole, string> = {
  super_admin: 'Software Owner',
  admin: 'Administrator',
  owner: 'Pharmacy Owner',
  product_manager: 'Product Manager',
  salesman: 'Salesman'
};

// Role descriptions - Updated for simplified roles
export const ROLE_DESCRIPTIONS: Record<UserRole, string> = {
  super_admin: 'Full system access with oversight of all pharmacies and software management capabilities.',
  admin: 'Complete pharmacy management access including all operational and administrative functions.',
  owner: 'Strategic oversight with access to reports, analytics, and user management. Focused on business intelligence and decision-making.',
  product_manager: 'Specialized in product catalog management, inventory control, pricing strategies, supplier relationships, and comprehensive operational management including inventory, sales, staff coordination, and daily operations.',
  salesman: 'Customer-facing role focused on sales transactions, customer service, prescription management, and point-of-sale operations including transaction processing and customer assistance.'
};

// Insurance Providers for POS System
export const INSURANCE_PROVIDERS = [
  { id: 'nhf', name: 'National Health Fund (NHF)', code: 'NHF', coverage: 0.8 },
  { id: 'nhif', name: 'National Health Insurance Fund (NHIF)', code: 'NHIF', coverage: 0.75 },
  { id: 'private_insurance', name: 'Private Insurance', code: 'PI', coverage: 0.9 },
  { id: 'corporate', name: 'Corporate Insurance', code: 'CORP', coverage: 0.85 },
  { id: 'student', name: 'Student Insurance', code: 'STU', coverage: 0.7 },
  { id: 'senior', name: 'Senior Citizen Coverage', code: 'SEN', coverage: 0.6 },
  { id: 'disability', name: 'Disability Benefits', code: 'DIS', coverage: 0.95 },
  { id: 'emergency', name: 'Emergency Coverage', code: 'EMG', coverage: 0.5 }
] as const;

export type InsuranceProvider = typeof INSURANCE_PROVIDERS[number];

// Enhanced Currency Configuration
export const SUPPORTED_CURRENCIES = [
  { code: 'TZS', name: 'Tanzanian Shilling', symbol: 'TSh' },
  { code: 'USD', name: 'US Dollar', symbol: '$' },
  { code: 'EUR', name: 'Euro', symbol: '€' },
  { code: 'GBP', name: 'British Pound', symbol: '£' },
  { code: 'KES', name: 'Kenyan Shilling', symbol: 'KSh' },
  { code: 'UGX', name: 'Ugandan Shilling', symbol: 'USh' },
  { code: 'RWF', name: 'Rwandan Franc', symbol: 'RF' },
  { code: 'ZAR', name: 'South African Rand', symbol: 'R' }
] as const;

export type CurrencyCode = typeof SUPPORTED_CURRENCIES[number]['code'];

// Comprehensive Product Categories for Pharmacy Management
export const PRODUCT_CATEGORIES = [
  'Prescription Medicines',
  'Over-the-Counter',
  'Pain Relief', 
  'Antibiotics',
  'Vitamins & Supplements',
  'Cold & Flu',
  'Digestive Health',
  'Dermatological',
  'Baby & Child Care',
  'Medical Devices',
  'First Aid',
  'Personal Care'
] as const;

export type ProductCategory = typeof PRODUCT_CATEGORIES[number];

// Enhanced Measurement Units
export const MEASUREMENT_UNITS = [
  'tablets', 'capsules', 'bottles', 'boxes', 'tubes', 'sachets',
  'vials', 'ampoules', 'strips', 'pieces', 'ml', 'mg', 'g', 'kg'
] as const;

export type MeasurementUnit = typeof MEASUREMENT_UNITS[number];

// Application Status Types
export type AppStatus = 'loading' | 'ready' | 'error' | 'offline' | 'maintenance';

// Enhanced Error Types
export type ErrorType = 'auth' | 'network' | 'validation' | 'permission' | 'ai' | 'system' | 'critical';

export interface AppError {
  id: string;
  type: ErrorType;
  message: string;
  description?: string;
  context?: string;
  timestamp: Date;
  isPermissionError?: boolean;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

// AI Connection Status
export type AIStatus = 'connecting' | 'ready' | 'fallback' | 'quota-exceeded' | 'auth-error' | 'offline';

// Enhanced Notification Types for Pharmacy Operations
export interface PharmacyNotification {
  id: string;
  type: 'expiry_alert' | 'low_stock' | 'out_of_stock' | 'sales_milestone' | 'system_update' | 'audit_log';
  title: string;
  message: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  timestamp: Date;
  isRead: boolean;
  actionUrl?: string;
  metadata?: Record<string, any>;
}

// Time periods for reports and analytics
export const TIME_PERIODS = [
  { label: 'Today', value: 'today' },
  { label: 'Yesterday', value: 'yesterday' },
  { label: 'This Week', value: 'this_week' },
  { label: 'Last Week', value: 'last_week' },
  { label: 'This Month', value: 'this_month' },
  { label: 'Last Month', value: 'last_month' },
  { label: 'This Quarter', value: 'this_quarter' },
  { label: 'This Year', value: 'this_year' },
  { label: 'Custom Range', value: 'custom' }
] as const;

export type TimePeriod = typeof TIME_PERIODS[number]['value'];

// Super Admin specific constants - PRODUCTION EMAIL DOMAINS
export const SUPER_ADMIN_EMAIL_DOMAINS = [
  '@pharmacyms.com', 
  '@admin.pharmacyms.com',
  '@superadmin.pharmacyms.com',
  '@gmail.com'
];

export interface SuperAdminMetrics {
  totalPharmacies: number;
  activePharmacies: number;
  totalUsers: number;
  totalRevenue: number;
  monthlyGrowth: number;
  systemHealth: 'excellent' | 'good' | 'warning' | 'critical';
}

export interface PharmacyOverview {
  id: string;
  name: string;
  owner: string;
  location: string;
  status: 'active' | 'inactive' | 'suspended';
  createdAt: Date;
  lastActivity: Date;
  totalUsers: number;
  monthlyRevenue: number;
  inventoryValue: number;
  healthScore: number;
}

// Default Application Settings
export const DEFAULT_SETTINGS = {
  currency: 'TZS' as CurrencyCode,
  timezone: 'Africa/Dar_es_Salaam',
  dateFormat: 'DD/MM/YYYY',
  timeFormat: '24h',
  language: 'english',
  theme: 'light',
  notifications: {
    email: true,
    browser: true,
    mobile: false
  },
  inventory: {
    lowStockThreshold: 10,
    autoReorderEnabled: false,
    expiryAlertDays: 30
  },
  sales: {
    taxRate: 18, // VAT rate for Tanzania
    discountEnabled: true,
    loyaltyProgram: false
  }
} as const;

// Validation Constants
export const VALIDATION_RULES = {
  password: {
    minLength: 8,
    requireUppercase: true,
    requireLowercase: true,
    requireNumbers: true,
    requireSpecialChars: false
  },
  product: {
    nameMaxLength: 100,
    skuMaxLength: 50,
    batchNumberMaxLength: 50,
    descriptionMaxLength: 500
  },
  shop: {
    nameMaxLength: 100,
    addressMaxLength: 200,
    phoneMaxLength: 20
  },
  user: {
    nameMaxLength: 100,
    emailMaxLength: 150
  }
} as const;

// API Configuration
export const API_CONFIG = {
  baseUrl: process.env.NODE_ENV === 'production' 
    ? 'https://your-production-api.com' 
    : 'http://localhost:3000',
  timeout: 30000, // 30 seconds
  retryAttempts: 3,
  retryDelay: 1000 // 1 second
} as const;

// Feature Flags - Enhanced for Pharmacy Management
export const FEATURE_FLAGS = {
  aiAnalytics: true,
  batchTracking: true,
  prescriptionManagement: true,
  mobileApp: true,
  offlineMode: true,
  multiCurrency: true,
  advancedReports: true,
  auditLogs: true,
  realTimeNotifications: true,
  barcodePrinting: true,
  customerLoyalty: false, // Coming soon
  deliveryManagement: false, // Coming soon
  insuranceClaims: false, // Coming soon
  telemedicine: false, // Coming soon
  superAdminPortal: true // New feature
} as const;

export type FeatureFlag = keyof typeof FEATURE_FLAGS;

// Debug and Development Constants
export const DEBUG_CONFIG = {
  enableLogging: isDevelopment,
  enableProfiling: isDevelopment,
  mockDataEnabled: isDevelopment,
  skipAuthInDev: false,
  verboseErrors: isDevelopment
} as const;

// Super Admin restricted views
export const SUPER_ADMIN_VIEWS: View[] = [
  'super-admin-dashboard',
  'all-pharmacies', 
  'pharmacy-analytics',
  'system-overview',
  'software-settings'
];

// Export utilities for role and permission checking
export const hasPermission = (userRole: UserRole, view: View): boolean => {
  return RolePermissions[userRole]?.includes(view) ?? false;
};

// Enhanced permission checking with super admin view restrictions
export const canAccessView = (userRole: UserRole, view: View): boolean => {
  // Super admin views are only accessible to super admins
  if (SUPER_ADMIN_VIEWS.includes(view)) {
    return userRole === 'super_admin';
  }
  
  // Check regular permissions for other views
  return hasPermission(userRole, view);
};

// Get appropriate error message for access denied scenarios
export const getAccessDeniedMessage = (userRole: UserRole, attemptedView: View): string => {
  if (SUPER_ADMIN_VIEWS.includes(attemptedView)) {
    return `Access denied: The '${attemptedView}' feature is restricted to system administrators only. Your current role '${getRoleDisplayName(userRole)}' does not have the required permissions.`;
  }
  
  return `Access denied: Your role '${getRoleDisplayName(userRole)}' does not have permission to access '${attemptedView}'.`;
};

// Get detailed explanation for super admin email access denial
export const getSuperAdminEmailDenialReason = (email: string): string => {
  if (!email || !email.includes('@')) {
    return 'Invalid email format provided.';
  }
  
  const emailLower = email.toLowerCase().trim();
  const domain = emailLower.split('@')[1];
  
  if (!domain) {
    return 'Email domain could not be determined.';
  }
  
  const authorizedDomains = SUPER_ADMIN_EMAIL_DOMAINS.map(d => d.toLowerCase().replace('@', ''));
  const hasAuthorizedDomain = authorizedDomains.some(authDomain => domain === authDomain);
  
  if (hasAuthorizedDomain) {
    return 'Email domain is authorized but validation failed. Please contact support.';
  }
  
  return `Email domain '${domain}' is not authorized. Only ${SUPER_ADMIN_EMAIL_DOMAINS.join(', ')} domains are permitted for super admin access.`;
};

export const getRoleDisplayName = (role: UserRole): string => {
  return ROLE_DISPLAY_NAMES[role] || role;
};

export const isSuperAdmin = (userRole: UserRole): boolean => {
  return userRole === 'super_admin';
};

export const canAccessSuperAdminPortal = (userEmail: string): boolean => {
  // Ensure email is provided and valid
  if (!userEmail || typeof userEmail !== 'string' || !userEmail.includes('@')) {
    return false;
  }
  
  const emailLower = userEmail.toLowerCase().trim();
  
  // PRODUCTION MODE: Strict email domain validation
  const isAuthorizedDomain = SUPER_ADMIN_EMAIL_DOMAINS.some(domain => 
    emailLower.endsWith(domain.toLowerCase())
  );
  
  const hasAccess = isAuthorizedDomain;
  
  // Log access attempts for security monitoring
  if (!hasAccess) {
    console.warn(`🚫 Super admin access denied for email: ${userEmail}. Only authorized domains (${SUPER_ADMIN_EMAIL_DOMAINS.join(', ')}) are permitted.`);
  } else {
    console.log(`✅ Super admin access granted for authorized email: ${userEmail}`);
  }
  
  return hasAccess;
};

// Enhanced error handling for different user types
export const getDefaultErrorMessage = (role: UserRole): string => {
  if (role === 'super_admin') {
    return 'System error occurred. Check logs for details.';
  }
  return 'An error occurred. Please try again or contact support.';
};

// Check if user can create other users
export const canCreateUsers = (userRole: UserRole): boolean => {
  return ['owner', 'admin', 'super_admin'].includes(userRole);
};

// Check if user can import products - FIXED: Explicit role check for product_manager
export const canImportProducts = (userRole: UserRole): boolean => {
  // Explicit check to ensure product_manager is always included
  const allowedRoles: UserRole[] = ['product_manager', 'owner', 'admin', 'super_admin'];
  const hasPermission = allowedRoles.includes(userRole);
  
  // Debug logging to help identify permission issues
  if (typeof window !== 'undefined' && (window as any).__PHARMACY_MS_DEBUG__) {
    console.log('🔍 canImportProducts check:', {
      userRole,
      allowedRoles,
      hasPermission,
      timestamp: new Date().toISOString()
    });
  }
  
  return hasPermission;
};

// Check if user can manage products
export const canManageProducts = (userRole: UserRole): boolean => {
  return ['product_manager', 'admin', 'super_admin'].includes(userRole);
};

// Get creatable roles for a user role - Updated for simplified roles
export const getCreatableRoles = (userRole: UserRole): UserRole[] => {
  switch (userRole) {
    case 'super_admin':
      return ['admin', 'owner', 'product_manager', 'salesman'];
    case 'admin':
      return ['owner', 'product_manager', 'salesman'];
    case 'owner':
      return OWNER_CREATABLE_ROLES;
    default:
      return [];
  }
};

// Check if a role is hierarchically above another - Updated for simplified roles
export const isRoleAbove = (higherRole: UserRole, lowerRole: UserRole): boolean => {
  const hierarchy: Record<UserRole, number> = {
    super_admin: 5,
    admin: 4,
    owner: 3,
    product_manager: 2,
    salesman: 1
  };
  
  return hierarchy[higherRole] > hierarchy[lowerRole];
};

// React DevTools configuration for debugging - DISABLED IN PRODUCTION
if (typeof window !== 'undefined' && DEBUG_CONFIG.enableLogging) {
  (window as any).__PHARMACY_MS_DEBUG__ = {
    version: APP_VERSION,
    isDevelopment,
    featureFlags: FEATURE_FLAGS,
    supportedCurrencies: SUPPORTED_CURRENCIES,
    productCategories: PRODUCT_CATEGORIES
  };
}