import { 
  collection,
  doc,
  addDoc,
  updateDoc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  serverTimestamp,
  Timestamp
} from 'firebase/firestore';
import { db } from './firebase-config';
import { Shop, COLLECTIONS } from './firebase-types';

export class ShopService {

  /**
   * Create a new shop with pending status
   */
  static async createShop(shopData: Omit<Shop, 'id' | 'created_at' | 'updated_at' | 'status'>): Promise<Shop> {
    try {
      const shopWithDefaults = {
        ...shopData,
        status: 'pending' as const, // New shops start as pending
        created_at: serverTimestamp(),
        updated_at: serverTimestamp()
      };

      const docRef = await addDoc(collection(db, 'shops'), shopWithDefaults);
      
      const createdShop: Shop = {
        id: docRef.id,
        ...shopData,
        status: 'pending',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      console.log('✅ Shop created successfully with pending status:', createdShop.id);
      return createdShop;
    } catch (error: any) {
      console.error('❌ Error creating shop:', error);
      throw error;
    }
  }

  /**
   * Get shop by ID
   */
  static async getShopById(shopId: string): Promise<Shop | null> {
    try {
      const docRef = doc(db, 'shops', shopId);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          ...data,
          created_at: data.created_at instanceof Timestamp ? data.created_at.toDate().toISOString() : data.created_at,
          updated_at: data.updated_at instanceof Timestamp ? data.updated_at.toDate().toISOString() : data.updated_at
        } as Shop;
      }

      return null;
    } catch (error: any) {
      console.error('❌ Error fetching shop:', error);
      throw error;
    }
  }

  /**
   * Update shop status (for super admin use)
   */
  static async updateShopStatus(shopId: string, status: 'pending' | 'active' | 'inactive'): Promise<void> {
    try {
      const docRef = doc(db, 'shops', shopId);
      await updateDoc(docRef, {
        status,
        updated_at: serverTimestamp()
      });

      console.log(`✅ Shop ${shopId} status updated to: ${status}`);
    } catch (error: any) {
      console.error('❌ Error updating shop status:', error);
      throw error;
    }
  }

  /**
   * Update shop information
   */
  static async updateShop(shopId: string, updates: Partial<Omit<Shop, 'id' | 'created_at'>>): Promise<void> {
    try {
      const docRef = doc(db, 'shops', shopId);
      await updateDoc(docRef, {
        ...updates,
        updated_at: serverTimestamp()
      });

      console.log('✅ Shop updated successfully:', shopId);
    } catch (error: any) {
      console.error('❌ Error updating shop:', error);
      throw error;
    }
  }

  /**
   * Check if shop name is available
   */
  static async isShopNameAvailable(name: string): Promise<boolean> {
    try {
      const q = query(
        collection(db, 'shops'),
        where('name', '==', name)
      );
      
      const querySnapshot = await getDocs(q);
      return querySnapshot.empty;
    } catch (error: any) {
      console.error('❌ Error checking shop name availability:', error);
      throw error;
    }
  }

  /**
   * Get all shops (for super admin)
   */
  static async getAllShops(): Promise<Shop[]> {
    try {
      if (!db) {
        throw new Error('Firebase database not initialized');
      }
      
      const q = query(
        collection(db, 'shops'),
        orderBy('created_at', 'desc')
      );
      
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          created_at: data.created_at instanceof Timestamp ? data.created_at.toDate().toISOString() : data.created_at,
          updated_at: data.updated_at instanceof Timestamp ? data.updated_at.toDate().toISOString() : data.updated_at
        } as Shop;
      });
    } catch (error: any) {
      console.error('❌ Error fetching all shops:', error);
      throw error;
    }
  }

  /**
   * Get shops by status (for super admin)
   */
  static async getShopsByStatus(status: 'pending' | 'active' | 'inactive'): Promise<Shop[]> {
    try {
      if (!db) {
        throw new Error('Firebase database not initialized');
      }
      
      const q = query(
        collection(db, 'shops'),
        where('status', '==', status),
        orderBy('created_at', 'desc')
      );
      
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          created_at: data.created_at instanceof Timestamp ? data.created_at.toDate().toISOString() : data.created_at,
          updated_at: data.updated_at instanceof Timestamp ? data.updated_at.toDate().toISOString() : data.updated_at
        } as Shop;
      });
    } catch (error: any) {
      console.error('❌ Error fetching shops by status:', error);
      throw error;
    }
  }

  /**
   * Get pending shops count (for super admin dashboard)
   */
  static async getPendingShopsCount(): Promise<number> {
    try {
      const q = query(
        collection(db, 'shops'),
        where('status', '==', 'pending')
      );
      
      const querySnapshot = await getDocs(q);
      return querySnapshot.size;
    } catch (error: any) {
      console.error('❌ Error getting pending shops count:', error);
      return 0;
    }
  }

  /**
   * Get shops by owner ID
   */
  static async getShopsByOwner(ownerId: string): Promise<Shop[]> {
    try {
      const q = query(
        collection(db, 'shops'),
        where('owner_id', '==', ownerId),
        orderBy('created_at', 'desc')
      );
      
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          created_at: data.created_at instanceof Timestamp ? data.created_at.toDate().toISOString() : data.created_at,
          updated_at: data.updated_at instanceof Timestamp ? data.updated_at.toDate().toISOString() : data.updated_at
        } as Shop;
      });
    } catch (error: any) {
      console.error('❌ Error fetching shops by owner:', error);
      throw error;
    }
  }

  /**
   * Check if shop is active
   */
  static async isShopActive(shopId: string): Promise<boolean> {
    try {
      const shop = await this.getShopById(shopId);
      return shop?.status === 'active' || false;
    } catch (error: any) {
      console.error('❌ Error checking shop status:', error);
      return false;
    }
  }

  /**
   * Activate shop (super admin only)
   */
  static async activateShop(shopId: string): Promise<void> {
    await this.updateShopStatus(shopId, 'active');
  }

  /**
   * Deactivate shop (super admin only)
   */
  static async deactivateShop(shopId: string): Promise<void> {
    await this.updateShopStatus(shopId, 'inactive');
  }

  /**
   * Set shop to pending (super admin only)
   */
  static async setPendingShop(shopId: string): Promise<void> {
    await this.updateShopStatus(shopId, 'pending');
  }

  /**
   * Get shop statistics (for super admin dashboard)
   */
  static async getShopStatistics(): Promise<{
    total: number;
    active: number;
    pending: number;
    inactive: number;
  }> {
    try {
      const allShops = await this.getAllShops();
      
      return {
        total: allShops.length,
        active: allShops.filter(shop => shop.status === 'active').length,
        pending: allShops.filter(shop => shop.status === 'pending').length,
        inactive: allShops.filter(shop => shop.status === 'inactive').length
      };
    } catch (error: any) {
      console.error('❌ Error getting shop statistics:', error);
      return { total: 0, active: 0, pending: 0, inactive: 0 };
    }
  }
}