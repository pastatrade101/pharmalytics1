/**
 * Currency utilities for TZS (Tanzanian Shilling) formatting and calculations
 */

export const CURRENCY_CONFIG = {
  code: 'TZS',
  symbol: 'TSh',
  name: 'Tanzanian Shilling',
  locale: 'sw-TZ'
};

/**
 * Format amount as TZS currency with safe handling for NaN and invalid values
 */
export function formatTZS(amount: number | string | null | undefined): string {
  // Handle edge cases
  if (amount === null || amount === undefined) {
    return `${CURRENCY_CONFIG.symbol} 0`;
  }
  
  // Convert string to number if necessary
  const numericAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
  
  // Handle NaN or invalid numbers
  if (isNaN(numericAmount) || !isFinite(numericAmount)) {
    console.warn('formatTZS received invalid amount:', amount);
    return `${CURRENCY_CONFIG.symbol} 0`;
  }
  
  // Ensure we have a positive number for currency display
  const safeAmount = Math.max(0, numericAmount);
  
  try {
    return new Intl.NumberFormat(CURRENCY_CONFIG.locale, {
      style: 'currency',
      currency: CURRENCY_CONFIG.code,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(safeAmount);
  } catch (error) {
    // Fallback formatting if Intl fails
    console.warn('Intl.NumberFormat failed, using fallback:', error);
    return `${CURRENCY_CONFIG.symbol} ${safeAmount.toLocaleString('en-US')}`;
  }
}

/**
 * Format amount as TZS with symbol prefix with safe handling
 */
export function formatTZSWithSymbol(amount: number | string | null | undefined): string {
  // Handle edge cases
  if (amount === null || amount === undefined) {
    return `${CURRENCY_CONFIG.symbol} 0`;
  }
  
  // Convert string to number if necessary
  const numericAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
  
  // Handle NaN or invalid numbers
  if (isNaN(numericAmount) || !isFinite(numericAmount)) {
    console.warn('formatTZSWithSymbol received invalid amount:', amount);
    return `${CURRENCY_CONFIG.symbol} 0`;
  }
  
  // Ensure we have a positive number
  const safeAmount = Math.max(0, numericAmount);
  
  return `${CURRENCY_CONFIG.symbol} ${safeAmount.toLocaleString('en-US')}`;
}

/**
 * Parse TZS string to number
 */
export function parseTZS(value: string): number {
  // Remove currency symbols and spaces, parse as number
  const cleanValue = value.replace(/[^\d.-]/g, '');
  return parseFloat(cleanValue) || 0;
}

/**
 * Validate TZS amount
 */
export function isValidTZSAmount(value: string | number): boolean {
  const amount = typeof value === 'string' ? parseTZS(value) : value;
  return !isNaN(amount) && amount >= 0;
}

/**
 * Format compact TZS (K, M, B notation)
 */
export function formatCompactTZS(amount: number): string {
  if (amount >= 1000000000) {
    return `${CURRENCY_CONFIG.symbol} ${(amount / 1000000000).toFixed(1)}B`;
  } else if (amount >= 1000000) {
    return `${CURRENCY_CONFIG.symbol} ${(amount / 1000000).toFixed(1)}M`;
  } else if (amount >= 1000) {
    return `${CURRENCY_CONFIG.symbol} ${(amount / 1000).toFixed(1)}K`;
  } else {
    return formatTZSWithSymbol(amount);
  }
}

/**
 * Calculate profit metrics for TZS amounts
 */
export function calculateProfitMetrics(cost: number, price: number) {
  const profit = price - cost;
  const margin = price > 0 ? (profit / price) * 100 : 0;
  const markup = cost > 0 ? (profit / cost) * 100 : 0;
  
  return {
    profit,
    margin,
    markup,
    profitFormatted: formatTZS(profit),
    marginFormatted: `${margin.toFixed(1)}%`,
    markupFormatted: `${markup.toFixed(1)}%`
  };
}

/**
 * TZS amount input helpers
 */
export const TZS_INPUT_PROPS = {
  type: 'number',
  min: 0,
  step: 100, // Step by 100 TZS for easier input
  placeholder: '0'
};

/**
 * Common TZS amounts for quick selection
 */
export const COMMON_TZS_AMOUNTS = [
  500, 1000, 2000, 5000, 10000, 20000, 50000, 100000
];

/**
 * Price validation for TZS
 */
export function validateTZSPrice(cost: number, price: number): {
  isValid: boolean;
  errors: string[];
  warnings: string[];
} {
  const errors: string[] = [];
  const warnings: string[] = [];
  
  if (price <= 0) {
    errors.push('Price must be greater than 0 TZS');
  }
  
  if (cost < 0) {
    errors.push('Cost cannot be negative');
  }
  
  if (price <= cost) {
    errors.push('Selling price must be higher than cost price');
  }
  
  const margin = price > 0 ? ((price - cost) / price) * 100 : 0;
  
  if (margin < 10) {
    warnings.push('Profit margin is very low (under 10%)');
  } else if (margin > 200) {
    warnings.push('Profit margin is very high (over 200%) - verify pricing');
  }
  
  return {
    isValid: errors.length === 0,
    errors,
    warnings
  };
}