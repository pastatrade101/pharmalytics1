// Gemini MCP Integration for Sales Analytics
interface GeminiConfig {
  apiKey: string;
  model: string;
  fallbackModel?: string;
  temperature: number;
}

interface SalesAnalysisPrompt {
  salesData: any[];
  dateRange: string;
  previousPeriodData?: any[];
}

// Environment variable helper
const getEnvVar = (key: string, fallback: string) => {
  if (typeof window !== 'undefined') {
    return fallback; // Client-side fallback
  }
  try {
    return process?.env?.[key] || fallback;
  } catch {
    return fallback;
  }
};

// Available Gemini models in order of preference
const GEMINI_MODELS = [
  'gemini-1.5-flash',      // Most cost-effective and fast
  'gemini-1.5-pro',       // More capable but slower
  'gemini-pro',           // Original Gemini Pro
  'gemini-1.0-pro'        // Fallback model
];

export class GeminiMCPConnector {
  private config: GeminiConfig;
  private workingModel: string | null = null;
  private quotaExceeded: boolean = false; // Track quota status
  private lastQuotaCheck: number = 0; // Track last quota check

  constructor(config: GeminiConfig) {
    this.config = config;
  }

  async generateSalesSummary(prompt: SalesAnalysisPrompt): Promise<any> {
    console.log('🤖 Gemini MCP: Generating sales summary with AI');
    
    // Check if we recently hit quota limits (avoid repeated API calls)
    const now = Date.now();
    if (this.quotaExceeded && (now - this.lastQuotaCheck) < 600000) { // 10 minutes cooldown
      console.log('💰 Recently hit quota limits, using enhanced mock analysis immediately (cooldown period)');
      return await this.enhancedMockAnalysisWithQuotaNotice(prompt);
    }

    const systemPrompt = `You are an expert sales analyst AI specializing in small business retail analytics. Analyze the provided sales data and generate actionable insights for shop owners.

Your response should be a JSON object with this exact structure:
{
  "summary": "Brief overview of sales performance focusing on key achievements and concerns",
  "keyMetrics": {
    "totalRevenue": number,
    "totalTransactions": number,
    "averageTransactionValue": number,
    "topProduct": "product name"
  },
  "insights": [
    "Specific insight about sales patterns or customer behavior",
    "Analysis of product performance and trends",
    "Time-based patterns and seasonality observations"
  ],
  "recommendations": [
    "Specific actionable recommendation to improve sales",
    "Inventory or staffing suggestion based on data",
    "Marketing or operational improvement idea"
  ],
  "trends": {
    "salesTrend": "increasing|decreasing|stable",
    "peakHours": "specific time ranges when sales peak",
    "slowPeriods": "specific time ranges when sales are slow"
  },
  "alerts": [
    "Any urgent concerns or opportunities that need immediate attention"
  ]
}

Focus on:
- Practical, actionable insights
- Real business impact
- Specific recommendations the shop owner can implement today
- Alert them to any concerning patterns or opportunities

Respond only with valid JSON.`;

    const userPrompt = `Analyze this sales data for ${prompt.dateRange}:

Current Period Sales Data:
${JSON.stringify(prompt.salesData, null, 2)}

${prompt.previousPeriodData ? `Previous Period Comparison Data:
${JSON.stringify(prompt.previousPeriodData, null, 2)}` : ''}

Please provide detailed analysis focusing on:
1. Revenue performance and transaction patterns
2. Product performance and customer preferences  
3. Time-based sales patterns and peak hours
4. Actionable recommendations for immediate implementation
5. Any alerts or concerns that require attention

Return valid JSON only.`;

    try {
      // Use real Gemini API if API key is available and valid
      if (this.config.apiKey && this.config.apiKey.startsWith('AIza') && !this.config.apiKey.includes('mock')) {
        console.log('🤖 Attempting to use real Gemini API...');
        return await this.callGeminiWithFallback(systemPrompt, userPrompt);
      } else {
        console.log('🤖 Invalid/missing API key, using enhanced mock analysis...');
        return await this.enhancedMockAnalysis(prompt);
      }
    } catch (error: any) {
      console.error('🤖 Gemini MCP Error:', error);
      
      const errorMessage = error?.message || String(error);
      
      // Enhanced quota exceeded handling
      if (error.name === 'QuotaExceededError' || errorMessage.includes('quota') || errorMessage.includes('429') || errorMessage.includes('insufficient_quota')) {
        console.log('💰 Gemini quota exceeded - marking for cooldown period');
        this.quotaExceeded = true;
        this.lastQuotaCheck = now;
        return await this.enhancedMockAnalysisWithQuotaNotice(prompt);
      } else if (error.name === 'AuthenticationError' || errorMessage.includes('authentication') || errorMessage.includes('401') || errorMessage.includes('API_KEY_INVALID')) {
        console.log('🔑 Gemini authentication failed - API key issue');
        const mockResult = await this.enhancedMockAnalysis(prompt);
        mockResult.alerts = mockResult.alerts || [];
        mockResult.alerts.unshift('AI Analysis unavailable: Authentication failed. Please verify your Gemini API key configuration.');
        return mockResult;
      } else if (errorMessage.includes('network') || errorMessage.includes('fetch')) {
        console.log('🌐 Network connectivity issues detected');
        const mockResult = await this.enhancedMockAnalysis(prompt);
        mockResult.alerts = mockResult.alerts || [];
        mockResult.alerts.unshift('AI Analysis temporarily unavailable due to network connectivity issues. Using intelligent fallback analysis.');
        return mockResult;
      } else {
        console.log('❌ General Gemini error, falling back to enhanced mock analysis...');
        const mockResult = await this.enhancedMockAnalysis(prompt);
        mockResult.alerts = mockResult.alerts || [];
        mockResult.alerts.unshift('AI Analysis temporarily unavailable due to service issues. Using intelligent fallback analysis.');
        return mockResult;
      }
    }
  }

  private async enhancedMockAnalysisWithQuotaNotice(prompt: SalesAnalysisPrompt): Promise<any> {
    const mockResult = await this.enhancedMockAnalysis(prompt);
    mockResult.alerts = mockResult.alerts || [];
    mockResult.alerts.unshift('Gemini API quota exceeded. Using intelligent fallback analysis until quota is restored. Please check your Google Cloud billing plan at console.cloud.google.com/billing');
    mockResult.quotaExceeded = true; // Mark as quota exceeded
    mockResult.quotaInfo = {
      exceeded: true,
      resetTime: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // Estimate 24h reset
      upgradeUrl: 'https://console.cloud.google.com/billing',
      currentTier: 'Free Tier',
      dailyLimit: '50 requests'
    };
    return mockResult;
  }

  private async callGeminiWithFallback(systemPrompt: string, userPrompt: string): Promise<any> {
    // Try the configured model first, then fallback models
    const modelsToTry = [
      this.workingModel, // Previously working model (if any)
      this.config.model,
      this.config.fallbackModel,
      ...GEMINI_MODELS
    ].filter((model, index, array) => 
      model && array.indexOf(model) === index // Remove duplicates and null values
    );

    let lastError: any = null;

    for (const model of modelsToTry) {
      try {
        console.log(`🤖 Trying Gemini model: ${model}`);
        const result = await this.callGemini(systemPrompt, userPrompt, model);
        
        // Success! Remember this model for future calls and reset quota flag
        this.workingModel = model;
        this.quotaExceeded = false; // Reset quota exceeded flag on success
        console.log(`✅ Successfully used model: ${model}`);
        return result;
        
      } catch (error: any) {
        console.log(`❌ Model ${model} failed:`, error.message);
        lastError = error;
        
        // If it's a quota error, don't try other models
        if (error.name === 'QuotaExceededError' || 
            error.message?.includes('quota') || 
            error.message?.includes('429') || 
            error.message?.includes('insufficient_quota')) {
          console.log('💰 Quota exceeded error - stopping model attempts');
          break;
        }
        
        // If it's a model access error, try the next model
        if (error.message?.includes('model') && error.message?.includes('not found')) {
          continue;
        }
        
        // If it's a different error (auth, etc.), don't try other models
        break;
      }
    }

    // All models failed, throw the last error
    throw lastError || new Error('All Gemini models failed');
  }

  private async callGemini(systemPrompt: string, userPrompt: string, model: string): Promise<any> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout

    try {
      const requestBody = {
        contents: [
          {
            parts: [
              {
                text: `${systemPrompt}\n\nUser Request: ${userPrompt}`
              }
            ]
          }
        ],
        generationConfig: {
          temperature: this.config.temperature,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 2048,
          responseMimeType: "application/json"
        },
        safetySettings: [
          {
            category: "HARM_CATEGORY_HARASSMENT",
            threshold: "BLOCK_MEDIUM_AND_ABOVE"
          },
          {
            category: "HARM_CATEGORY_HATE_SPEECH",
            threshold: "BLOCK_MEDIUM_AND_ABOVE"
          },
          {
            category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
            threshold: "BLOCK_MEDIUM_AND_ABOVE"
          },
          {
            category: "HARM_CATEGORY_DANGEROUS_CONTENT",
            threshold: "BLOCK_MEDIUM_AND_ABOVE"
          }
        ]
      };

      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${this.config.apiKey}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(requestBody),
          signal: controller.signal
        }
      );

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorText = await response.text();
        let errorData;
        try {
          errorData = JSON.parse(errorText);
        } catch {
          errorData = { error: { message: errorText } };
        }
        
        console.error(`Gemini API Error (${model}):`, response.status, errorData);
        
        // Enhanced error handling for different status codes
        if (response.status === 429) {
          const quotaError = new Error(`Gemini API quota exceeded: ${errorData.error?.message || 'You exceeded your current quota, please check your plan and billing details.'}`);
          quotaError.name = 'QuotaExceededError';
          throw quotaError;
        } else if (response.status === 401 || response.status === 403) {
          const authError = new Error(`Gemini API authentication failed: ${errorData.error?.message || 'Invalid API key or insufficient permissions'}`);
          authError.name = 'AuthenticationError';
          throw authError;
        } else if (response.status === 404) {
          const modelError = new Error(`Gemini model not found: ${model}`);
          modelError.name = 'ModelNotFoundError';
          throw modelError;
        } else if (response.status >= 500) {
          const serverError = new Error(`Gemini API server error: ${response.status} - Please try again later`);
          serverError.name = 'ServerError';
          throw serverError;
        } else {
          throw new Error(`Gemini API error: ${response.status} ${errorData.error?.message || response.statusText}`);
        }
      }

      const data = await response.json();
      
      if (!data.candidates || !data.candidates[0] || !data.candidates[0].content) {
        throw new Error('Invalid response structure from Gemini API');
      }

      const content = data.candidates[0].content.parts[0].text;
      
      try {
        const parsedContent = JSON.parse(content);
        console.log('✅ Successfully parsed Gemini JSON response');
        return parsedContent;
      } catch (parseError) {
        console.error('Failed to parse Gemini response as JSON:', content);
        throw new Error('Invalid JSON response from Gemini - response was not valid JSON format');
      }

    } catch (error: any) {
      clearTimeout(timeoutId);
      
      if (error.name === 'AbortError') {
        throw new Error('Gemini API request timed out after 30 seconds');
      }
      
      throw error;
    }
  }

  private async enhancedMockAnalysis(prompt: SalesAnalysisPrompt): Promise<any> {
    // Simulate API call delay for realism
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    try {
      const salesData = prompt.salesData || [];
      const totalRevenue = salesData.reduce((sum, sale) => sum + (sale.totalPrice || 0), 0);
      const totalTransactions = salesData.length;
      const averageTransactionValue = totalTransactions > 0 ? totalRevenue / totalTransactions : 0;
      
      // Analyze products safely
      const productCounts: Record<string, number> = {};
      salesData.forEach(sale => {
        if (sale && sale.item) {
          productCounts[sale.item] = (productCounts[sale.item] || 0) + (sale.quantity || 1);
        }
      });
      
      const topProduct = Object.keys(productCounts).length > 0 ? 
        Object.keys(productCounts).reduce((a, b) => 
          productCounts[a] > productCounts[b] ? a : b
        ) : 'No sales';

      // Analyze time patterns safely
      const hours = salesData.map(sale => {
        try {
          if (sale && sale.timestamp) {
            const hour = new Date(sale.timestamp).getHours();
            return !isNaN(hour) && hour >= 0 && hour <= 23 ? hour : null;
          }
        } catch {
          return null;
        }
        return null;
      }).filter(hour => hour !== null);

      const peakHour = hours.length > 0 ? 
        hours.reduce((a, b, i, arr) => 
          arr.filter(v => v === a).length >= arr.filter(v => v === b).length ? a : b
        ) : null;

      // Generate insights based on actual data
      const insights = [];
      const recommendations = [];
      const alerts = [];

      if (totalTransactions === 0) {
        insights.push("No sales activity recorded today - this requires immediate investigation and action");
        recommendations.push("Check POS system functionality, verify staff availability, and review store hours");
        recommendations.push("Consider running promotional activities or customer outreach campaigns");
        alerts.push("URGENT: Zero sales detected - immediate management attention required");
      } else {
        // Revenue performance analysis
        if (totalRevenue > 500) {
          insights.push(`Exceptional sales performance with $${totalRevenue.toFixed(2)} revenue - this represents strong market engagement and effective sales execution`);
          recommendations.push("Analyze what drove today's success and implement strategies to replicate this performance");
        } else if (totalRevenue > 300) {
          insights.push(`Strong sales performance with $${totalRevenue.toFixed(2)} revenue showing healthy business momentum`);
          recommendations.push("Build on today's solid performance by identifying opportunities for incremental growth");
        } else if (totalRevenue > 150) {
          insights.push(`Moderate revenue performance at $${totalRevenue.toFixed(2)} with clear opportunities for improvement`);
          recommendations.push("Focus on upselling strategies and promotional activities to boost daily revenue");
        } else {
          insights.push(`Below-target revenue performance at $${totalRevenue.toFixed(2)} indicating need for immediate action`);
          recommendations.push("Implement aggressive promotional pricing and increase customer acquisition efforts");
          alerts.push("Low daily revenue - requires strategic intervention to meet business targets");
        }

        // Transaction value insights
        if (averageTransactionValue > 40) {
          insights.push(`Outstanding average transaction value of $${averageTransactionValue.toFixed(2)} demonstrates exceptional customer engagement and successful premium positioning`);
          recommendations.push("Maintain premium product mix and continue training staff on high-value selling techniques");
        } else if (averageTransactionValue > 25) {
          insights.push(`Good average transaction value of $${averageTransactionValue.toFixed(2)} shows healthy customer spending patterns with room for growth`);
          recommendations.push("Introduce complementary product suggestions and seasonal bundles to increase basket size");
        } else if (averageTransactionValue > 15) {
          insights.push(`Moderate transaction values averaging $${averageTransactionValue.toFixed(2)} indicate potential for strategic upselling initiatives`);
          recommendations.push("Train staff on cross-selling techniques and create attractive product bundle offers");
        } else {
          insights.push(`Lower average transaction value of $${averageTransactionValue.toFixed(2)} suggests significant opportunities for revenue optimization through strategic pricing and bundling`);
          recommendations.push("Implement comprehensive upselling training, create value-added bundles, and review pricing strategy");
        }

        // Product diversity and performance analysis
        const uniqueProducts = Object.keys(productCounts).length;
        if (uniqueProducts === 0) {
          insights.push("No product sales data available - requires immediate system verification and operational review");
          recommendations.push("Verify POS system functionality and ensure proper sales recording procedures");
          alerts.push("No product data recorded - critical system or operational issue detected");
        } else if (uniqueProducts === 1) {
          insights.push("Sales concentrated entirely on single product line - this creates significant business risk and missed revenue opportunities");
          recommendations.push("Aggressively promote product variety through strategic displays, staff recommendations, and targeted promotions");
          alerts.push("Product concentration risk - diversify sales mix to reduce business vulnerability");
        } else if (uniqueProducts > totalTransactions * 0.6) {
          insights.push(`Excellent product diversity with ${uniqueProducts} different items sold, demonstrating broad customer appeal and effective merchandising`);
          recommendations.push("Continue promoting product variety while identifying opportunities to increase quantity per transaction");
        } else if (uniqueProducts > totalTransactions * 0.3) {
          insights.push(`Good product mix diversity with ${uniqueProducts} items contributing to sales, showing balanced customer preferences`);
          recommendations.push("Analyze top-performing products and create strategic bundles to increase overall transaction value");
        } else {
          insights.push(`Limited product diversity with ${uniqueProducts} items - opportunity to expand sales variety and increase customer options`);
          recommendations.push("Identify popular product categories and expand offerings to increase transaction diversity");
        }

        // Time-based performance insights
        if (peakHour !== null) {
          if (peakHour >= 7 && peakHour <= 9) {
            insights.push("Morning rush period (7-9 AM) drives peak sales - capitalize on commuter and early-riser traffic patterns");
            recommendations.push("Ensure optimal morning inventory, consider breakfast promotions, and evaluate extended early hours");
          } else if (peakHour >= 12 && peakHour <= 14) {
            insights.push("Lunch period (12-2 PM) represents primary sales driver - strong positioning for midday customer needs");
            recommendations.push("Optimize lunch menu offerings, ensure adequate staffing, and consider lunch-specific promotions");
          } else if (peakHour >= 15 && peakHour <= 17) {
            insights.push("Afternoon period (3-5 PM) shows strong performance - excellent capture of after-work and snack traffic");
            recommendations.push("Promote afternoon beverages and snacks, ensure fresh inventory for peak period");
          } else if (peakHour >= 18 && peakHour <= 20) {
            insights.push("Evening sales (6-8 PM) indicate strong dinner and after-work market penetration");
            recommendations.push("Consider extended evening hours and dinner-focused product offerings");
          }
        }

        // Operational recommendations
        recommendations.push("Monitor inventory levels for top-selling products to prevent stockouts during peak periods");
        recommendations.push("Implement systematic customer feedback collection to identify service improvement opportunities");
        
        if (totalTransactions < 20) {
          recommendations.push("Increase customer traffic through social media marketing, local partnerships, and community engagement");
          recommendations.push("Consider implementing a customer loyalty program to encourage repeat business");
        }
        
        if (totalTransactions > 30) {
          insights.push("High transaction volume demonstrates strong customer traffic and operational efficiency");
          recommendations.push("Focus on maintaining service quality during busy periods and consider capacity optimization");
        }
      }

      // Determine sales trends
      let salesTrend = "stable";
      if (prompt.previousPeriodData && prompt.previousPeriodData.length > 0) {
        const prevRevenue = prompt.previousPeriodData.reduce((sum, day) => sum + (day.revenue || 0), 0);
        if (prevRevenue > 0) {
          const changePercent = ((totalRevenue - prevRevenue) / prevRevenue) * 100;
          if (changePercent > 15) salesTrend = "increasing";
          else if (changePercent < -15) salesTrend = "decreasing";
        }
      } else {
        // Base trend assessment on current performance
        if (totalRevenue > 400) salesTrend = "increasing";
        else if (totalRevenue < 100) salesTrend = "decreasing";
      }

      // Generate performance-based alerts
      if (totalRevenue < 100 && totalTransactions > 0) {
        alerts.push("Low revenue per transaction - review pricing strategy and product mix");
      }
      if (totalTransactions > 50 && averageTransactionValue < 10) {
        alerts.push("High volume but low value transactions - implement value-addition strategies");
      }

      console.log('✅ Enhanced mock analysis completed successfully');

      return {
        summary: totalTransactions > 0 
          ? `Comprehensive analysis of ${prompt.dateRange} sales shows ${totalTransactions} transactions generating $${totalRevenue.toFixed(2)} in revenue. ${topProduct} emerged as the top-performing product, with ${salesTrend} trend indicators suggesting ${salesTrend === 'increasing' ? 'positive' : salesTrend === 'decreasing' ? 'concerning' : 'stable'} business momentum. Key focus areas include ${averageTransactionValue < 20 ? 'transaction value optimization' : 'maintaining strong performance'} and ${uniqueProducts < 5 ? 'product diversification' : 'inventory management'}.`
          : `No sales activity recorded for ${prompt.dateRange}, representing a critical business situation requiring immediate management intervention. This could indicate system failures, operational issues, or external factors affecting business operations.`,
        keyMetrics: {
          totalRevenue: Math.round(totalRevenue * 100) / 100,
          totalTransactions,
          averageTransactionValue: Math.round(averageTransactionValue * 100) / 100,
          topProduct: topProduct
        },
        insights,
        recommendations,
        trends: {
          salesTrend,
          peakHours: peakHour !== null ? `${peakHour}:00 - ${peakHour + 1}:00` : "Insufficient data for pattern analysis",
          slowPeriods: totalTransactions < 5 ? "Most operational hours showing low activity" : "Early morning and late evening typically slower"
        },
        alerts,
        isMockData: true, // Mark as mock data
        isEnhancedFallback: true
      };

    } catch (error) {
      console.error('🚨 Error in enhanced mock analysis:', error);
      
      // Ultra-safe fallback
      return {
        summary: `Analysis system experiencing technical difficulties. Basic performance data: ${prompt.salesData?.length || 0} transactions recorded.`,
        keyMetrics: {
          totalRevenue: 0,
          totalTransactions: prompt.salesData?.length || 0,
          averageTransactionValue: 0,
          topProduct: 'Analysis Error'
        },
        insights: [
          'Analysis system temporarily unavailable due to technical issues.',
          'Manual review of sales data recommended.',
          'System recovery procedures are in progress.'
        ],
        recommendations: [
          'Continue normal business operations.',
          'Manually monitor key performance indicators.',
          'Contact technical support if issues persist.'
        ],
        trends: {
          salesTrend: 'analysis unavailable',
          peakHours: 'System error',
          slowPeriods: 'System error'
        },
        alerts: [
          'Analysis system error - immediate technical review required.'
        ],
        isMockData: true,
        systemError: true
      };
    }
  }

  async generateReportText(analysisData: any): Promise<string> {
    try {
      const reportDate = new Date().toLocaleDateString();
      const isQuotaExceeded = analysisData.quotaExceeded || false;
      
      return `
🏪 ${isQuotaExceeded ? 'INTELLIGENT FALLBACK' : 'AI-POWERED'} DAILY SALES REPORT - ${reportDate}

${isQuotaExceeded ? `
🔄 QUOTA NOTICE: Gemini API quota exceeded. This report uses intelligent fallback analysis.
Please check your Google Cloud billing plan at: https://console.cloud.google.com/billing

` : ''}📊 EXECUTIVE SUMMARY
${analysisData.summary}

📈 KEY PERFORMANCE METRICS
• Total Revenue: $${analysisData.keyMetrics.totalRevenue.toFixed(2)}
• Total Transactions: ${analysisData.keyMetrics.totalTransactions}
• Average Transaction Value: $${analysisData.keyMetrics.averageTransactionValue.toFixed(2)}
• Best Performing Product: ${analysisData.keyMetrics.topProduct}

💡 ${isQuotaExceeded ? 'INTELLIGENT FALLBACK' : 'AI-POWERED'} INSIGHTS
${analysisData.insights.map((insight: string, index: number) => `${index + 1}. ${insight}`).join('\n')}

🎯 STRATEGIC RECOMMENDATIONS
${analysisData.recommendations.map((rec: string, index: number) => `${index + 1}. ${rec}`).join('\n')}

📊 SALES TRENDS ANALYSIS
• Overall Trend: ${analysisData.trends.salesTrend.toUpperCase()}
• Peak Sales Hours: ${analysisData.trends.peakHours}
• Slower Periods: ${analysisData.trends.slowPeriods}

${analysisData.alerts.length > 0 ? `
⚠️ IMMEDIATE ATTENTION REQUIRED
${analysisData.alerts.map((alert: string, index: number) => `${index + 1}. ${alert}`).join('\n')}
` : ''}

---
Generated by Shop Sales Dashboard AI
${isQuotaExceeded ? 'Powered by Intelligent Fallback Analysis' : 'Powered by Google Gemini AI'} • ${new Date().toLocaleString()}
${isQuotaExceeded ? 'Note: Real AI analysis will resume when Gemini quota is restored.' : ''}
      `.trim();
      
    } catch (error) {
      console.error('🚨 Error generating report text:', error);
      return `
📊 SALES REPORT ERROR - ${new Date().toLocaleDateString()}

Unable to generate report due to system error.
Please try again or contact technical support.

Error: ${error.message || 'Unknown error occurred'}

---
Generated by Shop Sales Dashboard AI • ${new Date().toLocaleString()}
      `.trim();
    }
  }
}

// Create singleton instance with the provided API key
export const geminiConnector = new GeminiMCPConnector({
  apiKey: 'AIzaSyAggzujVwm7VMwVUYUy62r3wcqr7qeNv0M',
  model: 'gemini-1.5-flash',
  fallbackModel: 'gemini-pro',
  temperature: 0.3
});