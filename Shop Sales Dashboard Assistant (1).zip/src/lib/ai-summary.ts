import { useSalesStore } from './sales-store';
import { geminiConnector } from './gemini-mcp';
import { formatTZS } from './currency-utils';

export interface DailySummaryData {
  date: string;
  totalSales: number;
  totalRevenue: number;
  averageTransaction: number;
  topSellingItem: string;
  salesCount: number;
  insights: string[];
  recommendations: string[];
  trends: {
    salesTrend: string;
    peakHours: string;
    slowPeriods: string;
  };
  alerts: string[];
  aiAnalysis?: any;
}

export async function generateDailySummary(): Promise<DailySummaryData> {
  console.log('🤖 Starting AI-powered daily summary generation with Gemini...');
  
  try {
    const { todaysSales, todaysRevenue, topProducts, salesTrend } = useSalesStore.getState();
    
    const salesCount = todaysSales.length;
    const averageTransaction = salesCount > 0 ? todaysRevenue / salesCount : 0;
    const topSellingItem = topProducts[0]?.name || 'No sales';

    // Prepare data for Gemini analysis
    const salesData = todaysSales.map(sale => ({
      item: sale.item,
      quantity: sale.quantity,
      unitPrice: sale.unitPrice,
      totalPrice: sale.totalPrice,
      timestamp: sale.timestamp,
      hour: new Date(sale.timestamp).getHours()
    }));

    // Get previous period data for comparison
    const previousPeriodData = salesTrend.slice(-7).map(day => ({
      date: day.date,
      sales: day.sales,
      revenue: day.revenue
    }));

    let aiAnalysis = null;
    let insights: string[] = [];
    let recommendations: string[] = [];
    let trends = {
      salesTrend: 'stable',
      peakHours: 'Not enough data',
      slowPeriods: 'Not enough data'
    };
    let alerts: string[] = [];

    try {
      // Generate AI analysis using Gemini MCP
      console.log('🤖 Attempting Gemini analysis...');
      aiAnalysis = await geminiConnector.generateSalesSummary({
        salesData,
        dateRange: 'today',
        previousPeriodData
      });

      insights = aiAnalysis.insights || [];
      recommendations = aiAnalysis.recommendations || [];
      trends = aiAnalysis.trends || trends;
      alerts = aiAnalysis.alerts || [];

      console.log('✅ Gemini analysis completed successfully');
      
    } catch (error: any) {
      console.error('🤖 Gemini analysis failed, using enhanced fallback logic:', error);
      
      // Enhanced error handling for specific Gemini issues
      const errorMessage = error?.message || String(error);
      
      if (errorMessage.includes('quota') || errorMessage.includes('429') || errorMessage.includes('insufficient_quota')) {
        console.log('💰 Gemini quota exceeded - falling back to enhanced mock analysis');
        alerts.push('Gemini API quota exceeded. Using intelligent fallback analysis until quota is restored. Please check your Google Cloud billing plan.');
      } else if (errorMessage.includes('authentication') || errorMessage.includes('401') || errorMessage.includes('API_KEY_INVALID')) {
        console.log('🔑 Gemini authentication failed - falling back to enhanced mock analysis');
        alerts.push('Gemini authentication failed. Using intelligent fallback analysis. Please verify your API key configuration.');
      } else if (errorMessage.includes('network') || errorMessage.includes('fetch')) {
        console.log('🌐 Network connectivity issues - falling back to enhanced mock analysis');
        alerts.push('Network connectivity issues prevented Gemini API access. Using intelligent fallback analysis.');
      } else {
        console.log('❌ Gemini service error - falling back to enhanced mock analysis');
        alerts.push('Gemini service temporarily unavailable. Using intelligent fallback analysis.');
      }
      
      // Fallback to rule-based analysis with enhanced logic
      const fallbackAnalysis = generateEnhancedFallbackInsights(
        todaysSales, 
        todaysRevenue, 
        averageTransaction, 
        salesCount,
        topSellingItem
      );
      
      insights = fallbackAnalysis.insights;
      recommendations = fallbackAnalysis.recommendations;
      trends = fallbackAnalysis.trends;
      alerts = [...alerts, ...fallbackAnalysis.alerts];
    }

    return {
      date: new Date().toLocaleDateString(),
      totalSales: salesCount,
      totalRevenue: todaysRevenue,
      averageTransaction,
      topSellingItem,
      salesCount,
      insights,
      recommendations,
      trends,
      alerts,
      aiAnalysis,
    };
    
  } catch (error: any) {
    console.error('🚨 Critical error in generateDailySummary:', error);
    
    // Ultimate fallback when everything fails
    return {
      date: new Date().toLocaleDateString(),
      totalSales: 0,
      totalRevenue: 0,
      averageTransaction: 0,
      topSellingItem: 'System Error',
      salesCount: 0,
      insights: [
        'Analysis system temporarily unavailable due to critical errors.',
        'Please check system logs and try refreshing the page.',
        'If the issue persists, contact technical support.'
      ],
      recommendations: [
        'System recovery in progress - manual monitoring recommended.',
        'Ensure all sales transactions are properly recorded.',
        'Try refreshing the page to restore normal functionality.'
      ],
      trends: {
        salesTrend: 'system error',
        peakHours: 'Analysis unavailable',
        slowPeriods: 'Analysis unavailable'
      },
      alerts: [
        'Critical system error in analysis generation - immediate technical review required.'
      ],
      aiAnalysis: null
    };
  }
}

// Enhanced fallback analysis with proper error handling and variable scoping
function generateEnhancedFallbackInsights(
  sales: any[], 
  revenue: number, 
  avgTransaction: number, 
  salesCount: number,
  topSellingItem: string
) {
  const insights: string[] = [];
  const recommendations: string[] = [];
  const alerts: string[] = [];

  try {
    console.log('🔄 Generating enhanced fallback insights for', salesCount, 'sales...');
    
    if (salesCount === 0) {
      insights.push("No sales recorded today. This could indicate a system issue or unusual market conditions.");
      recommendations.push("Check POS system functionality and consider promotional activities.");
      recommendations.push("Verify store hours and staff availability for customer service.");
      recommendations.push("Review marketing efforts and consider customer outreach campaigns.");
      alerts.push("CRITICAL: Zero sales detected - immediate management attention required");
      
      return {
        insights,
        recommendations,
        trends: {
          salesTrend: 'declining',
          peakHours: 'No sales data available',
          slowPeriods: 'All operational hours'
        },
        alerts
      };
    }

    // Enhanced revenue analysis with more detailed insights (TZS amounts)
    if (revenue > 500000) {
      insights.push(`🎉 Exceptional performance! Revenue exceeded ${formatTZS(500000)} - outstanding sales day with significant business impact!`);
      insights.push(`Strong customer engagement resulted in ${salesCount} transactions with high-value outcomes.`);
      recommendations.push("Analyze what drove today's exceptional success and create strategies to replicate this performance consistently.");
      recommendations.push("Document successful tactics for staff training and future promotional campaigns.");
    } else if (revenue > 250000) {
      insights.push(`🌟 Excellent performance! Revenue exceeded ${formatTZS(250000)} - exceptional sales day demonstrating strong market position!`);
      insights.push(`Solid transaction volume of ${salesCount} sales indicates effective customer acquisition and retention.`);
      recommendations.push("Identify and replicate the key success factors from today's strong performance.");
      recommendations.push("Consider expanding successful product lines or services based on today's results.");
    } else if (revenue > 125000) {
      insights.push(`📈 Strong performance with solid revenue generation above ${formatTZS(125000)} - demonstrating consistent business growth.`);
      insights.push(`Transaction count of ${salesCount} shows healthy customer traffic and engagement levels.`);
      recommendations.push("Build on today's solid foundation by identifying opportunities for incremental revenue growth.");
      recommendations.push("Analyze customer preferences to optimize product mix and pricing strategies.");
    } else if (revenue > 50000) {
      insights.push("📊 Moderate sales performance with clear opportunities for improvement and growth.");
      insights.push(`${salesCount} transactions provide a foundation to build upon with targeted strategies.`);
      recommendations.push("Focus on upselling strategies and promotional activities to boost daily revenue targets.");
      recommendations.push("Implement customer retention programs to increase repeat business frequency.");
    } else {
      insights.push("📉 Below-average sales performance indicating need for immediate strategic action and intervention.");
      insights.push(`Low transaction count of ${salesCount} suggests challenges in customer acquisition or market conditions.`);
      recommendations.push("Implement aggressive promotional pricing and increase customer acquisition efforts immediately.");
      recommendations.push("Review operational efficiency and consider extended business hours or new marketing channels.");
      alerts.push("Low daily revenue requires immediate strategic intervention to meet business sustainability targets");
    }

    // Enhanced transaction value analysis (TZS amounts)
    if (avgTransaction > 25000) {
      insights.push(`💎 Outstanding average transaction value of ${formatTZS(avgTransaction)} demonstrates premium market positioning and exceptional customer value delivery.`);
      recommendations.push("Maintain premium product mix and continue advanced training for staff on high-value selling techniques.");
      recommendations.push("Document and standardize your premium customer experience processes for consistent delivery.");
    } else if (avgTransaction > 12500) {
      insights.push(`💰 Excellent average transaction value of ${formatTZS(avgTransaction)} indicates successful premium positioning and effective customer engagement strategies.`);
      recommendations.push("Continue staff training on premium product presentation and value-added service delivery.");
      recommendations.push("Explore opportunities to introduce higher-value products or service packages.");
    } else if (avgTransaction > 6000) {
      insights.push(`💵 Good average transaction value of ${formatTZS(avgTransaction)} shows healthy customer spending patterns with clear growth opportunities.`);
      recommendations.push("Introduce complementary product suggestions and seasonal bundles to increase average basket size.");
      recommendations.push("Train staff on effective cross-selling techniques and create attractive product combination offers.");
    } else if (avgTransaction > 2500) {
      insights.push(`💳 Moderate transaction values averaging ${formatTZS(avgTransaction)} indicate significant potential for strategic upselling initiatives and revenue optimization.`);
      recommendations.push("Implement comprehensive staff training on cross-selling techniques and create compelling product bundle offers.");
      recommendations.push("Analyze customer purchase patterns to identify opportunities for value-added services or products.");
    } else {
      insights.push(`🔍 Lower average transaction value of ${formatTZS(avgTransaction)} suggests substantial opportunities for revenue optimization through strategic pricing and customer value enhancement.`);
      recommendations.push("Implement comprehensive upselling training, create attractive value-added bundles, and review pricing strategy comprehensively.");
      recommendations.push("Develop customer education programs about premium products and services to increase purchase confidence.");
      alerts.push("Low average transaction value requires immediate attention - implement value-enhancement strategies");
    }

    // Enhanced time pattern analysis with error handling
    let timePattern = null;
    try {
      timePattern = analyzeTimePatterns(sales);
      if (timePattern) {
        insights.push(timePattern.insight);
        if (timePattern.recommendation) {
          recommendations.push(timePattern.recommendation);
        }
      }
    } catch (timeError) {
      console.error('Error in time pattern analysis:', timeError);
      insights.push("Time-based analysis temporarily unavailable - using general operational recommendations.");
    }

    // Enhanced product diversity analysis with proper error handling and variable scoping
    let uniqueProducts = 0;
    try {
      // FIXED: Properly calculate uniqueProducts within the correct scope
      if (sales && sales.length > 0) {
        const productSet = new Set();
        sales.forEach(sale => {
          if (sale && sale.item) {
            productSet.add(sale.item);
          }
        });
        uniqueProducts = productSet.size;
        
        console.log(`📦 Product diversity analysis: ${uniqueProducts} unique products from ${salesCount} sales`);
        
        if (uniqueProducts === 0) {
          insights.push("No product data available - ensure sales recording includes item information.");
          recommendations.push("Verify sales recording process captures complete product information for better analysis.");
        } else if (uniqueProducts === 1) {
          insights.push("📦 Sales concentrated entirely on single product line - this creates significant business risk and limits revenue diversification opportunities.");
          recommendations.push("Aggressively promote product variety through strategic displays, staff recommendations, and targeted promotional campaigns.");
          recommendations.push("Analyze customer preferences to introduce complementary products that align with current demand patterns.");
          alerts.push("Product concentration risk detected - diversify sales mix to reduce business vulnerability and increase revenue potential");
        } else if (uniqueProducts > salesCount * 0.6) {
          insights.push(`🛍️ Excellent product diversity with ${uniqueProducts} different items sold from ${salesCount} transactions, demonstrating broad customer appeal and effective merchandising strategies.`);
          recommendations.push("Continue promoting product variety while identifying opportunities to increase quantity per transaction through bundling strategies.");
          recommendations.push("Analyze top-performing product combinations to create strategic cross-selling opportunities.");
        } else if (uniqueProducts > salesCount * 0.3) {
          insights.push(`📋 Good product mix diversity with ${uniqueProducts} unique items contributing to ${salesCount} total sales, showing balanced customer preferences and market appeal.`);
          recommendations.push("Analyze top-performing products and create strategic bundles to increase overall transaction value and customer satisfaction.");
          recommendations.push("Identify underperforming products and implement targeted promotional strategies to improve their sales contribution.");
        } else {
          insights.push(`📊 Limited product diversity with ${uniqueProducts} items from ${salesCount} sales - opportunity to expand customer choice and increase revenue potential.`);
          recommendations.push("Implement strategic product promotion campaigns to increase variety in customer purchases and overall basket size.");
          recommendations.push("Train staff on effective product recommendation techniques to guide customers toward diverse purchasing decisions.");
        }
      } else {
        insights.push("Product analysis requires sales data - ensure transactions are properly recorded with item information.");
      }
    } catch (productError) {
      console.error('Error in product diversity analysis:', productError);
      insights.push("Product diversity analysis temporarily unavailable - focusing on transaction volume insights.");
    }

    // Volume-based insights with enhanced analysis
    if (salesCount > 50) {
      insights.push(`🚀 Exceptional transaction volume with ${salesCount} sales demonstrates outstanding customer traffic management and operational efficiency capabilities.`);
      recommendations.push("Maintain service quality standards during high-volume periods and consider capacity optimization strategies for sustainable growth.");
      recommendations.push("Document successful high-volume operational procedures for staff training and consistency in peak periods.");
    } else if (salesCount > 30) {
      insights.push(`📈 Strong transaction volume with ${salesCount} sales indicates effective customer attraction and efficient operational processes.`);
      recommendations.push("Focus on maintaining consistent service quality while exploring opportunities to increase average transaction values.");
      recommendations.push("Analyze peak hour patterns to optimize staffing and inventory management for maximum efficiency.");
    } else if (salesCount < 10) {
      insights.push(`📉 Low transaction volume with only ${salesCount} sales indicates significant opportunities for customer acquisition and market expansion.`);
      recommendations.push("Implement comprehensive customer acquisition strategies including social media marketing, local partnerships, and community engagement initiatives.");
      recommendations.push("Analyze barriers to customer entry and implement solutions to improve accessibility and appeal to target demographics.");
      alerts.push("Low transaction volume requires immediate attention - implement customer acquisition and retention strategies");
    } else {
      insights.push(`📊 Moderate transaction volume with ${salesCount} sales provides a solid foundation for implementing growth-focused strategies and improvements.`);
      recommendations.push("Balance customer acquisition efforts with retention strategies to build sustainable business growth patterns.");
    }

    // Enhanced operational recommendations
    recommendations.push("Monitor inventory levels continuously for top-selling products to prevent stockouts during peak demand periods and maintain customer satisfaction.");
    recommendations.push("Implement systematic customer feedback collection processes to identify service improvement opportunities and enhance customer experience quality.");
    recommendations.push("Analyze daily performance patterns to optimize staffing schedules, inventory management, and promotional timing for maximum business impact.");
    
    if (salesCount > 0) {
      recommendations.push("Consider implementing a comprehensive customer loyalty program to encourage repeat business and increase customer lifetime value.");
      recommendations.push("Evaluate current pricing strategies against market conditions and customer feedback to ensure optimal revenue generation and competitive positioning.");
    }

    // Determine sales trends with enhanced logic (TZS amounts)
    let salesTrend = "stable";
    if (revenue > 200000 && salesCount > 25) {
      salesTrend = "strongly increasing";
    } else if (revenue > 100000 && salesCount > 15) {
      salesTrend = "increasing";
    } else if (revenue < 25000 || salesCount < 5) {
      salesTrend = "declining";
    } else if (revenue < 50000 && salesCount < 10) {
      salesTrend = "slightly declining";
    }

    // Performance-based alerts with enhanced criteria (TZS amounts)
    if (revenue < 37500 && salesCount > 0) {
      alerts.push("Revenue performance below optimal levels - review pricing strategy, product mix, and customer value propositions immediately");
    }
    if (salesCount > 40 && avgTransaction < 3750) {
      alerts.push("High transaction volume with low individual values detected - implement immediate value-addition strategies and upselling training");
    }
    if (revenue > 250000 && uniqueProducts < 3) {
      alerts.push("Strong revenue concentrated on limited products - diversify offerings to reduce business risk and capture additional market opportunities");
    }

    console.log('✅ Enhanced fallback analysis completed successfully');
    
    return {
      insights,
      recommendations,
      trends: {
        salesTrend,
        peakHours: timePattern?.peakHours || 'Insufficient data for pattern analysis - continue monitoring throughout operational hours',
        slowPeriods: timePattern?.slowPeriods || 'Pattern analysis requires additional transaction data - maintain consistent service standards'
      },
      alerts
    };
    
  } catch (error) {
    console.error('🚨 Critical error in enhanced fallback analysis:', error);
    
    // Ultimate fallback with minimal error risk
    return {
      insights: [
        "Analysis system temporarily experiencing issues - using basic performance summary.",
        `Today's performance: ${salesCount} transactions generating ${formatTZS(revenue)} in total revenue.`,
        revenue > 75000 ? "Revenue performance shows positive indicators." : "Revenue performance requires attention and improvement strategies."
      ],
      recommendations: [
        "System analysis will resume normal operation shortly - continue monitoring sales performance manually.",
        "Ensure all sales transactions are properly recorded for accurate future analysis and reporting.",
        "Review operational procedures and customer service standards to maintain business quality during system recovery."
      ],
      trends: {
        salesTrend: revenue > 300 ? "positive" : "requires attention",
        peakHours: "Analysis temporarily unavailable - monitor patterns manually",
        slowPeriods: "Analysis temporarily unavailable - maintain service standards"
      },
      alerts: [
        "Analysis system experiencing technical issues - manual monitoring recommended until full functionality is restored."
      ]
    };
  }
}

// Enhanced time pattern analysis with better error handling
function analyzeTimePatterns(sales: any[]) {
  try {
    if (!sales || sales.length < 3) {
      return null;
    }

    console.log('⏰ Analyzing time patterns for', sales.length, 'sales...');

    // Extract and validate timestamps
    const validSales = sales.filter(sale => {
      try {
        if (!sale || !sale.timestamp) return false;
        const timestamp = new Date(sale.timestamp);
        return !isNaN(timestamp.getTime());
      } catch {
        return false;
      }
    });

    if (validSales.length < 3) {
      console.log('⏰ Insufficient valid timestamps for time analysis');
      return null;
    }

    const hours = validSales.map(sale => {
      try {
        return new Date(sale.timestamp).getHours();
      } catch {
        return null;
      }
    }).filter(hour => hour !== null && hour >= 0 && hour <= 23);

    if (hours.length === 0) {
      return null;
    }

    // Count transactions by hour
    const hourCounts = hours.reduce((acc, hour) => {
      acc[hour] = (acc[hour] || 0) + 1;
      return acc;
    }, {} as Record<number, number>);

    // Categorize hours into periods
    const morningHours = Object.keys(hourCounts).filter(h => {
      const hour = parseInt(h);
      return !isNaN(hour) && hour >= 6 && hour < 12;
    });
    
    const afternoonHours = Object.keys(hourCounts).filter(h => {
      const hour = parseInt(h);
      return !isNaN(hour) && hour >= 12 && hour < 18;
    });
    
    const eveningHours = Object.keys(hourCounts).filter(h => {
      const hour = parseInt(h);
      return !isNaN(hour) && (hour >= 18 || hour < 6);
    });

    // Calculate period totals
    const morningCount = morningHours.reduce((sum, h) => {
      const count = hourCounts[parseInt(h)] || 0;
      return sum + count;
    }, 0);
    
    const afternoonCount = afternoonHours.reduce((sum, h) => {
      const count = hourCounts[parseInt(h)] || 0;
      return sum + count;
    }, 0);
    
    const eveningCount = eveningHours.reduce((sum, h) => {
      const count = hourCounts[parseInt(h)] || 0;
      return sum + count;
    }, 0);

    // Determine peak period
    let peakPeriod = 'morning';
    let peakCount = morningCount;

    if (afternoonCount > peakCount) {
      peakPeriod = 'afternoon';
      peakCount = afternoonCount;
    }
    if (eveningCount > peakCount) {
      peakPeriod = 'evening';
      peakCount = eveningCount;
    }

    // Find specific peak hour
    const peakHour = Object.keys(hourCounts).reduce((a, b) => {
      const countA = hourCounts[parseInt(a)] || 0;
      const countB = hourCounts[parseInt(b)] || 0;
      return countA > countB ? a : b;
    });

    // Generate insights based on peak period
    const periodInsights: Record<string, any> = {
      morning: {
        insight: "🌅 Peak sales activity occurs during morning hours (6 AM - 12 PM), indicating strong positioning for breakfast, coffee, and early shopping demographics.",
        recommendation: "Ensure adequate morning staffing levels, maintain fresh breakfast inventory, and consider early-bird promotional offers to maximize morning customer traffic.",
        peakHours: "6 AM - 12 PM (Morning Rush)",
        slowPeriods: "Afternoon and evening hours show lower activity"
      },
      afternoon: {
        insight: "☀️ Afternoon period (12 PM - 6 PM) represents your primary sales driver, indicating excellent positioning for lunch, business, and midday shopping traffic.",
        recommendation: "Optimize lunch menu offerings, ensure adequate midday staffing coverage, and consider afternoon-specific promotions to maintain strong performance",
        peakHours: "12 PM - 6 PM (Afternoon Peak)",
        slowPeriods: "Morning and evening hours require attention"
      },
      evening: {
        insight: "🌙 Evening sales (6 PM onwards) demonstrate strong after-work and dinner market penetration, indicating effective capture of end-of-day customer needs.",
        recommendation: "Evaluate extended evening hours feasibility, optimize dinner and takeaway offerings, and consider evening-specific service enhancements",
        peakHours: "6 PM onwards (Evening Strong)",
        slowPeriods: "Morning and afternoon hours show opportunity for growth"
      }
    };

    const result = {
      ...periodInsights[peakPeriod],
      peakHour: `${peakHour}:00 (${hourCounts[parseInt(peakHour)]} transactions)`,
      totalPeakPeriodSales: peakCount,
      periodDistribution: {
        morning: morningCount,
        afternoon: afternoonCount,
        evening: eveningCount
      }
    };

    console.log('✅ Time pattern analysis completed:', peakPeriod, 'peak with', peakCount, 'transactions');
    return result;

  } catch (error) {
    console.error('⏰ Error in time pattern analysis:', error);
    return null;
  }
}

// Enhanced report formatting with better error handling
export async function formatSummaryText(summary: DailySummaryData): Promise<string> {
  try {
    console.log('📄 Formatting summary report...');
    
    // Use Gemini MCP to format the report if available and analysis was successful
    if (summary.aiAnalysis && !summary.aiAnalysis.isMockData) {
      try {
        console.log('📄 Using Gemini for report formatting...');
        const formattedReport = await geminiConnector.generateReportText(summary.aiAnalysis);
        console.log('✅ Gemini report formatting completed');
        return formattedReport;
      } catch (error) {
        console.error('📄 Gemini formatting failed, using fallback:', error);
        // Continue to fallback formatting
      }
    }

    // Enhanced fallback formatting
    console.log('📄 Using enhanced fallback formatting...');
    
    const reportDate = new Date().toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });

    const isUsingAI = summary.aiAnalysis && !summary.aiAnalysis.isMockData;
    const analysisType = isUsingAI ? 'AI-POWERED ANALYSIS' : 'ENHANCED INTELLIGENT ANALYSIS';
    
    const report = `
🏪 SHOP SALES DASHBOARD - COMPREHENSIVE DAILY REPORT
${reportDate}

📊 EXECUTIVE SUMMARY
${summary.insights[0] || `Today's performance summary: ${summary.totalSales} transactions generating $${summary.totalRevenue.toFixed(2)} in revenue.`}

📈 KEY PERFORMANCE INDICATORS
• Total Revenue: $${summary.totalRevenue.toFixed(2)}
• Total Transactions: ${summary.totalSales}
• Average Transaction Value: $${summary.averageTransaction.toFixed(2)}
• Top Performing Product: ${summary.topSellingItem}
• Sales Trend: ${summary.trends.salesTrend.toUpperCase()}

💡 ${analysisType} - BUSINESS INSIGHTS
${summary.insights.map((insight, index) => `${index + 1}. ${insight}`).join('\n')}

🎯 STRATEGIC RECOMMENDATIONS
${summary.recommendations.map((rec, index) => `${index + 1}. ${rec}`).join('\n')}

📊 OPERATIONAL TRENDS ANALYSIS
• Overall Performance Trend: ${summary.trends.salesTrend.toUpperCase()}
• Peak Sales Hours: ${summary.trends.peakHours}
• Lower Activity Periods: ${summary.trends.slowPeriods}

${summary.alerts.length > 0 ? `
⚠️ MANAGEMENT ATTENTION REQUIRED
${summary.alerts.map((alert, index) => `${index + 1}. ${alert}`).join('\n')}
` : `
✅ OPERATIONAL STATUS: ALL SYSTEMS PERFORMING WITHIN NORMAL PARAMETERS
No immediate alerts or concerns requiring management intervention.
`}

📋 ANALYSIS METHODOLOGY
• Data Source: Real-time sales transaction records
• Analysis Engine: ${isUsingAI ? 'Google Gemini AI with MCP Integration' : 'Enhanced Intelligent Fallback System'}
• Accuracy Level: ${isUsingAI ? 'AI-Enhanced Professional Grade' : 'Rule-Based High Accuracy'}
• Report Generation: Automated with manual oversight capabilities

---
Generated by Shop Sales Dashboard AI Management System
Powered by ${isUsingAI ? 'Google Gemini AI' : 'Enhanced Intelligent Analysis Engine'}
Report ID: ${Date.now()}-${Math.random().toString(36).substr(2, 9)}
Generated: ${new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })} EST
    `.trim();

    console.log('✅ Enhanced fallback report formatting completed');
    return report;
    
  } catch (error) {
    console.error('🚨 Critical error in report formatting:', error);
    
    // Ultra-safe fallback
    return `
📊 DAILY SALES SUMMARY - ${new Date().toLocaleDateString()}

System temporarily experiencing formatting issues.

Basic Performance Metrics:
• Sales Count: ${summary?.totalSales || 0}
• Revenue: $${summary?.totalRevenue?.toFixed(2) || '0.00'}
• Average Transaction: $${summary?.averageTransaction?.toFixed(2) || '0.00'}

Report generation system will resume normal operation shortly.
Manual review of sales data recommended until full system restoration.

Generated: ${new Date().toLocaleString()}
    `.trim();
  }
}