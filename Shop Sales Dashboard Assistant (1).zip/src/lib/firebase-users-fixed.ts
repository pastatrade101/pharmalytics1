// Enhanced Firebase users service with comprehensive user and shop management
import { 
  createUserWithEmailAndPassword,
  sendEmailVerification,
  signInWithEmailAndPassword,
  updateProfile
} from 'firebase/auth';
import { 
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  query,
  where,
  getDocs,
  serverTimestamp,
  Timestamp,
  writeBatch
} from 'firebase/firestore';
import { auth, db } from './firebase-config';
import { UserProfile, Shop, COLLECTIONS } from './firebase-types';
import { ShopService } from './firebase-shops';

export interface CreateUserAccountData {
  email: string;
  password: string;
  full_name: string;
  role: string;
  shop_id: string;
  phone?: string;
  license_number?: string;
  certification_number?: string;
  experience_years?: number;
}

export interface CreateUserProfileData {
  uid: string;
  email: string;
  full_name: string;
  role: 'owner' | 'admin' | 'product_manager' | 'salesman' | 'super_admin';
  shop_id?: string;
  phone?: string;
  license_number?: string;
  certification_number?: string;
  experience_years?: number;
}

export interface SendCredentialsData {
  email: string;
  full_name: string;
  password: string;
  shop_name: string;
  role: string;
}

// Helper function to remove undefined values from objects
const removeUndefinedValues = (obj: any): any => {
  const cleaned: any = {};
  Object.keys(obj).forEach(key => {
    if (obj[key] !== undefined) {
      cleaned[key] = obj[key];
    }
  });
  return cleaned;
};

export class FirebaseService {
  /**
   * Create user profile in Firestore (used during registration)
   */
  static async createUserProfile(userData: CreateUserProfileData): Promise<UserProfile> {
    console.log('🔄 Creating user profile for:', userData.email);
    
    try {
      // Create the base user profile without undefined values
      const baseUserProfile = {
        uid: userData.uid,
        email: userData.email,
        full_name: userData.full_name,
        role: userData.role,
        created_at: serverTimestamp(),
        updated_at: serverTimestamp()
      };

      // Add optional fields only if they are defined
      const optionalFields: Partial<UserProfile> = {};
      if (userData.shop_id !== undefined) {
        optionalFields.shop_id = userData.shop_id;
      }
      if (userData.phone !== undefined) {
        optionalFields.phone = userData.phone;
      }
      if (userData.license_number !== undefined) {
        optionalFields.license_number = userData.license_number;
      }
      if (userData.certification_number !== undefined) {
        optionalFields.certification_number = userData.certification_number;
      }
      if (userData.experience_years !== undefined) {
        optionalFields.experience_years = userData.experience_years;
      }

      // Combine base profile with optional fields
      const userProfile = { ...baseUserProfile, ...optionalFields };

      // Double-check to remove any undefined values
      const cleanUserProfile = removeUndefinedValues(userProfile);

      console.log('📝 Creating user document with data:', {
        uid: userData.uid,
        email: userData.email,
        hasShopId: 'shop_id' in cleanUserProfile,
        fields: Object.keys(cleanUserProfile)
      });

      await setDoc(doc(db, COLLECTIONS.USERS, userData.uid), cleanUserProfile);

      const createdProfile: UserProfile = {
        id: userData.uid,
        uid: userData.uid,
        email: userData.email,
        full_name: userData.full_name,
        role: userData.role,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        ...optionalFields
      };

      console.log('✅ User profile created successfully:', userData.email);
      return createdProfile;
    } catch (error: any) {
      console.error('❌ Error creating user profile:', error);
      throw error;
    }
  }

  /**
   * Update user profile with shop assignment
   */
  static async updateUserProfileWithShop(userId: string, shopId: string): Promise<void> {
    console.log('🔄 Updating user profile with shop assignment:', { userId, shopId });
    
    try {
      await updateDoc(doc(db, COLLECTIONS.USERS, userId), {
        shop_id: shopId,
        updated_at: serverTimestamp()
      });
      
      console.log('✅ User profile updated with shop assignment');
    } catch (error: any) {
      console.error('❌ Error updating user profile with shop:', error);
      throw error;
    }
  }

  /**
   * Get current user profile with enhanced error handling
   */
  static async getCurrentUserProfile(): Promise<UserProfile | null> {
    try {
      const currentUser = auth.currentUser;
      if (!currentUser) {
        console.log('No current user found');
        return null;
      }

      console.log('Loading profile for user:', currentUser.uid);
      const userDoc = await getDoc(doc(db, COLLECTIONS.USERS, currentUser.uid));
      
      if (!userDoc.exists()) {
        console.warn('User document does not exist for:', currentUser.uid);
        return null;
      }

      const userData = userDoc.data();
      let profile: UserProfile = {
        uid: currentUser.uid,
        id: userDoc.id,
        email: currentUser.email || userData.email,
        ...userData,
        created_at: userData.created_at instanceof Timestamp ? userData.created_at.toDate().toISOString() : userData.created_at,
        updated_at: userData.updated_at instanceof Timestamp ? userData.updated_at.toDate().toISOString() : userData.updated_at
      } as UserProfile;

      // Load shop information if user has a shop_id
      if (profile.shop_id) {
        try {
          console.log('Loading shop information for shop_id:', profile.shop_id);
          const shop = await ShopService.getShopById(profile.shop_id);
          if (shop) {
            profile.shop = shop;
            console.log('✅ Shop information loaded:', shop.name, 'Status:', shop.status);
          } else {
            console.warn('⚠️ Shop not found for shop_id:', profile.shop_id);
          }
        } catch (shopError) {
          console.error('❌ Error loading shop information:', shopError);
          // Don't fail profile loading if shop loading fails
        }
      }

      console.log('✅ Profile loaded successfully:', profile.full_name, profile.role);
      return profile;
    } catch (error: any) {
      console.error('❌ Error loading user profile:', error);
      
      // Enhanced error context for debugging
      if (error.code === 'permission-denied') {
        error.isPermissionError = true;
        error.context = 'User Profile Loading';
      }
      
      throw error;
    }
  }

  /**
   * Create user account with immediate shop assignment
   */
  static async createUserAccount(userData: CreateUserAccountData): Promise<UserProfile> {
    console.log('🔄 Creating user account for:', userData.email);
    
    try {
      // Create Firebase Auth user
      const userCredential = await createUserWithEmailAndPassword(
        auth,
        userData.email,
        userData.password
      );
      
      // Update display name
      await updateProfile(userCredential.user, {
        displayName: userData.full_name
      });

      // Send email verification
      await sendEmailVerification(userCredential.user);
      console.log('📧 Email verification sent to:', userData.email);

      // Create user profile document with shop assignment
      const userProfileData: CreateUserProfileData = {
        uid: userCredential.user.uid,
        email: userData.email,
        full_name: userData.full_name,
        role: userData.role as any,
        shop_id: userData.shop_id,
        phone: userData.phone,
        license_number: userData.license_number,
        certification_number: userData.certification_number,
        experience_years: userData.experience_years
      };

      const createdProfile = await this.createUserProfile(userProfileData);

      console.log('✅ User account created successfully:', userData.email);
      return createdProfile;
    } catch (error: any) {
      console.error('❌ Error creating user account:', error);
      throw error;
    }
  }

  /**
   * Get user by ID
   */
  static async getUserById(userId: string): Promise<UserProfile | null> {
    try {
      const userDoc = await getDoc(doc(db, COLLECTIONS.USERS, userId));
      
      if (!userDoc.exists()) {
        return null;
      }

      const userData = userDoc.data();
      return {
        uid: userId,
        id: userDoc.id,
        ...userData,
        created_at: userData.created_at instanceof Timestamp ? userData.created_at.toDate().toISOString() : userData.created_at,
        updated_at: userData.updated_at instanceof Timestamp ? userData.updated_at.toDate().toISOString() : userData.updated_at
      } as UserProfile;
    } catch (error: any) {
      console.error('❌ Error fetching user by ID:', error);
      throw error;
    }
  }

  /**
   * Get users assigned to a specific shop
   */
  static async getShopUsers(shopId: string): Promise<UserProfile[]> {
    try {
      // Remove orderBy to avoid composite index requirement
      const q = query(
        collection(db, COLLECTIONS.USERS),
        where('shop_id', '==', shopId)
      );
      
      const querySnapshot = await getDocs(q);
      
      const users = querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          uid: doc.id,
          id: doc.id,
          ...data,
          created_at: data.created_at instanceof Timestamp ? data.created_at.toDate().toISOString() : data.created_at,
          updated_at: data.updated_at instanceof Timestamp ? data.updated_at.toDate().toISOString() : data.updated_at
        } as UserProfile;
      });

      // Sort in memory by created_at descending
      return users.sort((a, b) => {
        const dateA = new Date(a.created_at || 0).getTime();
        const dateB = new Date(b.created_at || 0).getTime();
        return dateB - dateA; // Desc order
      });
    } catch (error: any) {
      console.error('❌ Error fetching shop users:', error);
      throw error;
    }
  }

  /**
   * Get unassigned users (for super admin)
   */
  static async getUnassignedUsers(): Promise<UserProfile[]> {
    try {
      // Remove orderBy to avoid composite index requirement
      const q = query(
        collection(db, COLLECTIONS.USERS),
        where('shop_id', '==', null)
      );
      
      const querySnapshot = await getDocs(q);
      
      const users = querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          uid: doc.id,
          id: doc.id,
          ...data,
          created_at: data.created_at instanceof Timestamp ? data.created_at.toDate().toISOString() : data.created_at,
          updated_at: data.updated_at instanceof Timestamp ? data.updated_at.toDate().toISOString() : data.updated_at
        } as UserProfile;
      });

      // Sort in memory by created_at descending
      return users.sort((a, b) => {
        const dateA = new Date(a.created_at || 0).getTime();
        const dateB = new Date(b.created_at || 0).getTime();
        return dateB - dateA; // Desc order
      });
    } catch (error: any) {
      console.error('❌ Error fetching unassigned users:', error);
      throw error;
    }
  }

  /**
   * Assign user to shop
   */
  static async assignUserToShop(userId: string, shopId: string): Promise<void> {
    try {
      await updateDoc(doc(db, COLLECTIONS.USERS, userId), {
        shop_id: shopId,
        updated_at: serverTimestamp()
      });
      
      console.log('✅ User assigned to shop successfully');
    } catch (error: any) {
      console.error('❌ Error assigning user to shop:', error);
      throw error;
    }
  }

  /**
   * Remove user from shop
   */
  static async removeUserFromShop(userId: string): Promise<void> {
    try {
      await updateDoc(doc(db, COLLECTIONS.USERS, userId), {
        shop_id: null,
        updated_at: serverTimestamp()
      });
      
      console.log('✅ User removed from shop successfully');
    } catch (error: any) {
      console.error('❌ Error removing user from shop:', error);
      throw error;
    }
  }

  /**
   * Send user credentials via email
   */
  static async sendUserCredentials(data: SendCredentialsData): Promise<void> {
    try {
      // This would typically integrate with an email service
      // For now, we'll just log the credentials that would be sent
      console.log('📧 Would send credentials via email:', {
        to: data.email,
        subject: `Welcome to ${data.shop_name} - Your Account Details`,
        body: `
          Hello ${data.full_name},
          
          Your account has been created for ${data.shop_name}.
          
          Login Details:
          Email: ${data.email}
          Password: ${data.password}
          Role: ${data.role}
          
          Please change your password after your first login.
          
          Best regards,
          Pharmacy Management System Team
        `
      });
      
      // In a real implementation, you would call an email service here
      // throw new Error('Email service not implemented yet');
    } catch (error: any) {
      console.error('❌ Error sending credentials email:', error);
      throw error;
    }
  }

  /**
   * Check if user's shop is active (blocks operations for inactive shops)
   */
  static async checkShopActive(userProfile: UserProfile): Promise<boolean> {
    try {
      // Super admins and admins bypass shop activation checks
      if (['super_admin', 'admin'].includes(userProfile.role)) {
        return true;
      }
      
      // Users without shops cannot perform operations
      if (!userProfile.shop_id) {
        return false;
      }
      
      // Check shop status
      const shop = await ShopService.getShopById(userProfile.shop_id);
      return shop?.status === 'active' || false;
    } catch (error: any) {
      console.error('❌ Error checking shop status:', error);
      return false;
    }
  }

  /**
   * Validate shop operation access
   */
  static async validateShopOperationAccess(userProfile: UserProfile): Promise<void> {
    const isActive = await this.checkShopActive(userProfile);
    
    if (!isActive) {
      const error = new Error('Shop is not active. Operations are restricted until activation by system administrators.');
      error.name = 'ShopInactiveError';
      throw error;
    }
  }

  /**
   * Create super admin account
   */
  static async createSuperAdminAccount(userData: {
    email: string;
    password: string;
    fullName: string;
    role: string;
  }): Promise<UserProfile> {
    console.log('🛡️ Creating super admin account for:', userData.email);
    
    try {
      // Create Firebase Auth user
      console.log('🔄 Creating Firebase auth user...');
      const userCredential = await createUserWithEmailAndPassword(
        auth,
        userData.email,
        userData.password
      );
      console.log('✅ Firebase auth user created:', userCredential.user.uid);
      
      // Update display name
      console.log('🔄 Updating user profile display name...');
      await updateProfile(userCredential.user, {
        displayName: userData.fullName
      });
      console.log('✅ Display name updated');

      // Send email verification (optional for super admins)
      console.log('🔄 Sending email verification...');
      try {
        await sendEmailVerification(userCredential.user);
        console.log('📧 Email verification sent to super admin:', userData.email);
      } catch (verificationError) {
        // Don't fail super admin creation if email verification fails
        console.warn('⚠️ Email verification failed for super admin (continuing anyway):', verificationError);
      }

      // Create super admin profile document
      const superAdminProfileData: CreateUserProfileData = {
        uid: userCredential.user.uid,
        email: userData.email,
        full_name: userData.fullName,
        role: 'super_admin'
        // Super admins don't have shop_id
      };

      console.log('🔄 Creating super admin profile document...');
      const createdProfile = await this.createUserProfile(superAdminProfileData);
      console.log('✅ Super admin profile created');

      console.log('✅ Super admin account created successfully:', userData.email);
      return createdProfile;
    } catch (error: any) {
      console.error('❌ Error creating super admin account:', error);
      console.error('❌ Error details:', {
        code: error?.code,
        message: error?.message,
        name: error?.name,
        stack: error?.stack
      });
      throw error;
    }
  }

  /**
   * Sign in super admin
   */
  static async signInSuperAdmin(email: string, password: string): Promise<UserProfile> {
    console.log('🛡️ Attempting super admin sign in for:', email);
    
    try {
      // First authenticate with Firebase
      console.log('🔄 Authenticating with Firebase...');
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      console.log('✅ Super admin Firebase auth successful:', userCredential.user.uid);
      
      // Get the user profile to verify super admin role
      console.log('🔄 Fetching user profile document...');
      const userDoc = await getDoc(doc(db, COLLECTIONS.USERS, userCredential.user.uid));
      
      if (!userDoc.exists()) {
        console.warn('⚠️ User document does not exist for super admin UID:', userCredential.user.uid);
        console.log('🔄 Creating missing super admin profile document...');
        
        // Create the missing super admin profile
        const superAdminProfileData: CreateUserProfileData = {
          uid: userCredential.user.uid,
          email: userCredential.user.email || email,
          full_name: userCredential.user.displayName || 'Super Admin',
          role: 'super_admin'
          // Super admins don't have shop_id
        };

        try {
          const createdProfile = await this.createUserProfile(superAdminProfileData);
          console.log('✅ Super admin profile created successfully during sign-in');
          return createdProfile;
        } catch (profileCreationError) {
          console.error('❌ Failed to create super admin profile during sign-in:', profileCreationError);
          const error = new Error('Super admin profile could not be created. Please contact the system administrator.');
          error.name = 'SuperAdminProfileCreationFailed';
          throw error;
        }
      }

      const userData = userDoc.data();
      console.log('📄 User document found:', { 
        uid: userCredential.user.uid, 
        role: userData.role,
        email: userData.email,
        hasAllRequiredFields: !!(userData.email && userData.full_name && userData.role)
      });
      
      // Verify this is actually a super admin
      if (userData.role !== 'super_admin') {
        console.error('❌ Access denied - user role is not super_admin:', userData.role);
        const error = new Error('Access denied. This account is not authorized for super admin access.');
        error.name = 'SuperAdminAccessDenied';
        throw error;
      }

      const profile: UserProfile = {
        uid: userCredential.user.uid,
        id: userDoc.id,
        email: userCredential.user.email || userData.email,
        ...userData,
        created_at: userData.created_at instanceof Timestamp ? userData.created_at.toDate().toISOString() : userData.created_at,
        updated_at: userData.updated_at instanceof Timestamp ? userData.updated_at.toDate().toISOString() : userData.updated_at
      } as UserProfile;

      console.log('✅ Super admin sign in successful:', profile.full_name, 'Role:', profile.role);
      return profile;
    } catch (error: any) {
      console.error('❌ Super admin sign in failed:', error);
      console.error('❌ Detailed error information:', {
        code: error?.code,
        message: error?.message,
        name: error?.name,
        stack: error?.stack,
        email: email
      });
      
      // Enhance error messages for super admin context
      if (error.code === 'auth/user-not-found') {
        error.message = 'No super admin account found with this email address.';
      } else if (error.code === 'auth/wrong-password') {
        error.message = 'Incorrect password for super admin account.';
      } else if (error.code === 'auth/invalid-credential') {
        error.message = 'Invalid email or password for super admin account.';
      } else if (error.name === 'SuperAdminProfileNotFound') {
        error.message = 'Super admin profile not found. Please contact the system administrator.';
      } else if (error.name === 'SuperAdminProfileCreationFailed') {
        // Keep the original message for profile creation failure
      } else if (error.name === 'SuperAdminAccessDenied') {
        // Keep the original message for access denied
      } else if (!error.message) {
        error.message = 'Failed to sign in as super admin. Please try again.';
      }
      
      throw error;
    }
  }

  /**
   * Ensure super admin profile exists for a given UID
   * This can be used to fix missing profiles for existing super admin accounts
   */
  static async ensureSuperAdminProfile(uid: string, email: string, displayName?: string): Promise<UserProfile> {
    console.log('🛡️ Ensuring super admin profile exists for:', uid, email);
    
    try {
      // Check if profile already exists
      const userDoc = await getDoc(doc(db, COLLECTIONS.USERS, uid));
      
      if (userDoc.exists()) {
        const userData = userDoc.data();
        console.log('✅ Super admin profile already exists');
        
        return {
          uid: uid,
          id: userDoc.id,
          email: email,
          ...userData,
          created_at: userData.created_at instanceof Timestamp ? userData.created_at.toDate().toISOString() : userData.created_at,
          updated_at: userData.updated_at instanceof Timestamp ? userData.updated_at.toDate().toISOString() : userData.updated_at
        } as UserProfile;
      }

      // Create the missing profile
      console.log('🔄 Creating missing super admin profile...');
      const superAdminProfileData: CreateUserProfileData = {
        uid: uid,
        email: email,
        full_name: displayName || 'Super Admin',
        role: 'super_admin'
      };

      const createdProfile = await this.createUserProfile(superAdminProfileData);
      console.log('✅ Super admin profile created successfully');
      return createdProfile;
    } catch (error: any) {
      console.error('❌ Error ensuring super admin profile:', error);
      throw error;
    }
  }
}