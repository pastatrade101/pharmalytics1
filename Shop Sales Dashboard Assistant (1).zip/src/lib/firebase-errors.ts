// Enhanced error handling for Firebase permission and authentication errors

interface EnhancedFirebaseError extends Error {
  code: string;
  context?: string;
  isPermissionError?: boolean;
  isAuthError?: boolean;
  userFriendlyMessage?: string;
  suggestions?: string[];
  retryable?: boolean;
}

// Authentication error mapping with user-friendly messages
const AUTH_ERROR_MESSAGES: Record<string, { message: string; suggestions: string[]; retryable: boolean }> = {
  'auth/invalid-credential': {
    message: 'The email or password you entered is incorrect.',
    suggestions: [
      'Double-check both your email and password',
      'Ensure you\'re using the correct email address',
      'Make sure your password is correct (check Caps Lock)',
      'Reset your password if you\'ve forgotten it'
    ],
    retryable: true
  },
  'auth/user-not-found': {
    message: 'No account found with this email address.',
    suggestions: [
      'Double-check your email address for typos',
      'Try creating a new account if you haven\'t registered yet',
      'Contact your pharmacy administrator if you should have an account'
    ],
    retryable: false
  },
  'auth/wrong-password': {
    message: 'The password you entered is incorrect.',
    suggestions: [
      'Check that Caps Lock is not enabled',
      'Try typing your password again carefully',
      'Reset your password if you\'ve forgotten it'
    ],
    retryable: true
  },
  'auth/invalid-email': {
    message: 'The email address format is not valid.',
    suggestions: [
      'Make sure your email contains @ and a domain (e.g., user@example.com)',
      'Remove any extra spaces before or after your email',
      'Use a valid email format'
    ],
    retryable: false
  },
  'auth/too-many-requests': {
    message: 'Too many failed sign-in attempts. Your account has been temporarily locked.',
    suggestions: [
      'Wait 15-30 minutes before trying again',
      'Reset your password to unlock your account immediately',
      'Contact support if the issue persists'
    ],
    retryable: false
  },
  'auth/network-request-failed': {
    message: 'Network connection failed. Please check your internet connection.',
    suggestions: [
      'Check your internet connection',
      'Try refreshing the page',
      'Ensure you\'re not behind a firewall blocking Firebase',
      'Try again in a few moments'
    ],
    retryable: true
  },
  'auth/user-disabled': {
    message: 'This account has been disabled by an administrator.',
    suggestions: [
      'Contact your pharmacy administrator',
      'Contact support for assistance',
      'This may be a temporary suspension'
    ],
    retryable: false
  },
  'auth/email-already-in-use': {
    message: 'An account with this email already exists.',
    suggestions: [
      'Try signing in instead of creating a new account',
      'Use a different email address',
      'Reset your password if you\'ve forgotten it'
    ],
    retryable: false
  },
  'auth/weak-password': {
    message: 'Password is too weak. Please choose a stronger password.',
    suggestions: [
      'Use at least 8 characters',
      'Include uppercase and lowercase letters',
      'Add numbers and special characters',
      'Avoid common words or patterns'
    ],
    retryable: false
  }
};

// Permission error mapping
const PERMISSION_ERROR_MESSAGES: Record<string, { message: string; suggestions: string[]; retryable: boolean }> = {
  'permission-denied': {
    message: 'Firebase security rules are not deployed or configured properly.',
    suggestions: [
      'Contact your system administrator',
      'Deploy the latest Firebase security rules',
      'Check the Firebase Console for rule configuration',
      'Follow the deployment guide in your project documentation'
    ],
    retryable: false
  },
  'failed-precondition': {
    message: 'Required database indexes are missing.',
    suggestions: [
      'Contact your system administrator',
      'Create the required indexes in Firebase Console',
      'Check the Firebase Console for missing indexes',
      'Try again after indexes are created'
    ],
    retryable: false
  },
  'unavailable': {
    message: 'Firebase service is temporarily unavailable.',
    suggestions: [
      'Try again in a few moments',
      'Check Firebase status page for outages',
      'Verify your internet connection',
      'Contact support if the issue persists'
    ],
    retryable: true
  }
};

export const enhanceFirebaseError = (error: any, context?: string): EnhancedFirebaseError => {
  const errorContext = context || 'unknown operation';
  const errorCode = error?.code || 'unknown-error';
  
  // Check if it's an authentication error
  const authErrorInfo = AUTH_ERROR_MESSAGES[errorCode];
  if (authErrorInfo) {
    const enhancedError = new Error(authErrorInfo.message) as EnhancedFirebaseError;
    enhancedError.code = errorCode;
    enhancedError.context = errorContext;
    enhancedError.isAuthError = true;
    enhancedError.userFriendlyMessage = authErrorInfo.message;
    enhancedError.suggestions = authErrorInfo.suggestions;
    enhancedError.retryable = authErrorInfo.retryable;
    
    console.error(`🔑 Authentication error in ${errorContext}:`, {
      code: errorCode,
      message: authErrorInfo.message,
      suggestions: authErrorInfo.suggestions
    });
    
    return enhancedError;
  }
  
  // Check if it's a permission error
  const permissionErrorInfo = PERMISSION_ERROR_MESSAGES[errorCode];
  if (permissionErrorInfo || error?.message?.includes('permission-denied')) {
    const enhancedError = new Error(permissionErrorInfo?.message || 'Permission denied') as EnhancedFirebaseError;
    enhancedError.code = errorCode;
    enhancedError.context = errorContext;
    enhancedError.isPermissionError = true;
    enhancedError.userFriendlyMessage = permissionErrorInfo?.message || 'Firebase security rules need to be deployed.';
    enhancedError.suggestions = permissionErrorInfo?.suggestions || [
      'Contact your system administrator',
      'Deploy Firebase security rules',
      'Check Firebase Console configuration'
    ];
    enhancedError.retryable = permissionErrorInfo?.retryable || false;
    
    console.error(`🚨 Permission error in ${errorContext}:`, {
      code: errorCode,
      message: enhancedError.userFriendlyMessage,
      suggestions: enhancedError.suggestions
    });
    
    return enhancedError;
  }
  
  // Handle other Firebase errors
  const enhancedError = new Error(error.message || 'Unknown Firebase error') as EnhancedFirebaseError;
  enhancedError.code = errorCode;
  enhancedError.context = errorContext;
  enhancedError.userFriendlyMessage = 'An unexpected error occurred. Please try again.';
  enhancedError.suggestions = [
    'Try again in a moment',
    'Check your internet connection',
    'Refresh the page and try again',
    'Contact support if the problem persists'
  ];
  enhancedError.retryable = true;
  
  console.error(`❌ Firebase error in ${errorContext}:`, {
    code: errorCode,
    message: error.message,
    originalError: error
  });
  
  return enhancedError;
};

// Legacy function for backward compatibility
export const handleFirebaseError = (error: any, context?: string): never => {
  const enhancedError = enhanceFirebaseError(error, context);
  throw enhancedError;
};

// Utility function to check if an error is retryable
export const isRetryableError = (error: any): boolean => {
  if (error?.retryable !== undefined) {
    return error.retryable;
  }
  
  const retryableCodes = [
    'auth/network-request-failed',
    'auth/invalid-credential', // User might fix their credentials
    'auth/wrong-password',
    'unavailable',
    'cancelled',
    'deadline-exceeded'
  ];
  
  return retryableCodes.includes(error?.code);
};

// Utility function to check if an error requires user action
export const requiresUserAction = (error: any): boolean => {
  const userActionCodes = [
    'auth/invalid-credential',
    'auth/wrong-password',
    'auth/user-not-found',
    'auth/invalid-email',
    'auth/email-already-in-use',
    'auth/weak-password',
    'auth/too-many-requests'
  ];
  
  return userActionCodes.includes(error?.code);
};

// Utility function to get user-friendly error message
export const getUserFriendlyMessage = (error: any): string => {
  if (error?.userFriendlyMessage) {
    return error.userFriendlyMessage;
  }
  
  const errorCode = error?.code || 'unknown-error';
  const authError = AUTH_ERROR_MESSAGES[errorCode];
  const permissionError = PERMISSION_ERROR_MESSAGES[errorCode];
  
  if (authError) return authError.message;
  if (permissionError) return permissionError.message;
  
  return error?.message || 'An unexpected error occurred. Please try again.';
};

// Utility function to get error suggestions
export const getErrorSuggestions = (error: any): string[] => {
  if (error?.suggestions) {
    return error.suggestions;
  }
  
  const errorCode = error?.code || 'unknown-error';
  const authError = AUTH_ERROR_MESSAGES[errorCode];
  const permissionError = PERMISSION_ERROR_MESSAGES[errorCode];
  
  if (authError) return authError.suggestions;
  if (permissionError) return permissionError.suggestions;
  
  return [
    'Try again in a moment',
    'Check your internet connection',
    'Contact support if the problem persists'
  ];
};