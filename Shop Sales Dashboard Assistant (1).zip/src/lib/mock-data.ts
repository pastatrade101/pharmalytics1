import { Sale } from './sales-store';

// Generate mock sales data for the last 7 days
export const mockSales: Sale[] = [
  // Today's sales
  {
    id: 'sale_001',
    item: 'Premium Coffee',
    quantity: 2,
    unitPrice: 4.50,
    totalPrice: 9.00,
    timestamp: new Date().toISOString(),
  },
  {
    id: 'sale_002',
    item: 'Croissant',
    quantity: 1,
    unitPrice: 3.25,
    totalPrice: 3.25,
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'sale_003',
    item: 'T-Shirt',
    quantity: 1,
    unitPrice: 24.99,
    totalPrice: 24.99,
    timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
  },

  // Yesterday's sales
  {
    id: 'sale_004',
    item: 'Premium Coffee',
    quantity: 3,
    unitPrice: 4.50,
    totalPrice: 13.50,
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'sale_005',
    item: 'Sandwich',
    quantity: 2,
    unitPrice: 8.99,
    totalPrice: 17.98,
    timestamp: new Date(Date.now() - 25 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'sale_006',
    item: 'Phone Case',
    quantity: 1,
    unitPrice: 15.99,
    totalPrice: 15.99,
    timestamp: new Date(Date.now() - 26 * 60 * 60 * 1000).toISOString(),
  },

  // 2 days ago
  {
    id: 'sale_007',
    item: 'Premium Coffee',
    quantity: 4,
    unitPrice: 4.50,
    totalPrice: 18.00,
    timestamp: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'sale_008',
    item: 'Muffin',
    quantity: 2,
    unitPrice: 2.75,
    totalPrice: 5.50,
    timestamp: new Date(Date.now() - 49 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'sale_009',
    item: 'T-Shirt',
    quantity: 2,
    unitPrice: 24.99,
    totalPrice: 49.98,
    timestamp: new Date(Date.now() - 50 * 60 * 60 * 1000).toISOString(),
  },

  // 3 days ago
  {
    id: 'sale_010',
    item: 'Latte',
    quantity: 1,
    unitPrice: 5.25,
    totalPrice: 5.25,
    timestamp: new Date(Date.now() - 72 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'sale_011',
    item: 'Bagel',
    quantity: 3,
    unitPrice: 3.50,
    totalPrice: 10.50,
    timestamp: new Date(Date.now() - 73 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'sale_012',
    item: 'Notebook',
    quantity: 1,
    unitPrice: 12.99,
    totalPrice: 12.99,
    timestamp: new Date(Date.now() - 74 * 60 * 60 * 1000).toISOString(),
  },

  // 4 days ago
  {
    id: 'sale_013',
    item: 'Premium Coffee',
    quantity: 5,
    unitPrice: 4.50,
    totalPrice: 22.50,
    timestamp: new Date(Date.now() - 96 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'sale_014',
    item: 'Croissant',
    quantity: 4,
    unitPrice: 3.25,
    totalPrice: 13.00,
    timestamp: new Date(Date.now() - 97 * 60 * 60 * 1000).toISOString(),
  },

  // 5 days ago
  {
    id: 'sale_015',
    item: 'Cappuccino',
    quantity: 2,
    unitPrice: 4.75,
    totalPrice: 9.50,
    timestamp: new Date(Date.now() - 120 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'sale_016',
    item: 'Danish',
    quantity: 1,
    unitPrice: 4.25,
    totalPrice: 4.25,
    timestamp: new Date(Date.now() - 121 * 60 * 60 * 1000).toISOString(),
  },

  // 6 days ago
  {
    id: 'sale_017',
    item: 'Premium Coffee',
    quantity: 3,
    unitPrice: 4.50,
    totalPrice: 13.50,
    timestamp: new Date(Date.now() - 144 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'sale_018',
    item: 'Scone',
    quantity: 2,
    unitPrice: 3.75,
    totalPrice: 7.50,
    timestamp: new Date(Date.now() - 145 * 60 * 60 * 1000).toISOString(),
  },
];

// Mock daily reports data
export const mockReports = [
  {
    id: 'report_001',
    date: 'Today',
    generatedAt: '09:00 AM',
    salesCount: 12,
    revenue: 156.78,
    topProduct: 'Premium Coffee',
    status: 'pending' as const,
  },
  {
    id: 'report_002',
    date: 'Yesterday',
    generatedAt: '08:30 PM',
    salesCount: 18,
    revenue: 234.56,
    topProduct: 'Premium Coffee',
    status: 'sent' as const,
  },
  {
    id: 'report_003',
    date: '2 days ago',
    generatedAt: '08:45 PM',
    salesCount: 15,
    revenue: 189.23,
    topProduct: 'T-Shirt',
    status: 'sent' as const,
  },
  {
    id: 'report_004',
    date: '3 days ago',
    generatedAt: '09:15 PM',
    salesCount: 22,
    revenue: 298.45,
    topProduct: 'Premium Coffee',
    status: 'sent' as const,
  },
  {
    id: 'report_005',
    date: '4 days ago',
    generatedAt: '08:20 PM',
    salesCount: 19,
    revenue: 267.89,
    topProduct: 'Sandwich',
    status: 'sent' as const,
  },
];

// Sample product categories for quick entry
export const productSuggestions = [
  'Premium Coffee',
  'Latte',
  'Cappuccino',
  'Espresso',
  'Croissant',
  'Bagel',
  'Sandwich',
  'Muffin',
  'Scone',
  'Danish',
  'T-Shirt',
  'Phone Case',
  'Notebook',
  'Pen',
  'Water Bottle',
];

// Common price suggestions for different categories
export const priceSuggestions = {
  beverages: [3.50, 4.25, 4.50, 4.75, 5.25],
  food: [2.75, 3.25, 3.75, 8.99, 12.50],
  merchandise: [9.99, 12.99, 15.99, 19.99, 24.99],
};