import { DailySummaryData, formatSummaryText } from './ai-summary';

// Enhanced MCP Connector for Firestore with real-time capabilities
export class FirestoreMCPConnector {
  private projectId: string;
  private apiKey: string;
  private listeners: Map<string, Function> = new Map();

  constructor(projectId: string, apiKey: string) {
    this.projectId = projectId;
    this.apiKey = apiKey;
  }

  async saveSale(saleData: any): Promise<boolean> {
    console.log('📦 Firestore MCP: Saving sale data', saleData);
    
    try {
      // Real Firestore REST API call example
      const response = await this.makeFirestoreCall('POST', 'sales', saleData);
      
      // Trigger real-time updates
      this.notifyListeners('sale_added', saleData);
      
      console.log('📦 Sale saved successfully to Firestore');
      return true;
    } catch (error) {
      console.error('📦 Firestore save error:', error);
      throw error;
    }
  }

  async getSalesData(dateRange: { start: string; end: string }): Promise<any[]> {
    console.log('📦 Firestore MCP: Fetching sales data', dateRange);
    
    try {
      // Query with date range filter
      const query = {
        structuredQuery: {
          from: [{ collectionId: 'sales' }],
          where: {
            compositeFilter: {
              op: 'AND',
              filters: [
                {
                  fieldFilter: {
                    field: { fieldPath: 'timestamp' },
                    op: 'GREATER_THAN_OR_EQUAL',
                    value: { timestampValue: dateRange.start }
                  }
                },
                {
                  fieldFilter: {
                    field: { fieldPath: 'timestamp' },
                    op: 'LESS_THAN_OR_EQUAL',
                    value: { timestampValue: dateRange.end }
                  }
                }
              ]
            }
          },
          orderBy: [
            {
              field: { fieldPath: 'timestamp' },
              direction: 'DESCENDING'
            }
          ]
        }
      };

      const response = await this.makeFirestoreCall('POST', ':runQuery', query);
      return this.parseFirestoreResponse(response);
    } catch (error) {
      console.error('📦 Firestore fetch error:', error);
      return [];
    }
  }

  async setupRealtimeUpdates(callback: (data: any) => void): Promise<void> {
    console.log('📦 Firestore MCP: Setting up real-time listener');
    
    // In a real implementation, this would use Firestore's listen() method
    // For now, simulate with polling
    const listenerId = 'sales_listener';
    this.listeners.set(listenerId, callback);

    // Mock real-time updates every 30 seconds
    setInterval(() => {
      if (this.listeners.has(listenerId)) {
        callback({
          type: 'document_change',
          timestamp: new Date().toISOString(),
          data: { message: 'Real-time update simulation' }
        });
      }
    }, 30000);
  }

  private async makeFirestoreCall(method: string, endpoint: string, data?: any): Promise<any> {
    const url = `https://firestore.googleapis.com/v1/projects/${this.projectId}/databases/(default)/documents/${endpoint}`;
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 300));
    
    // Mock successful response
    return { success: true, data };
  }

  private parseFirestoreResponse(response: any): any[] {
    // Mock parsing of Firestore response
    return response.data || [];
  }

  private notifyListeners(event: string, data: any): void {
    this.listeners.forEach(callback => {
      callback({ event, data, timestamp: new Date().toISOString() });
    });
  }
}

// Enhanced Google Sheets MCP with advanced formatting
export class GoogleSheetsMCPConnector {
  private spreadsheetId: string;
  private apiKey: string;
  private serviceAccountEmail?: string;

  constructor(spreadsheetId: string, apiKey: string, serviceAccountEmail?: string) {
    this.spreadsheetId = spreadsheetId;
    this.apiKey = apiKey;
    this.serviceAccountEmail = serviceAccountEmail;
  }

  async createDailyReport(summary: DailySummaryData): Promise<string> {
    console.log('📊 Google Sheets MCP: Creating daily report', summary);
    
    try {
      // Create new worksheet for the daily report
      const worksheetName = `Report_${new Date().toISOString().split('T')[0]}`;
      
      // Prepare comprehensive report data with formatting
      const reportData = await this.formatReportForSheets(summary);
      
      // Mock API calls for sheet creation and formatting
      await this.createWorksheet(worksheetName);
      await this.populateWorksheet(worksheetName, reportData);
      await this.formatWorksheet(worksheetName);
      
      const reportUrl = `https://docs.google.com/spreadsheets/d/${this.spreadsheetId}/edit#gid=0`;
      console.log('📊 Daily report created successfully');
      
      return reportUrl;
    } catch (error) {
      console.error('📊 Sheets creation error:', error);
      throw error;
    }
  }

  async updateMasterSheet(data: any[]): Promise<void> {
    console.log('📊 Google Sheets MCP: Updating master sheet with', data.length, 'records');
    
    try {
      // Append to master tracking sheet
      const range = 'Master!A:Z';
      await this.appendToSheet(range, data);
      
      // Update summary formulas
      await this.updateSummaryFormulas();
      
      console.log('📊 Master sheet updated successfully');
    } catch (error) {
      console.error('📊 Master sheet update error:', error);
      throw error;
    }
  }

  async exportToPDF(sheetUrl: string): Promise<string> {
    console.log('📊 Google Sheets MCP: Exporting to PDF', sheetUrl);
    
    // Simulate PDF generation process
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const pdfUrl = `${sheetUrl}/export?format=pdf&portrait=true&size=A4&fzr=true&gid=0`;
    console.log('📊 PDF export completed');
    
    return pdfUrl;
  }

  async createCharts(worksheetName: string, salesData: any[]): Promise<void> {
    console.log('📊 Creating charts in worksheet:', worksheetName);
    
    // Mock chart creation with different types
    const charts = [
      {
        type: 'LINE',
        title: 'Sales Trend Over Time',
        range: 'A1:B10'
      },
      {
        type: 'PIE',
        title: 'Product Distribution',
        range: 'D1:E10'
      },
      {
        type: 'COLUMN',
        title: 'Hourly Sales Pattern',
        range: 'G1:H24'
      }
    ];

    for (const chart of charts) {
      await this.addChart(worksheetName, chart);
    }
  }

  private async formatReportForSheets(summary: DailySummaryData): Promise<any[][]> {
    return [
      ['DAILY SALES REPORT', `Date: ${summary.date}`],
      [],
      ['KEY METRICS', ''],
      ['Total Sales', summary.totalSales],
      ['Total Revenue', `$${summary.totalRevenue.toFixed(2)}`],
      ['Average Transaction', `$${summary.averageTransaction.toFixed(2)}`],
      ['Top Product', summary.topSellingItem],
      [],
      ['INSIGHTS', ''],
      ...summary.insights.map(insight => [insight, '']),
      [],
      ['RECOMMENDATIONS', ''],
      ...summary.recommendations.map(rec => [rec, '']),
      [],
      ['SALES TRENDS', ''],
      ['Overall Trend', summary.trends.salesTrend],
      ['Peak Hours', summary.trends.peakHours],
      ['Slow Periods', summary.trends.slowPeriods],
    ];
  }

  private async createWorksheet(name: string): Promise<void> {
    console.log('📊 Creating worksheet:', name);
    await new Promise(resolve => setTimeout(resolve, 500));
  }

  private async populateWorksheet(name: string, data: any[][]): Promise<void> {
    console.log('📊 Populating worksheet with data');
    await new Promise(resolve => setTimeout(resolve, 800));
  }

  private async formatWorksheet(name: string): Promise<void> {
    console.log('📊 Applying formatting to worksheet');
    await new Promise(resolve => setTimeout(resolve, 300));
  }

  private async appendToSheet(range: string, data: any[]): Promise<void> {
    console.log('📊 Appending data to range:', range);
    await new Promise(resolve => setTimeout(resolve, 400));
  }

  private async updateSummaryFormulas(): Promise<void> {
    console.log('📊 Updating summary formulas');
    await new Promise(resolve => setTimeout(resolve, 200));
  }

  private async addChart(worksheetName: string, chart: any): Promise<void> {
    console.log('📊 Adding chart:', chart.title);
    await new Promise(resolve => setTimeout(resolve, 600));
  }
}

// Enhanced Email MCP with templates and scheduling
export class EmailMCPConnector {
  private smtpConfig: any;
  private templates: Map<string, any> = new Map();

  constructor(smtpConfig: any) {
    this.smtpConfig = smtpConfig;
    this.initializeTemplates();
  }

  async sendDailySummary(
    to: string[], 
    summary: DailySummaryData, 
    attachments?: string[]
  ): Promise<boolean> {
    console.log('📧 Email MCP: Sending daily summary to', to);
    
    try {
      const emailContent = await this.formatSummaryEmail(summary);
      
      const emailData = {
        from: this.smtpConfig.auth?.user || 'demo@shop.com',
        to: to.join(', '),
        subject: `Daily Sales Summary - ${summary.date} | $${summary.totalRevenue.toFixed(2)} Revenue`,
        html: emailContent.html,
        text: emailContent.text,
        attachments: attachments?.map(url => ({
          filename: `sales-report-${summary.date}.pdf`,
          path: url
        })) || []
      };

      await this.sendEmail(emailData);
      console.log('📧 Daily summary email sent successfully');
      
      return true;
    } catch (error) {
      console.error('📧 Email sending error:', error);
      throw error;
    }
  }

  async sendAlert(to: string[], message: string, priority: 'low' | 'medium' | 'high'): Promise<boolean> {
    console.log(`📧 Email MCP: Sending ${priority} priority alert to`, to);
    
    const alertTemplate = this.templates.get('alert');
    const subject = this.getAlertSubject(priority);
    
    const emailData = {
      from: this.smtpConfig.auth?.user || 'demo@shop.com',
      to: to.join(', '),
      subject,
      html: alertTemplate.html.replace('{{message}}', message),
      text: alertTemplate.text.replace('{{message}}', message),
      priority: priority === 'high' ? 'high' : 'normal'
    };

    await this.sendEmail(emailData);
    return true;
  }

  async scheduleWeeklyReport(to: string[], schedule: string): Promise<void> {
    console.log('📧 Scheduling weekly report for:', to, 'Schedule:', schedule);
    
    // In a real implementation, this would integrate with a job scheduler
    // like node-cron or a cloud function scheduler
    console.log('📧 Weekly report scheduled successfully');
  }

  private async formatSummaryEmail(summary: DailySummaryData): Promise<{html: string, text: string}> {
    const template = this.templates.get('dailySummary');
    const textSummary = await formatSummaryText(summary);
    
    const html = template.html
      .replace(/\{\{date\}\}/g, summary.date)
      .replace(/\{\{totalRevenue\}\}/g, summary.totalRevenue.toFixed(2))
      .replace(/\{\{totalSales\}\}/g, summary.totalSales.toString())
      .replace(/\{\{averageTransaction\}\}/g, summary.averageTransaction.toFixed(2))
      .replace(/\{\{topProduct\}\}/g, summary.topSellingItem)
      .replace(/\{\{insights\}\}/g, summary.insights.map(i => `<li>${i}</li>`).join(''))
      .replace(/\{\{recommendations\}\}/g, summary.recommendations.map(r => `<li>${r}</li>`).join(''));

    return { html, text: textSummary };
  }

  private async sendEmail(emailData: any): Promise<void> {
    // Mock SMTP sending
    console.log('📧 Sending email:', emailData.subject);
    await new Promise(resolve => setTimeout(resolve, 1000));
  }

  private getAlertSubject(priority: string): string {
    const prefixes = {
      high: '🚨 URGENT',
      medium: '⚠️ ATTENTION',
      low: '📢 NOTICE'
    };
    return `${prefixes[priority as keyof typeof prefixes]} - Shop Sales Alert`;
  }

  private initializeTemplates(): void {
    // Initialize templates using regular strings instead of template literals
    // to avoid JavaScript evaluation during initialization
    this.templates.set('dailySummary', {
      html: '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">' +
            '<h1 style="color: #333;">Daily Sales Report - {{date}}</h1>' +
            '<div style="background: #f5f5f5; padding: 20px; border-radius: 8px; margin: 20px 0;">' +
            '<h2>Key Metrics</h2>' +
            '<ul>' +
            '<li><strong>Total Revenue:</strong> ${{totalRevenue}}</li>' +
            '<li><strong>Total Sales:</strong> {{totalSales}} transactions</li>' +
            '<li><strong>Average Transaction:</strong> ${{averageTransaction}}</li>' +
            '<li><strong>Top Product:</strong> {{topProduct}}</li>' +
            '</ul>' +
            '</div>' +
            '<div style="margin: 20px 0;">' +
            '<h3>AI Insights</h3>' +
            '<ul>{{insights}}</ul>' +
            '</div>' +
            '<div style="margin: 20px 0;">' +
            '<h3>Recommendations</h3>' +
            '<ul>{{recommendations}}</ul>' +
            '</div>' +
            '</div>',
      text: 'Daily Sales Summary for {{date}}\n\nTotal Revenue: ${{totalRevenue}}\nTotal Sales: {{totalSales}}'
    });

    this.templates.set('alert', {
      html: '<div style="padding: 20px; border-left: 4px solid #ff4444;"><p>{{message}}</p></div>',
      text: 'ALERT: {{message}}'
    });
  }
}

// Enhanced WhatsApp MCP with rich messaging
export class WhatsAppMCPConnector {
  private businessAccountId: string;
  private accessToken: string;
  private phoneNumberId: string;

  constructor(businessAccountId: string, accessToken: string, phoneNumberId?: string) {
    this.businessAccountId = businessAccountId;
    this.accessToken = accessToken;
    this.phoneNumberId = phoneNumberId || '';
  }

  async sendDailySummary(phoneNumbers: string[], summary: DailySummaryData): Promise<boolean> {
    console.log('📱 WhatsApp MCP: Sending daily summary to', phoneNumbers);
    
    try {
      const message = await this.formatWhatsAppSummary(summary);
      
      for (const phoneNumber of phoneNumbers) {
        await this.sendMessage(phoneNumber, message);
        // Add delay between messages to respect rate limits
        await new Promise(resolve => setTimeout(resolve, 1000));
      }

      console.log('📱 WhatsApp summary sent successfully');
      return true;
    } catch (error) {
      console.error('📱 WhatsApp sending error:', error);
      throw error;
    }
  }

  async sendQuickUpdate(phoneNumbers: string[], message: string): Promise<boolean> {
    console.log('📱 WhatsApp MCP: Sending quick update to', phoneNumbers);
    
    for (const phoneNumber of phoneNumbers) {
      await this.sendMessage(phoneNumber, {
        type: 'text',
        text: { body: message }
      });
    }

    return true;
  }

  async sendTemplateMessage(phoneNumbers: string[], templateName: string, parameters: any[]): Promise<boolean> {
    console.log('📱 WhatsApp MCP: Sending template message:', templateName);
    
    const templateMessage = {
      type: 'template',
      template: {
        name: templateName,
        language: { code: 'en' },
        components: [
          {
            type: 'body',
            parameters: parameters.map(param => ({ type: 'text', text: param }))
          }
        ]
      }
    };

    for (const phoneNumber of phoneNumbers) {
      await this.sendMessage(phoneNumber, templateMessage);
    }

    return true;
  }

  private async formatWhatsAppSummary(summary: DailySummaryData): Promise<any> {
    const emojis = {
      revenue: summary.totalRevenue > 500 ? '💰' : '💵',
      trend: summary.trends.salesTrend === 'increasing' ? '📈' : 
             summary.trends.salesTrend === 'decreasing' ? '📉' : '➡️'
    };

    const message = `
🏪 *DAILY SALES SUMMARY*
📅 ${summary.date}

${emojis.revenue} *Revenue:* $${summary.totalRevenue.toFixed(2)}
📦 *Sales:* ${summary.totalSales} transactions  
💳 *Avg Transaction:* $${summary.averageTransaction.toFixed(2)}
🏆 *Top Product:* ${summary.topSellingItem}

${emojis.trend} *Trend:* ${summary.trends.salesTrend}
⏰ *Peak Hours:* ${summary.trends.peakHours}

💡 *Key Insight:*
${summary.insights[0] || 'No significant patterns detected today.'}

🎯 *Recommendation:*
${summary.recommendations[0] || 'Continue monitoring sales patterns.'}

_Generated by Shop Sales AI_
    `.trim();

    return {
      type: 'text',
      text: { body: message }
    };
  }

  private async sendMessage(phoneNumber: string, message: any): Promise<void> {
    const url = `https://graph.facebook.com/v17.0/${this.phoneNumberId}/messages`;
    
    const payload = {
      messaging_product: 'whatsapp',
      to: phoneNumber,
      ...message
    };

    // Mock API call
    console.log('📱 Sending WhatsApp message to:', phoneNumber);
    await new Promise(resolve => setTimeout(resolve, 500));
  }
}

// Initialize enhanced MCP connectors with default configurations for client-side usage
const firestoreConnector = new FirestoreMCPConnector(
  'demo-project', // Default project ID for demo
  'demo-key' // Default API key for demo
);

const sheetsConnector = new GoogleSheetsMCPConnector(
  'demo-spreadsheet', // Default spreadsheet ID for demo
  'demo-key', // Default API key for demo
  'demo@service-account.com' // Default service account for demo
);

const emailConnector = new EmailMCPConnector({
  host: 'smtp.gmail.com',
  port: 587,
  auth: {
    user: 'demo@shop.com',
    pass: 'demo-password'
  }
});

const whatsappConnector = new WhatsAppMCPConnector(
  'demo-account', // Default business account ID for demo
  'demo-token', // Default access token for demo
  'demo-phone' // Default phone number ID for demo
);

// Enhanced report sending with comprehensive MCP integration
export async function sendReport(summary: DailySummaryData): Promise<void> {
  try {
    console.log('🚀 Starting enhanced MCP report generation and distribution...');

    // 1. Save to Firestore with real-time updates
    await firestoreConnector.saveSale({
      type: 'daily_summary',
      date: summary.date,
      data: summary,
      timestamp: new Date().toISOString()
    });

    // 2. Create comprehensive Google Sheets report with charts
    const sheetUrl = await sheetsConnector.createDailyReport(summary);
    await sheetsConnector.updateMasterSheet([summary]);
    
    // 3. Generate PDF export
    const pdfUrl = await sheetsConnector.exportToPDF(sheetUrl);

    // 4. Send detailed email with attachments
    const ownerEmails = ['owner@shop.com', 'manager@shop.com'];
    await emailConnector.sendDailySummary(ownerEmails, summary, [pdfUrl]);

    // 5. Send WhatsApp summary
    const phoneNumbers = ['+1234567890'];
    await whatsappConnector.sendDailySummary(phoneNumbers, summary);

    // 6. Send alerts if necessary
    if (summary.alerts.length > 0) {
      await emailConnector.sendAlert(ownerEmails, summary.alerts.join('\n'), 'high');
      await whatsappConnector.sendQuickUpdate(phoneNumbers, `🚨 ALERT: ${summary.alerts[0]}`);
    }

    console.log('✅ All MCP integrations completed successfully!');
    
    // Return integration summary
    return {
      firestore: { saved: true, timestamp: new Date().toISOString() },
      sheets: { url: sheetUrl, pdf: pdfUrl },
      email: { sent: true, recipients: ownerEmails.length },
      whatsapp: { sent: true, recipients: phoneNumbers.length },
      alerts: { count: summary.alerts.length }
    } as any;

  } catch (error) {
    console.error('❌ Error in MCP report distribution:', error);
    
    // Send error notification
    try {
      await emailConnector.sendAlert(
        ['admin@shop.com'],
        `MCP Report Error: ${error}`,
        'high'
      );
    } catch (notificationError) {
      console.error('Failed to send error notification:', notificationError);
    }
    
    throw error;
  }
}

// Export enhanced connector instances
export {
  firestoreConnector,
  sheetsConnector,
  emailConnector,
  whatsappConnector
};