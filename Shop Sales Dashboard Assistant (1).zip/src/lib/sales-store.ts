import { create } from 'zustand';
import { mockSales } from './mock-data';

export interface Sale {
  id: string;
  item: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  timestamp: string;
}

export interface Product {
  name: string;
  quantity: number;
  revenue: number;
}

export interface SalesTrend {
  date: string;
  sales: number;
  revenue: number;
}

interface SalesState {
  sales: Sale[];
  addSale: (saleData: Omit<Sale, 'id' | 'timestamp'>) => Promise<void>;
  todaysSales: Sale[];
  todaysRevenue: number;
  totalRevenue: number;
  topProducts: Product[];
  salesTrend: SalesTrend[];
}

export const useSalesStore = create<SalesState>((set, get) => ({
  sales: mockSales,
  
  addSale: async (saleData) => {
    const newSale: Sale = {
      ...saleData,
      id: `sale_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
    };

    set(state => ({
      sales: [newSale, ...state.sales]
    }));

    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 500));
  },

  get todaysSales() {
    const today = new Date().toDateString();
    return get().sales.filter(sale => 
      new Date(sale.timestamp).toDateString() === today
    );
  },

  get todaysRevenue() {
    return get().todaysSales.reduce((total, sale) => total + sale.totalPrice, 0);
  },

  get totalRevenue() {
    return get().sales.reduce((total, sale) => total + sale.totalPrice, 0);
  },

  get topProducts() {
    const sales = get().sales;
    const productMap = new Map<string, Product>();

    sales.forEach(sale => {
      const existing = productMap.get(sale.item);
      if (existing) {
        existing.quantity += sale.quantity;
        existing.revenue += sale.totalPrice;
      } else {
        productMap.set(sale.item, {
          name: sale.item,
          quantity: sale.quantity,
          revenue: sale.totalPrice,
        });
      }
    });

    return Array.from(productMap.values())
      .sort((a, b) => b.quantity - a.quantity);
  },

  get salesTrend() {
    const sales = get().sales;
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - i);
      return date.toISOString().split('T')[0];
    }).reverse();

    return last7Days.map(date => {
      const daySales = sales.filter(sale => 
        sale.timestamp.split('T')[0] === date
      );
      
      return {
        date,
        sales: daySales.length,
        revenue: daySales.reduce((total, sale) => total + sale.totalPrice, 0),
      };
    });
  },
}));