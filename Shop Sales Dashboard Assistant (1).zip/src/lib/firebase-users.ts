import { 
  collection, 
  query, 
  where, 
  getDocs, 
  doc, 
  getDoc, 
  updateDoc, 
  setDoc,
  serverTimestamp
} from 'firebase/firestore';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { auth, db } from './firebase-config';
import { UserProfile } from './firebase-types';

export class UserService {
  static async getCurrentUserProfile(): Promise<UserProfile | null> {
    try {
      const user = auth.currentUser;
      if (!user) return null;

      const userRef = doc(db, 'profiles', user.uid);
      const userSnap = await getDoc(userRef);
      
      if (!userSnap.exists()) return null;

      const data = userSnap.data();
      return {
        id: user.uid,
        ...data,
        created_at: data.created_at?.toDate?.()?.toISOString() || new Date().toISOString(),
        updated_at: data.updated_at?.toDate?.()?.toISOString() || new Date().toISOString()
      } as UserProfile;
    } catch (error) {
      console.error('Error getting current user profile:', error);
      return null;
    }
  }

  static async getUnassignedUsers(): Promise<any[]> {
    try {
      console.log('👥 Getting unassigned users');
      const profilesRef = collection(db, 'profiles');
      const q = query(profilesRef, where('shop_id', '==', null));
      const querySnapshot = await getDocs(q);
      const users: any[] = [];
      
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        users.push({
          id: doc.id,
          ...data,
          created_at: data.created_at?.toDate?.()?.toISOString() || new Date().toISOString(),
          updated_at: data.updated_at?.toDate?.()?.toISOString() || new Date().toISOString(),
          status: 'pending'
        });
      });

      return users.filter(user => user.role !== 'owner');
    } catch (error) {
      console.error('Error getting unassigned users:', error);
      return [];
    }
  }

  static async getShopUsers(shopId: string): Promise<UserProfile[]> {
    try {
      console.log('👥 Getting users for shop:', shopId);
      const profilesRef = collection(db, 'profiles');
      const q = query(profilesRef, where('shop_id', '==', shopId));
      const querySnapshot = await getDocs(q);
      const users: UserProfile[] = [];
      
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        users.push({
          id: doc.id,
          ...data,
          created_at: data.created_at?.toDate?.()?.toISOString() || new Date().toISOString(),
          updated_at: data.updated_at?.toDate?.()?.toISOString() || new Date().toISOString()
        } as UserProfile);
      });

      return users;
    } catch (error) {
      console.error('Error getting shop users:', error);
      return [];
    }
  }

  static async assignUserToShop(userId: string, shopId: string): Promise<void> {
    try {
      const userRef = doc(db, 'profiles', userId);
      await updateDoc(userRef, {
        shop_id: shopId,
        updated_at: serverTimestamp()
      });
    } catch (error) {
      console.error('Error assigning user to shop:', error);
      throw error;
    }
  }

  static async removeUserFromShop(userId: string): Promise<void> {
    try {
      const userRef = doc(db, 'profiles', userId);
      await updateDoc(userRef, {
        shop_id: null,
        updated_at: serverTimestamp()
      });
    } catch (error) {
      console.error('Error removing user from shop:', error);
      throw error;
    }
  }

  static async createUserAccount(userData: {
    email: string;
    password: string;
    full_name: string;
    role: string;
    shop_id: string;
  }): Promise<UserProfile> {
    try {
      // Verify owner is authenticated
      const currentUser = auth.currentUser;
      if (!currentUser) {
        throw new Error('Must be logged in as an owner to create user accounts');
      }

      console.log('🔐 Creating user account with session preservation approach');

      // Store current user info for restoration
      const originalUserEmail = currentUser.email;
      const originalUserUid = currentUser.uid;
      
      console.log('💾 Storing current session info:', originalUserEmail);

      // Create the new user account (this will temporarily sign them in)
      const userCredential = await createUserWithEmailAndPassword(auth, userData.email, userData.password);
      console.log('👤 New user account created:', userData.email);
      
      // Create the profile for the new user
      const userProfile = {
        email: userData.email,
        full_name: userData.full_name,
        role: userData.role,
        shop_id: userData.shop_id,
        created_at: serverTimestamp(),
        updated_at: serverTimestamp()
      };

      const userRef = doc(db, 'profiles', userCredential.user.uid);
      await setDoc(userRef, userProfile);
      console.log('📝 User profile created for:', userData.full_name);

      // Important: Sign out the newly created user immediately
      await auth.signOut();
      console.log('🚪 Signed out newly created user');
      
      // The app's auth state listener will handle the sign-out and the owner will need to sign back in
      // This is actually the safest approach as it prevents session conflicts
      
      console.log('⚠️ Owner will need to sign back in - this is expected behavior');
      
      return {
        id: userCredential.user.uid,
        ...userProfile,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      } as UserProfile;
      
    } catch (error: any) {
      console.error('Error creating user account:', error);
      
      // Handle specific Firebase errors
      if (error?.code === 'auth/email-already-in-use') {
        throw new Error('An account with this email already exists');
      } else if (error?.code === 'auth/weak-password') {
        throw new Error('Password is too weak. Please use a stronger password');
      } else if (error?.code === 'auth/invalid-email') {
        throw new Error('Invalid email address format');
      } else if (error?.code === 'permission-denied') {
        throw new Error('Permission denied. Please ensure Firebase rules allow user creation');
      } else {
        throw error;
      }
    }
  }

  static async sendUserCredentials(credentialsData: {
    email: string;
    full_name: string;
    password: string;
    shop_name: string;
    role: string;
  }): Promise<void> {
    try {
      console.log('📧 Sending user credentials via email:', credentialsData.email);
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate delay
      console.log('✅ User credentials email sent successfully');
    } catch (error) {
      console.error('Error sending user credentials:', error);
      throw error;
    }
  }
}