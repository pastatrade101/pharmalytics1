// Main Firebase service aggregator
export { auth, db } from './firebase-config';
export { 
  onAuthStateChange, 
  signOut, 
  resetPassword, 
  getCurrentUser,
  // Export the wrapped functions with their proper names
  signIn, 
  signUp, 
  signUpAuthOnly 
} from './firebase-auth';

// Also export the raw Firebase functions for direct use
export { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  sendEmailVerification,
  updateProfile
} from 'firebase/auth';

export { ShopService } from './firebase-shops';
export { ProductsService } from './firebase-products';
export * from './firebase-types';

// Import the base service
import { FirebaseService as BaseFirebaseService } from './firebase-users-fixed';
import { ShopService } from './firebase-shops';
import { ProductsService } from './firebase-products';
import { SalesService } from './firebase-sales';
import { canImportProducts } from './app-constants';

// Enhanced FirebaseService with shop status management and product operations - explicitly include all methods
export const FirebaseService = {
  // Base service methods
  createUserProfile: BaseFirebaseService.createUserProfile,
  updateUserProfileWithShop: BaseFirebaseService.updateUserProfileWithShop,
  getCurrentUserProfile: BaseFirebaseService.getCurrentUserProfile,
  createUserAccount: BaseFirebaseService.createUserAccount,
  getUserById: BaseFirebaseService.getUserById,
  getShopUsers: BaseFirebaseService.getShopUsers,
  getUnassignedUsers: BaseFirebaseService.getUnassignedUsers,
  assignUserToShop: BaseFirebaseService.assignUserToShop,
  removeUserFromShop: BaseFirebaseService.removeUserFromShop,
  sendUserCredentials: BaseFirebaseService.sendUserCredentials,
  checkShopActive: BaseFirebaseService.checkShopActive,
  validateShopOperationAccess: BaseFirebaseService.validateShopOperationAccess,
  
  // Super admin methods
  createSuperAdminAccount: BaseFirebaseService.createSuperAdminAccount,
  signInSuperAdmin: BaseFirebaseService.signInSuperAdmin,
  ensureSuperAdminProfile: BaseFirebaseService.ensureSuperAdminProfile,
  
  // Shop management methods
  createShop: ShopService.createShop,
  isShopNameAvailable: ShopService.isShopNameAvailable,
  getShopById: ShopService.getShopById,
  updateShopStatus: ShopService.updateShopStatus,
  getAllShops: ShopService.getAllShops,
  getAllPharmacies: ShopService.getAllShops, // Alias for getAllShops for backward compatibility
  getShopsByStatus: ShopService.getShopsByStatus,
  getPendingShopsCount: ShopService.getPendingShopsCount,
  isShopActive: ShopService.isShopActive,
  activateShop: ShopService.activateShop,
  deactivateShop: ShopService.deactivateShop,
  setPendingShop: ShopService.setPendingShop,
  getShopStatistics: ShopService.getShopStatistics,

  // Product management methods with permission validation
  createProduct: async (productData: any) => {
    // Get current user profile to check role
    const userProfile = await BaseFirebaseService.getCurrentUserProfile();
    if (!userProfile) {
      const error = new Error('User authentication required');
      (error as any).isPermissionError = true;
      throw error;
    }

    // FIXED: Updated to use the correct permission check and roles
    if (!canImportProducts(userProfile.role)) {
      const error = new Error(`Your role (${userProfile.role}) doesn't have permission to import products. Required roles: product_manager, owner, admin, super_admin`);
      (error as any).type = 'error';
      (error as any).action = 'Review Error Details';
      (error as any).instructions = 'Review the error details and try refreshing the page. Contact support if the issue persists.';
      (error as any).originalError = {};
      (error as any).isPermissionError = true;
      throw error;
    }

    // If user has permission, ensure shop_id is set
    if (!productData.shop_id && userProfile.shop_id) {
      productData.shop_id = userProfile.shop_id;
    }

    return await ProductsService.createProduct(productData);
  },

  getProduct: ProductsService.getProduct,
  getProducts: ProductsService.getProducts,
  getActiveProducts: ProductsService.getActiveProducts,
  getProductBySKU: ProductsService.getProductBySKU,
  updateProduct: ProductsService.updateProduct,
  deleteProduct: ProductsService.deleteProduct,
  hardDeleteProduct: ProductsService.hardDeleteProduct,
  updateStock: ProductsService.updateStock,
  getLowStockProducts: ProductsService.getLowStockProducts,
  getExpiringProducts: ProductsService.getExpiringProducts,
  subscribeToProducts: ProductsService.subscribeToProducts,

  // Helper method to get products for current user
  async getProductsForCurrentUser() {
    const userProfile = await BaseFirebaseService.getCurrentUserProfile();
    if (!userProfile || !userProfile.shop_id) {
      throw new Error('No pharmacy associated with your account');
    }
    return await ProductsService.getProducts(userProfile.shop_id);
  },

  // Sales management methods - FIXED: Added missing methods causing FirebaseService2 errors
  createSale: SalesService.createSale,
  getSales: SalesService.getSales,
  getSalesByShop: SalesService.getSalesByShop,
  getSalesForShop: SalesService.getSalesForShop,
  getTodaysSales: SalesService.getTodaysSales,
  subscribeToSales: SalesService.subscribeToSales,
  generateAIDailySummary: SalesService.generateAIDailySummary,

  // User profile methods - FIXED: Added missing getUserProfile method
  getUserProfile: BaseFirebaseService.getCurrentUserProfile, // Alias for getCurrentUserProfile

  // Connection management methods
  getConnectionStatus: ProductsService.getConnectionStatus,
  resetConnections: ProductsService.resetConnections,
  cleanupAllListeners: ProductsService.cleanupAllListeners,
};

// Re-export SalesService as a separate export to avoid circular dependencies
export { SalesService } from './firebase-sales';