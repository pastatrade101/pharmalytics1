/**
 * Data Validation and Safe Parsing Utilities
 * 
 * This module provides safe parsing functions for potentially undefined or invalid data
 * coming from Firestore, preventing runtime errors and ensuring data integrity.
 */

/**
 * Safely parses a numeric value from potentially undefined/null input
 * @param value - The value to parse (could be string, number, undefined, null)
 * @param fallback - The fallback value if parsing fails (default: 0)
 * @returns A valid number or the fallback value
 */
export function safeParseFloat(value: any, fallback: number = 0): number {
  try {
    if (value === null || value === undefined || value === '') {
      return fallback;
    }
    
    const parsed = parseFloat(value.toString());
    
    if (isNaN(parsed) || !isFinite(parsed)) {
      return fallback;
    }
    
    // Return fallback for negative values if they shouldn't be allowed
    return parsed >= 0 ? parsed : fallback;
  } catch (error) {
    console.warn('⚠️ Error parsing float value:', { value, error });
    return fallback;
  }
}

/**
 * Safely parses an integer value from potentially undefined/null input
 * @param value - The value to parse (could be string, number, undefined, null)
 * @param fallback - The fallback value if parsing fails (default: 0)
 * @returns A valid integer or the fallback value
 */
export function safeParseInt(value: any, fallback: number = 0): number {
  try {
    if (value === null || value === undefined || value === '') {
      return fallback;
    }
    
    const parsed = parseInt(value.toString(), 10);
    
    if (isNaN(parsed) || !isFinite(parsed)) {
      return fallback;
    }
    
    // Return fallback for negative values if they shouldn't be allowed
    return parsed >= 0 ? parsed : fallback;
  } catch (error) {
    console.warn('⚠️ Error parsing integer value:', { value, error });
    return fallback;
  }
}

/**
 * Safely extracts a string value from potentially undefined/null input
 * @param value - The value to extract (could be string, undefined, null)
 * @param fallback - The fallback value if extraction fails (default: '')
 * @returns A valid string or the fallback value
 */
export function safeString(value: any, fallback: string = ''): string {
  try {
    if (value === null || value === undefined) {
      return fallback;
    }
    
    return value.toString();
  } catch (error) {
    console.warn('⚠️ Error converting to string:', { value, error });
    return fallback;
  }
}

/**
 * Safely calculates inventory value from product data
 * @param products - Array of products with price and stock_quantity fields
 * @returns Total inventory value
 */
export function calculateInventoryValue(products: any[]): number {
  if (!Array.isArray(products)) {
    console.warn('⚠️ Invalid products array provided to calculateInventoryValue');
    return 0;
  }
  
  return products.reduce((total, product) => {
    try {
      const price = safeParseFloat(product?.price, 0);
      const stockQuantity = safeParseInt(product?.stock_quantity, 0);
      
      // Only add valid combinations
      if (price > 0 && stockQuantity > 0) {
        return total + (price * stockQuantity);
      }
      
      return total;
    } catch (error) {
      console.warn(`⚠️ Error calculating value for product ${product?.id || 'unknown'}:`, error);
      return total;
    }
  }, 0);
}

/**
 * Safely calculates total revenue from sales data
 * @param sales - Array of sales with total_price field
 * @param pharmacyId - Optional pharmacy ID for better error logging
 * @returns Total revenue
 */
export function calculateTotalRevenue(sales: any[], pharmacyId?: string): number {
  if (!Array.isArray(sales)) {
    console.warn('⚠️ Invalid sales array provided to calculateTotalRevenue');
    return 0;
  }
  
  return sales.reduce((total, sale) => {
    try {
      const totalPrice = safeParseFloat(sale?.total_price, 0);
      
      // Only add positive revenue
      if (totalPrice > 0) {
        return total + totalPrice;
      }
      
      return total;
    } catch (error) {
      const saleId = sale?.id || 'unknown';
      const pharmacyRef = pharmacyId ? ` in pharmacy ${pharmacyId}` : '';
      console.warn(`⚠️ Error calculating revenue for sale ${saleId}${pharmacyRef}:`, error);
      return total;
    }
  }, 0);
}

/**
 * Validates and sanitizes product data
 * @param product - Raw product data from Firestore
 * @returns Sanitized product data with valid defaults
 */
export function sanitizeProductData(product: any) {
  return {
    id: safeString(product?.id, 'unknown'),
    name: safeString(product?.name, 'Unknown Product'),
    price: safeParseFloat(product?.price, 0),
    stock_quantity: safeParseInt(product?.stock_quantity, 0),
    min_stock_level: safeParseInt(product?.min_stock_level, 0),
    barcode: safeString(product?.barcode, ''),
    category: safeString(product?.category, 'Uncategorized'),
    description: safeString(product?.description, ''),
    shop_id: safeString(product?.shop_id, ''),
    created_at: product?.created_at || new Date().toISOString(),
    updated_at: product?.updated_at || new Date().toISOString(),
    status: safeString(product?.status, 'active'),
    ...product // Preserve other fields
  };
}

/**
 * Validates and sanitizes sale data
 * @param sale - Raw sale data from Firestore
 * @returns Sanitized sale data with valid defaults
 */
export function sanitizeSaleData(sale: any) {
  return {
    id: safeString(sale?.id, 'unknown'),
    shop_id: safeString(sale?.shop_id, ''),
    cashier_id: safeString(sale?.cashier_id, ''),
    customer_id: safeString(sale?.customer_id, ''),
    total_price: safeParseFloat(sale?.total_price, 0),
    subtotal: safeParseFloat(sale?.subtotal, 0),
    tax_amount: safeParseFloat(sale?.tax_amount, 0),
    discount_amount: safeParseFloat(sale?.discount_amount, 0),
    payment_method: safeString(sale?.payment_method, 'cash'),
    sale_number: safeString(sale?.sale_number, ''),
    timestamp: sale?.timestamp || new Date().toISOString(),
    created_at: sale?.created_at || new Date().toISOString(),
    items: Array.isArray(sale?.items) ? sale.items : [],
    status: safeString(sale?.status, 'completed'),
    ...sale // Preserve other fields
  };
}

/**
 * Safely parses a date from various input formats
 * @param value - The date value to parse
 * @param fallback - Fallback date if parsing fails
 * @returns A valid Date object
 */
export function safeParseDate(value: any, fallback: Date = new Date()): Date {
  try {
    if (value === null || value === undefined) {
      return fallback;
    }
    
    // Handle Firestore Timestamp objects
    if (value?.toDate && typeof value.toDate === 'function') {
      return value.toDate();
    }
    
    // Handle string dates
    if (typeof value === 'string' || typeof value === 'number') {
      const parsed = new Date(value);
      if (!isNaN(parsed.getTime())) {
        return parsed;
      }
    }
    
    // Handle Date objects
    if (value instanceof Date && !isNaN(value.getTime())) {
      return value;
    }
    
    return fallback;
  } catch (error) {
    console.warn('⚠️ Error parsing date value:', { value, error });
    return fallback;
  }
}

/**
 * Validates if a shop/pharmacy has valid basic data
 * @param shop - Shop data to validate
 * @returns Boolean indicating if shop data is valid
 */
export function isValidShopData(shop: any): boolean {
  return !!(
    shop &&
    safeString(shop.id) &&
    safeString(shop.name) &&
    shop.created_at
  );
}

/**
 * Creates a safe error context for logging with pharmacy/shop information
 * @param pharmacyId - Pharmacy ID
 * @param operation - Operation being performed
 * @param additionalContext - Additional context data
 * @returns Formatted error context string
 */
export function createErrorContext(
  pharmacyId: string, 
  operation: string, 
  additionalContext?: any
): string {
  const baseContext = `Pharmacy ${pharmacyId} - ${operation}`;
  
  if (additionalContext) {
    return `${baseContext} - ${JSON.stringify(additionalContext)}`;
  }
  
  return baseContext;
}

/**
 * Batch validates an array of data items with error reporting
 * @param items - Array of items to validate
 * @param validator - Validation function
 * @param context - Context for error reporting
 * @returns Array of valid items
 */
export function batchValidate<T>(
  items: any[],
  validator: (item: any) => T | null,
  context: string = 'Unknown context'
): T[] {
  if (!Array.isArray(items)) {
    console.warn(`⚠️ Invalid array provided for batch validation - ${context}`);
    return [];
  }
  
  const validItems: T[] = [];
  let errorCount = 0;
  
  items.forEach((item, index) => {
    try {
      const validated = validator(item);
      if (validated !== null) {
        validItems.push(validated);
      } else {
        errorCount++;
      }
    } catch (error) {
      console.warn(`⚠️ Validation error for item ${index} in ${context}:`, error);
      errorCount++;
    }
  });
  
  if (errorCount > 0) {
    console.warn(`⚠️ ${errorCount} items failed validation in ${context}`);
  }
  
  return validItems;
}