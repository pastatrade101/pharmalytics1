import { 
  collection, 
  addDoc, 
  getDocs, 
  doc, 
  getDoc,
  query, 
  where, 
  serverTimestamp,
  runTransaction,
  orderBy,
  limit
} from 'firebase/firestore';
import { db, auth, parseFirestoreTimestamp } from './firebase-config';
import { Sale, DailyReport, Product } from './firebase-types';
import { handleFirebaseError } from './firebase-errors';
import { formatTZS } from './currency-utils';
import FirebaseConnectionManager from './firebase-connection-manager';

export class SalesService {
  private static connectionManager = FirebaseConnectionManager.getInstance();

  static async createSale(saleData: Omit<Sale, 'id' | 'created_at' | 'updated_at'>) {
    // Clean the sale data and declare it outside try block for error logging
    let cleanSaleData: any;
    
    try {
      console.log('💰 Creating sale with stock update:', saleData);
      
      // Validate required fields to prevent undefined errors
      if (!saleData.shop_id) {
        throw new Error('shop_id is required for sale creation');
      }
      
      if (!saleData.cashier_id) {
        throw new Error('cashier_id is required for sale creation');
      }
      
      // Clean the sale data to remove any undefined values
      cleanSaleData = this.cleanSaleData(saleData);
      
      // Use a transaction to ensure atomicity of sale creation and stock update
      // CRITICAL: Firestore transactions require ALL reads before ALL writes
      const result = await runTransaction(db, async (transaction) => {
        console.log('🔄 Starting transaction with proper read/write ordering');
        
        // PHASE 1: READ ALL PRODUCTS FIRST (Firestore requirement)
        const productReads: Array<{
          item: any;
          productDocRef: any;
          productDoc: any;
          productData: Product | null;
        }> = [];
        
        for (const item of cleanSaleData.items) {
          if (!item.product_id) {
            console.log('⚠️ Skipping stock update for item without product_id:', item.product_name);
            continue;
          }
          
          const productDocRef = doc(db, 'products', item.product_id);
          console.log('📖 Reading product document for:', item.product_name);
          
          try {
            const productDoc = await transaction.get(productDocRef);
            const productData = productDoc.exists() ? (productDoc.data() as Product) : null;
            
            productReads.push({
              item,
              productDocRef,
              productDoc,
              productData
            });
            
            console.log('✅ Product read completed for:', item.product_name, 'exists:', productDoc.exists());
          } catch (readError: any) {
            console.error('❌ Error reading product:', item.product_name, readError);
            throw new Error(`Failed to read product ${item.product_name}: ${readError.message}`);
          }
        }
        
        console.log('✅ All product reads completed. Starting validation and writes...');
        
        // PHASE 2: VALIDATE AND PREPARE STOCK UPDATES
        const stockUpdates: Array<{
          productDocRef: any;
          updateData: any;
          productName: string;
          currentStock: number;
          newStock: number;
        }> = [];
        
        for (const { item, productDocRef, productDoc, productData } of productReads) {
          try {
            if (!productDoc.exists()) {
              console.log('⚠️ Product document not found for stock update:', item.product_id);
              continue;
            }
            
            if (!productData) {
              console.log('⚠️ Product data is null for:', item.product_name);
              continue;
            }
            
            // Verify the product belongs to the same shop
            if (productData.shop_id !== cleanSaleData.shop_id) {
              console.log('⚠️ Product shop mismatch:', {
                productShopId: productData.shop_id,
                expectedShopId: cleanSaleData.shop_id,
                productName: item.product_name
              });
              continue;
            }
            
            if (productData.status !== 'active') {
              console.log('⚠️ Product not active for stock update:', item.product_name, 'status:', productData.status);
              continue;
            }
            
            const currentStock = productData.stock_quantity || 0;
            const newStock = Math.max(0, currentStock - item.quantity);
            
            console.log('📦 Preparing stock update for:', {
              product: item.product_name,
              productId: item.product_id,
              oldStock: currentStock,
              soldQuantity: item.quantity,
              newStock: newStock,
              authUser: auth.currentUser?.uid,
              shopId: cleanSaleData.shop_id
            });
            
            // Validate the stock update is allowed
            if (newStock > currentStock) {
              console.error('❌ Invalid stock update: new stock cannot be higher than current stock');
              throw new Error(`Invalid stock update for ${item.product_name}: cannot increase stock during sale`);
            }
            
            // Check for insufficient stock
            if (currentStock < item.quantity) {
              console.warn('⚠️ Insufficient stock detected:', {
                product: item.product_name,
                available: currentStock,
                requested: item.quantity,
                proceeding_with: newStock
              });
            }
            
            // Prepare the stock update
            stockUpdates.push({
              productDocRef,
              updateData: {
                stock_quantity: newStock,
                updated_at: serverTimestamp()
              },
              productName: item.product_name,
              currentStock,
              newStock
            });
            
            // Log low stock warning
            if (newStock <= (productData.min_stock_level || 0)) {
              console.log('⚠️ Low stock alert:', item.product_name, 'will be at', newStock, 'units');
            }
            
          } catch (validationError: any) {
            console.error('❌ Error validating stock update for item:', item.product_name, validationError);
            throw new Error(`Stock validation failed for ${item.product_name}: ${validationError.message}`);
          }
        }
        
        // PHASE 3: PERFORM ALL WRITES (Firestore requirement - all writes after all reads)
        console.log('📝 Starting write phase - updating', stockUpdates.length, 'products');
        
        // First, update all product stocks
        for (const { productDocRef, updateData, productName } of stockUpdates) {
          try {
            transaction.update(productDocRef, updateData);
            console.log('✅ Stock update queued for:', productName);
          } catch (updateError: any) {
            console.error('❌ Error updating stock for item:', productName, updateError);
            
            // Handle specific permission errors
            if (updateError.code === 'permission-denied') {
              console.error('🚨 PERMISSION DENIED: Salesman role cannot update product stock');
              console.error('🚨 This indicates Firestore rules need to be updated');
              console.error('🚨 Check if the salesman stock update rule is properly deployed');
              
              // Re-throw permission errors as they indicate configuration issues
              throw new Error(`Permission denied updating stock for ${productName}. Firestore rules may need updating.`);
            }
            
            // Re-throw all stock update errors in transactions
            throw new Error(`Failed to update stock for ${productName}: ${updateError.message}`);
          }
        }
        
        // Finally, create the sale record
        const salesRef = collection(db, 'sales');
        const saleWithTimestamps = {
          ...cleanSaleData,
          created_at: serverTimestamp(),
          updated_at: serverTimestamp()
        };
        
        console.log('💾 Adding sale document to Firestore:', {
          shop_id: saleWithTimestamps.shop_id,
          cashier_id: saleWithTimestamps.cashier_id,
          customer_id: saleWithTimestamps.customer_id,
          items_count: saleWithTimestamps.items.length,
          total_price: saleWithTimestamps.total_price,
          sale_number: saleWithTimestamps.sale_number
        });
        
        // Debug: Log auth context for troubleshooting
        console.log('🔐 Current auth context for sale creation:', {
          auth_available: auth.currentUser !== null,
          auth_uid: auth.currentUser?.uid,
          auth_email: auth.currentUser?.email,
          cashier_id_matches: auth.currentUser?.uid === saleWithTimestamps.cashier_id
        });
        
        const saleDocRef = await addDoc(salesRef, saleWithTimestamps);
        console.log('✅ Transaction completed successfully - sale created with stock updates');
        
        return saleDocRef;
      });
      
      // Get the created sale document
      const docSnap = await getDoc(result);
      
      if (docSnap.exists()) {
        const data = docSnap.data();
        
        const sale = {
          id: docSnap.id,
          ...data,
          created_at: parseFirestoreTimestamp(data.created_at),
          updated_at: parseFirestoreTimestamp(data.updated_at)
        } as Sale;
        
        console.log('✅ Sale created successfully with stock updates:', sale.id);
        return sale;
      }
      
      throw new Error('Failed to retrieve created sale document');
    } catch (error: any) {
      console.error('❌ Error in createSale transaction:', error);
      
      // Provide specific error context based on the error type
      if (error?.code === 'invalid-argument' && error?.message?.includes('reads to be executed before all writes')) {
        console.error('🚨 TRANSACTION ORDERING ERROR: This should be fixed now with proper read/write separation');
        console.error('🚨 If you see this error, there may be a remaining transaction ordering issue');
      } else if (error?.code === 'permission-denied') {
        console.error('🚨 PERMISSION ERROR: Check Firestore rules for sales creation and product stock updates');
        console.error('🚨 Current user:', auth.currentUser?.uid);
        
        // Only log cleanSaleData if it exists (to prevent ReferenceError)
        if (cleanSaleData) {
          console.error('🚨 Shop ID:', cleanSaleData.shop_id);
          console.error('🚨 Cashier ID:', cleanSaleData.cashier_id);
        } else {
          console.error('🚨 Shop ID:', saleData.shop_id);
          console.error('🚨 Cashier ID:', saleData.cashier_id);
        }
      } else if (error?.message?.includes('stock')) {
        console.error('🚨 STOCK UPDATE ERROR: Issue with product inventory validation or updates');
      } else if (error?.message?.includes('Product')) {
        console.error('🚨 PRODUCT ERROR: Issue reading or validating products for sale');
      }
      
      handleFirebaseError(error, 'Creating Sale');
      throw error;
    }
  }
  
  // Helper method to clean sale data and remove undefined values
  private static cleanSaleData(saleData: Omit<Sale, 'id' | 'created_at' | 'updated_at'>) {
    const cleaned = { ...saleData };
    
    // Remove undefined fields that could cause Firestore errors
    Object.keys(cleaned).forEach(key => {
      if (cleaned[key] === undefined) {
        delete cleaned[key];
      }
    });
    
    // Ensure required fields have valid values
    if (!cleaned.customer_id) {
      delete cleaned.customer_id;
    }
    
    if (!cleaned.customer_name) {
      delete cleaned.customer_name;
    }
    
    if (!cleaned.customer_phone) {
      delete cleaned.customer_phone;
    }
    
    if (!cleaned.customer_address) {
      delete cleaned.customer_address;
    }
    
    if (!cleaned.payment_reference) {
      delete cleaned.payment_reference;
    }
    
    // Clean up prescription fields if not needed
    if (!cleaned.prescription_number) {
      delete cleaned.prescription_number;
    }
    
    if (!cleaned.doctor_name) {
      delete cleaned.doctor_name;
    }
    
    // Clean up insurance fields if not needed
    if (!cleaned.insurance_provider) {
      delete cleaned.insurance_provider;
    }
    
    if (!cleaned.insurance_number) {
      delete cleaned.insurance_number;
    }
    
    return cleaned;
  }

  // FIXED: Parameter validation helper
  private static validateShopId(shopId?: string): string {
    if (!shopId || typeof shopId !== 'string' || shopId.trim().length === 0) {
      throw new Error('Invalid or missing shop_id parameter. Shop ID is required for sales queries.');
    }
    return shopId.trim();
  }

  // FIXED: getSales now has two variants - one for super admins, one for shop-specific queries
  static async getSales(limitCount: number = 100): Promise<Sale[]> {
    try {
      // Only log warning in development mode
      if (process.env.NODE_ENV === 'development') {
        console.warn('⚠️ getSales() called without shop filter - should only be used by super admins');
      }
      console.log('📊 Getting all sales (no shop filter)');
      
      // Validate current user has permission for cross-shop access
      const currentUser = auth.currentUser;
      if (!currentUser) {
        throw new Error('User must be authenticated to access sales data');
      }
      
      const salesRef = collection(db, 'sales');
      // FIXED: Use simple query without orderBy to avoid index requirement
      const q = query(salesRef, limit(limitCount));

      const querySnapshot = await getDocs(q);
      const sales: Sale[] = [];
      
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        
        sales.push({
          id: doc.id,
          ...data,
          created_at: parseFirestoreTimestamp(data.created_at),
          updated_at: parseFirestoreTimestamp(data.updated_at)
        } as Sale);
      });

      // Sort by timestamp on the client side to avoid index requirement
      sales.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

      console.log(`✅ Retrieved ${sales.length} sales (no shop filter)`);
      return sales;
    } catch (error: any) {
      console.error('Error getting sales:', error);
      
      // Handle specific Firebase errors
      if (error?.code === 'permission-denied') {
        console.log('🚨 PERMISSION ERROR in getSales - returning empty array as fallback');
        return [];
      }
      
      if (error?.code === 'failed-precondition') {
        console.error('🚨 INDEX ERROR: Firebase index required for getSales query');
        console.error('🚨 Falling back to simple query without ordering');
        // Return empty array to prevent app crash
        return [];
      }
      
      throw error;
    }
  }

  // FIXED: Add the missing getSalesByShop method that components are trying to call
  static async getSalesByShop(shopId: string, limitCount: number = 100, dateRange?: { start: string; end: string }): Promise<Sale[]> {
    try {
      // Validate shopId parameter
      const validShopId = this.validateShopId(shopId);
      
      console.log('📊 Getting sales for shop:', validShopId, 'limit:', limitCount);
      
      const salesRef = collection(db, 'sales');
      
      // FIXED: Use simple query to avoid index requirement
      const q = query(
        salesRef, 
        where('shop_id', '==', validShopId),
        limit(limitCount)
      );

      const querySnapshot = await getDocs(q);
      const sales: Sale[] = [];
      
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        
        sales.push({
          id: doc.id,
          ...data,
          created_at: parseFirestoreTimestamp(data.created_at),
          updated_at: parseFirestoreTimestamp(data.updated_at)
        } as Sale);
      });

      // Sort by timestamp on the client side to avoid index requirement
      sales.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

      // Filter by date range if provided
      if (dateRange) {
        const filtered = sales.filter(sale => {
          try {
            const saleDate = new Date(sale.timestamp);
            return saleDate >= new Date(dateRange.start) && saleDate <= new Date(dateRange.end);
          } catch {
            return false;
          }
        });
        console.log(`✅ Retrieved ${filtered.length} sales for shop ${validShopId} with date range`);
        return filtered;
      }

      console.log(`✅ Retrieved ${sales.length} sales for shop ${validShopId}`);
      return sales;
    } catch (error: any) {
      console.error('Error getting sales by shop:', error);
      
      // Handle specific Firebase errors
      if (error?.code === 'permission-denied') {
        console.log('🚨 PERMISSION ERROR in getSalesByShop - returning empty array as fallback');
        return [];
      }
      
      if (error?.code === 'failed-precondition') {
        console.error('🚨 INDEX ERROR: Firebase index required for getSalesByShop query');
        console.error('🚨 Error details:', error.message);
        console.error('🚨 Falling back to simple query');
        
        // Try a simpler query without ordering
        try {
          const salesRef = collection(db, 'sales');
          const simpleQuery = query(salesRef, where('shop_id', '==', shopId));
          const querySnapshot = await getDocs(simpleQuery);
          
          const sales: Sale[] = [];
          querySnapshot.forEach((doc) => {
            const data = doc.data();
            sales.push({
              id: doc.id,
              ...data,
              created_at: parseFirestoreTimestamp(data.created_at),
              updated_at: parseFirestoreTimestamp(data.updated_at)
            } as Sale);
          });
          
          // Sort on client side
          sales.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
          
          // Apply limit on client side
          const limitedSales = sales.slice(0, limitCount);
          
          console.log(`✅ Retrieved ${limitedSales.length} sales for shop ${shopId} using fallback query`);
          return limitedSales;
        } catch (fallbackError) {
          console.error('❌ Fallback query also failed:', fallbackError);
          return [];
        }
      }
      
      throw error;
    }
  }

  // FIXED: Update original getSales method to require shopId to maintain backwards compatibility
  static async getSalesForShop(shopId: string, dateRange?: { start: string; end: string }): Promise<Sale[]> {
    // This is the old getSales method - redirect to getSalesByShop for clarity
    return this.getSalesByShop(shopId, 100, dateRange);
  }

  static async getTodaysSales(shopId: string): Promise<Sale[]> {
    try {
      // Validate shopId parameter
      const validShopId = this.validateShopId(shopId);
      
      const today = new Date().toISOString().split('T')[0];
      const startOfDay = `${today}T00:00:00.000Z`;
      const endOfDay = `${today}T23:59:59.999Z`;

      return this.getSalesByShop(validShopId, 100, { start: startOfDay, end: endOfDay });
    } catch (error: any) {
      console.error('Error getting today\'s sales:', error);
      
      // Handle permission errors gracefully
      if (error?.code === 'permission-denied') {
        console.log('🚨 PERMISSION ERROR in getTodaysSales - returning empty array as fallback');
        return [];
      }
      
      throw error;
    }
  }

  static subscribeToSales(shopId: string, callback: (sales: Sale[]) => void): () => void {
    try {
      // FIXED: Validate shopId parameter BEFORE creating the listener to avoid 'this' context issues
      const validShopId = SalesService.validateShopId(shopId);
      
      console.log('🔄 Setting up managed real-time sales subscription for shop:', validShopId);

      const salesRef = collection(db, 'sales');
      
      // FIXED: Use simple query to avoid index requirement
      const q = query(
        salesRef, 
        where('shop_id', '==', validShopId),
        limit(100)
      );

      // Use the connection manager for better error handling and connection management
      return SalesService.connectionManager.createManagedListener<Sale>(
        q,
        (sales) => {
          // Sort by timestamp on the client side
          sales.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
          console.log(`✅ Managed real-time sales update: ${sales.length} records for shop ${validShopId}`);
          callback(sales);
        },
        (error) => {
          console.error('❌ Error in managed sales subscription:', error);
          
          // Handle specific Firebase errors
          if (error.code === 'failed-precondition') {
            console.error('🚨 INDEX ERROR in sales subscription - Firebase index required');
            console.error('🚨 Index URL provided in error, but falling back to empty results');
          }
          
          // For permission errors, provide graceful fallback
          if (error.code === 'permission-denied') {
            console.log('🚨 PERMISSION ERROR in sales subscription - providing empty array fallback');
          }
          
          // Always provide fallback for any error
          callback([]);
        },
        `sales_${validShopId}` // Unique listener key
      );
    } catch (error: any) {
      console.error('❌ Error setting up managed sales subscription:', error);
      
      // Provide fallback behavior
      callback([]);
      return () => {
        console.log('🔄 Cleaning up failed sales subscription');
      };
    }
  }

  static async generateAIDailySummary(shopId: string): Promise<DailyReport> {
    try {
      // Validate shopId parameter
      const validShopId = this.validateShopId(shopId);
      
      console.log('🤖 Generating AI-powered daily summary for shop:', validShopId);
      
      // Get today's sales data
      const todaysSales = await this.getTodaysSales(validShopId);
      const totalRevenue = todaysSales.reduce((sum, sale) => sum + parseFloat(sale.total_price.toString()), 0);
      const averageTransaction = todaysSales.length > 0 ? totalRevenue / todaysSales.length : 0;
      
      // Get top selling items from sale items
      const productCounts: { [key: string]: number } = {};
      let totalTransactions = 0;
      
      todaysSales.forEach(sale => {
        totalTransactions++;
        sale.items.forEach(item => {
          productCounts[item.product_name] = (productCounts[item.product_name] || 0) + item.quantity;
        });
      });
      
      const topSellingItem = Object.keys(productCounts).length > 0 
        ? Object.keys(productCounts).reduce((a, b) => productCounts[a] > productCounts[b] ? a : b)
        : 'No sales today';
      
      const fallbackReport: DailyReport = {
        id: `report-${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
        shop_id: validShopId,
        total_sales: totalTransactions,
        total_revenue: totalRevenue,
        total_transactions: totalTransactions,
        average_transaction: averageTransaction,
        top_selling_item: topSellingItem,
        insights: [
          `Today's performance: ${totalTransactions} transactions generating ${formatTZS(totalRevenue)} in revenue.`,
          totalRevenue > 125000 ? 'Strong revenue performance today!' : 'Consider promotional strategies to boost sales.',
          Object.keys(productCounts).length > 0 ? `${Object.keys(productCounts).length} different products sold today.` : 'No product sales recorded today.'
        ],
        recommendations: [
          'Monitor inventory levels for top-selling items.',
          'Continue tracking sales patterns for future analysis.',
          productCounts[topSellingItem] > 5 ? `High demand for ${topSellingItem} - ensure adequate stock.` : 'Review product mix to identify sales opportunities.'
        ],
        trends: {
          salesTrend: totalRevenue > 75000 ? 'increasing' : totalRevenue > 25000 ? 'stable' : 'declining',
          peakHours: 'Analysis unavailable - requires hourly data tracking',
          slowPeriods: 'Analysis unavailable - requires hourly data tracking'
        },
        alerts: totalRevenue < 10000 ? ['Low sales volume today - consider promotional activities'] : [],
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        aiAnalysis: {
          reportText: `Daily Sales Summary - ${new Date().toLocaleDateString()}
            
Basic Metrics:
• Total Transactions: ${totalTransactions}
• Revenue: ${formatTZS(totalRevenue)}
• Average Transaction: ${formatTZS(averageTransaction)}
• Top Selling Item: ${topSellingItem} (${productCounts[topSellingItem] || 0} units)
• Products Sold: ${Object.keys(productCounts).length} different items

Performance Analysis:
${totalRevenue > 125000 ? '✅ Excellent daily performance' : totalRevenue > 75000 ? '👍 Good daily performance' : totalRevenue > 25000 ? '⚠️ Average daily performance' : '🔻 Below average performance'}

Generated by Pharmacy Management System
${new Date().toLocaleString()}`,
          generatedBy: 'Basic Analysis Engine',
          timestamp: new Date().toISOString(),
          isMockData: true
        }
      };
      
      return fallbackReport;
    } catch (error: any) {
      console.error('Error generating AI daily summary:', error);
      throw error;
    }
  }

  // Static method to get connection status
  static getConnectionStatus() {
    return this.connectionManager.getConnectionState();
  }

  // Static method to reset connections (useful during auth changes)
  static resetConnections() {
    this.connectionManager.resetConnectionState();
  }

  // Static method to cleanup all listeners (useful during sign out)
  static cleanupAllListeners() {
    this.connectionManager.cleanupAllListeners();
  }
}