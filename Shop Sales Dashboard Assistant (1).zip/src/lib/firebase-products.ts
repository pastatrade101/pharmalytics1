import { 
  collection, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs, 
  getDoc,
  query, 
  where, 
  orderBy, 
  Timestamp,
  serverTimestamp
} from 'firebase/firestore';
import { db, parseFirestoreTimestamp } from './firebase-config';
import { Product } from './firebase-types';
import { handleFirebaseError } from './firebase-errors';
import FirebaseConnectionManager from './firebase-connection-manager';

export class ProductsService {
  private static readonly COLLECTION_NAME = 'products';
  private static connectionManager = FirebaseConnectionManager.getInstance();
  
  /**
   * Safely parse product data from Firestore to ensure numeric values are valid
   */
  private static parseProductData(doc: any): Product {
    const data = doc.data();
    
    // Log any problematic data for debugging
    if (data.retail_price === null || data.retail_price === undefined || isNaN(Number(data.retail_price))) {
      console.warn('🚨 Product with invalid retail_price found:', {
        id: doc.id,
        name: data.name,
        retail_price: data.retail_price,
        typeof_retail_price: typeof data.retail_price
      });
    }
    
    // Use the shared timestamp parsing utility
    
    return {
      id: doc.id,
      ...data,
      // Safely parse numeric price fields - prevent NaN values
      retail_price: Math.max(0, parseFloat(data.retail_price) || 0),
      cost_price: Math.max(0, parseFloat(data.cost_price) || 0),
      wholesale_price: data.wholesale_price ? Math.max(0, parseFloat(data.wholesale_price) || 0) : undefined,
      insurance_price: data.insurance_price ? Math.max(0, parseFloat(data.insurance_price) || 0) : undefined,
      markup_percentage: Math.max(0, parseFloat(data.markup_percentage) || 0),
      
      // Safely parse stock quantities
      stock_quantity: Math.max(0, parseInt(data.stock_quantity) || 0),
      min_stock_level: Math.max(0, parseInt(data.min_stock_level) || 0),
      max_stock_level: data.max_stock_level ? Math.max(0, parseInt(data.max_stock_level) || 0) : undefined,
      reorder_quantity: Math.max(0, parseInt(data.reorder_quantity) || 0),
      
      // Ensure string fields have defaults
      name: data.name || 'Unknown Product',
      sku: data.sku || 'N/A',
      category: data.category || 'general',
      manufacturer: data.manufacturer || 'Unknown',
      unit_of_measure: data.unit_of_measure || 'piece',
      dosage_form: data.dosage_form || 'tablet',
      status: data.status || 'active',
      
      // Safely parse timestamps using the shared utility
      created_at: parseFirestoreTimestamp(data.created_at),
      updated_at: parseFirestoreTimestamp(data.updated_at),
      expiry_date: data.expiry_date ? parseFirestoreTimestamp(data.expiry_date) : undefined
    } as Product;
  }
  
  /**
   * Create a new product in the database
   */
  static async createProduct(productData: Omit<Product, 'id' | 'created_at' | 'updated_at'>): Promise<Product> {
    try {
      console.log('📦 Creating product in database:', productData.name);
      
      if (!productData.shop_id) {
        throw new Error('Shop ID is required to create a product');
      }
      
      // Validate required fields
      if (!productData.name?.trim()) {
        throw new Error('Product name is required');
      }
      
      if (!productData.sku?.trim()) {
        throw new Error('Product SKU is required');
      }
      
      if (!productData.retail_price || productData.retail_price <= 0) {
        throw new Error('Product retail price must be greater than 0');
      }
      
      if (productData.stock_quantity < 0) {
        throw new Error('Stock quantity cannot be negative');
      }
      
      // Check for duplicate SKU in the same shop
      const existingProduct = await ProductsService.getProductBySKU(productData.sku, productData.shop_id);
      if (existingProduct) {
        throw new Error(`A product with SKU "${productData.sku}" already exists in this pharmacy`);
      }
      
      const productsCollection = collection(db, ProductsService.COLLECTION_NAME);
      
      const newProductData = {
        ...productData,
        created_at: serverTimestamp(),
        updated_at: serverTimestamp()
      };
      
      console.log('💾 Saving product data to Firestore:', {
        name: newProductData.name,
        sku: newProductData.sku,
        shop_id: newProductData.shop_id,
        category: newProductData.category
      });
      
      const docRef = await addDoc(productsCollection, newProductData);
      
      // Get the created document to return with server timestamp
      const createdDoc = await getDoc(docRef);
      const createdData = createdDoc.data();
      
      if (!createdData) {
        throw new Error('Failed to retrieve created product data');
      }
      
      const product: Product = {
        id: docRef.id,
        ...productData,
        created_at: createdData.created_at?.toDate()?.toISOString() || new Date().toISOString(),
        updated_at: createdData.updated_at?.toDate()?.toISOString() || new Date().toISOString()
      };
      
      console.log('✅ Product created successfully with ID:', docRef.id);
      return product;
      
    } catch (error: any) {
      console.error('❌ Error creating product:', error);
      
      // Add more specific error context
      if (error.code === 'permission-denied') {
        throw handleFirebaseError({
          ...error,
          isPermissionError: true,
          context: 'product creation'
        });
      }
      
      throw handleFirebaseError(error);
    }
  }
  
  /**
   * Get all products for a specific shop
   */
  static async getProducts(shopId: string): Promise<Product[]> {
    try {
      console.log('📦 Fetching products for shop:', shopId);
      
      if (!shopId) {
        throw new Error('Shop ID is required to fetch products');
      }
      
      const productsCollection = collection(db, ProductsService.COLLECTION_NAME);
      const q = query(
        productsCollection,
        where('shop_id', '==', shopId),
        where('status', '!=', 'deleted'),
        orderBy('status', 'desc'),
        orderBy('created_at', 'desc')
      );
      
      const querySnapshot = await getDocs(q);
      const products: Product[] = [];
      
      querySnapshot.forEach((doc) => {
        products.push(ProductsService.parseProductData(doc));
      });
      
      console.log('✅ Retrieved', products.length, 'products for shop:', shopId);
      return products;
      
    } catch (error: any) {
      console.error('❌ Error fetching products:', error);
      
      if (error.code === 'permission-denied') {
        throw handleFirebaseError({
          ...error,
          isPermissionError: true,
          context: 'product retrieval'
        });
      }
      
      throw handleFirebaseError(error);
    }
  }
  
  /**
   * Get active products only
   */
  static async getActiveProducts(shopId: string): Promise<Product[]> {
    try {
      console.log('📦 Fetching active products for shop:', shopId);
      
      const productsCollection = collection(db, ProductsService.COLLECTION_NAME);
      const q = query(
        productsCollection,
        where('shop_id', '==', shopId),
        where('status', '==', 'active'),
        orderBy('name', 'asc')
      );
      
      const querySnapshot = await getDocs(q);
      const products: Product[] = [];
      
      querySnapshot.forEach((doc) => {
        products.push(ProductsService.parseProductData(doc));
      });
      
      console.log('✅ Retrieved', products.length, 'active products');
      return products;
      
    } catch (error: any) {
      console.error('❌ Error fetching active products:', error);
      throw handleFirebaseError(error);
    }
  }
  
  /**
   * Get a single product by ID
   */
  static async getProduct(productId: string): Promise<Product | null> {
    try {
      console.log('📦 Fetching product:', productId);
      
      const productDoc = doc(db, ProductsService.COLLECTION_NAME, productId);
      const docSnapshot = await getDoc(productDoc);
      
      if (!docSnapshot.exists()) {
        console.log('Product not found:', productId);
        return null;
      }
      
      const product = ProductsService.parseProductData(docSnapshot);
      
      console.log('✅ Product retrieved:', product.name);
      return product;
      
    } catch (error: any) {
      console.error('❌ Error fetching product:', error);
      throw handleFirebaseError(error);
    }
  }
  
  /**
   * Get product by SKU (for duplicate checking)
   */
  static async getProductBySKU(sku: string, shopId: string): Promise<Product | null> {
    try {
      const productsCollection = collection(db, ProductsService.COLLECTION_NAME);
      const q = query(
        productsCollection,
        where('shop_id', '==', shopId),
        where('sku', '==', sku),
        where('status', '!=', 'deleted')
      );
      
      const querySnapshot = await getDocs(q);
      
      if (querySnapshot.empty) {
        return null;
      }
      
      const doc = querySnapshot.docs[0];
      
      return ProductsService.parseProductData(doc);
      
    } catch (error: any) {
      console.error('❌ Error checking SKU:', error);
      throw handleFirebaseError(error);
    }
  }
  
  /**
   * Update an existing product
   */
  static async updateProduct(productId: string, updates: Partial<Product>): Promise<Product> {
    try {
      console.log('📦 Updating product:', productId);
      
      if (!productId) {
        throw new Error('Product ID is required to update a product');
      }
      
      // Remove fields that shouldn't be updated
      const { id, created_at, ...updateData } = updates;
      
      const productDoc = doc(db, ProductsService.COLLECTION_NAME, productId);
      
      const updatePayload = {
        ...updateData,
        updated_at: serverTimestamp()
      };
      
      await updateDoc(productDoc, updatePayload);
      
      // Get the updated document
      const updatedDoc = await getDoc(productDoc);
      
      if (!updatedDoc.exists()) {
        throw new Error('Product not found after update');
      }
      
      const updatedProduct = ProductsService.parseProductData(updatedDoc);
      
      console.log('✅ Product updated successfully');
      return updatedProduct;
      
    } catch (error: any) {
      console.error('❌ Error updating product:', error);
      
      if (error.code === 'permission-denied') {
        throw handleFirebaseError({
          ...error,
          isPermissionError: true,
          context: 'product update'
        });
      }
      
      throw handleFirebaseError(error);
    }
  }
  
  /**
   * Soft delete a product (mark as deleted)
   */
  static async deleteProduct(productId: string): Promise<void> {
    try {
      console.log('📦 Soft deleting product:', productId);
      
      await ProductsService.updateProduct(productId, {
        status: 'deleted'
      });
      
      console.log('✅ Product soft deleted successfully');
      
    } catch (error: any) {
      console.error('❌ Error deleting product:', error);
      throw handleFirebaseError(error);
    }
  }
  
  /**
   * Hard delete a product (permanently remove from database)
   */
  static async hardDeleteProduct(productId: string): Promise<void> {
    try {
      console.log('📦 Hard deleting product:', productId);
      
      const productDoc = doc(db, ProductsService.COLLECTION_NAME, productId);
      await deleteDoc(productDoc);
      
      console.log('✅ Product permanently deleted');
      
    } catch (error: any) {
      console.error('❌ Error hard deleting product:', error);
      
      if (error.code === 'permission-denied') {
        throw handleFirebaseError({
          ...error,
          isPermissionError: true,
          context: 'product deletion'
        });
      }
      
      throw handleFirebaseError(error);
    }
  }
  
  /**
   * Update product stock quantity
   */
  static async updateStock(productId: string, newQuantity: number): Promise<void> {
    try {
      console.log('📦 Updating stock for product:', productId, 'to', newQuantity);
      
      if (newQuantity < 0) {
        throw new Error('Stock quantity cannot be negative');
      }
      
      await ProductsService.updateProduct(productId, {
        stock_quantity: newQuantity
      });
      
      console.log('✅ Stock updated successfully');
      
    } catch (error: any) {
      console.error('❌ Error updating stock:', error);
      throw handleFirebaseError(error);
    }
  }
  
  /**
   * Get low stock products
   */
  static async getLowStockProducts(shopId: string): Promise<Product[]> {
    try {
      console.log('📦 Fetching low stock products for shop:', shopId);
      
      const allProducts = await ProductsService.getActiveProducts(shopId);
      
      // Filter products where stock is at or below minimum level
      const lowStockProducts = allProducts.filter(product => 
        product.stock_quantity <= product.min_stock_level
      );
      
      console.log('✅ Found', lowStockProducts.length, 'low stock products');
      return lowStockProducts;
      
    } catch (error: any) {
      console.error('❌ Error fetching low stock products:', error);
      throw handleFirebaseError(error);
    }
  }
  
  /**
   * Get products expiring soon (pharmacy-specific)
   */
  static async getExpiringProducts(shopId: string, daysAhead: number = 30): Promise<Product[]> {
    try {
      console.log('📦 Fetching products expiring in', daysAhead, 'days for shop:', shopId);
      
      const allProducts = await ProductsService.getActiveProducts(shopId);
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() + daysAhead);
      
      // Filter products with expiry dates within the specified period
      const expiringProducts = allProducts.filter(product => {
        if (!product.expiry_date) return false;
        
        const expiryDate = new Date(product.expiry_date);
        return expiryDate <= cutoffDate && expiryDate > new Date();
      });
      
      console.log('✅ Found', expiringProducts.length, 'products expiring soon');
      return expiringProducts;
      
    } catch (error: any) {
      console.error('❌ Error fetching expiring products:', error);
      throw handleFirebaseError(error);
    }
  }
  
  /**
   * Subscribe to real-time product updates with enhanced connection management
   */
  static subscribeToProducts(shopId: string, callback: (products: Product[]) => void): () => void {
    try {
      console.log('🔄 Setting up managed real-time products subscription for shop:', shopId);
      
      if (!shopId) {
        console.warn('⚠️ No shopId provided for products subscription');
        callback([]);
        return () => {};
      }
      
      const productsCollection = collection(db, ProductsService.COLLECTION_NAME);
      const q = query(
        productsCollection,
        where('shop_id', '==', shopId),
        where('status', '!=', 'deleted'),
        orderBy('status', 'desc'),
        orderBy('created_at', 'desc')
      );
      
      // Use the connection manager for better error handling and connection management
      return ProductsService.connectionManager.createManagedListener<Product>(
        q,
        (products) => {
          console.log('✅ Managed real-time products update:', products.length, 'records');
          callback(products);
        },
        (error) => {
          console.error('❌ Error in managed products subscription:', error);
          
          // For permission errors, provide graceful fallback
          if (error.code === 'permission-denied') {
            console.log('🚨 PERMISSION ERROR in products subscription - providing empty array fallback');
            callback([]);
          }
        },
        `products_${shopId}` // Unique listener key
      );
      
    } catch (error: any) {
      console.error('❌ Error setting up managed products subscription:', error);
      callback([]);
      return () => {};
    }
  }

  // Static method to get connection status
  static getConnectionStatus() {
    return ProductsService.connectionManager.getConnectionState();
  }

  // Static method to reset connections (useful during auth changes)
  static resetConnections() {
    ProductsService.connectionManager.resetConnectionState();
  }

  // Static method to cleanup all listeners (useful during sign out)
  static cleanupAllListeners() {
    ProductsService.connectionManager.cleanupAllListeners();
  }
}