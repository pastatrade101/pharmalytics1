// Global user creation state management utility
let globalUserCreationInProgress = false;

export const UserCreationManager = {
  setUserCreationInProgress: (inProgress: boolean) => {
    globalUserCreationInProgress = inProgress;
    console.log('🔄 User creation state updated:', inProgress);
  },
  isUserCreationInProgress: () => globalUserCreationInProgress
};