import { createClient } from '@supabase/supabase-js'

// Environment variable fallbacks for demo environment
const getEnvVar = (key: string, fallback: string) => {
  if (typeof window !== 'undefined') {
    // Browser environment - use fallbacks
    return fallback;
  }
  // Server environment - try to get from process.env
  try {
    return process?.env?.[key] || fallback;
  } catch {
    return fallback;
  }
};

const supabaseUrl = getEnvVar('NEXT_PUBLIC_SUPABASE_URL', 'https://demo-project.supabase.co');
const supabaseAnonKey = getEnvVar('NEXT_PUBLIC_SUPABASE_ANON_KEY', 'demo-anon-key-placeholder');

// Create a mock Supabase client for demo purposes
const createMockSupabaseClient = () => {
  const mockUser = {
    id: 'demo-user-id',
    email: 'demo@shop.com',
    user_metadata: {
      full_name: 'Demo User',
      role: 'owner'
    }
  };

  const mockShop = {
    id: 'demo-shop-id',
    name: 'Demo Shop',
    owner_id: 'demo-user-id',
    settings: {
      timezone: 'UTC',
      currency: 'USD',
      report_time: '20:00'
    }
  };

  const mockProfile = {
    id: 'demo-user-id',
    email: 'demo@shop.com',
    full_name: 'Demo User',
    role: 'owner' as const,
    shop_id: 'demo-shop-id',
    shop: mockShop,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };

  return {
    auth: {
      getUser: async () => ({ data: { user: mockUser }, error: null }),
      signInWithPassword: async ({ email, password }: { email: string; password: string }) => {
        // Mock authentication - allow demo credentials
        if (email === 'demo@shop.com' && password === 'demo123') {
          return { data: { user: mockUser, session: { user: mockUser } }, error: null };
        }
        return { data: { user: null, session: null }, error: { message: 'Invalid credentials' } };
      },
      signUp: async ({ email, password, options }: any) => {
        return { 
          data: { 
            user: { 
              ...mockUser, 
              email, 
              user_metadata: options?.data || {} 
            }, 
            session: null 
          }, 
          error: null 
        };
      },
      signOut: async () => ({ error: null }),
      onAuthStateChange: (callback: any) => {
        // Mock auth state changes
        setTimeout(() => callback('SIGNED_IN', { user: mockUser }), 100);
        return {
          data: {
            subscription: {
              unsubscribe: () => {}
            }
          }
        };
      }
    },
    from: (table: string) => ({
      select: (columns?: string) => ({
        eq: (column: string, value: any) => ({
          single: async () => ({ data: mockProfile, error: null }),
          order: (column: string, options?: any) => ({
            limit: (count: number) => ({
              async then(resolve: any) {
                return resolve({ data: [], error: null });
              }
            }),
            async then(resolve: any) {
              return resolve({ data: [], error: null });
            }
          }),
          gte: (column: string, value: any) => ({
            lte: (column: string, value: any) => ({
              async then(resolve: any) {
                return resolve({ data: [], error: null });
              }
            }),
            async then(resolve: any) {
              return resolve({ data: [], error: null });
            }
          }),
          async then(resolve: any) {
            return resolve({ data: [mockProfile], error: null });
          }
        }),
        gte: (column: string, value: any) => ({
          order: (column: string, options?: any) => ({
            async then(resolve: any) {
              return resolve({ data: [], error: null });
            }
          }),
          async then(resolve: any) {
            return resolve({ data: [], error: null });
          }
        }),
        order: (column: string, options?: any) => ({
          limit: (count: number) => ({
            async then(resolve: any) {
              return resolve({ data: [], error: null });
            }
          }),
          async then(resolve: any) {
            return resolve({ data: [], error: null });
          }
        }),
        limit: (count: number) => ({
          async then(resolve: any) {
            return resolve({ data: [], error: null });
          }
        }),
        async then(resolve: any) {
          if (table === 'profiles') {
            return resolve({ data: mockProfile, error: null });
          }
          return resolve({ data: [], error: null });
        }
      }),
      insert: (data: any) => ({
        select: () => ({
          single: async () => ({ 
            data: { 
              id: `mock-${Date.now()}`, 
              ...data, 
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString()
            }, 
            error: null 
          }),
          async then(resolve: any) {
            return resolve({ 
              data: [{ 
                id: `mock-${Date.now()}`, 
                ...data, 
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
              }], 
              error: null 
            });
          }
        }),
        async then(resolve: any) {
          return resolve({ 
            data: [{ 
              id: `mock-${Date.now()}`, 
              ...data, 
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString()
            }], 
            error: null 
          });
        }
      }),
      update: (data: any) => ({
        eq: (column: string, value: any) => ({
          select: () => ({
            single: async () => ({ data: { ...mockProfile, ...data }, error: null })
          })
        })
      })
    }),
    channel: (name: string) => ({
      on: (event: string, options: any, callback: any) => ({
        subscribe: () => ({
          unsubscribe: () => {}
        })
      })
    })
  };
};

// Use real Supabase if credentials are available, otherwise use mock
let supabase: any;
try {
  if (supabaseUrl.includes('demo') || supabaseAnonKey.includes('demo')) {
    console.log('Using mock Supabase client for demo');
    supabase = createMockSupabaseClient();
  } else {
    supabase = createClient(supabaseUrl, supabaseAnonKey);
  }
} catch (error) {
  console.log('Failed to create Supabase client, using mock:', error);
  supabase = createMockSupabaseClient();
}

export { supabase };

// Database Types
export interface Sale {
  id: string
  item: string
  quantity: number
  unit_price: number
  total_price: number
  timestamp: string
  seller_id: string
  shop_id: string
  created_at: string
  updated_at: string
  seller?: {
    full_name: string
    email: string
  }
}

export interface DailyReport {
  id: string
  date: string
  total_sales: number
  total_revenue: number
  average_transaction: number
  top_selling_item: string
  insights: string[]
  recommendations: string[]
  trends: {
    salesTrend: string
    peakHours: string
    slowPeriods: string
  }
  alerts: string[]
  shop_id: string
  created_at: string
  updated_at: string
}

export interface UserProfile {
  id: string
  email: string
  full_name: string
  role: 'owner' | 'seller' | 'manager'
  shop_id: string
  created_at: string
  updated_at: string
  shop?: Shop
}

export interface Shop {
  id: string
  name: string
  owner_id: string
  settings: {
    timezone: string
    currency: string
    report_time: string
  }
  created_at: string
  updated_at: string
}

// Database Functions with error handling
export class SupabaseService {
  // Sales Functions
  static async createSale(saleData: Omit<Sale, 'id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from('sales')
        .insert([saleData])
        .select()
        .single()

      if (error) throw error
      return data
    } catch (error) {
      console.error('Error creating sale:', error);
      // Return mock data for demo
      return {
        id: `sale-${Date.now()}`,
        ...saleData,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
    }
  }

  static async getSales(shopId: string, dateRange?: { start: string; end: string }) {
    try {
      let query = supabase
        .from('sales')
        .select(`
          *,
          seller:profiles(full_name, email)
        `)
        .eq('shop_id', shopId)
        .order('timestamp', { ascending: false })

      if (dateRange) {
        query = query
          .gte('timestamp', dateRange.start)
          .lte('timestamp', dateRange.end)
      }

      const { data, error } = await query
      if (error) throw error
      return data || []
    } catch (error) {
      console.error('Error getting sales:', error);
      return [];
    }
  }

  static async getTodaysSales(shopId: string) {
    const today = new Date().toISOString().split('T')[0]
    const startOfDay = `${today}T00:00:00.000Z`
    const endOfDay = `${today}T23:59:59.999Z`

    return this.getSales(shopId, { start: startOfDay, end: endOfDay })
  }

  // Daily Reports Functions
  static async createDailyReport(reportData: Omit<DailyReport, 'id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from('daily_reports')
        .insert([reportData])
        .select()
        .single()

      if (error) throw error
      return data
    } catch (error) {
      console.error('Error creating daily report:', error);
      return {
        id: `report-${Date.now()}`,
        ...reportData,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
    }
  }

  static async getDailyReports(shopId: string, limit = 30) {
    try {
      const { data, error } = await supabase
        .from('daily_reports')
        .select('*')
        .eq('shop_id', shopId)
        .order('date', { ascending: false })
        .limit(limit)

      if (error) throw error
      return data || []
    } catch (error) {
      console.error('Error getting daily reports:', error);
      return [];
    }
  }

  static async getReportByDate(shopId: string, date: string) {
    try {
      const { data, error } = await supabase
        .from('daily_reports')
        .select('*')
        .eq('shop_id', shopId)
        .eq('date', date)
        .single()

      if (error && error.code !== 'PGRST116') throw error // PGRST116 is "not found"
      return data
    } catch (error) {
      console.error('Error getting report by date:', error);
      return null;
    }
  }

  // User & Shop Functions
  static async getCurrentUserProfile() {
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return null

      const { data, error } = await supabase
        .from('profiles')
        .select(`
          *,
          shop:shops(*)
        `)
        .eq('id', user.id)
        .single()

      if (error) throw error
      return data
    } catch (error) {
      console.error('Error getting user profile:', error);
      // Return mock profile for demo
      return {
        id: 'demo-user-id',
        email: 'demo@shop.com',
        full_name: 'Demo User',
        role: 'owner' as const,
        shop_id: 'demo-shop-id',
        shop: {
          id: 'demo-shop-id',
          name: 'Demo Shop',
          owner_id: 'demo-user-id',
          settings: {
            timezone: 'UTC',
            currency: 'USD',
            report_time: '20:00'
          },
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
    }
  }

  static async updateUserProfile(userId: string, updates: Partial<UserProfile>) {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', userId)
        .select()
        .single()

      if (error) throw error
      return data
    } catch (error) {
      console.error('Error updating user profile:', error);
      return null;
    }
  }

  static async createShop(shopData: Omit<Shop, 'id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from('shops')
        .insert([shopData])
        .select()
        .single()

      if (error) throw error
      return data
    } catch (error) {
      console.error('Error creating shop:', error);
      return {
        id: `shop-${Date.now()}`,
        ...shopData,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
    }
  }

  // Real-time subscriptions with error handling
  static subscribeToSales(shopId: string, callback: (payload: any) => void) {
    try {
      return supabase
        .channel('sales_changes')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'sales',
            filter: `shop_id=eq.${shopId}`
          },
          callback
        )
        .subscribe()
    } catch (error) {
      console.error('Error setting up sales subscription:', error);
      return { unsubscribe: () => {} };
    }
  }

  static subscribeToReports(shopId: string, callback: (payload: any) => void) {
    try {
      return supabase
        .channel('reports_changes')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'daily_reports',
            filter: `shop_id=eq.${shopId}`
          },
          callback
        )
        .subscribe()
    } catch (error) {
      console.error('Error setting up reports subscription:', error);
      return { unsubscribe: () => {} };
    }
  }

  // Analytics Functions with fallbacks
  static async getSalesAnalytics(shopId: string, days = 30) {
    try {
      const startDate = new Date()
      startDate.setDate(startDate.getDate() - days)
      
      const { data, error } = await supabase
        .from('sales')
        .select('*')
        .eq('shop_id', shopId)
        .gte('timestamp', startDate.toISOString())
        .order('timestamp', { ascending: true })

      if (error) throw error

      // Process data for analytics
      const dailyTotals = (data || []).reduce((acc: any, sale) => {
        const date = sale.timestamp.split('T')[0]
        if (!acc[date]) {
          acc[date] = { date, sales: 0, revenue: 0 }
        }
        acc[date].sales += 1
        acc[date].revenue += sale.total_price
        return acc
      }, {})

      return Object.values(dailyTotals)
    } catch (error) {
      console.error('Error getting sales analytics:', error);
      return [];
    }
  }

  static async getTopProducts(shopId: string, days = 30) {
    try {
      const startDate = new Date()
      startDate.setDate(startDate.getDate() - days)
      
      const { data, error } = await supabase
        .from('sales')
        .select('item, quantity, total_price')
        .eq('shop_id', shopId)
        .gte('timestamp', startDate.toISOString())

      if (error) throw error

      // Process data for top products
      const productTotals = (data || []).reduce((acc: any, sale) => {
        if (!acc[sale.item]) {
          acc[sale.item] = { name: sale.item, quantity: 0, revenue: 0 }
        }
        acc[sale.item].quantity += sale.quantity
        acc[sale.item].revenue += sale.total_price
        return acc
      }, {})

      return Object.values(productTotals)
        .sort((a: any, b: any) => b.revenue - a.revenue)
        .slice(0, 10)
    } catch (error) {
      console.error('Error getting top products:', error);
      return [];
    }
  }
}

// Authentication helpers with error handling
export const signIn = async (email: string, password: string) => {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })
    if (error) throw error
    return data
  } catch (error) {
    console.error('Sign in error:', error);
    throw error;
  }
}

export const signUp = async (email: string, password: string, fullName: string, role: 'owner' | 'seller') => {
  try {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName,
          role: role,
        }
      }
    })
    if (error) throw error
    return data
  } catch (error) {
    console.error('Sign up error:', error);
    throw error;
  }
}

export const signOut = async () => {
  try {
    const { error } = await supabase.auth.signOut()
    if (error) throw error
  } catch (error) {
    console.error('Sign out error:', error);
    throw error;
  }
}

export const getCurrentUser = async () => {
  try {
    const { data: { user } } = await supabase.auth.getUser()
    return user
  } catch (error) {
    console.error('Get current user error:', error);
    return null;
  }
}