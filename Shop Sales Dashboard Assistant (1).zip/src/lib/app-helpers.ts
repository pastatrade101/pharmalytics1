// Helper functions for the main application

import React from 'react';
import { Loader2, Zap, Sparkles, DollarSign, AlertTriangle, Brain, Key, Wifi, WifiOff } from 'lucide-react';
import { ROLE_DISPLAY_NAMES, ROLE_DESCRIPTIONS, AI_STATUS_MESSAGES, AISystemStatus } from './app-constants';

export const getRoleDisplayName = (role: string) => {
  return ROLE_DISPLAY_NAMES[role as keyof typeof ROLE_DISPLAY_NAMES] || role;
};

export const getRoleDescription = (role: string) => {
  return ROLE_DESCRIPTIONS[role as keyof typeof ROLE_DESCRIPTIONS] || 'Manage shop operations';
};

// Add debugging to track when this function is called
export const getAIStatusDisplay = (aiSystemStatus: AISystemStatus) => {
  // Only log in development to avoid console spam in production
  if (process.env.NODE_ENV === 'development') {
    console.debug('🔍 getAIStatusDisplay called with status:', aiSystemStatus);
  }
  
  switch (aiSystemStatus) {
    case 'checking':
      return { 
        icon: <Loader2 className="h-3 w-3 animate-spin" />, 
        text: 'Checking AI...', 
        color: 'text-blue-500',
        label: 'Checking AI...',
        bgColor: 'bg-blue-50',
        textColor: 'text-blue-700',
        description: 'Testing AI connectivity and capabilities...'
      };
    case 'ready':
      return { 
        icon: <Zap className="h-3 w-3" />, 
        text: 'Gemini Ready', 
        color: 'text-green-500',
        label: 'AI Ready',
        bgColor: 'bg-green-50',
        textColor: 'text-green-700',
        description: 'AI system is fully operational and ready to provide intelligent insights.'
      };
    case 'fallback':
      return { 
        icon: <Sparkles className="h-3 w-3" />, 
        text: 'Fallback Mode', 
        color: 'text-yellow-500',
        label: 'Smart Fallback',
        bgColor: 'bg-yellow-50',
        textColor: 'text-yellow-700',
        description: 'Using intelligent fallback mode with pre-built analytics and insights.'
      };
    case 'quota-exceeded':
      return { 
        icon: <DollarSign className="h-3 w-3" />, 
        text: 'Quota Exceeded', 
        color: 'text-orange-500',
        label: 'Quota Exceeded',
        bgColor: 'bg-orange-50',
        textColor: 'text-orange-700',
        description: 'AI quota limit reached. Using cached insights and fallback analytics.'
      };
    case 'auth-error':
      return { 
        icon: <Key className="h-3 w-3" />, 
        text: 'Auth Error', 
        color: 'text-red-400',
        label: 'Auth Error',
        bgColor: 'bg-red-50',
        textColor: 'text-red-700',
        description: 'AI authentication failed. Using local analytics capabilities.'
      };
    case 'network-error':
      return { 
        icon: <WifiOff className="h-3 w-3" />, 
        text: 'Network Error', 
        color: 'text-red-300',
        label: 'Network Error',
        bgColor: 'bg-gray-50',
        textColor: 'text-gray-700',
        description: 'Network connectivity issues. Operating in offline mode.'
      };
    case 'error':
      return { 
        icon: <AlertTriangle className="h-3 w-3" />, 
        text: 'AI Error', 
        color: 'text-red-500',
        label: 'AI Error',
        bgColor: 'bg-red-50',
        textColor: 'text-red-700',
        description: 'AI system encountered an error. Using standard analytics.'
      };
    default:
      return { 
        icon: <Brain className="h-3 w-3" />, 
        text: 'Unknown', 
        color: 'text-gray-500',
        label: 'Unknown Status',
        bgColor: 'bg-gray-50',
        textColor: 'text-gray-700',
        description: 'AI system status unknown. Please check your connection.'
      };
  }
};

export const getAIStatusMessage = (aiSystemStatus: AISystemStatus) => {
  return AI_STATUS_MESSAGES[aiSystemStatus] || 'Unknown status';
};

export const getSystemStatusText = (aiSystemStatus: AISystemStatus) => {
  switch (aiSystemStatus) {
    case 'ready':
      return '⚡ Gemini Ready';
    case 'fallback':
      return '⚡ Fallback Mode';
    case 'quota-exceeded':
      return '💰 Quota Exceeded';
    case 'auth-error':
      return '🔑 Auth Error';
    case 'network-error':
      return '🌐 Network Error';
    case 'checking':
      return '🔍 Testing Gemini...';
    case 'error':
      return '❌ AI Error';
    default:
      return '❓ Unknown';
  }
};

// Additional helper functions for pharmacy management
export const formatUserRole = (role: string): string => {
  return getRoleDisplayName(role);
};

export const getUserPermissions = (role: string): string[] => {
  const { ROLE_PERMISSIONS } = require('./app-constants');
  return ROLE_PERMISSIONS[role as keyof typeof ROLE_PERMISSIONS] || [];
};

export const hasPermission = (userRole: string, requiredPermission: string): boolean => {
  const permissions = getUserPermissions(userRole);
  return permissions.includes(requiredPermission) || permissions.includes('view-all');
};

export const canAccessView = (userRole: string, view: string): boolean => {
  const { VIEW_ACCESS } = require('./app-constants');
  const allowedViews = VIEW_ACCESS[userRole as keyof typeof VIEW_ACCESS] || [];
  return allowedViews.includes(view as any);
};

// Pharmacy-specific helper functions
export const formatPharmacyCategory = (category: string): string => {
  return category.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
};

export const formatDosageForm = (form: string): string => {
  return form.replace(/-/g, '/').replace(/\b\w/g, l => l.toUpperCase());
};

export const formatPaymentMethod = (method: string): string => {
  const methodNames = {
    'cash': 'Cash',
    'card': 'Card Payment',
    'mobile-money': 'Mobile Money',
    'insurance': 'Insurance Claim',
    'credit': 'Credit Sale',
    'bank-transfer': 'Bank Transfer'
  };
  return methodNames[method as keyof typeof methodNames] || method;
};

export const getInsuranceProviderName = (provider: string): string => {
  const providerNames = {
    'NHIF': 'National Health Insurance Fund',
    'Jubilee': 'Jubilee Insurance',
    'Strategis': 'Strategis Insurance',
    'AAR': 'AAR Insurance',
    'Phoenix': 'Phoenix Insurance',
    'Other': 'Other Insurance Provider'
  };
  return providerNames[provider as keyof typeof providerNames] || provider;
};

export const getStockMovementDescription = (type: string): string => {
  const descriptions = {
    'purchase': 'Stock Purchase',
    'sale': 'Product Sale',
    'adjustment': 'Stock Adjustment',
    'transfer': 'Inter-branch Transfer',
    'return': 'Product Return',
    'expiry': 'Expired Stock',
    'damage': 'Damaged Stock'
  };
  return descriptions[type as keyof typeof descriptions] || type;
};

export const getAlertTypeDescription = (type: string): string => {
  const descriptions = {
    'low-stock': 'Low Stock Alert',
    'expiry-warning': 'Expiry Warning',
    'expiry-critical': 'Critical Expiry Alert',
    'sales-target': 'Sales Target Notification',
    'system-maintenance': 'System Maintenance',
    'user-activity': 'User Activity Alert'
  };
  return descriptions[type as keyof typeof descriptions] || type;
};