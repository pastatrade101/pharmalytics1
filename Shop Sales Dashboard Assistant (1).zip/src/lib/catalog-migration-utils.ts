// Catalog Migration Utilities
// Functions to import the comprehensive pharmacy catalog into the Firebase database

import { FirebaseService } from './firebase';
import { COMPREHENSIVE_PHARMACY_CATALOG } from './comprehensive-pharmacy-catalog';
import { UserProfile } from './firebase-types';

export class CatalogMigrationService {
  
  /**
   * Import the complete pharmacy catalog into Firebase
   * This will create all 100 products with proper expiry dates
   */
  static async importCompleteCatalog(userProfile: UserProfile) {
    if (!userProfile.shop_id) {
      throw new Error('User must have a pharmacy/shop assigned to import products');
    }

    console.log('🚀 Starting import of 100-medicine catalog...');
    const results = {
      success: 0,
      failed: 0,
      errors: [] as string[]
    };

    for (let i = 0; i < COMPREHENSIVE_PHARMACY_CATALOG.length; i++) {
      const product = COMPREHENSIVE_PHARMACY_CATALOG[i];
      
      try {
        console.log(`📦 Importing ${i + 1}/100: ${product.name}`);
        
        // Create the product in Firebase
        await FirebaseService.createProduct({
          name: product.name,
          generic_name: product.generic_name,
          brand_name: product.brand_name,
          description: product.description,
          category: product.category,
          strength: product.strength,
          manufacturer: product.manufacturer,
          sku: product.sku,
          cost_price: product.cost_price,
          retail_price: product.retail_price,
          stock_quantity: product.stock_quantity,
          min_stock_level: product.min_stock_level,
          status: product.status,
          expiry_date: product.expiry_date, // This is the key addition for expiry management
          batch_number: product.batch_number,
          supplier_info: product.supplier_info,
          created_by: userProfile.id
        });

        results.success++;
        
        // Add a small delay to prevent overwhelming Firebase
        if (i % 10 === 0) {
          await new Promise(resolve => setTimeout(resolve, 500));
        }
        
      } catch (error: any) {
        console.error(`❌ Failed to import ${product.name}:`, error);
        results.failed++;
        results.errors.push(`${product.name}: ${error.message}`);
      }
    }

    console.log('✅ Catalog import completed!');
    console.log(`📊 Results: ${results.success} successful, ${results.failed} failed`);
    
    if (results.errors.length > 0) {
      console.log('❌ Errors:', results.errors);
    }

    return results;
  }

  /**
   * Import only products with specific expiry status
   */
  static async importByExpiryStatus(
    userProfile: UserProfile, 
    status: 'expired' | 'critical' | 'warning' | 'good'
  ) {
    const today = new Date();
    let filteredProducts = [];

    switch (status) {
      case 'expired':
        filteredProducts = COMPREHENSIVE_PHARMACY_CATALOG.filter(p => p.expiry_date < today);
        break;
      case 'critical':
        const critical = new Date();
        critical.setDate(today.getDate() + 7);
        filteredProducts = COMPREHENSIVE_PHARMACY_CATALOG.filter(p => 
          p.expiry_date >= today && p.expiry_date <= critical
        );
        break;
      case 'warning':
        const warningStart = new Date();
        warningStart.setDate(today.getDate() + 8);
        const warningEnd = new Date();
        warningEnd.setDate(today.getDate() + 30);
        filteredProducts = COMPREHENSIVE_PHARMACY_CATALOG.filter(p => 
          p.expiry_date >= warningStart && p.expiry_date <= warningEnd
        );
        break;
      case 'good':
        const goodDate = new Date();
        goodDate.setDate(today.getDate() + 30);
        filteredProducts = COMPREHENSIVE_PHARMACY_CATALOG.filter(p => p.expiry_date > goodDate);
        break;
    }

    console.log(`🚀 Starting import of ${filteredProducts.length} products with '${status}' expiry status...`);
    
    const results = {
      success: 0,
      failed: 0,
      errors: [] as string[]
    };

    for (const product of filteredProducts) {
      try {
        await FirebaseService.createProduct({
          name: product.name,
          generic_name: product.generic_name,
          brand_name: product.brand_name,
          description: product.description,
          category: product.category,
          strength: product.strength,
          manufacturer: product.manufacturer,
          sku: product.sku,
          cost_price: product.cost_price,
          retail_price: product.retail_price,
          stock_quantity: product.stock_quantity,
          min_stock_level: product.min_stock_level,
          status: product.status,
          expiry_date: product.expiry_date,
          batch_number: product.batch_number,
          supplier_info: product.supplier_info,
          created_by: userProfile.id
        });

        results.success++;
        
      } catch (error: any) {
        results.failed++;
        results.errors.push(`${product.name}: ${error.message}`);
      }
    }

    return results;
  }

  /**
   * Import products by category
   */
  static async importByCategory(userProfile: UserProfile, category: string) {
    const filteredProducts = COMPREHENSIVE_PHARMACY_CATALOG.filter(p => p.category === category);
    
    console.log(`🚀 Starting import of ${filteredProducts.length} products in '${category}' category...`);
    
    const results = {
      success: 0,
      failed: 0,
      errors: [] as string[]
    };

    for (const product of filteredProducts) {
      try {
        await FirebaseService.createProduct({
          name: product.name,
          generic_name: product.generic_name,
          brand_name: product.brand_name,
          description: product.description,
          category: product.category,
          strength: product.strength,
          manufacturer: product.manufacturer,
          sku: product.sku,
          cost_price: product.cost_price,
          retail_price: product.retail_price,
          stock_quantity: product.stock_quantity,
          min_stock_level: product.min_stock_level,
          status: product.status,
          expiry_date: product.expiry_date,
          batch_number: product.batch_number,
          supplier_info: product.supplier_info,
          created_by: userProfile.id
        });

        results.success++;
        
      } catch (error: any) {
        results.failed++;
        results.errors.push(`${product.name}: ${error.message}`);
      }
    }

    return results;
  }

  /**
   * Clear all products and import fresh catalog
   * USE WITH CAUTION - This will delete all existing products
   */
  static async refreshCompleteCatalog(userProfile: UserProfile) {
    if (!userProfile.shop_id) {
      throw new Error('User must have a pharmacy/shop assigned');
    }

    console.log('⚠️  WARNING: This will delete all existing products and import fresh catalog');
    console.log('🗑️  Clearing existing products...');
    
    try {
      // Get all existing products
      const existingProducts = await FirebaseService.getProductsForCurrentUser();
      
      // Delete each product
      for (const product of existingProducts) {
        await FirebaseService.deleteProduct(product.id);
      }
      
      console.log(`✅ Cleared ${existingProducts.length} existing products`);
      
      // Import the new catalog
      return await this.importCompleteCatalog(userProfile);
      
    } catch (error: any) {
      console.error('❌ Failed to refresh catalog:', error);
      throw error;
    }
  }

  /**
   * Get catalog statistics without importing
   */
  static getCatalogStatistics() {
    const today = new Date();
    const critical = new Date();
    critical.setDate(today.getDate() + 7);
    const warning = new Date();
    warning.setDate(today.getDate() + 30);
    
    const expired = COMPREHENSIVE_PHARMACY_CATALOG.filter(p => p.expiry_date < today);
    const criticalExpiry = COMPREHENSIVE_PHARMACY_CATALOG.filter(p => 
      p.expiry_date >= today && p.expiry_date <= critical
    );
    const warningExpiry = COMPREHENSIVE_PHARMACY_CATALOG.filter(p => 
      p.expiry_date > critical && p.expiry_date <= warning
    );
    const goodExpiry = COMPREHENSIVE_PHARMACY_CATALOG.filter(p => p.expiry_date > warning);
    
    const categories = {
      'Prescription Medicines': COMPREHENSIVE_PHARMACY_CATALOG.filter(p => p.category === 'Prescription Medicines').length,
      'Over-the-Counter': COMPREHENSIVE_PHARMACY_CATALOG.filter(p => p.category === 'Over-the-Counter').length,
      'Antibiotics': COMPREHENSIVE_PHARMACY_CATALOG.filter(p => p.category === 'Antibiotics').length,
      'Vitamins & Supplements': COMPREHENSIVE_PHARMACY_CATALOG.filter(p => p.category === 'Vitamins & Supplements').length,
      'Cold & Flu': COMPREHENSIVE_PHARMACY_CATALOG.filter(p => p.category === 'Cold & Flu').length,
      'Digestive Health': COMPREHENSIVE_PHARMACY_CATALOG.filter(p => p.category === 'Digestive Health').length,
      'Baby & Child Care': COMPREHENSIVE_PHARMACY_CATALOG.filter(p => p.category === 'Baby & Child Care').length
    };

    const totalValue = COMPREHENSIVE_PHARMACY_CATALOG.reduce((sum, p) => sum + (p.stock_quantity * p.cost_price), 0);
    const valueAtRisk = [...expired, ...criticalExpiry, ...warningExpiry].reduce((sum, p) => sum + (p.stock_quantity * p.cost_price), 0);

    return {
      total: COMPREHENSIVE_PHARMACY_CATALOG.length,
      expiry: {
        expired: expired.length,
        critical: criticalExpiry.length,
        warning: warningExpiry.length,
        good: goodExpiry.length
      },
      categories,
      inventory: {
        totalValue,
        valueAtRisk,
        lowStock: COMPREHENSIVE_PHARMACY_CATALOG.filter(p => p.stock_quantity <= p.min_stock_level).length,
        outOfStock: COMPREHENSIVE_PHARMACY_CATALOG.filter(p => p.stock_quantity === 0).length
      }
    };
  }

  /**
   * Generate a sample of products for testing
   */
  static getSampleProducts(count: number = 10) {
    return COMPREHENSIVE_PHARMACY_CATALOG.slice(0, count);
  }

  /**
   * Search products in the catalog
   */
  static searchCatalog(query: string) {
    const lowerQuery = query.toLowerCase();
    return COMPREHENSIVE_PHARMACY_CATALOG.filter(product =>
      product.name.toLowerCase().includes(lowerQuery) ||
      product.generic_name.toLowerCase().includes(lowerQuery) ||
      product.brand_name.toLowerCase().includes(lowerQuery) ||
      product.category.toLowerCase().includes(lowerQuery) ||
      product.manufacturer.toLowerCase().includes(lowerQuery) ||
      product.sku.toLowerCase().includes(lowerQuery)
    );
  }
}

// Browser console utility functions for easy testing
if (typeof window !== 'undefined') {
  (window as any).CatalogUtils = {
    importAll: (userProfile: UserProfile) => CatalogMigrationService.importCompleteCatalog(userProfile),
    importExpired: (userProfile: UserProfile) => CatalogMigrationService.importByExpiryStatus(userProfile, 'expired'),
    importCritical: (userProfile: UserProfile) => CatalogMigrationService.importByExpiryStatus(userProfile, 'critical'),
    importWarning: (userProfile: UserProfile) => CatalogMigrationService.importByExpiryStatus(userProfile, 'warning'),
    importGood: (userProfile: UserProfile) => CatalogMigrationService.importByExpiryStatus(userProfile, 'good'),
    importCategory: (userProfile: UserProfile, category: string) => CatalogMigrationService.importByCategory(userProfile, category),
    getStats: () => CatalogMigrationService.getCatalogStatistics(),
    search: (query: string) => CatalogMigrationService.searchCatalog(query),
    refreshAll: (userProfile: UserProfile) => CatalogMigrationService.refreshCompleteCatalog(userProfile)
  };

  console.log('🧪 Catalog utilities available in browser console:');
  console.log('• CatalogUtils.importAll(userProfile) - Import all 100 products');
  console.log('• CatalogUtils.importExpired(userProfile) - Import only expired products');
  console.log('• CatalogUtils.importCritical(userProfile) - Import products expiring within 7 days');
  console.log('• CatalogUtils.importWarning(userProfile) - Import products expiring within 30 days');
  console.log('• CatalogUtils.importGood(userProfile) - Import products with good expiry dates');
  console.log('• CatalogUtils.importCategory(userProfile, "Antibiotics") - Import by category');
  console.log('• CatalogUtils.getStats() - Get catalog statistics');
  console.log('• CatalogUtils.search("paracetamol") - Search products');
  console.log('• CatalogUtils.refreshAll(userProfile) - Clear all and import fresh (DANGEROUS)');
}

export default CatalogMigrationService;