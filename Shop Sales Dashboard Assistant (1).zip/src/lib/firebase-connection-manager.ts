// Firebase Connection Manager - Handles WebChannelConnection errors and optimizes real-time listeners
import { onSnapshot, FirestoreError } from 'firebase/firestore';

interface ConnectionState {
  isOnline: boolean;
  retryCount: number;
  lastError: FirestoreError | null;
  activeListeners: Set<string>;
}

class FirebaseConnectionManager {
  private static instance: FirebaseConnectionManager;
  private connectionState: ConnectionState = {
    isOnline: true,
    retryCount: 0,
    lastError: null,
    activeListeners: new Set()
  };
  
  private maxRetries = 3;
  private retryDelay = 1000; // Start with 1 second
  private maxRetryDelay = 10000; // Max 10 seconds
  
  static getInstance(): FirebaseConnectionManager {
    if (!FirebaseConnectionManager.instance) {
      FirebaseConnectionManager.instance = new FirebaseConnectionManager();
    }
    return FirebaseConnectionManager.instance;
  }

  // Enhanced listener wrapper with connection management
  createManagedListener<T>(
    query: any,
    onNext: (data: T[]) => void,
    onError?: (error: FirestoreError) => void,
    listenerKey?: string
  ): () => void {
    // Generate unique listener key if not provided
    const key = listenerKey || `listener_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    // Check if listener already exists
    if (this.connectionState.activeListeners.has(key)) {
      console.warn(`⚠️ Listener ${key} already exists, skipping duplicate`);
      return () => {};
    }

    let unsubscribe: (() => void) | null = null;
    let isRetrying = false;

    const setupListener = () => {
      try {
        console.log(`🔄 Setting up managed listener: ${key}`);
        this.connectionState.activeListeners.add(key);

        unsubscribe = onSnapshot(
          query,
          (querySnapshot) => {
            try {
              // Reset retry count on successful connection
              this.connectionState.retryCount = 0;
              this.connectionState.isOnline = true;
              this.connectionState.lastError = null;

              const results: T[] = [];
              querySnapshot.forEach((doc) => {
                const data = doc.data();
                results.push({
                  id: doc.id,
                  ...data,
                  created_at: data.created_at?.toDate?.()?.toISOString() || new Date().toISOString(),
                  updated_at: data.updated_at?.toDate?.()?.toISOString() || new Date().toISOString()
                } as T);
              });

              console.log(`✅ Listener ${key} received ${results.length} records`);
              onNext(results);
            } catch (processingError) {
              console.error(`❌ Error processing data for listener ${key}:`, processingError);
              onNext([]);
            }
          },
          (error: FirestoreError) => {
            console.error(`❌ Listener ${key} error:`, error.code, error.message);
            
            this.connectionState.lastError = error;
            this.connectionState.isOnline = false;

            // Handle specific error types
            if (error.code === 'permission-denied') {
              console.log(`🚨 Permission denied for listener ${key} - providing empty data`);
              onNext([]);
              onError?.(error);
              return;
            }

            if (error.code === 'unavailable' || error.code === 'failed-precondition') {
              console.log(`🔄 Connection issue for listener ${key}, will retry...`);
              this.handleRetry(key, setupListener, onNext, onError);
              return;
            }

            // For other errors, notify the callback
            onError?.(error);
          }
        );
      } catch (setupError) {
        console.error(`❌ Error setting up listener ${key}:`, setupError);
        this.connectionState.activeListeners.delete(key);
        onNext([]);
      }
    };

    // Initial setup
    setupListener();

    // Return cleanup function
    return () => {
      console.log(`🔄 Cleaning up managed listener: ${key}`);
      
      if (unsubscribe) {
        unsubscribe();
        unsubscribe = null;
      }
      
      this.connectionState.activeListeners.delete(key);
      isRetrying = false;
    };
  }

  private handleRetry<T>(
    key: string,
    setupFn: () => void,
    onNext: (data: T[]) => void,
    onError?: (error: FirestoreError) => void
  ) {
    if (this.connectionState.retryCount >= this.maxRetries) {
      console.error(`❌ Max retries exceeded for listener ${key}`);
      this.connectionState.activeListeners.delete(key);
      onNext([]);
      return;
    }

    this.connectionState.retryCount++;
    const delay = Math.min(
      this.retryDelay * Math.pow(2, this.connectionState.retryCount - 1),
      this.maxRetryDelay
    );

    console.log(`🔄 Retrying listener ${key} in ${delay}ms (attempt ${this.connectionState.retryCount}/${this.maxRetries})`);

    setTimeout(() => {
      if (this.connectionState.activeListeners.has(key)) {
        setupFn();
      }
    }, delay);
  }

  // Get connection status
  getConnectionState(): ConnectionState {
    return { ...this.connectionState };
  }

  // Reset connection state (useful after auth changes)
  resetConnectionState() {
    console.log('🔄 Resetting Firebase connection state');
    this.connectionState.retryCount = 0;
    this.connectionState.isOnline = true;
    this.connectionState.lastError = null;
  }

  // Clean up all listeners (useful during sign out)
  cleanupAllListeners() {
    console.log(`🧹 Cleaning up ${this.connectionState.activeListeners.size} active listeners`);
    this.connectionState.activeListeners.clear();
    this.resetConnectionState();
  }

  // Get active listener count
  getActiveListenerCount(): number {
    return this.connectionState.activeListeners.size;
  }
}

export default FirebaseConnectionManager;