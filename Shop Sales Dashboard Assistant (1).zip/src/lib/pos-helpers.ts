import { Product, Sale, SaleItem, PaymentMethod, InsuranceProvider } from './firebase-types';

export interface CartItem extends SaleItem {
  product: Product;
  availableStock: number;
}

export interface CartTotals {
  subtotal: number;
  discountAmount: number;
  taxAmount: number;
  total: number;
}

export interface PaymentDetails {
  method: PaymentMethod;
  amount: number;
  reference?: string;
  insuranceDetails?: {
    provider: InsuranceProvider;
    memberNumber: string;
    copayAmount: number;
  };
}

// Helper function for safe numeric input parsing
export const parseNumericInput = (value: string): number => {
  const parsed = parseFloat(value);
  return isNaN(parsed) ? 0 : parsed;
};

// Calculate cart totals with tax and discount with safe numeric handling
export const calculateCartTotals = (
  cart: CartItem[], 
  discount: { percentage: number; amount: number }
): CartTotals => {
  // Safely calculate subtotal from cart items
  const subtotal = cart.reduce((sum, item) => {
    const itemTotal = Math.max(0, item.total || 0);
    return sum + itemTotal;
  }, 0);
  
  // Safely calculate discount
  const safeDiscountPercentage = Math.max(0, discount.percentage || 0);
  const safeDiscountAmount = Math.max(0, discount.amount || 0);
  
  const discountAmount = safeDiscountPercentage > 0 
    ? (subtotal * safeDiscountPercentage) / 100
    : safeDiscountAmount;
  
  // Calculate tax on discounted amount
  const taxableAmount = Math.max(0, subtotal - discountAmount);
  const taxAmount = taxableAmount * 0.18; // 18% VAT
  const total = Math.max(0, subtotal - discountAmount + taxAmount);
  
  return {
    subtotal: Math.max(0, subtotal),
    discountAmount: Math.max(0, discountAmount),
    taxAmount: Math.max(0, taxAmount),
    total: Math.max(0, total)
  };
};

// Create cart item from product with safe numeric handling
export const createCartItem = (
  product: Product, 
  quantity: number, 
  useInsurance: boolean
): CartItem => {
  // Safely parse prices and handle edge cases
  const parsePrice = (price: any): number => {
    if (price === null || price === undefined) return 0;
    const parsed = typeof price === 'string' ? parseFloat(price) : price;
    return isNaN(parsed) || !isFinite(parsed) ? 0 : Math.max(0, parsed);
  };
  
  const retailPrice = parsePrice(product.retail_price);
  const insurancePrice = parsePrice(product.insurance_price);
  const safeQuantity = Math.max(1, quantity || 1);
  
  const price = useInsurance && insurancePrice > 0 ? insurancePrice : retailPrice;
  const subtotal = price * safeQuantity;
  const taxRate = 0.18;
  const taxAmount = subtotal * taxRate;
  
  return {
    product_id: product.id,
    product_name: product.name || 'Unknown Product',
    category: product.category || 'Medicine', // Include category from product
    quantity: safeQuantity,
    unit_price: price,
    discount_percentage: 0,
    discount_amount: 0,
    subtotal,
    tax_rate: taxRate,
    tax_amount: taxAmount,
    total: subtotal + taxAmount,
    product,
    availableStock: Math.max(0, product.stock_quantity || 0)
  };
};

// Update cart item quantity and recalculate totals with safe numeric handling
export const updateCartItemQuantity = (
  item: CartItem, 
  newQuantity: number
): CartItem => {
  // Ensure safe numeric values
  const safeQuantity = Math.max(0, newQuantity || 0);
  const safeUnitPrice = Math.max(0, item.unit_price || 0);
  const safeTaxRate = Math.max(0, item.tax_rate || 0);
  const safeDiscountAmount = Math.max(0, item.discount_amount || 0);
  
  const subtotal = safeUnitPrice * safeQuantity;
  const taxAmount = subtotal * safeTaxRate;
  
  return {
    ...item,
    quantity: safeQuantity,
    subtotal,
    tax_amount: taxAmount,
    total: Math.max(0, subtotal + taxAmount - safeDiscountAmount)
  };
};

// Filter products based on search query
export const filterProducts = (products: Product[], searchQuery: string): Product[] => {
  if (!products || !Array.isArray(products)) {
    return [];
  }
  
  return products.filter(product => 
    product && 
    product.status === 'active' &&
    product.stock_quantity > 0 &&
    (product.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
     product.generic_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
     product.sku?.toLowerCase().includes(searchQuery.toLowerCase()) ||
     product.barcode?.toLowerCase().includes(searchQuery.toLowerCase()))
  );
};

// Get active products with stock
export const getAvailableProducts = (products: Product[]): Product[] => {
  if (!products || !Array.isArray(products)) {
    return [];
  }
  return products.filter(p => p && p.status === 'active' && p.stock_quantity > 0);
};

// Find product by barcode or SKU
export const findProductByCode = (products: Product[], code: string): Product | undefined => {
  if (!products || !Array.isArray(products)) {
    return undefined;
  }
  
  return products.find(p => 
    p.barcode === code || 
    p.sku === code
  );
};

// Create sale data object with proper null handling to prevent Firestore undefined errors
export const createSaleData = (
  userProfile: any,
  cart: CartItem[],
  totals: CartTotals,
  paymentAmount: number,
  paymentMethod: PaymentMethod,
  paymentReference: string,
  selectedCustomer: any,
  isPrescriptionSale: boolean,
  prescriptionNumber: string,
  doctorName: string,
  useInsurance: boolean,
  insuranceProvider: InsuranceProvider,
  insuranceNumber: string
): Omit<Sale, 'id' | 'created_at' | 'updated_at'> => {
  // Helper function to safely handle undefined values - Firestore doesn't accept undefined
  const safeValue = (value: any): any => {
    return value === undefined ? null : value;
  };
  
  // Helper function for optional string fields
  const safeString = (value: string | undefined): string | undefined => {
    return value && value.trim() ? value.trim() : undefined;
  };
  
  const saleData = {
    shop_id: userProfile.shop_id,
    branch_id: safeValue(userProfile.branch_id),
    sale_number: `SALE-${Date.now()}`,
    customer_id: safeValue(selectedCustomer?.id),
    customer_name: safeValue(selectedCustomer?.name),
    customer_phone: safeValue(selectedCustomer?.phone),
    customer_address: safeValue(selectedCustomer?.address),
    items: cart.map(item => ({
      product_id: item.product_id,
      product_name: item.product_name,
      category: item.category || item.product?.category || 'Medicine', // Include category in sale items
      batch_id: safeValue(item.batch_id),
      quantity: item.quantity,
      unit_price: item.unit_price,
      discount_percentage: item.discount_percentage || 0,
      discount_amount: item.discount_amount || 0,
      subtotal: item.subtotal,
      tax_rate: item.tax_rate,
      tax_amount: item.tax_amount,
      total: item.total
    })),
    subtotal: totals.subtotal,
    tax_amount: totals.taxAmount,
    discount_amount: totals.discountAmount,
    total_price: totals.total,
    amount_paid: paymentAmount,
    change_amount: Math.max(0, paymentAmount - totals.total),
    payment_method: paymentMethod,
    payment_status: 'paid' as const,
    payment_reference: paymentReference || null,
    cashier_id: userProfile.uid || userProfile.id, // Use auth UID for Firestore rules - must match request.auth.uid
    approved_by: safeValue(userProfile.uid || userProfile.id), // For audit trail
    notes: safeValue(null),
    receipt_printed: false,
    status: 'completed' as const,
    void_reason: safeValue(null),
    timestamp: new Date().toISOString()
  };
  
  // Add prescription fields only if it's a prescription sale
  if (isPrescriptionSale) {
    Object.assign(saleData, {
      prescription_number: safeString(prescriptionNumber),
      doctor_name: safeString(doctorName)
    });
  }
  
  // Add insurance fields only if using insurance
  if (useInsurance) {
    Object.assign(saleData, {
      insurance_provider: insuranceProvider,
      insurance_number: safeString(insuranceNumber)
    });
  }
  
  return saleData;
};