// Debugging utilities for development
import React from 'react';

export const useRenderTracker = (componentName: string, props?: Record<string, any>) => {
  if (process.env.NODE_ENV === 'development') {
    const renderCount = React.useRef(0);
    renderCount.current += 1;
    
    console.log(`🔄 ${componentName} render #${renderCount.current}`, props ? { props } : '');
    
    // Track if this component is rendering too frequently
    if (renderCount.current > 10) {
      console.warn(`⚠️ ${componentName} has rendered ${renderCount.current} times - potential performance issue`);
    }
  }
};

export const debugLog = (message: string, data?: any) => {
  if (process.env.NODE_ENV === 'development') {
    console.debug(`🐛 [DEBUG] ${message}`, data || '');
  }
};

export const logFunctionCall = (functionName: string, args?: any[]) => {
  if (process.env.NODE_ENV === 'development') {
    console.debug(`📞 [FUNCTION] ${functionName}`, args ? { args } : '');
  }
};

// Session storage utilities to prevent repeated operations
export const SessionFlags = {
  setFlag: (key: string, value: any) => {
    try {
      sessionStorage.setItem(`app_flag_${key}`, JSON.stringify(value));
    } catch (error) {
      console.warn('Failed to set session flag:', key, error);
    }
  },
  
  getFlag: (key: string) => {
    try {
      const item = sessionStorage.getItem(`app_flag_${key}`);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.warn('Failed to get session flag:', key, error);
      return null;
    }
  },
  
  hasFlag: (key: string) => {
    try {
      return sessionStorage.getItem(`app_flag_${key}`) !== null;
    } catch (error) {
      return false;
    }
  },
  
  clearFlag: (key: string) => {
    try {
      sessionStorage.removeItem(`app_flag_${key}`);
    } catch (error) {
      console.warn('Failed to clear session flag:', key, error);
    }
  },
  
  clearAllFlags: () => {
    try {
      const keys = [];
      for (let i = 0; i < sessionStorage.length; i++) {
        const key = sessionStorage.key(i);
        if (key && key.startsWith('app_flag_')) {
          keys.push(key);
        }
      }
      keys.forEach(key => sessionStorage.removeItem(key));
    } catch (error) {
      console.warn('Failed to clear all session flags:', error);
    }
  }
};