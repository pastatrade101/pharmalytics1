import { initializeApp, getApps } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// Direct Firebase configuration - hardcoded for immediate functionality
const firebaseConfig = {
  apiKey: "AIzaSyCwvoeRHE_So4WRllf7D8WJvI974REDVMY",
  authDomain: "shopsalesai.firebaseapp.com",
  projectId: "shopsalesai",
  storageBucket: "shopsalesai.firebasestorage.app",
  messagingSenderId: "665172496842",
  appId: "1:665172496842:web:ffd0e6fa3f19bc26163f33"
};

// Export configuration status - always true now
export const isConfigured = true;

// Initialize Firebase
let app;
let auth;
let db;

const initializeFirebase = () => {
  try {
    console.log('🔧 Initializing Firebase...');
    
    if (getApps().length === 0) {
      console.log('🆕 Creating new Firebase app');
      app = initializeApp(firebaseConfig);
    } else {
      console.log('🔄 Using existing Firebase app');
      app = getApps()[0];
    }
    
    console.log('🔐 Initializing Auth');
    auth = getAuth(app);
    
    console.log('🗄️ Initializing Firestore');
    db = getFirestore(app);
    
    // Verify all services are properly initialized
    if (!app) {
      throw new Error('Firebase app initialization failed');
    }
    if (!auth) {
      throw new Error('Firebase Auth initialization failed');
    }
    if (!db) {
      throw new Error('Firestore database initialization failed');
    }
    
    console.log('✅ Firebase initialized successfully:', {
      projectId: firebaseConfig.projectId,
      app: !!app,
      auth: !!auth,
      db: !!db
    });
    
    return { app, auth, db };
  } catch (error) {
    console.error('❌ Firebase initialization failed:', error);
    throw new Error(`Firebase initialization failed: ${error}`);
  }
};

// Initialize Firebase services
const services = initializeFirebase();

/**
 * Safely parse timestamp fields from Firestore to handle different data types
 * Supports Firestore Timestamps, JavaScript Dates, strings, and fallback to current date
 */
export const parseFirestoreTimestamp = (timestamp: any): string => {
  if (!timestamp) {
    return new Date().toISOString();
  }
  
  // If it's already a string, validate and return or use default
  if (typeof timestamp === 'string') {
    try {
      const date = new Date(timestamp);
      if (!isNaN(date.getTime())) {
        return date.toISOString();
      }
    } catch (error) {
      console.warn('Invalid timestamp string:', timestamp);
    }
    return new Date().toISOString();
  }
  
  // If it's a JavaScript Date object
  if (timestamp instanceof Date) {
    return timestamp.toISOString();
  }
  
  // If it's a Firestore Timestamp object
  if (timestamp && typeof timestamp.toDate === 'function') {
    try {
      return timestamp.toDate().toISOString();
    } catch (error) {
      console.warn('Failed to convert Firestore timestamp:', error);
      return new Date().toISOString();
    }
  }
  
  // If it's a Firestore Timestamp-like object with seconds and nanoseconds
  if (timestamp && typeof timestamp.seconds === 'number') {
    try {
      const date = new Date(timestamp.seconds * 1000);
      return date.toISOString();
    } catch (error) {
      console.warn('Failed to convert timestamp object:', error);
      return new Date().toISOString();
    }
  }
  
  // Default fallback
  console.warn('Unknown timestamp format:', typeof timestamp, timestamp);
  return new Date().toISOString();
};

// Ensure we export properly initialized instances
if (!services.auth || !services.db) {
  throw new Error('Firebase services not properly initialized');
}

// Extract services for export
auth = services.auth;
db = services.db;

export { auth, db };