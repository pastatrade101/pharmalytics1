# Firebase Index Errors - IMMEDIATE FIX REQUIRED

## 🚨 CRITICAL ERRORS IDENTIFIED

**Current Errors:**
1. `FirebaseError: [code=failed-precondition]: The query requires an index`
2. `TypeError: Cannot read properties of undefined (reading 'icon')`

These errors are preventing the Super Admin Dashboard from loading properly.

## ✅ IMMEDIATE FIXES APPLIED

### 1. SuperAdminDashboard Icon Error Fixed
- **Problem**: Status badge function trying to access icon property on undefined config
- **Fix**: Added fallback for unknown status values in `getStatusBadge` function
- **File**: `/components/SuperAdminDashboard.tsx` line 403

### 2. Firebase Query Index Requirements Removed
- **Problem**: `getShopUsers()` and `getUnassignedUsers()` using `orderBy` with `where` clauses
- **Fix**: Removed `orderBy` from queries, added in-memory sorting instead
- **Files**: `/lib/firebase-users-fixed.ts` lines 296-318 and 325-347

### 3. Updated Firebase Index Configuration
- **Added**: Complete index definitions for all required composite queries
- **File**: `/firestore_indexes.json` - now includes profiles collection indexes

## 🚀 DEPLOYMENT REQUIRED

**Run this command immediately:**

```bash
chmod +x scripts/fix-firebase-indexes.sh
./scripts/fix-firebase-indexes.sh
```

**Or deploy manually:**

```bash
firebase deploy --only firestore:indexes
```

## 📋 INDEXES BEING DEPLOYED

The following composite indexes will be created:

1. **profiles collection**:
   - `shop_id` (ASC) + `created_at` (DESC)
   - `role` (ASC) + `created_at` (DESC)

2. **sales collection**:
   - `shop_id` (ASC) + `created_at` (DESC)
   - `shop_id` (ASC) + `timestamp` (DESC)

3. **products collection**:
   - `shop_id` (ASC) + `status` (ASC)
   - `shop_id` (ASC) + `expiry_date` (ASC)

4. **users collection**:
   - `shop_id` (ASC) + `role` (ASC)

5. **shops collection**:
   - `status` (ASC) + `created_at` (DESC)

### 2. Fix SalesService Method Calls

The issue is that somewhere in your code, `SalesService.getSales()` is being called without the required `shopId` parameter. 

**Check these files for incorrect calls:**
- Any component importing SalesService
- FinancialReports component (though current version looks clean)
- MainDashboard or other dashboard components

**Correct usage:**
```typescript
// ❌ Wrong - will cause the error you're seeing
const sales = await SalesService.getSales();

// ✅ Correct - use getSalesByShop with shopId
const sales = await SalesService.getSalesByShop(userProfile.shop_id);
```

### 3. Firebase Permission Issues

The permission errors suggest your Firestore rules need to be deployed. 

**Quick check:**
```bash
firebase deploy --only firestore:rules
```

### 4. Network/Connection Issues

The WebChannel transport errors are usually temporary. Try:

1. **Refresh the browser page**
2. **Clear browser cache/localStorage**
3. **Check your internet connection**
4. **Try incognito mode**

## Detailed Fix Steps

### Step 1: Check Current Firebase Status

```bash
# Check if logged in
firebase login --list

# Check current project
firebase use

# Check Firestore rules status
firebase firestore:rules get
```

### Step 2: Deploy Required Indexes

The error message provides a direct link to create the index. You can either:

**Option A: Use the provided URL**
Copy the URL from your error message and open it in browser:
```
https://console.firebase.google.com/v1/r/project/shopsalesai/firestore/indexes?create_composite=...
```

**Option B: Use our script**
```bash
./scripts/fix-firebase-indexes.sh
```

**Option C: Manual deployment**
```bash
firebase deploy --only firestore:indexes
```

### Step 3: Fix Method Calls in Code

Search your codebase for incorrect SalesService calls:

```bash
# Search for problematic calls
grep -r "SalesService.getSales()" components/
grep -r "SalesService.getSales()" lib/
```

Replace any instances of:
```typescript
SalesService.getSales()
```

With:
```typescript
SalesService.getSalesByShop(shopId)
```

### Step 4: Verify Firebase Rules

Make sure your Firestore rules allow the queries:

```bash
firebase deploy --only firestore:rules
```

## Expected Index Build Time

- **Simple indexes**: 2-5 minutes
- **Complex indexes**: 5-15 minutes
- **Large datasets**: Up to 30 minutes

## Verification Steps

After deploying indexes, test these queries in Firebase Console:

1. Go to Firestore in Firebase Console
2. Navigate to the `sales` collection
3. Try filtering by `shop_id` and ordering by `timestamp`

## If Issues Persist

1. **Check Firebase Console**: Look for any failed index builds
2. **Check browser console**: Look for specific error details
3. **Try incognito mode**: Rules cache sometimes causes issues
4. **Wait longer**: Large datasets take time to index

## Production Deployment Notes

- Index building happens in background
- Your app should continue working with fallback queries
- Monitor Firebase Console for index completion status
- Consider deploying during low-traffic periods

## Emergency Fallback

If indexes fail, the updated SalesService will:
1. Catch the `failed-precondition` error
2. Use simple queries without ordering
3. Sort results on the client side
4. Return empty arrays instead of crashing

This ensures your app continues working while indexes build.