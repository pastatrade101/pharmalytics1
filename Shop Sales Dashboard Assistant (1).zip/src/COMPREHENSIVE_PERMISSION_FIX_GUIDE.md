# 🚨 COMPREHENSIVE FIREBASE PERMISSION FIX GUIDE

## Quick Fix Summary

Your Firebase permission errors are caused by **missing Firestore security rules**. This is the #1 cause of permission-denied errors in Firebase projects.

### 🚀 IMMEDIATE FIX (3 minutes)

**Option 1: Firebase Console (Recommended)**
1. Go to [Firebase Console](https://console.firebase.google.com)
2. Select your project → **Firestore Database** → **Rules**
3. Copy the complete rules from `/COMPLETE_FIRESTORE_RULES_FOR_CONSOLE.md`
4. **Replace all content** and click **Publish**

**Option 2: Command Line**
```bash
firebase deploy --only firestore:rules
```

**Option 3: Emergency Script**
```bash
chmod +x scripts/emergency-firebase-fix.sh
./scripts/emergency-firebase-fix.sh
```

---

## 🔍 Detailed Diagnosis

### Step 1: Identify the Problem

**Symptoms:**
- `FirebaseError: [code=permission-denied]`
- Product creation fails
- Profile loading issues
- "Deploy security rules immediately" messages

**Root Cause:**
Firestore has **default-deny rules** when no custom rules are deployed. This blocks all operations.

### Step 2: Run Comprehensive Diagnostic

Use the **Critical Firebase Fix Panel** in your app to run automated diagnostics:

1. **Authentication Check** - Verifies user is properly signed in
2. **Profile Access Check** - Tests user profile document access
3. **Rules Deployment Check** - Confirms security rules are active
4. **Product Creation Test** - End-to-end functionality test

### Step 3: Fix Each Issue

#### Issue 1: Authentication Problems
**Symptoms:** No authenticated user, invalid tokens
**Fix:** Sign out and sign in again

#### Issue 2: Missing User Profile
**Symptoms:** Profile document doesn't exist
**Fix:** The diagnostic tool will create a basic profile automatically

#### Issue 3: Rules Not Deployed (Most Common)
**Symptoms:** Permission denied on all Firestore operations
**Fix:** Deploy the security rules (see Quick Fix above)

#### Issue 4: Invalid User Role
**Symptoms:** User can't create products despite rules being deployed
**Fix:** Ensure user has role: 'admin', 'owner', or 'manager'

#### Issue 5: Missing Shop Assignment
**Symptoms:** User has valid role but no shop_id
**Fix:** Assign user to a shop or use 'default-shop-001' for testing

---

## 🛠️ Step-by-Step Solutions

### Solution 1: Deploy Rules via Firebase Console

1. **Open Firebase Console**
   - Go to https://console.firebase.google.com
   - Select your project

2. **Navigate to Rules**
   - Click **Firestore Database**
   - Click **Rules** tab

3. **Copy Complete Rules**
   - Open `/COMPLETE_FIRESTORE_RULES_FOR_CONSOLE.md`
   - Copy all the rules code

4. **Replace and Publish**
   - Delete all existing content in the console
   - Paste the new rules
   - Click **Publish**
   - Wait for "Rules published successfully"

5. **Verify Success**
   - Refresh your web application
   - Permission errors should disappear immediately

### Solution 2: Command Line Deployment

1. **Check Project Structure**
   ```bash
   # Verify you're in the right directory
   ls -la firebase.json firestore.rules
   ```

2. **Login to Firebase**
   ```bash
   firebase login
   ```

3. **Select Project**
   ```bash
   firebase use your-project-id
   ```

4. **Deploy Rules**
   ```bash
   firebase deploy --only firestore:rules
   ```

5. **Verify Deployment**
   ```bash
   firebase firestore:rules:get
   ```

### Solution 3: Fix User Profile Issues

If your user profile is missing or invalid:

1. **Check Current Profile**
   - Use the diagnostic tool in your app
   - Look for missing fields

2. **Create/Fix Profile**
   ```javascript
   // Basic profile structure needed
   {
     email: "user@example.com",
     full_name: "User Name",
     role: "admin", // or "owner", "manager"
     shop_id: "your-shop-id",
     created_at: "timestamp",
     updated_at: "timestamp"
   }
   ```

3. **Use Diagnostic Auto-Fix**
   - The Critical Firebase Fix Panel can create missing profiles automatically

### Solution 4: Emergency Shop Setup

If you need a test shop for immediate functionality:

1. **Use Default Test Shop**
   - Shop ID: `default-shop-001`
   - This is created automatically by the diagnostic tool

2. **Create Proper Shop Later**
   - Use the User Management interface
   - Assign users to real shops as needed

---

## 🧪 Testing and Verification

### Test 1: Basic Authentication
```javascript
// Check if user is signed in
console.log('User:', auth.currentUser?.email);
```

### Test 2: Profile Access
```javascript
// Try to read user profile
const profile = await FirebaseService.getCurrentUserProfile();
console.log('Profile:', profile);
```

### Test 3: Product Creation
```javascript
// Try to create a test product
const testProduct = {
  name: "Test Product",
  sku: "TEST-001",
  category: "otc",
  price: 1000,
  cost: 800,
  stock_quantity: 1,
  min_stock_level: 1,
  status: "active",
  shop_id: "your-shop-id"
};

const result = await FirebaseService.createProduct(testProduct);
console.log('Product created:', result);
```

### Test 4: Rules Verification
1. Go to Firebase Console → Firestore → Rules
2. Check that rules have a recent timestamp
3. Rules should be 2000+ characters (comprehensive rules)

---

## ⚡ Quick Recovery Checklist

- [ ] Firebase Console → Firestore → Rules → Deploy rules
- [ ] Refresh web application
- [ ] Run diagnostic in Critical Firebase Fix Panel
- [ ] Verify all tests pass
- [ ] Try creating a product
- [ ] Check user profile has valid role and shop_id

---

## 🔧 Advanced Troubleshooting

### Issue: Rules deployed but still getting errors
**Cause:** Rules take 1-2 minutes to propagate globally
**Solution:** Wait and refresh, clear browser cache

### Issue: User can read but can't write
**Cause:** User role doesn't have write permissions
**Solution:** Check role is 'admin', 'owner', or 'manager' for product creation

### Issue: Rules syntax errors
**Cause:** Invalid rules format
**Solution:** Use the exact rules from the provided guide, don't modify

### Issue: Wrong Firebase project
**Cause:** Deploying to wrong project
**Solution:** Run `firebase use your-correct-project-id`

### Issue: Missing Firebase CLI
**Cause:** Firebase tools not installed
**Solution:** Run `npm install -g firebase-tools`

---

## 📞 Still Having Issues?

If you're still experiencing problems after following this guide:

1. **Check the Error Console**
   - Look for specific error codes
   - Check browser developer tools

2. **Use the Diagnostic Tool**
   - Run the comprehensive diagnostic
   - Review all test results

3. **Verify Environment**
   - Check `.env.local` has correct Firebase config
   - Ensure all environment variables are set

4. **Try Fresh Browser Session**
   - Clear browser cache and cookies
   - Try incognito/private browsing mode

---

## ✅ Success Indicators

You'll know everything is working when:

- ✅ No permission-denied errors in console
- ✅ User profile loads successfully
- ✅ Products can be created without errors
- ✅ All diagnostic tests pass
- ✅ Critical Firebase Fix Panel shows green status

**Expected time to fix: 2-5 minutes** ⏱️

---

This comprehensive guide should resolve 99% of Firebase permission issues. The most common fix is simply deploying the security rules, which takes less than 3 minutes.