# Product Manager Permission Troubleshooting Guide

## Current Issue
Users with `product_manager` role are seeing the error:
```
"Your role (product_manager) doesn't have permission to import products. Required roles: manager, owner, admin"
```

## Root Cause Analysis

### 1. Error Message Sources Found:
✅ **FileImportDialog.tsx (Line 265)** - **FIXED** - Now shows correct roles
✅ **firebase.ts (Line 81)** - **FIXED** - Now shows correct roles  
✅ **ProductManager.tsx (Line 666)** - **FIXED** - Now shows correct roles
✅ **Firestore Rules** - **FIXED** - Now includes product_manager role

### 2. Remaining Issue: Cache/Browser State
The error message format "Required roles: manager, owner, admin" suggests there may be:
- Cached JavaScript files
- Cached validation logic
- Browser storage with old role data
- Service worker caching

## Complete Fix Implementation

### Step 1: Updated Permission Functions
```typescript
// lib/app-constants.ts
export const canImportProducts = (userRole: UserRole): boolean => {
  return ['product_manager', 'owner', 'admin', 'super_admin'].includes(userRole);
};

export const canManageProducts = (userRole: UserRole): boolean => {
  return ['product_manager', 'admin', 'super_admin'].includes(userRole);
};
```

### Step 2: Updated Firestore Rules
```javascript
// firestore.rules
function canManageProducts(shopId) {
  return isAuthenticated() && 
         (isAdmin() || 
          (hasAnyRole(['product_manager']) && belongsToShop(shopId)));
}
```

### Step 3: Updated Error Messages
All hardcoded error messages now show:
```
"Required roles: product_manager, owner, admin, super_admin"
```

### Step 4: Cache Clearing Required
Since the error persists, users need to:

1. **Clear Browser Cache:**
   - Chrome: Ctrl+Shift+Del → "All time" → Clear data
   - Firefox: Ctrl+Shift+Del → "Everything" → Clear
   - Safari: Develop → Empty Caches

2. **Clear Application Storage:**
   - Open Developer Tools (F12)
   - Go to Application/Storage tab
   - Clear Local Storage, Session Storage, IndexedDB

3. **Hard Refresh:**
   - Ctrl+F5 (Windows) or Cmd+Shift+R (Mac)

4. **Incognito/Private Mode Test:**
   - Test in private browsing to bypass cache

5. **Sign Out & Sign In:**
   - Complete logout and fresh login

## Verification Steps

### 1. Use ProductImportDebugger Component
The system now includes a debug component to verify:
- Current user role
- Permission function results
- Browser cache state
- Firebase authentication state

### 2. Console Verification
Open browser console and run:
```javascript
// Check current user profile
console.log('User Profile:', await FirebaseService.getCurrentUserProfile());

// Check permission function
import { canImportProducts } from './lib/app-constants';
console.log('Can Import Products:', canImportProducts('product_manager')); // Should be true
```

### 3. Network Tab Check
- Open Network tab in DevTools
- Try to import
- Look for actual API call responses
- Check if 403/permission errors come from server

## Expected Behavior After Fix

### ✅ Working State:
- `product_manager` role can click "Import from File" button
- Import dialog opens without permission error
- File can be selected and import process starts
- Products are successfully created in Firestore

### ❌ If Still Failing:
1. Check console for JavaScript errors
2. Verify user role is exactly `product_manager` (case-sensitive)
3. Ensure user has `shop_id` assigned
4. Check Firebase Rules deployment status
5. Verify user's email is verified

## Deployment Instructions

### 1. Deploy Updated Firestore Rules
```bash
firebase deploy --only firestore:rules
```

### 2. Verify Rule Deployment
```bash
firebase firestore:rules get
```

### 3. Clear CDN/Edge Cache (if using)
If using Vercel, Netlify, or similar:
```bash
# Vercel
vercel env pull
vercel --prod

# Netlify
netlify deploy --prod
```

### 4. Force Client Updates
Add cache-busting parameter to force fresh JavaScript:
- Update version numbers
- Add timestamp to imports
- Clear service worker cache

## Emergency Fix Options

### Option 1: Temporary Override
If issue persists, temporarily add override in FileImportDialog.tsx:
```typescript
// TEMPORARY: Force allow product_manager
if (userProfile.role === 'product_manager') {
  // Skip permission check, proceed with import
}
```

### Option 2: Database Direct Fix
Check user profile in Firebase Console:
1. Go to Firestore
2. Open `profiles` collection
3. Find user document
4. Verify role field is exactly `product_manager`

### Option 3: Force Re-authentication
```typescript
// Force user to re-authenticate
await signOut();
// Redirect to login
```

## Success Indicators

### ✅ Fixed When:
1. Debug component shows `canImportProducts: true` for product_manager
2. Import button is enabled (not disabled)
3. Clicking import opens dialog immediately
4. No permission errors in console
5. Import process completes successfully

### 📊 Monitoring:
- Check error logs for permission denials
- Monitor successful import counts
- Track user feedback on import functionality

## Contact Support
If issue persists after following all steps:
1. Provide debug component output
2. Include browser console logs
3. Share network tab screenshots
4. Specify exact error messages
5. Include user profile information (role, shop_id, email_verified)

---

**Last Updated:** [Current Date]
**Status:** Active troubleshooting for persistent cache issues
**Next Steps:** Clear browser cache and test in incognito mode