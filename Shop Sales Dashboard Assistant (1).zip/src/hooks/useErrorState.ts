import React from 'react';
import { useError } from '../contexts/ErrorContext';
import { SessionFlags } from '../lib/debug-utils';
import { toast } from 'sonner';

export function useErrorState() {
  const { 
    errors, 
    hasErrorsOfType,
    getPermissionErrors,
    getIndexErrors
  } = useError();

  // Enhanced permission and AI error handling with reduced UI noise
  React.useEffect(() => {
    const permissionErrors = getPermissionErrors();
    
    if (permissionErrors.length > 0) {
      console.log('🚨 CRITICAL: Permission errors detected:', permissionErrors.length);
      
      // Only show critical permission errors that require immediate action
      const criticalPermissionError = permissionErrors.find(error => 
        error.context.includes('Profile') || 
        error.context.includes('Authentication')
      );
      
      if (criticalPermissionError && !SessionFlags.hasFlag('critical_permission_shown')) {
        toast.error('🚨 Firebase Rules Required', {
          description: 'Deploy security rules to enable all features.',
          duration: 8000,
          action: {
            label: 'View Fix Guide',
            onClick: () => {
              console.log('📋 User clicked to view Firebase rules fix guide');
            }
          }
        });
        SessionFlags.setFlag('critical_permission_shown', true);
      }
    }
  }, [getPermissionErrors]);

  // Memoized error state calculations with system error filtering
  const errorState = React.useMemo(() => {
    const permissionErrors = getPermissionErrors();
    const indexErrors = getIndexErrors();
    
    // Filter out system errors from general error checking
    const userActionableErrors = errors.filter(error => {
      const systemErrorPatterns = [
        'Real AI analytics',
        'Gemini API connection',
        'Connection established',
        'Analytics available',
        'Loaded',
        'products for expiry monitoring',
        'products from database',
        'Welcome back',
        'Successfully loaded',
        'Authentication successful',
        'Successfully signed out',
        'Welcome to Shop Sales Dashboard',
        'system using fallback',
        'fallback analysis',
        'quota exceeded',
        'intelligent fallback'
      ];
      
      const errorMessage = error.message || error.description || '';
      const isSystemError = systemErrorPatterns.some(pattern => 
        errorMessage.toLowerCase().includes(pattern.toLowerCase())
      );
      
      return error.isPermissionError || 
             error.type === 'validation' ||
             !isSystemError;
    });
    
    return {
      permissionErrors,
      indexErrors,
      hasPermissionErrors: permissionErrors.length > 0,
      hasIndexErrors: indexErrors.length > 0,
      hasNetworkErrors: hasErrorsOfType('network'),
      hasValidationErrors: hasErrorsOfType('validation'),
      hasCriticalErrors: permissionErrors.length > 0 || indexErrors.length > 0,
      userActionableErrors
    };
  }, [getPermissionErrors, getIndexErrors, hasErrorsOfType, errors]);

  return errorState;
}