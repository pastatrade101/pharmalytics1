// Barrel export for custom hooks
export { useAIConnection } from './useAIConnection';