import { useState, useEffect, useRef, useCallback } from 'react';
import { auth, signOut, onAuthStateChange } from '../lib/firebase';
import { SalesService } from '../lib/firebase-sales';
import { SessionFlags, debugLog } from '../lib/debug-utils';
import { isDevelopment, isSuperAdmin } from '../lib/app-constants';
import { UserCreationManager } from '../lib/user-creation-manager';
import { useError } from '../contexts/ErrorContext';

export function useAuthState() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [emailVerified, setEmailVerified] = useState<boolean | null>(null);
  const [authMode, setAuthMode] = useState<'regular' | 'super_admin'>('regular');
  
  // Refs to prevent repeated operations and manage connection state
  const authStateInitializedRef = useRef(false);
  const unsubscribeRef = useRef<(() => void) | null>(null);
  const connectionResetTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const { addError, clearErrorsByContext } = useError();

  // Enhanced auth state management with reduced system noise
  useEffect(() => {
    // Prevent multiple initializations
    if (authStateInitializedRef.current) {
      debugLog('Auth state already initialized, skipping');
      return;
    }

    debugLog('App initializing with enhanced connection management');
    console.log('🚀 App initializing with Firebase connection optimization...');
    
    // Only log detailed info in development
    if (isDevelopment) {
      console.log('📍 Current URL:', window.location.href);
      console.log('🕐 Timestamp:', new Date().toISOString());
      console.log('🔧 Environment:', 'Development');
    }

    const unsubscribe = onAuthStateChange(async (user) => {
      try {
        debugLog('Auth state changed', user?.uid || 'null');
        console.log('🔄 Auth state changed:', user?.uid || 'signed out');
        
        // Clear connection reset timeout if exists
        if (connectionResetTimeoutRef.current) {
          clearTimeout(connectionResetTimeoutRef.current);
          connectionResetTimeoutRef.current = null;
        }
        
        if (user) {
          console.log('👤 User authenticated:', user.email);
          
          // Check email verification status
          setEmailVerified(user.emailVerified);
          console.log('📧 Email verified:', user.emailVerified);
          
          // Reset connection state for new user session
          SalesService.resetConnections();
          
          setIsAuthenticated(true);
          
          // If this was during user creation, don't immediately clear flag (UserManagement will handle it)
          const isUserCreationContext = UserCreationManager.isUserCreationInProgress();
          if (isUserCreationContext) {
            console.log('🔄 User creation process detected - handling gracefully');
          }
        } else {
          console.log('👤 User signed out');
          
          // Clear user creation flag if set
          UserCreationManager.setUserCreationInProgress(false);
          
          // Cleanup all Firebase listeners and reset connection state
          SalesService.cleanupAllListeners();
          
          // Delay connection reset to allow cleanup
          connectionResetTimeoutRef.current = setTimeout(() => {
            SalesService.resetConnections();
          }, 1000);
          
          setIsAuthenticated(false);
          setEmailVerified(null);
          setAuthMode('regular');
          
          // Clear session flags when user signs out
          SessionFlags.clearAllFlags();
          debugLog('Session flags and connections cleared on sign out');
        }
        setIsLoading(false);
      } catch (error: any) {
        console.error('❌ Auth state change error:', error);
        
        // Only show critical errors in UI
        if (error?.isPermissionError) {
          addError(error, 'Authentication', '🚨 CRITICAL: Firebase rules deployment required.');
        } else if (error?.code === 'unavailable') {
          // Don't show connection warnings in UI, just log them
          console.warn('Firebase connection temporarily unavailable during authentication.');
        } else if (isDevelopment) {
          addError(error, 'Authentication', 'Failed to authenticate user. Please refresh and try again.');
        }
        
        setIsLoading(false);
      }
    });

    unsubscribeRef.current = unsubscribe;
    authStateInitializedRef.current = true;

    return () => {
      debugLog('Cleaning up auth listener and connections');
      console.log('🧹 Cleaning up auth listener and Firebase connections');
      
      if (unsubscribeRef.current) {
        unsubscribeRef.current();
        unsubscribeRef.current = null;
      }
      
      if (connectionResetTimeoutRef.current) {
        clearTimeout(connectionResetTimeoutRef.current);
        connectionResetTimeoutRef.current = null;
      }
      
      // Cleanup all Firebase listeners
      SalesService.cleanupAllListeners();
      
      authStateInitializedRef.current = false;
    };
  }, [addError]);

  // Handle sign out with enhanced cleanup
  const handleSignOut = useCallback(async () => {
    try {
      console.log('🚪 Signing out...');
      
      // Clear user creation flag if set
      UserCreationManager.setUserCreationInProgress(false);
      
      // Cleanup all Firebase listeners before signing out
      SalesService.cleanupAllListeners();
      
      await signOut();
      
      // Log success instead of showing UI notification
      console.log('✅ Successfully signed out');
      
      // Clear session flags on sign out
      SessionFlags.clearAllFlags();
      clearErrorsByContext('All');
      
      // Reset Firebase connection state after cleanup
      setTimeout(() => {
        SalesService.resetConnections();
      }, 500);
      
      debugLog('All session data and connections cleared on sign out');
    } catch (error: any) {
      console.error('❌ Sign out error:', error);
      // Only show critical sign out errors
      addError(error, 'Authentication', 'Failed to sign out. Please refresh the page.');
    }
  }, [addError, clearErrorsByContext]);

  // Handle auth success with reduced notifications
  const handleAuthSuccess = useCallback(() => {
    console.log('🎉 Authentication successful');
    
    // Reduce UI noise - log success instead of showing notification
    const authSuccessKey = 'auth_success_shown';
    if (!SessionFlags.hasFlag(authSuccessKey)) {
      console.log('🎉 Authentication successful - Welcome to Shop Sales Dashboard!');
      SessionFlags.setFlag(authSuccessKey, true);
      debugLog('Auth success logged');
    }
  }, []);

  // Handle super admin auth success
  const handleSuperAdminAuthSuccess = useCallback(() => {
    console.log('🛡️ Super Admin authentication successful');
    setAuthMode('regular'); // Reset to regular mode after successful auth
    handleAuthSuccess();
  }, [handleAuthSuccess]);

  // Switch to super admin auth mode
  const handleSwitchToSuperAdmin = useCallback(() => {
    setAuthMode('super_admin');
  }, []);

  // Switch back to regular auth mode
  const handleBackToRegular = useCallback(() => {
    setAuthMode('regular');
  }, []);

  return {
    isAuthenticated,
    isLoading,
    emailVerified,
    authMode,
    setEmailVerified,
    handleSignOut,
    handleAuthSuccess,
    handleSuperAdminAuthSuccess,
    handleSwitchToSuperAdmin,
    handleBackToRegular
  };
}