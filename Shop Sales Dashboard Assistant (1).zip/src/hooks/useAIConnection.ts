// Custom hook for AI connectivity testing

import { useState, useEffect, useRef, useCallback } from 'react';
import { AISystemStatus } from '../lib/app-constants';
import { geminiConnector } from '../lib/gemini-mcp';
import { useError } from '../contexts/ErrorContext';

export const useAIConnection = () => {
  const [aiSystemStatus, setAiSystemStatus] = useState<AISystemStatus>('checking');
  const { addError, addSuccess, addInfo, addWarning } = useError();
  const hasTestedRef = useRef(false); // Prevent multiple tests
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Memoize the test function to prevent recreating it on every render
  const testAIConnection = useCallback(async () => {
    // Prevent multiple simultaneous tests
    if (hasTestedRef.current) {
      console.log('🤖 AI connection test already completed, skipping...');
      return;
    }

    try {
      console.log('🤖 Testing Gemini API connectivity...');
      setAiSystemStatus('checking');
      hasTestedRef.current = true; // Mark as tested
      
      // Simple test with minimal sales data
      const testData = await geminiConnector.generateSalesSummary({
        salesData: [
          { item: 'Test Product', quantity: 1, totalPrice: 10, timestamp: new Date().toISOString() }
        ],
        dateRange: 'test',
        previousPeriodData: []
      });
      
      // Check if real AI was used or if quota was exceeded
      const hasQuotaError = testData.quotaExceeded || testData.alerts?.some((alert: string) => 
        alert.includes('quota') || alert.includes('billing') || alert.includes('exceeded')
      );
      
      const isUsingFallback = testData.isMockData || testData.isEnhancedFallback || testData.alerts?.some((alert: string) => 
        alert.includes('unavailable') || alert.includes('fallback') || alert.includes('Authentication failed')
      );
      
      const hasSystemError = testData.systemError;
      
      if (hasQuotaError) {
        setAiSystemStatus('quota-exceeded');
        // Log quota issue to console - system will handle gracefully with fallback
        console.log('💰 Gemini quota exceeded - using enhanced fallback analysis');
      } else if (hasSystemError) {
        setAiSystemStatus('error');
        // Log system error to console - fallback mode will handle analysis
        console.log('🚨 System analysis error detected');
      } else if (isUsingFallback) {
        setAiSystemStatus('fallback');
        // Log fallback mode to console - system continues to work normally
        console.log('⚠️ AI system using fallback - Gemini API may have authentication or connectivity issues');
      } else {
        setAiSystemStatus('ready');
        // Log success to console instead of creating UI notification noise
        console.log('✅ Gemini API connection successful - real AI analytics available');
      }
      
    } catch (error: any) {
      console.error('❌ AI system test failed:', error);
      
      const errorMessage = error?.message || String(error);
      
      if (error?.name === 'QuotaExceededError' || errorMessage.includes('quota') || errorMessage.includes('429') || errorMessage.includes('insufficient_quota')) {
        setAiSystemStatus('quota-exceeded');
        // Log quota error to console - system continues with fallback analysis
        console.log('💰 Quota exceeded error caught in test function');
      } else if (error?.name === 'AuthenticationError' || errorMessage.includes('authentication') || errorMessage.includes('401') || errorMessage.includes('API_KEY_INVALID')) {
        setAiSystemStatus('auth-error');
        // Log auth error to console - only show critical permission errors to users
        console.log('🔑 Authentication error detected');
      } else if (errorMessage.includes('network') || errorMessage.includes('fetch') || errorMessage.includes('timeout')) {
        setAiSystemStatus('network-error');
        // Log network issues to console - system gracefully handles with fallback
        console.log('🌐 Network connectivity issues detected');
      } else {
        setAiSystemStatus('error');
        // Log unexpected errors to console - system maintains functionality with fallback
        console.log('❌ Unexpected error in AI connection test');
      }
    }
  }, [addError, addSuccess, addInfo, addWarning]);

  useEffect(() => {
    // Only run the test once when the hook is first initialized
    if (!hasTestedRef.current) {
      // Test AI connection after a short delay to let other systems initialize
      timeoutRef.current = setTimeout(() => {
        testAIConnection();
      }, 2000);
    }

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []); // Empty dependency array - only run once on mount

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      hasTestedRef.current = false; // Reset for potential remounts
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  return aiSystemStatus;
};