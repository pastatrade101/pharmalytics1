import { useState, useRef, useCallback } from 'react';
import { auth, FirebaseService, SalesService } from '../lib/firebase';
import { UserProfile as UserProfileType } from '../lib/firebase-types';
import { SessionFlags, debugLog, logFunctionCall } from '../lib/debug-utils';
import { isDevelopment, isSuperAdmin } from '../lib/app-constants';
import { UserCreationManager } from '../lib/user-creation-manager';
import { useError } from '../contexts/ErrorContext';
import { toast } from 'sonner';

export function useUserProfile() {
  const [userProfile, setUserProfile] = useState<UserProfileType | null>(null);
  const [shopActivated, setShopActivated] = useState<boolean | null>(null);
  
  // Refs to prevent repeated operations
  const profileLoadedRef = useRef<string | null>(null);

  const { addError, clearErrorsByContext } = useError();

  // Enhanced profile loader with user creation handling and better error handling
  const loadUserProfile = useCallback(async (userId: string, isUserCreationContext = false) => {
    logFunctionCall('loadUserProfile', [userId, isUserCreationContext]);
    
    // Skip profile loading if we're in the middle of user creation
    if (UserCreationManager.isUserCreationInProgress() && !isUserCreationContext) {
      debugLog('Skipping profile load during user creation process', userId);
      return;
    }
    
    // Prevent loading the same user profile multiple times
    if (profileLoadedRef.current === userId) {
      debugLog('User profile already loaded for user', userId);
      return;
    }

    const welcomeShownKey = `welcome_shown_${userId}`;
    const welcomeAlreadyShown = SessionFlags.hasFlag(welcomeShownKey);

    try {
      debugLog('Loading user profile for user', userId);
      clearErrorsByContext('User Profile');
      
      // Reset Firebase connection state for new user
      SalesService.resetConnections();
      
      const profile = await FirebaseService.getCurrentUserProfile();
      
      if (!profile) {
        // Handle case where user document doesn't exist
        console.log(`ℹ️ User document does not exist for: ${userId}`);
        
        // This might happen during signup process or if document creation failed
        if (isUserCreationContext) {
          console.log('📝 User document missing during creation context - this may be expected');
          return;
        }
        
        // For existing users, this might be a new user or a temporary issue
        console.log('⚠️ User profile not found - this might be a new user or temporary issue');
        
        // Don't show error toast immediately - wait a moment and retry
        setTimeout(() => {
          console.log('🔄 Retrying profile load after user document creation delay...');
          profileLoadedRef.current = null;
          loadUserProfile(userId);
        }, 2000);
        
        return;
      }
      
      setUserProfile(profile);
      profileLoadedRef.current = userId;
      debugLog('User profile loaded successfully', profile);
      
      // Check shop status if user has a shop
      if (profile && profile.shop_id && !isSuperAdmin(profile.role)) {
        try {
          const shop = await FirebaseService.getShopById(profile.shop_id);
          if (shop) {
            setShopActivated(shop.status === 'active');
            console.log(`🏪 Shop status: ${shop.status}`);
          } else {
            console.warn('⚠️ Shop not found but user has shop_id');
            // Don't block login - the shop might be in a different state
            setShopActivated(true);
          }
        } catch (error) {
          console.error('Error checking shop status:', error);
          // Don't block login for shop status errors
          setShopActivated(true);
        }
      } else {
        // Super admins and users without shops don't need activation
        setShopActivated(true);
      }
      
      // Only show welcome message once per session for this user (and not in development)
      if (profile && !welcomeAlreadyShown && !isDevelopment) {
        // Reduced UI noise - only show welcome in console
        console.log(`✅ Welcome back, ${profile.full_name}!`);
        SessionFlags.setFlag(welcomeShownKey, true);
        debugLog('Welcome message shown for user', userId);
      }
      
    } catch (error: any) {
      console.error('❌ Failed to load user profile:', error);
      
      // During user creation, be more lenient with errors
      if (isUserCreationContext) {
        console.warn('⚠️ Profile load error during user creation - this may be expected');
        // Reset the loaded flag and continue
        profileLoadedRef.current = null;
        return;
      }
      
      // Handle specific error cases
      if (error?.code === 'permission-denied' || error?.isPermissionError) {
        addError(error, 'User Profile', '🚨 CRITICAL: Firebase rules not deployed. Profile loading blocked.');
        
        // Only show toast for critical permission errors with action
        if (!SessionFlags.hasFlag('profile_permission_error_shown')) {
          toast.error('🚨 Firebase Rules Required', {
            description: 'Deploy security rules to access your pharmacy data.',
            duration: 10000,
            action: {
              label: 'View Fix Guide',
              onClick: () => {
                console.log('📋 Firebase Rules Fix Guide:');
                console.log('1. Go to: https://console.firebase.google.com/project/shopsalesai/firestore/rules');
                console.log('2. Follow the complete rules in COMPLETE_FIREBASE_RULES_FIX.md');
                console.log('3. Click Publish and wait for confirmation');
                console.log('4. Refresh this application');
                window.open('https://console.firebase.google.com/project/shopsalesai/firestore/rules', '_blank');
              }
            }
          });
          SessionFlags.setFlag('profile_permission_error_shown', true);
        }
      } else if (error?.code === 'unavailable') {
        // Don't show UI errors for temporary unavailability, just retry
        console.warn('Firebase temporarily unavailable. Retrying profile load...');
        setTimeout(() => {
          profileLoadedRef.current = null;
          loadUserProfile(userId);
        }, 2000);
        return;
      } else if (error?.message?.includes('User document does not exist')) {
        // Handle missing user document more gracefully
        console.warn(`⚠️ User document missing for ${userId} - this might be a new user`);
        
        // For new users, this might be expected during signup
        if (!SessionFlags.hasFlag(`missing_document_${userId}`)) {
          toast.warning('Profile Setup Required', {
            description: 'Your profile is being set up. Please try signing in again in a moment.',
            duration: 6000
          });
          SessionFlags.setFlag(`missing_document_${userId}`, true);
        }
      } else {
        // Only add user-actionable errors in production
        if (isDevelopment) {
          addError(error, 'User Profile', 'Failed to load user profile. Please try refreshing the page.');
        }
      }
      
      // Reset the loaded flag on error so we can retry
      profileLoadedRef.current = null;
    }
  }, [addError, clearErrorsByContext]);

  // Handle email verification completion
  const handleEmailVerified = useCallback(async () => {
    console.log('📧 Email verification completed');
    
    // Reload user profile to get updated information
    if (auth.currentUser) {
      await loadUserProfile(auth.currentUser.uid);
    }
  }, [loadUserProfile]);

  // Handle shop activation completion
  const handleShopActivated = useCallback(async () => {
    console.log('🏪 Shop activation completed');
    setShopActivated(true);
    
    // Reload user profile to get updated shop information
    if (auth.currentUser) {
      await loadUserProfile(auth.currentUser.uid);
    }
  }, [loadUserProfile]);

  // Reset profile state
  const resetProfile = useCallback(() => {
    setUserProfile(null);
    setShopActivated(null);
    profileLoadedRef.current = null;
  }, []);

  return {
    userProfile,
    shopActivated,
    setShopActivated,
    loadUserProfile,
    handleEmailVerified,
    handleShopActivated,
    resetProfile
  };
}