# Firebase Setup Guide for Shop Sales Dashboard

This guide will help you set up Firebase for the Shop Sales Dashboard application.

## 1. Firebase Project Setup

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create a new project or select your existing "shopsalesai" project
3. Enable Authentication and Firestore Database

## 2. Authentication Setup

1. In Firebase Console, go to **Authentication** > **Sign-in method**
2. Enable **Email/Password** authentication
3. Optionally, enable other providers as needed

## 3. Firestore Database Setup

### Step 1: Create Firestore Database
1. Go to **Firestore Database**
2. Click **Create database**
3. Choose **Start in test mode** (we'll update rules later)
4. Select your preferred region

### Step 2: Update Security Rules
1. Go to **Firestore Database** > **Rules**
2. Replace the default rules with the content from `/firestore.rules` file
3. Click **Publish**

### Step 3: Create Initial Collections (Optional)
The app will create collections automatically, but you can create them manually:

- `profiles` - User profiles
- `shops` - Shop information
- `sales` - Sales transactions
- `daily_reports` - AI-generated daily reports

## 4. Environment Configuration

Make sure your `.env.local` file has the correct Firebase configuration:

```env
NEXT_PUBLIC_FIREBASE_API_KEY=AIzaSyCwvoeRHE_So4WRllf7D8WJvI974REDVMY
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=shopsalesai.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=shopsalesai
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=shopsalesai.firebasestorage.app
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=665172496842
NEXT_PUBLIC_FIREBASE_APP_ID=1:665172496842:web:your-app-id-here
```

## 5. Security Rules Explanation

The Firestore security rules ensure:

- **Users can only access their own profile data**
- **Shop owners can manage their shops and view all associated data**
- **Sellers can only create sales for their assigned shop**
- **Users can only view data from their associated shop**

## 6. Testing the Setup

1. Start your application: `npm run dev`
2. Try signing up with a new account
3. Create some test sales data
4. Verify data appears in Firebase Console

## 7. Troubleshooting

### Permission Denied Errors
- Verify Firestore rules are published correctly
- Check that user authentication is working
- Ensure user has proper shop assignment

### Authentication Issues
- Verify Email/Password is enabled in Firebase Console
- Check that API keys are correct in `.env.local`
- Ensure Firebase project is active

### Demo Mode Fallback
If Firebase is not configured, the app automatically falls back to demo mode with mock data.

## 8. Production Deployment

Before deploying to production:

1. Review and tighten security rules if needed
2. Set up Firebase project billing
3. Configure proper domains in Firebase Console
4. Set up monitoring and alerts

## 9. Advanced Features

### Real-time Updates
The app uses Firestore real-time listeners for:
- Live sales updates across all connected users
- Instant notification of new sales
- Real-time dashboard updates

### AI Integration
- OpenAI analysis requires valid API key
- Daily reports are generated automatically
- Insights are stored in Firestore for historical tracking

## Support

If you encounter issues:
1. Check the browser console for detailed error messages
2. Verify Firebase Console shows your project is active
3. Ensure all security rules are properly configured
4. Check that the user has appropriate permissions

The application includes extensive fallback mechanisms and will work in demo mode even without proper Firebase configuration.