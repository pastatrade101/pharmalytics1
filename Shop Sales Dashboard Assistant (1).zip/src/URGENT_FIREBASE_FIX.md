# 🚨 URGENT: Fix Firebase Permission Errors NOW

## Current Problem
Your pharmacy import system is failing because **Firestore security rules are NOT deployed**. This is blocking all product creation operations.

## ⚡ IMMEDIATE SOLUTION (2 Minutes)

### Option 1: Use the Automated Deployment Script
```bash
# Run the automated deployment script:
chmod +x scripts/deploy-firebase-rules.sh
./scripts/deploy-firebase-rules.sh
```

### Option 2: Manual Deployment
```bash
# Run this command in your project root directory:
firebase deploy --only firestore:rules

# If you don't have Firebase CLI installed:
npm install -g firebase-tools
firebase login
firebase deploy --only firestore:rules
```

### Step 2: Test Using the Built-in Tester
1. Refresh your web application
2. Look for the **"Firebase Permission Tester"** yellow panel
3. Click **"Run Tests"** to verify everything works
4. All tests should show "Passed" status

### Step 3: Test Import Again
1. Try importing products again
2. The permission errors should be resolved
3. You should see "✅ Product created successfully" messages

## 🔍 If Still Failing - Debug User Profile

Add this debug code temporarily to check your user profile:

```javascript
// Add this to your browser console on the pharmacy import page:
console.log("=== USER PROFILE DEBUG ===");
console.log("Current user:", firebase.auth().currentUser);
console.log("User profile from component:", /* your userProfile data */);

// Or look for this in your browser console - it should already be logging:
// "🔍 Import Debug - User Profile:"
```

### Required User Profile Fields:
- `role`: Must be 'manager', 'owner', or 'admin' 
- `shop_id`: Must have a valid shop assignment
- `uid`: Must match authenticated user

## 🧪 Test Firebase Rules (After Deployment)

Create this test file to verify everything works:

```javascript
// test-firestore-access.js
const { initializeApp } = require('firebase/app');
const { getFirestore, doc, setDoc } = require('firebase/firestore');

// Your Firebase config
const firebaseConfig = {
  // Add your config here
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

async function testProductCreation() {
  try {
    const testProduct = {
      name: 'Test Product',
      sku: 'TEST-001',
      category: 'otc',
      price: 1000,
      cost: 800,
      stock_quantity: 10,
      min_stock_level: 5,
      status: 'active',
      shop_id: 'your-shop-id', // Replace with actual shop ID
      created_at: new Date(),
      updated_at: new Date()
    };
    
    await setDoc(doc(db, 'products', 'test-product'), testProduct);
    console.log('✅ Product creation test PASSED');
  } catch (error) {
    console.error('❌ Product creation test FAILED:', error);
  }
}

testProductCreation();
```

## 📋 Verification Checklist

- [ ] Firebase CLI installed and logged in
- [ ] Firestore rules deployed successfully
- [ ] User has role: manager/owner/admin
- [ ] User has valid shop_id assigned
- [ ] Test product creation works
- [ ] Import functionality working

## 🆘 Emergency Workaround (TEMPORARY ONLY)

If you need immediate access for testing, add this TEMPORARY rule to your `firestore.rules`:

```javascript
// TEMPORARY RULE - ADD TO firestore.rules - REMOVE AFTER TESTING
match /products/{productId} {
  allow read, write: if request.auth != null;
}
```

Then deploy: `firebase deploy --only firestore:rules`

**⚠️ CRITICAL: Remove this rule after testing - it's not secure!**

## 🔧 Common Issues

### Issue 1: Wrong Firebase Project
```bash
# Check current project:
firebase projects:list
firebase use your-project-id
firebase deploy --only firestore:rules
```

### Issue 2: Rules File Not Found
Make sure `firestore.rules` exists in your project root and contains your security rules.

### Issue 3: User Role Issues
Your user account must have role 'manager', 'owner', or 'admin' in the Firestore `profiles` collection.

## 📞 Still Having Issues?

1. Check browser console for detailed error messages
2. Verify your Firebase project settings
3. Ensure you're connected to the correct Firebase project
4. Check that your user profile document exists in Firestore

## ✅ Success Indicators

You'll know it's working when:
- Import functionality works without permission errors
- Console shows: "✅ Product created successfully"
- Debug panel no longer shows permission errors
- Product appears in your pharmacy inventory

---

**This fix should resolve your issues in under 5 minutes. Deploy the rules NOW!**