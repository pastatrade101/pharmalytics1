# Firebase Permission Debugging Guide

## Current Issue Analysis

The import functionality is failing with permission errors when trying to create products. This indicates either:

1. **Firestore security rules are not deployed**
2. **User profile data is incomplete or incorrect**
3. **User doesn't have the required role for product creation**
4. **Shop association is missing or incorrect**

## Debugging Steps

### 1. Check User Profile Data
```javascript
// Add this to your component to debug user profile
console.log('🔍 User Profile Debug:', {
  uid: userProfile?.uid,
  role: userProfile?.role,
  shop_id: userProfile?.shop_id,
  email: userProfile?.email,
  full_name: userProfile?.full_name
});
```

### 2. Verify Required Roles
According to the Firestore rules, these roles can create products:
- `manager`
- `owner` 
- `admin`

### 3. Deploy Firestore Rules
Run this command in your project root:
```bash
firebase deploy --only firestore:rules
```

### 4. Test Firestore Rules
```javascript
// Test function to verify permissions
const testPermissions = async () => {
  try {
    const testProduct = {
      name: 'Test Product',
      sku: 'TEST-001',
      category: 'otc',
      price: 1000,
      cost: 800,
      stock_quantity: 10,
      min_stock_level: 5,
      status: 'active',
      shop_id: userProfile?.shop_id
    };
    
    await FirebaseService.createProduct(testProduct);
    console.log('✅ Permissions test passed');
  } catch (error) {
    console.error('❌ Permissions test failed:', error);
  }
};
```

## Quick Fixes

### Fix 1: Ensure User Has Correct Role
Make sure your user account has role `manager`, `owner`, or `admin`.

### Fix 2: Deploy Rules Immediately
```bash
# In your project root directory
firebase deploy --only firestore:rules
```

### Fix 3: Verify Shop Association
Ensure your user profile has a valid `shop_id` field.

## Emergency Workaround
If you need immediate access, temporarily modify the Firestore rules:

```javascript
// Temporary rule - REMOVE AFTER TESTING
match /products/{productId} {
  allow read, write: if request.auth != null;
}
```

**⚠️ WARNING: Remove this rule after debugging - it's not secure!**