#!/bin/bash

# Deploy Firebase rules with product_manager role support

echo "🚀 Deploying updated Firestore rules with product_manager role..."

# Deploy only Firestore rules
firebase deploy --only firestore:rules

echo "✅ Firestore rules deployment complete!"

# Verify deployment
echo "🔍 Verifying rule deployment..."
firebase firestore:rules get --project="$(firebase use --current | grep -o '[^ ]*$')"

echo "📋 Rules updated to include product_manager role in:"
echo "- Product management operations"
echo "- Sales operations" 
echo "- Import operations"
echo "- All relevant collections"

echo "✅ product_manager role now has full access to import products!"