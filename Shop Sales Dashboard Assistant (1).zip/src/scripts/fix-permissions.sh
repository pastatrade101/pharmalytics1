#!/bin/bash

# 🚨 URGENT: Fix Firestore Permission Errors
# This script deploys the pharmacy management system security rules

set -e

echo "🏥 Pharmacy Management System - Permission Fix"
echo "=============================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check if Firebase CLI is installed
if ! command -v firebase &> /dev/null; then
    echo -e "${RED}❌ Firebase CLI not found${NC}"
    echo "Installing Firebase CLI..."
    npm install -g firebase-tools
fi

echo -e "${BLUE}🔍 Checking Firebase CLI version...${NC}"
firebase --version

# Check if user is logged in
echo -e "${BLUE}🔐 Checking Firebase authentication...${NC}"
if ! firebase projects:list &> /dev/null; then
    echo -e "${YELLOW}⚠️  Not logged in to Firebase${NC}"
    echo "Please log in:"
    firebase login
fi

# List available projects
echo -e "${BLUE}📋 Available Firebase projects:${NC}"
firebase projects:list

# Get project ID
echo ""
read -p "Enter your Firebase Project ID: " PROJECT_ID

if [ -z "$PROJECT_ID" ]; then
    echo -e "${RED}❌ Project ID cannot be empty${NC}"
    exit 1
fi

# Set the project
echo -e "${BLUE}🎯 Setting Firebase project to: $PROJECT_ID${NC}"
firebase use "$PROJECT_ID"

# Check if firestore.rules exists
if [ ! -f "firestore.rules" ]; then
    echo -e "${RED}❌ firestore.rules file not found${NC}"
    echo "Please ensure you're running this script from the project root directory"
    exit 1
fi

# Deploy the rules
echo -e "${BLUE}🚀 Deploying Firestore security rules...${NC}"
if firebase deploy --only firestore:rules; then
    echo -e "${GREEN}✅ Firestore rules deployed successfully!${NC}"
else
    echo -e "${RED}❌ Failed to deploy rules${NC}"
    exit 1
fi

# Verify deployment
echo -e "${BLUE}🔍 Verifying rules deployment...${NC}"
if firebase firestore:rules:get &> /dev/null; then
    echo -e "${GREEN}✅ Rules verification successful${NC}"
else
    echo -e "${YELLOW}⚠️  Could not verify rules deployment${NC}"
fi

echo ""
echo -e "${GREEN}🎉 Permission fix complete!${NC}"
echo ""
echo -e "${BLUE}📋 What was fixed:${NC}"
echo "• Enhanced user roles (admin, owner, manager, cashier, seller)"
echo "• Pharmacy-specific collections (products, prescriptions, customers)"
echo "• Real-time sales data subscriptions"
echo "• Multi-branch support"
echo "• Comprehensive security rules"
echo ""

echo -e "${YELLOW}⚡ Next Steps:${NC}"
echo "1. Refresh your pharmacy management application"
echo "2. Test POS system functionality"
echo "3. Verify inventory management works"
echo "4. Check that sales data loads properly"
echo ""

echo -e "${BLUE}🏥 Supported Features:${NC}"
echo "• Point of Sale (POS) system"
echo "• Inventory & Product Management"
echo "• Prescription tracking"
echo "• Customer management"
echo "• Sales reports & analytics"
echo "• Multi-branch operations"
echo "• Insurance claim processing"
echo ""

echo -e "${GREEN}✅ Your pharmacy management system should now work without permission errors!${NC}"

# Optional: Test basic connectivity
read -p "Would you like to test basic Firestore connectivity? (y/n): " TEST_CHOICE

if [ "$TEST_CHOICE" = "y" ] || [ "$TEST_CHOICE" = "Y" ]; then
    echo -e "${BLUE}🧪 Testing Firestore connectivity...${NC}"
    
    # Simple test using Firebase CLI
    if firebase firestore:data:get users --limit 1 &> /dev/null; then
        echo -e "${GREEN}✅ Firestore is accessible${NC}"
    else
        echo -e "${YELLOW}⚠️  Firestore test returned an error (this may be normal if no data exists yet)${NC}"
    fi
fi

echo ""
echo -e "${GREEN}🎊 Permission fix completed successfully!${NC}"
echo -e "${BLUE}Your pharmacy management system is ready to use.${NC}"