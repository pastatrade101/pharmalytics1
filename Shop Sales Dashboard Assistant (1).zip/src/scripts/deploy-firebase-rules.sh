#!/bin/bash

# Firebase Rules Deployment Script - COMPREHENSIVE FIX
# This script deploys Firestore security rules to fix permission errors

set -e  # Exit on any error

echo "🚀 URGENT: Deploying Firebase Security Rules..."
echo "=============================================="
echo "📅 $(date)"

# Check if Firebase CLI is installed
if ! command -v firebase &> /dev/null; then
    echo "❌ Firebase CLI not found. Installing now..."
    npm install -g firebase-tools
    if [ $? -ne 0 ]; then
        echo "❌ Failed to install Firebase CLI. Please install manually:"
        echo "   npm install -g firebase-tools"
        exit 1
    fi
fi

# Check if user is logged in
echo "🔍 Checking Firebase authentication..."
if ! firebase projects:list &> /dev/null; then
    echo "🔑 Please login to Firebase..."
    firebase login
    if [ $? -ne 0 ]; then
        echo "❌ Firebase login failed. Please try again."
        exit 1
    fi
fi

# Show current project
echo "📍 Current Firebase project:"
firebase use
echo ""

# Verify firestore.rules exists
if [ ! -f "firestore.rules" ]; then
    echo "❌ ERROR: firestore.rules file not found!"
    echo "Please ensure you're in the correct project directory."
    exit 1
fi

echo "📋 Found firestore.rules file - checking content..."
RULES_SIZE=$(wc -l < firestore.rules)
echo "Rules file contains $RULES_SIZE lines"

if [ $RULES_SIZE -lt 10 ]; then
    echo "⚠️ WARNING: Rules file seems too small. Content preview:"
    head -n 5 firestore.rules
    echo ""
fi

# Deploy Firestore rules
echo "🔄 Deploying Firestore security rules..."
echo "This will fix your permission errors..."
firebase deploy --only firestore:rules

# Check deployment status
if [ $? -eq 0 ]; then
    echo ""
    echo "✅ SUCCESS! Firebase rules deployed successfully!"
    echo "🎉 Your pharmacy import system should now work!"
    echo ""
    echo "📋 VERIFICATION STEPS:"
    echo "1. ✅ Refresh your web application"
    echo "2. ✅ Try the 'Run Tests' button in the permission tester"
    echo "3. ✅ Try importing products again"
    echo "4. ✅ Verify your user role is 'manager', 'owner', or 'admin'"
    echo ""
    
    # Verify deployment
    echo "🔍 Verifying deployment..."
    firebase firestore:rules:get > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo "✅ Rules verification successful"
    else
        echo "⚠️ Could not verify rules deployment"
    fi
    
    echo ""
    echo "🏥 Your pharmacy system is now ready!"
    
else
    echo ""
    echo "❌ FAILED to deploy Firebase rules"
    echo ""
    echo "🔧 TROUBLESHOOTING STEPS:"
    echo "1. Check you're in the correct project directory (should contain firestore.rules)"
    echo "2. Verify Firebase project selection:"
    echo "   firebase projects:list"
    echo "   firebase use your-project-id"
    echo "3. Check firestore.rules file exists and has content"
    echo "4. Try manual deployment:"
    echo "   firebase deploy --only firestore:rules --debug"
    echo ""
    echo "📞 If issues persist:"
    echo "   - Check Firebase Console: https://console.firebase.google.com"
    echo "   - Verify project permissions"
    echo "   - See URGENT_FIREBASE_FIX.md for detailed troubleshooting"
    
    exit 1
fi

echo ""
echo "================================================"
echo "🚀 DEPLOYMENT COMPLETE - Test your app now!"
echo "================================================"