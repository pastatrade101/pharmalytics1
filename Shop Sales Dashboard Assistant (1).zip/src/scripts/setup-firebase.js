#!/usr/bin/env node

/**
 * Firebase Setup Script for Shop Sales Dashboard
 * 
 * This script helps set up Firebase services and initial configuration
 * Run with: node scripts/setup-firebase.js
 */

const fs = require('fs');
const path = require('path');

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
};

function log(message, color = colors.reset) {
  console.log(`${color}${message}${colors.reset}`);
}

function logSuccess(message) {
  log(`✅ ${message}`, colors.green);
}

function logWarning(message) {
  log(`⚠️  ${message}`, colors.yellow);
}

function logError(message) {
  log(`❌ ${message}`, colors.red);
}

function logInfo(message) {
  log(`ℹ️  ${message}`, colors.blue);
}

function logStep(message) {
  log(`🔄 ${message}`, colors.cyan);
}

// Check if .env.local exists
function checkEnvironmentFile() {
  logStep('Checking environment configuration...');
  
  const envLocalPath = path.join(process.cwd(), '.env.local');
  const envExamplePath = path.join(process.cwd(), '.env.example');
  
  if (!fs.existsSync(envLocalPath)) {
    if (fs.existsSync(envExamplePath)) {
      logWarning('.env.local not found. Please copy .env.example to .env.local');
      logInfo('Run: cp .env.example .env.local');
      return false;
    } else {
      logError('Neither .env.local nor .env.example found!');
      return false;
    }
  }
  
  logSuccess('.env.local found');
  return true;
}

// Check required environment variables
function checkRequiredEnvVars() {
  logStep('Checking required environment variables...');
  
  const requiredVars = [
    'NEXT_PUBLIC_FIREBASE_API_KEY',
    'NEXT_PUBLIC_FIREBASE_PROJECT_ID',
    'NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN',
    'NEXT_PUBLIC_GEMINI_API_KEY',
  ];
  
  const missingVars = [];
  
  // Load environment variables from .env.local
  const envLocalPath = path.join(process.cwd(), '.env.local');
  if (fs.existsSync(envLocalPath)) {
    const envContent = fs.readFileSync(envLocalPath, 'utf8');
    const envLines = envContent.split('\n');
    const envVars = {};
    
    envLines.forEach(line => {
      const [key, value] = line.split('=');
      if (key && value && !key.startsWith('#')) {
        envVars[key.trim()] = value.trim();
      }
    });
    
    requiredVars.forEach(varName => {
      if (!envVars[varName] || envVars[varName].includes('your_') || envVars[varName].includes('_here')) {
        missingVars.push(varName);
      }
    });
  }
  
  if (missingVars.length > 0) {
    logError('Missing or incomplete environment variables:');
    missingVars.forEach(varName => {
      log(`  - ${varName}`, colors.red);
    });
    return false;
  }
  
  logSuccess('All required environment variables are configured');
  return true;
}

// Check Firebase CLI installation
function checkFirebaseCLI() {
  logStep('Checking Firebase CLI...');
  
  try {
    const { execSync } = require('child_process');
    execSync('firebase --version', { stdio: 'ignore' });
    logSuccess('Firebase CLI is installed');
    return true;
  } catch (error) {
    logWarning('Firebase CLI not found');
    logInfo('Install with: npm install -g firebase-tools');
    return false;
  }
}

// Check Firebase login status
function checkFirebaseLogin() {
  logStep('Checking Firebase authentication...');
  
  try {
    const { execSync } = require('child_process');
    execSync('firebase projects:list', { stdio: 'ignore' });
    logSuccess('Firebase CLI is authenticated');
    return true;
  } catch (error) {
    logWarning('Firebase CLI not authenticated');
    logInfo('Run: firebase login');
    return false;
  }
}

// Generate Firestore security rules
function generateFirestoreRules() {
  logStep('Checking Firestore security rules...');
  
  const rulesPath = path.join(process.cwd(), 'firestore.rules');
  
  if (!fs.existsSync(rulesPath)) {
    logWarning('firestore.rules not found, creating...');
    
    const rulesContent = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users can read/write their own profile
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Shop-based access control
    match /shops/{shopId} {
      allow read, write: if request.auth != null && 
        exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.shop_id == shopId;
    }
    
    // Sales records - shop-based access
    match /sales/{saleId} {
      allow read, write: if request.auth != null && 
        exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
        resource.data.shop_id == get(/databases/$(database)/documents/users/$(request.auth.uid)).data.shop_id;
    }
    
    // Products - shop-based access
    match /products/{productId} {
      allow read, write: if request.auth != null && 
        exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
        resource.data.shop_id == get(/databases/$(database)/documents/users/$(request.auth.uid)).data.shop_id;
    }
    
    // Reports - shop-based access
    match /reports/{reportId} {
      allow read, write: if request.auth != null && 
        exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
        resource.data.shop_id == get(/databases/$(database)/documents/users/$(request.auth.uid)).data.shop_id;
    }
  }
}`;
    
    fs.writeFileSync(rulesPath, rulesContent);
    logSuccess('firestore.rules created');
  } else {
    logSuccess('firestore.rules already exists');
  }
  
  return true;
}

// Generate Firebase configuration file
function generateFirebaseConfig() {
  logStep('Checking firebase.json configuration...');
  
  const configPath = path.join(process.cwd(), 'firebase.json');
  
  if (!fs.existsSync(configPath)) {
    logWarning('firebase.json not found, creating...');
    
    const config = {
      firestore: {
        rules: 'firestore.rules',
        indexes: 'firestore.indexes.json'
      },
      hosting: {
        public: 'out',
        ignore: [
          'firebase.json',
          '**/.*',
          '**/node_modules/**'
        ],
        rewrites: [
          {
            source: '**',
            destination: '/index.html'
          }
        ]
      },
      emulators: {
        auth: {
          port: 9099
        },
        firestore: {
          port: 8080
        },
        hosting: {
          port: 5000
        },
        ui: {
          enabled: true
        }
      }
    };
    
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
    logSuccess('firebase.json created');
  } else {
    logSuccess('firebase.json already exists');
  }
  
  return true;
}

// Generate Firestore indexes file
function generateFirestoreIndexes() {
  logStep('Checking Firestore indexes...');
  
  const indexesPath = path.join(process.cwd(), 'firestore.indexes.json');
  
  if (!fs.existsSync(indexesPath)) {
    logWarning('firestore.indexes.json not found, creating...');
    
    const indexes = {
      indexes: [
        {
          collectionGroup: 'sales',
          queryScope: 'COLLECTION',
          fields: [
            { fieldPath: 'shop_id', order: 'ASCENDING' },
            { fieldPath: 'date', order: 'DESCENDING' }
          ]
        },
        {
          collectionGroup: 'sales',
          queryScope: 'COLLECTION',
          fields: [
            { fieldPath: 'shop_id', order: 'ASCENDING' },
            { fieldPath: 'seller_id', order: 'ASCENDING' },
            { fieldPath: 'date', order: 'DESCENDING' }
          ]
        },
        {
          collectionGroup: 'products',
          queryScope: 'COLLECTION',
          fields: [
            { fieldPath: 'shop_id', order: 'ASCENDING' },
            { fieldPath: 'category', order: 'ASCENDING' }
          ]
        },
        {
          collectionGroup: 'products',
          queryScope: 'COLLECTION',
          fields: [
            { fieldPath: 'shop_id', order: 'ASCENDING' },
            { fieldPath: 'status', order: 'ASCENDING' }
          ]
        },
        {
          collectionGroup: 'users',
          queryScope: 'COLLECTION',
          fields: [
            { fieldPath: 'shop_id', order: 'ASCENDING' },
            { fieldPath: 'role', order: 'ASCENDING' }
          ]
        }
      ]
    };
    
    fs.writeFileSync(indexesPath, JSON.stringify(indexes, null, 2));
    logSuccess('firestore.indexes.json created');
  } else {
    logSuccess('firestore.indexes.json already exists');
  }
  
  return true;
}

// Main setup function
async function runSetup() {
  log('\n' + '='.repeat(50), colors.bright);
  log('🚀 SHOP SALES DASHBOARD - FIREBASE SETUP', colors.bright);
  log('='.repeat(50) + '\n', colors.bright);
  
  let allGood = true;
  
  // Check environment
  if (!checkEnvironmentFile()) allGood = false;
  if (!checkRequiredEnvVars()) allGood = false;
  
  // Check Firebase CLI
  const hasFirebaseCLI = checkFirebaseCLI();
  const isLoggedIn = hasFirebaseCLI ? checkFirebaseLogin() : false;
  
  // Generate configuration files
  generateFirestoreRules();
  generateFirebaseConfig();
  generateFirestoreIndexes();
  
  // Summary
  log('\n' + '='.repeat(50), colors.bright);
  log('📋 SETUP SUMMARY', colors.bright);
  log('='.repeat(50), colors.bright);
  
  if (allGood && hasFirebaseCLI && isLoggedIn) {
    logSuccess('✅ All checks passed! Your Firebase setup is ready.');
    
    log('\n📝 NEXT STEPS:', colors.bright);
    log('1. Deploy Firestore rules: firebase deploy --only firestore:rules', colors.cyan);
    log('2. Deploy Firestore indexes: firebase deploy --only firestore:indexes', colors.cyan);
    log('3. Start development server: npm run dev', colors.cyan);
    
  } else {
    logWarning('⚠️  Setup incomplete. Please address the issues above.');
    
    log('\n📝 TODO:', colors.bright);
    if (!allGood) {
      log('• Configure environment variables in .env.local', colors.yellow);
    }
    if (!hasFirebaseCLI) {
      log('• Install Firebase CLI: npm install -g firebase-tools', colors.yellow);
    }
    if (hasFirebaseCLI && !isLoggedIn) {
      log('• Login to Firebase: firebase login', colors.yellow);
    }
  }
  
  log('\n📚 DOCUMENTATION:', colors.bright);
  log('• Setup Guide: LOCAL_SETUP_GUIDE.md', colors.blue);
  log('• Firebase Rules: FIRESTORE_RULES_DEPLOYMENT_GUIDE.md', colors.blue);
  log('• Troubleshooting: README.md', colors.blue);
  
  log('\n🆘 SUPPORT:', colors.bright);
  log('If you encounter issues, check the project documentation', colors.blue);
  log('or review the debug logs in the browser console.\n', colors.blue);
}

// Run the setup
runSetup().catch(error => {
  logError('Setup failed:', error.message);
  process.exit(1);
});