#!/usr/bin/env node

/**
 * Super Admin Permissions Test Script
 * 
 * This script helps verify that the super admin permissions are working correctly
 * after deploying the updated Firestore rules.
 */

const admin = require('firebase-admin');
const readline = require('readline');

// Colors for console output
const colors = {
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  reset: '\x1b[0m',
  bold: '\x1b[1m'
};

function log(color, message) {
  console.log(`${color}${message}${colors.reset}`);
}

function logSuccess(message) {
  log(colors.green, `✅ ${message}`);
}

function logError(message) {
  log(colors.red, `❌ ${message}`);
}

function logWarning(message) {
  log(colors.yellow, `⚠️  ${message}`);
}

function logInfo(message) {
  log(colors.blue, `ℹ️  ${message}`);
}

function logHeader(message) {
  log(colors.bold + colors.cyan, `\n🛡️  ${message}`);
  log(colors.cyan, '='.repeat(message.length + 4));
}

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function askQuestion(question) {
  return new Promise((resolve) => {
    rl.question(question, resolve);
  });
}

async function initializeFirebase() {
  try {
    // Check if Firebase is already initialized
    if (admin.apps.length === 0) {
      // Try to initialize with default credentials
      admin.initializeApp({
        credential: admin.credential.applicationDefault()
      });
    }
    
    logSuccess('Firebase Admin SDK initialized');
    return admin.firestore();
  } catch (error) {
    logError('Failed to initialize Firebase Admin SDK');
    logError('Make sure you have:');
    console.log('  1. Firebase CLI installed: npm install -g firebase-tools');
    console.log('  2. Logged in: firebase login');
    console.log('  3. Service account key or default credentials set up');
    throw error;
  }
}

async function testSuperAdminPermissions(db) {
  logHeader('TESTING SUPER ADMIN PERMISSIONS');
  
  const testResults = {
    shops: false,
    profiles: false,
    sales: false,
    products: false,
    systemSettings: false
  };
  
  try {
    // Test 1: Can read all shops
    logInfo('Testing access to shops collection...');
    const shopsSnapshot = await db.collection('shops').limit(1).get();
    testResults.shops = true;
    logSuccess(`Can read shops collection (${shopsSnapshot.size} shops found)`);
  } catch (error) {
    logError('Cannot read shops collection');
    console.log(`   Error: ${error.message}`);
  }
  
  try {
    // Test 2: Can read all user profiles
    logInfo('Testing access to profiles collection...');
    const profilesSnapshot = await db.collection('profiles').limit(1).get();
    testResults.profiles = true;
    logSuccess(`Can read profiles collection (${profilesSnapshot.size} profiles found)`);
  } catch (error) {
    logError('Cannot read profiles collection');
    console.log(`   Error: ${error.message}`);
  }
  
  try {
    // Test 3: Can read all sales
    logInfo('Testing access to sales collection...');
    const salesSnapshot = await db.collection('sales').limit(1).get();
    testResults.sales = true;
    logSuccess(`Can read sales collection (${salesSnapshot.size} sales found)`);
  } catch (error) {
    logError('Cannot read sales collection');
    console.log(`   Error: ${error.message}`);
  }
  
  try {
    // Test 4: Can read all products
    logInfo('Testing access to products collection...');
    const productsSnapshot = await db.collection('products').limit(1).get();
    testResults.products = true;
    logSuccess(`Can read products collection (${productsSnapshot.size} products found)`);
  } catch (error) {
    logError('Cannot read products collection');
    console.log(`   Error: ${error.message}`);
  }
  
  try {
    // Test 5: Can access system settings
    logInfo('Testing access to system_settings collection...');
    const settingsSnapshot = await db.collection('system_settings').limit(1).get();
    testResults.systemSettings = true;
    logSuccess(`Can read system_settings collection (${settingsSnapshot.size} settings found)`);
  } catch (error) {
    logError('Cannot read system_settings collection');
    console.log(`   Error: ${error.message}`);
  }
  
  return testResults;
}

async function generateTestSummary(testResults) {
  logHeader('TEST SUMMARY');
  
  const totalTests = Object.keys(testResults).length;
  const passedTests = Object.values(testResults).filter(Boolean).length;
  
  console.log(`\nTests passed: ${passedTests}/${totalTests}`);
  
  if (passedTests === totalTests) {
    logSuccess('All permission tests passed! 🎉');
    console.log('\n✅ Super Admin permissions are working correctly');
    console.log('✅ The Super Admin Dashboard should now load real data');
    console.log('✅ System-wide analytics and metrics should be available');
  } else {
    logWarning(`${totalTests - passedTests} test(s) failed`);
    console.log('\n🔧 Troubleshooting steps:');
    console.log('  1. Ensure Firestore rules have been deployed');
    console.log('  2. Check that the super_admin role is correctly set in user profiles');
    console.log('  3. Verify Firebase project configuration');
    console.log('  4. Run: firebase deploy --only firestore:rules');
  }
  
  console.log('\n📋 Detailed results:');
  Object.entries(testResults).forEach(([test, passed]) => {
    const status = passed ? colors.green + '✅' : colors.red + '❌';
    console.log(`  ${status} ${test}${colors.reset}`);
  });
}

async function main() {
  try {
    logHeader('SUPER ADMIN PERMISSIONS TESTER');
    console.log('This script tests if super admin permissions are working correctly\n');
    
    logWarning('IMPORTANT: This script uses Firebase Admin SDK');
    logWarning('Make sure you have appropriate credentials configured\n');
    
    const proceed = await askQuestion('Do you want to proceed with the test? (y/N): ');
    if (!proceed.toLowerCase().startsWith('y')) {
      console.log('Test cancelled.');
      rl.close();
      return;
    }
    
    const db = await initializeFirebase();
    const testResults = await testSuperAdminPermissions(db);
    await generateTestSummary(testResults);
    
  } catch (error) {
    logError('Test failed with error:');
    console.error(error.message);
    
    console.log('\n🔧 Common solutions:');
    console.log('  1. Run: firebase login');
    console.log('  2. Run: firebase deploy --only firestore:rules');
    console.log('  3. Check your Firebase project configuration');
    console.log('  4. Ensure service account credentials are set up');
  } finally {
    rl.close();
  }
}

// Run the script
if (require.main === module) {
  main().catch(console.error);
}

module.exports = {
  testSuperAdminPermissions,
  initializeFirebase
};