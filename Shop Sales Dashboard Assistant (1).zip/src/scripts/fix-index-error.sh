#!/bin/bash

# Quick Index Error Fix Script
# This script specifically deploys Firestore indexes to fix the Super Admin Dashboard

echo "🔧 Fixing Firestore Index Error for Super Admin Dashboard..."
echo "==========================================================="

# Check if Firebase CLI is installed
if ! command -v firebase &> /dev/null; then
    echo "❌ Firebase CLI is not installed!"
    echo "Please install it: npm install -g firebase-tools"
    exit 1
fi

# Check if user is logged in
if ! firebase projects:list &> /dev/null; then
    echo "❌ You are not logged in to Firebase!"
    echo "Please run: firebase login"
    exit 1
fi

# Check if indexes file exists
if [ ! -f "firestore.indexes.json" ]; then
    echo "❌ firestore.indexes.json not found!"
    echo "Please ensure the indexes file exists in your project root."
    exit 1
fi

echo "📋 Quick fix for index error..."
echo "✅ Firebase CLI available"
echo "✅ User logged in"
echo "✅ Indexes file found"
echo ""

# Show current project
echo "🎯 Current Firebase project:"
firebase use --current
echo ""

echo "🔧 This will deploy Firestore indexes to fix the error:"
echo "❌ Error getting all shops: [code=failed-precondition]: The query requires an index"
echo ""

echo "📊 Indexes that will be created:"
echo "  ✅ shops: status + created_at (for Super Admin Dashboard)"
echo "  ✅ shops: owner_id + created_at (for pharmacy queries)"
echo "  ✅ products: shop_id + name (for product searches)"
echo "  ✅ sales: shop_id + timestamp (for analytics)"
echo "  ✅ profiles: shop_id + role (for user management)"
echo ""

read -p "Deploy Firestore indexes to fix the error? (y/N): " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ Index deployment cancelled."
    echo ""
    echo "💡 Alternative: Click the link in your browser console error message"
    echo "   It will take you directly to create the required index."
    exit 1
fi

echo ""
echo "🚀 Deploying Firestore indexes..."
echo "================================="

# Deploy only indexes
if firebase deploy --only firestore:indexes; then
    echo ""
    echo "✅ SUCCESS: Firestore indexes deployed!"
    echo "======================================="
    echo ""
    echo "📊 Indexes created successfully:"
    echo "  ✅ Shops collection indexes"
    echo "  ✅ Products collection indexes"
    echo "  ✅ Sales collection indexes"
    echo "  ✅ Profiles collection indexes"
    echo ""
    echo "⏱️  Index building status:"
    echo "  • Indexes are now being built in the background"
    echo "  • This process typically takes 1-5 minutes"
    echo "  • You can check status in Firebase Console"
    echo ""
    echo "🔄 Next steps:"
    echo "  1. Wait 1-2 minutes for indexes to build"
    echo "  2. Refresh your Super Admin Dashboard"
    echo "  3. The error should be resolved"
    echo ""
    echo "🔍 To check index status:"
    echo "  firebase firestore:indexes:list"
    echo ""
    echo "🌐 Or visit Firebase Console:"
    echo "  https://console.firebase.google.com/project/shopsalesai/firestore/indexes"
    echo ""
else
    echo ""
    echo "❌ FAILED: Index deployment failed!"
    echo "===================================="
    echo ""
    echo "🔧 Alternative solutions:"
    echo "  1. Click the error link in your browser console"
    echo "  2. Manually create the index in Firebase Console"
    echo "  3. Check your Firebase project permissions"
    echo ""
    echo "🌐 Direct link to create index:"
    echo "  https://console.firebase.google.com/project/shopsalesai/firestore/indexes"
    echo ""
    echo "💡 Manual index creation:"
    echo "  Collection: shops"
    echo "  Field 1: status (Ascending)"
    echo "  Field 2: created_at (Descending)"
    echo ""
    exit 1
fi

echo "🎉 Index deployment complete!"
echo ""
echo "⚠️  Important notes:"
echo "  • Indexes need time to build (1-5 minutes)"
echo "  • Refresh your dashboard after waiting"
echo "  • Check Firebase Console for build status"
echo ""
echo "✨ Your Super Admin Dashboard index error should be fixed!"