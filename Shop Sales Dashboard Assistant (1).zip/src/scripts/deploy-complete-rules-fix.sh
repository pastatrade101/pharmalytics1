#!/bin/bash

# Complete Firebase Rules Fix Deployment Script
# This script deploys the corrected Firebase rules to fix all permission errors
# Usage: chmod +x scripts/deploy-complete-rules-fix.sh && ./scripts/deploy-complete-rules-fix.sh

echo "🚨 COMPLETE FIREBASE RULES FIX DEPLOYMENT"
echo "=========================================="
echo "Fixing ALL permission-denied errors in pharmacy management system"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check if firebase CLI is installed
if ! command -v firebase &> /dev/null; then
    echo -e "${RED}❌ Firebase CLI not found${NC}"
    echo "Installing Firebase CLI..."
    npm install -g firebase-tools
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Failed to install Firebase CLI${NC}"
        echo "Please install manually: npm install -g firebase-tools"
        exit 1
    fi
fi

echo -e "${BLUE}📋 Pre-deployment checks...${NC}"

# Check if we're in a Firebase project
if [ ! -f "firebase.json" ]; then
    echo -e "${RED}❌ firebase.json not found${NC}"
    echo "Please run this script from your Firebase project root directory"
    exit 1
fi

echo -e "${GREEN}✅ Firebase project structure verified${NC}"

# Check Firebase login status
echo -e "${BLUE}🔐 Checking Firebase authentication...${NC}"
if ! firebase projects:list &> /dev/null; then
    echo -e "${YELLOW}⚠️ Not logged in to Firebase${NC}"
    echo "Logging in to Firebase..."
    firebase login
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Firebase login failed${NC}"
        exit 1
    fi
fi

echo -e "${GREEN}✅ Firebase authentication verified${NC}"

# Show current project
CURRENT_PROJECT=$(firebase use --current 2>/dev/null || echo "No project selected")
echo -e "${BLUE}📊 Current Firebase project: ${YELLOW}${CURRENT_PROJECT}${NC}"

if [ "$CURRENT_PROJECT" = "No project selected" ]; then
    echo -e "${RED}❌ No Firebase project selected${NC}"
    echo "Setting project to shopsalesai..."
    firebase use shopsalesai
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Failed to set Firebase project${NC}"
        echo "Please run: firebase use shopsalesai"
        exit 1
    fi
fi

# Create backup of current rules
echo -e "${BLUE}💾 Creating rules backup...${NC}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="firestore.rules.backup.${TIMESTAMP}"

if [ -f "firestore.rules" ] && cp firestore.rules "$BACKUP_FILE" 2>/dev/null; then
    echo -e "${GREEN}✅ Rules backed up to: ${BACKUP_FILE}${NC}"
else
    echo -e "${YELLOW}⚠️ Could not create backup (continuing anyway)${NC}"
fi

# Deploy the complete fixed rules
echo ""
echo -e "${BLUE}🚀 Deploying COMPLETE Firebase Rules Fix...${NC}"
echo -e "${BLUE}   ▸ Fixing user profile access${NC}"
echo -e "${BLUE}   ▸ Fixing user management permissions${NC}"
echo -e "${BLUE}   ▸ Fixing pharmacy creation and access${NC}"
echo -e "${BLUE}   ▸ Fixing shop owner permissions${NC}"
echo ""

if firebase deploy --only firestore:rules; then
    echo ""
    echo -e "${GREEN}🎉 SUCCESS: Firebase rules deployed successfully!${NC}"
    echo ""
    echo -e "${BLUE}📋 All Permission Errors Fixed:${NC}"
    echo -e "${GREEN}   ✅ User profile access restored${NC}"
    echo -e "${GREEN}   ✅ User management functionality enabled${NC}"
    echo -e "${GREEN}   ✅ Pharmacy creation and access fixed${NC}"
    echo -e "${GREEN}   ✅ Shop owner permissions corrected${NC}"
    echo ""
    echo -e "${BLUE}🔄 Next steps:${NC}"
    echo "   1. Refresh your pharmacy management application (Ctrl+Shift+R)"
    echo "   2. Sign out and sign back in to refresh permissions"
    echo "   3. Test user management and pharmacy creation"
    echo "   4. All features should now work without permission errors"
    echo ""
    echo -e "${GREEN}✅ Your pharmacy management system is now fully functional!${NC}"
else
    echo ""
    echo -e "${RED}❌ FAILED: Rules deployment failed${NC}"
    echo ""
    echo -e "${YELLOW}🔧 Manual deployment steps:${NC}"
    echo "   1. Go to: https://console.firebase.google.com/project/shopsalesai/firestore/rules"
    echo "   2. Copy the complete rules from COMPLETE_FIREBASE_RULES_FIX.md"
    echo "   3. Replace ALL existing rules in the Firebase console"
    echo "   4. Click 'Publish' and wait for confirmation"
    echo "   5. Refresh your application"
    echo ""
    echo -e "${YELLOW}🔍 Common deployment issues:${NC}"
    echo "   • Check your firestore.rules file for syntax errors"
    echo "   • Verify you have proper permissions on the Firebase project"
    echo "   • Ensure you're connected to the internet"
    echo "   • Try running: firebase login --reauth"
    echo ""
    exit 1
fi

# Verify deployment
echo -e "${BLUE}🔍 Verifying deployment...${NC}"
sleep 3

if firebase firestore:rules:get > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Rules deployment verified successfully${NC}"
else
    echo -e "${YELLOW}⚠️ Could not verify deployment (may still be working)${NC}"
fi

echo ""
echo -e "${GREEN}🏁 COMPLETE RULES FIX DEPLOYMENT FINISHED!${NC}"
echo ""
echo -e "${BLUE}📞 If you're still experiencing issues:${NC}"
echo "   1. Wait 1-2 minutes for rules to propagate globally"
echo "   2. Clear browser cache and refresh your application"
echo "   3. Sign out and sign back in to refresh user permissions"
echo "   4. Check browser console for any remaining permission errors"
echo ""
echo -e "${BLUE}📋 Files created during this process:${NC}"
if [ -f "$BACKUP_FILE" ]; then
    echo "   • Backup: $BACKUP_FILE (your original rules)"
fi
echo "   • Applied: Complete Firebase rules fix"
echo ""
echo -e "${GREEN}🎉 Your pharmacy management system should now work perfectly!${NC}"