#!/bin/bash

# COMPLETE Emergency Firebase Fix - Rules + Indexes
# This script fixes both permission and index issues

set -e  # Exit on any error

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${RED}🚨 COMPLETE EMERGENCY FIREBASE FIX${NC}"
echo -e "${RED}=================================${NC}"
echo -e "${YELLOW}⚠️  Fixing permissions AND indexes${NC}"
echo -e "${BLUE}📅 $(date)${NC}"
echo ""

# Check Firebase CLI
if ! command -v firebase &> /dev/null; then
    echo -e "${RED}❌ Installing Firebase CLI...${NC}"
    npm install -g firebase-tools
fi

# Check login
echo -e "${BLUE}🔐 Checking Firebase authentication...${NC}"
if ! firebase projects:list &> /dev/null; then
    echo -e "${RED}❌ Please login to Firebase:${NC}"
    firebase login --reauth
fi

echo -e "${BLUE}📋 Current project:${NC}"
firebase use --current

# Backup existing files
BACKUP_TIME=$(date +"%Y%m%d_%H%M%S")
echo -e "${BLUE}📦 Creating backups...${NC}"

if [ -f "firestore.rules" ]; then
    cp firestore.rules "firestore.rules.backup.${BACKUP_TIME}"
fi

if [ -f "firestore.indexes.json" ]; then
    cp firestore.indexes.json "firestore.indexes.json.backup.${BACKUP_TIME}"
fi

# Fix indexes first
echo -e "${BLUE}🔧 Updating Firestore indexes...${NC}"
if [ -f "firestore.indexes.json.fixed" ]; then
    cp firestore.indexes.json.fixed firestore.indexes.json
    echo -e "${GREEN}✅ Indexes updated${NC}"
else
    echo -e "${YELLOW}⚠️ Fixed indexes file not found, skipping index update${NC}"
fi

# Deploy emergency rules
echo -e "${BLUE}🚀 Deploying emergency permission rules...${NC}"
if [ -f "firestore.emergency.rules" ]; then
    cp firestore.emergency.rules firestore.rules
else
    echo -e "${RED}❌ Emergency rules file not found!${NC}"
    echo -e "${YELLOW}Creating emergency rules...${NC}"
    cat > firestore.rules << 'EOF'
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
EOF
fi

# Deploy everything
echo -e "${BLUE}🔄 Deploying to Firebase...${NC}"
firebase deploy --only firestore

# Check deployment
if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✅ COMPLETE EMERGENCY FIX DEPLOYED!${NC}"
    echo -e "${GREEN}🎉 Your pharmacy system is restored!${NC}"
    echo ""
    echo -e "${BLUE}📋 VERIFICATION STEPS:${NC}"
    echo "1. ✅ Hard refresh browser (Ctrl+F5)"
    echo "2. ✅ Clear cache and cookies"
    echo "3. ✅ Sign out and sign back in"
    echo "4. ✅ Test adding users (should not cause logout)"
    echo "5. ✅ Verify all data loads properly"
    echo ""
    echo -e "${BLUE}🔍 CHECK FOR SUCCESS:${NC}"
    echo "- No permission errors in browser console"
    echo "- Products, sales, users all accessible"
    echo "- Adding users works without logout"
    echo "- All dashboard widgets load data"
    echo ""
    echo -e "${YELLOW}⚠️ SECURITY NOTE:${NC}"
    echo -e "${YELLOW}Emergency rules allow full access to authenticated users.${NC}"
    echo -e "${YELLOW}Deploy improved rules later: cp firestore.rules.fixed firestore.rules${NC}"
    echo ""
    echo -e "${GREEN}🏥 EMERGENCY FIX COMPLETE - Test your system now!${NC}"
else
    echo ""
    echo -e "${RED}❌ DEPLOYMENT FAILED!${NC}"
    echo ""
    echo -e "${YELLOW}🔧 MANUAL FIX STEPS:${NC}"
    echo "1. Open Firebase Console: https://console.firebase.google.com"
    echo "2. Go to Firestore Database > Rules"
    echo "3. Replace with these emergency rules:"
    echo ""
    echo "rules_version = '2';"
    echo "service cloud.firestore {"
    echo "  match /databases/{database}/documents {"
    echo "    match /{document=**} {"
    echo "      allow read, write: if request.auth != null;"
    echo "    }"
    echo "  }"
    echo "}"
    echo ""
    echo "4. Click Publish and wait for confirmation"
    exit 1
fi