#!/usr/bin/env node

/**
 * Super Admin Deployment Verification Script
 * 
 * This script verifies that the super admin rules have been properly deployed
 * and that the necessary permissions are working correctly.
 */

const readline = require('readline');

// Colors for console output
const colors = {
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  reset: '\x1b[0m',
  bold: '\x1b[1m'
};

function log(color, message) {
  console.log(`${color}${message}${colors.reset}`);
}

function logSuccess(message) {
  log(colors.green, `✅ ${message}`);
}

function logError(message) {
  log(colors.red, `❌ ${message}`);
}

function logWarning(message) {
  log(colors.yellow, `⚠️  ${message}`);
}

function logInfo(message) {
  log(colors.blue, `ℹ️  ${message}`);
}

function logHeader(message) {
  log(colors.bold + colors.cyan, `\n🛡️  ${message}`);
  log(colors.cyan, '='.repeat(message.length + 4));
}

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function askQuestion(question) {
  return new Promise((resolve) => {
    rl.question(question, resolve);
  });
}

async function checkFirebaseRulesDeployment() {
  logHeader('VERIFYING SUPER ADMIN RULES DEPLOYMENT');
  
  try {
    // Check if Firebase CLI is available
    const { exec } = require('child_process');
    const { promisify } = require('util');
    const execAsync = promisify(exec);
    
    logInfo('Checking Firebase CLI availability...');
    
    try {
      await execAsync('firebase --version');
      logSuccess('Firebase CLI is available');
    } catch (error) {
      logError('Firebase CLI not found');
      console.log('Please install Firebase CLI: npm install -g firebase-tools');
      return false;
    }
    
    // Check current project
    logInfo('Checking current Firebase project...');
    
    try {
      const { stdout } = await execAsync('firebase use --current');
      const project = stdout.trim();
      logSuccess(`Current project: ${project}`);
    } catch (error) {
      logError('No Firebase project selected');
      console.log('Please run: firebase use [project-id]');
      return false;
    }
    
    // Get current rules
    logInfo('Fetching current Firestore rules...');
    
    try {
      const { stdout } = await execAsync('firebase firestore:rules:get');
      const rules = stdout;
      
      // Check for super admin functions
      const checks = [
        {
          name: 'isSuperAdmin() function',
          pattern: /function isSuperAdmin\(\)/,
          found: rules.includes('function isSuperAdmin()')
        },
        {
          name: 'Enhanced isAdmin() function',
          pattern: /function isAdmin\(\)/,
          found: rules.includes('function isAdmin()')
        },
        {
          name: 'Super admin role in hasAnyRole',
          pattern: /super_admin/,
          found: rules.includes('super_admin')
        },
        {
          name: 'System metrics collection',
          pattern: /system_metrics/,
          found: rules.includes('system_metrics')
        },
        {
          name: 'Global settings collection', 
          pattern: /global_settings/,
          found: rules.includes('global_settings')
        }
      ];
      
      let allChecksPass = true;
      
      console.log('\n📋 Rule validation results:');
      checks.forEach(check => {
        if (check.found) {
          logSuccess(check.name);
        } else {
          logError(check.name);
          allChecksPass = false;
        }
      });
      
      if (allChecksPass) {
        logSuccess('All super admin rules are properly deployed!');
        return true;
      } else {
        logError('Some super admin rules are missing');
        return false;
      }
      
    } catch (error) {
      logError('Failed to fetch Firestore rules');
      console.log('Error:', error.message);
      return false;
    }
    
  } catch (error) {
    logError('Failed to verify deployment');
    console.log('Error:', error.message);
    return false;
  }
}

async function checkSuperAdminUserSetup() {
  logHeader('SUPER ADMIN USER SETUP GUIDE');
  
  console.log('\n📋 To complete super admin setup:');
  console.log('\n🔧 Option 1: Create new super admin account');
  console.log('  1. Go to Super Admin Portal in your app');
  console.log('  2. Click "Create Super Admin Account"');
  console.log('  3. Use email ending with @pharmacyms.com');
  console.log('  4. Enter access code: PHARMACY_MS_OWNER_2024');
  
  console.log('\n🔧 Option 2: Convert existing account');
  console.log('  1. Go to Firebase Console');
  console.log('  2. Navigate to Firestore Database');
  console.log('  3. Find your user in "profiles" collection');
  console.log('  4. Change "role" field to "super_admin"');
  console.log('  5. Set "shop_id" field to null');
  
  console.log('\n✅ Expected results after setup:');
  console.log('  • Super Admin Dashboard loads without errors');
  console.log('  • Real pharmacy data displays (not mock data)');
  console.log('  • System metrics show actual numbers');
  console.log('  • Pharmacy management table shows real pharmacies');
  console.log('  • No permission-denied errors in browser console');
}

async function generateSummaryReport(rulesDeployed) {
  logHeader('DEPLOYMENT SUMMARY REPORT');
  
  if (rulesDeployed) {
    logSuccess('Firebase rules deployment verification PASSED');
    console.log('\n🎉 Your super admin rules are properly deployed!');
    console.log('\n📋 What this means:');
    console.log('  ✅ Super admin role is recognized by Firebase');
    console.log('  ✅ System-wide data access is enabled');
    console.log('  ✅ Cross-pharmacy analytics are available');
    console.log('  ✅ Global system management is accessible');
    
    console.log('\n🔄 Next steps:');
    console.log('  1. Ensure your user account has super_admin role');
    console.log('  2. Sign in to the Super Admin Dashboard');
    console.log('  3. Verify real data is loading');
    console.log('  4. Check system metrics and pharmacy table');
    
  } else {
    logWarning('Firebase rules deployment verification FAILED');
    console.log('\n🔧 Required actions:');
    console.log('  1. Deploy the rules: firebase deploy --only firestore:rules');
    console.log('  2. Run this verification script again');
    console.log('  3. Check for any syntax errors in firestore.rules');
    console.log('  4. Ensure you have proper Firebase project permissions');
  }
  
  console.log('\n📞 Need help?');
  console.log('  • Check browser console for specific error messages');
  console.log('  • Verify Firebase project configuration');
  console.log('  • Ensure firestore.rules file is up to date');
  console.log('  • Confirm your Firebase project permissions');
}

async function main() {
  try {
    logHeader('SUPER ADMIN DEPLOYMENT VERIFICATION');
    console.log('This script verifies that super admin rules are properly deployed\n');
    
    const proceed = await askQuestion('Do you want to verify the deployment? (y/N): ');
    if (!proceed.toLowerCase().startsWith('y')) {
      console.log('Verification cancelled.');
      rl.close();
      return;
    }
    
    const rulesDeployed = await checkFirebaseRulesDeployment();
    await checkSuperAdminUserSetup();
    await generateSummaryReport(rulesDeployed);
    
  } catch (error) {
    logError('Verification failed with error:');
    console.error(error.message);
    
    console.log('\n🔧 Common solutions:');
    console.log('  1. Run: firebase login');
    console.log('  2. Run: firebase deploy --only firestore:rules');
    console.log('  3. Check your Firebase project selection');
    console.log('  4. Verify firestore.rules file exists');
  } finally {
    rl.close();
  }
}

// Run the script
if (require.main === module) {
  main().catch(console.error);
}

module.exports = {
  checkFirebaseRulesDeployment,
  checkSuperAdminUserSetup
};