#!/bin/bash

# Firebase Rules Deployment Fix Script
# This script will deploy Firestore security rules to fix permission errors

set -e  # Exit on any error

echo "🚀 Firebase Rules Deployment Fix"
echo "================================"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check if firebase CLI is installed
if ! command -v firebase &> /dev/null; then
    echo -e "${RED}❌ Firebase CLI not found${NC}"
    echo "Please install Firebase CLI first:"
    echo "npm install -g firebase-tools"
    exit 1
fi

echo -e "${BLUE}📋 Pre-deployment checks...${NC}"

# Check if we're in a Firebase project
if [ ! -f "firebase.json" ]; then
    echo -e "${RED}❌ firebase.json not found${NC}"
    echo "Please run this script from your Firebase project root directory"
    exit 1
fi

# Check if firestore.rules exists
if [ ! -f "firestore.rules" ]; then
    echo -e "${RED}❌ firestore.rules file not found${NC}"
    echo "Please ensure firestore.rules file exists in project root"
    exit 1
fi

echo -e "${GREEN}✅ Firebase project structure verified${NC}"

# Check Firebase login status
echo -e "${BLUE}🔐 Checking Firebase authentication...${NC}"
if ! firebase projects:list &> /dev/null; then
    echo -e "${YELLOW}⚠️ Not logged in to Firebase${NC}"
    echo "Please login to Firebase first:"
    echo "firebase login"
    exit 1
fi

echo -e "${GREEN}✅ Firebase authentication verified${NC}"

# Show current project
CURRENT_PROJECT=$(firebase use --current 2>/dev/null || echo "No project selected")
echo -e "${BLUE}📊 Current Firebase project: ${YELLOW}${CURRENT_PROJECT}${NC}"

if [ "$CURRENT_PROJECT" = "No project selected" ]; then
    echo -e "${RED}❌ No Firebase project selected${NC}"
    echo "Please select a project first:"
    echo "firebase use <project-id>"
    exit 1
fi

# Confirm deployment
echo ""
echo -e "${YELLOW}⚠️ About to deploy Firestore security rules to: ${CURRENT_PROJECT}${NC}"
echo ""
read -p "Continue with deployment? (y/N): " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${YELLOW}❌ Deployment cancelled${NC}"
    exit 1
fi

# Backup current rules (if possible)
echo -e "${BLUE}💾 Creating rules backup...${NC}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="firestore.rules.backup.${TIMESTAMP}"

if cp firestore.rules "$BACKUP_FILE" 2>/dev/null; then
    echo -e "${GREEN}✅ Rules backed up to: ${BACKUP_FILE}${NC}"
else
    echo -e "${YELLOW}⚠️ Could not create backup (continuing anyway)${NC}"
fi

# Deploy rules
echo -e "${BLUE}🚀 Deploying Firestore security rules...${NC}"
echo ""

if firebase deploy --only firestore:rules; then
    echo ""
    echo -e "${GREEN}🎉 SUCCESS: Firestore rules deployed successfully!${NC}"
    echo ""
    echo -e "${BLUE}📋 Next steps:${NC}"
    echo "1. Refresh your web application"
    echo "2. Run the Firebase Permission Tester again"
    echo "3. Try importing products again"
    echo ""
    echo -e "${GREEN}✅ Permission errors should now be resolved${NC}"
else
    echo ""
    echo -e "${RED}❌ FAILED: Rules deployment failed${NC}"
    echo ""
    echo -e "${YELLOW}🔧 Troubleshooting steps:${NC}"
    echo "1. Check your firestore.rules file for syntax errors"
    echo "2. Verify you have proper permissions on the Firebase project"
    echo "3. Ensure you're connected to the internet"
    echo "4. Try running: firebase login --reauth"
    echo ""
    exit 1
fi

# Verify deployment
echo -e "${BLUE}🔍 Verifying deployment...${NC}"
sleep 2

if firebase firestore:rules:get > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Rules deployment verified successfully${NC}"
else
    echo -e "${YELLOW}⚠️ Could not verify deployment (may still be working)${NC}"
fi

echo ""
echo -e "${GREEN}🏁 Deployment complete!${NC}"
echo ""
echo "If you're still experiencing permission errors:"
echo "1. Wait 1-2 minutes for rules to propagate"
echo "2. Clear browser cache and refresh"
echo "3. Check the Firebase Permission Tester in your app"
echo ""
echo -e "${BLUE}📞 Need help? Check the troubleshooting guides:${NC}"
echo "- FIREBASE_PERMISSION_DEBUGGING.md"
echo "- FIREBASE_RULES_DEPLOYMENT_GUIDE.md"