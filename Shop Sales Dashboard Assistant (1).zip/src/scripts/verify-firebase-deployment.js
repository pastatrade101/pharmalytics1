#!/usr/bin/env node

/**
 * Firebase Deployment Verification Script
 * Verifies that Firestore security rules are properly deployed and working
 */

const admin = require('firebase-admin');
const fs = require('fs');
const path = require('path');

// Colors for console output
const colors = {
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  reset: '\x1b[0m',
  bold: '\x1b[1m'
};

function log(message, color = colors.reset) {
  console.log(`${color}${message}${colors.reset}`);
}

function logError(message) {
  log(`❌ ${message}`, colors.red);
}

function logSuccess(message) {
  log(`✅ ${message}`, colors.green);
}

function logWarning(message) {
  log(`⚠️ ${message}`, colors.yellow);
}

function logInfo(message) {
  log(`ℹ️ ${message}`, colors.blue);
}

async function verifyFirebaseDeployment() {
  log('\n🔍 Firebase Deployment Verification', colors.bold);
  log('=====================================\n');

  try {
    // Check if Firebase service account key exists
    const serviceAccountPath = path.join(process.cwd(), 'service-account-key.json');
    if (!fs.existsSync(serviceAccountPath)) {
      logWarning('Service account key not found locally');
      logInfo('This is normal for production deployments using environment variables');
    } else {
      logSuccess('Service account key found');
    }

    // Check if firebase.json exists
    const firebaseJsonPath = path.join(process.cwd(), 'firebase.json');
    if (!fs.existsSync(firebaseJsonPath)) {
      logError('firebase.json not found');
      logInfo('Please ensure you are in the Firebase project root directory');
      process.exit(1);
    } else {
      logSuccess('firebase.json found');
    }

    // Check if firestore.rules exists
    const rulesPath = path.join(process.cwd(), 'firestore.rules');
    if (!fs.existsSync(rulesPath)) {
      logError('firestore.rules file not found');
      logInfo('Please ensure firestore.rules file exists in project root');
      process.exit(1);
    } else {
      logSuccess('firestore.rules file found');
      
      // Check rules file size
      const rulesStats = fs.statSync(rulesPath);
      logInfo(`Rules file size: ${rulesStats.size} bytes`);
      
      if (rulesStats.size < 1000) {
        logWarning('Rules file seems small - may be incomplete');
      } else {
        logSuccess('Rules file has substantial content');
      }
    }

    // Read and validate firebase.json
    const firebaseConfig = JSON.parse(fs.readFileSync(firebaseJsonPath, 'utf8'));
    if (!firebaseConfig.firestore) {
      logError('Firestore configuration not found in firebase.json');
      process.exit(1);
    } else {
      logSuccess('Firestore configuration found in firebase.json');
      
      const rulesFile = firebaseConfig.firestore.rules;
      if (rulesFile !== 'firestore.rules') {
        logWarning(`Rules file configured as: ${rulesFile}`);
      } else {
        logSuccess('Rules file correctly configured');
      }
    }

    // Try to initialize Firebase Admin (for testing purposes)
    try {
      if (process.env.FIREBASE_PROJECT_ID) {
        logInfo(`Testing connection to project: ${process.env.FIREBASE_PROJECT_ID}`);
        
        // Initialize with minimal config for testing
        if (process.env.GOOGLE_APPLICATION_CREDENTIALS || fs.existsSync(serviceAccountPath)) {
          const app = admin.initializeApp({
            projectId: process.env.FIREBASE_PROJECT_ID,
            credential: admin.credential.applicationDefault()
          });
          
          // Test Firestore connection
          const db = admin.firestore(app);
          
          // Try to access a system collection
          try {
            await db.collection('system_settings').limit(1).get();
            logSuccess('Firestore connection successful');
          } catch (firestoreError) {
            if (firestoreError.code === 'permission-denied') {
              logWarning('Permission denied accessing Firestore (this may be expected)');
              logInfo('This could indicate rules are deployed but restrictive (which is good)');
            } else {
              logError(`Firestore connection failed: ${firestoreError.message}`);
            }
          }
          
          // Cleanup
          await app.delete();
        } else {
          logInfo('No credentials found for Firebase Admin testing');
          logInfo('This is normal for client-side only applications');
        }
      } else {
        logInfo('FIREBASE_PROJECT_ID not set - skipping connection test');
      }
    } catch (adminError) {
      logWarning(`Firebase Admin test failed: ${adminError.message}`);
      logInfo('This is normal if running in a client-only environment');
    }

    // Verify environment variables
    log('\n📋 Environment Variables Check:', colors.bold);
    const requiredEnvVars = [
      'NEXT_PUBLIC_FIREBASE_API_KEY',
      'NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN',
      'NEXT_PUBLIC_FIREBASE_PROJECT_ID',
      'NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET',
      'NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID',
      'NEXT_PUBLIC_FIREBASE_APP_ID'
    ];

    let envVarsValid = true;
    requiredEnvVars.forEach(envVar => {
      if (process.env[envVar]) {
        logSuccess(`${envVar} is set`);
      } else {
        logError(`${envVar} is missing`);
        envVarsValid = false;
      }
    });

    if (!envVarsValid) {
      logError('Some required environment variables are missing');
      logInfo('Please check your .env.local file');
    } else {
      logSuccess('All required environment variables are set');
    }

    // Check for common configuration issues
    log('\n🔧 Configuration Validation:', colors.bold);
    
    // Check if project ID matches in different places
    const projectIdFromEnv = process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID;
    const projectIdFromFirebaseJson = firebaseConfig.projectId;
    
    if (projectIdFromEnv && projectIdFromFirebaseJson) {
      if (projectIdFromEnv === projectIdFromFirebaseJson) {
        logSuccess('Project ID matches between .env and firebase.json');
      } else {
        logError('Project ID mismatch between .env and firebase.json');
        logInfo(`Environment: ${projectIdFromEnv}`);
        logInfo(`firebase.json: ${projectIdFromFirebaseJson}`);
      }
    }

    // Summary
    log('\n📊 Verification Summary:', colors.bold);
    logSuccess('Configuration files are present and valid');
    logSuccess('Firebase project structure appears correct');
    
    if (envVarsValid) {
      logSuccess('Environment variables are properly configured');
    } else {
      logWarning('Some environment variables need attention');
    }

    log('\n🎯 Next Steps:', colors.bold);
    log('1. Ensure Firebase CLI is logged in: firebase login');
    log('2. Deploy rules: firebase deploy --only firestore:rules');
    log('3. Test the deployment with the Firebase Permission Tester in your app');
    log('4. If issues persist, check the Firebase console for rule deployment status');

    log('\n✨ Verification complete!', colors.green);

  } catch (error) {
    logError(`Verification failed: ${error.message}`);
    process.exit(1);
  }
}

// Run verification if called directly
if (require.main === module) {
  verifyFirebaseDeployment().catch(error => {
    logError(`Unexpected error: ${error.message}`);
    process.exit(1);
  });
}

module.exports = { verifyFirebaseDeployment };