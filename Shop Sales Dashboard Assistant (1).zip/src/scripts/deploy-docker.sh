#!/bin/bash

# Pharmacy Management System - Docker Deployment Script
# This script builds and deploys the application using Docker

set -e

# Configuration
IMAGE_NAME="pharmacy-ms"
CONTAINER_NAME="pharmacy-ms-app"
PORT=3000

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🏥 Pharmacy Management System - Docker Deployment${NC}"
echo "=================================================="

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo -e "${RED}❌ Docker is not installed. Please install Docker first.${NC}"
    exit 1
fi

# Check if docker-compose is installed
if ! command -v docker-compose &> /dev/null; then
    echo -e "${YELLOW}⚠️  docker-compose not found. Falling back to docker commands.${NC}"
    USE_COMPOSE=false
else
    USE_COMPOSE=true
fi

# Function to build and run with docker-compose
deploy_with_compose() {
    echo -e "${BLUE}🐳 Building and deploying with docker-compose...${NC}"
    
    # Check if .env.local exists
    if [ ! -f .env.local ]; then
        echo -e "${YELLOW}⚠️  .env.local not found. Please create it from .env.example${NC}"
        if [ -f .env.example ]; then
            echo "Would you like to copy .env.example to .env.local? (y/n)"
            read -r response
            if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
                cp .env.example .env.local
                echo -e "${GREEN}✅ Created .env.local from .env.example${NC}"
                echo -e "${YELLOW}⚠️  Please edit .env.local with your actual configuration before continuing.${NC}"
                exit 0
            fi
        fi
        exit 1
    fi
    
    # Stop any running containers
    docker-compose down 2>/dev/null || true
    
    # Build and start the application
    docker-compose up --build -d
    
    echo -e "${GREEN}✅ Application deployed successfully!${NC}"
    echo "🌐 Access the application at: http://localhost:${PORT}"
}

# Function to build and run with plain docker
deploy_with_docker() {
    echo -e "${BLUE}🐳 Building and deploying with Docker...${NC}"
    
    # Stop and remove existing container
    docker stop "$CONTAINER_NAME" 2>/dev/null || true
    docker rm "$CONTAINER_NAME" 2>/dev/null || true
    
    # Build the image
    echo -e "${BLUE}🔨 Building Docker image...${NC}"
    docker build -t "$IMAGE_NAME" .
    
    # Run the container
    echo -e "${BLUE}🚀 Starting container...${NC}"
    docker run -d \
        --name "$CONTAINER_NAME" \
        -p "$PORT:3000" \
        --env-file .env.local \
        --restart unless-stopped \
        "$IMAGE_NAME"
    
    echo -e "${GREEN}✅ Application deployed successfully!${NC}"
    echo "🌐 Access the application at: http://localhost:${PORT}"
}

# Function to show logs
show_logs() {
    echo -e "${BLUE}📋 Showing application logs...${NC}"
    if [ "$USE_COMPOSE" = true ]; then
        docker-compose logs -f pharmacy-ms
    else
        docker logs -f "$CONTAINER_NAME"
    fi
}

# Function to stop the application
stop_app() {
    echo -e "${YELLOW}🛑 Stopping application...${NC}"
    if [ "$USE_COMPOSE" = true ]; then
        docker-compose down
    else
        docker stop "$CONTAINER_NAME" 2>/dev/null || true
        docker rm "$CONTAINER_NAME" 2>/dev/null || true
    fi
    echo -e "${GREEN}✅ Application stopped.${NC}"
}

# Function to show status
show_status() {
    echo -e "${BLUE}📊 Application Status:${NC}"
    if [ "$USE_COMPOSE" = true ]; then
        docker-compose ps
    else
        docker ps --filter "name=$CONTAINER_NAME"
    fi
}

# Main menu
case "${1:-}" in
    "build"|"deploy")
        if [ "$USE_COMPOSE" = true ]; then
            deploy_with_compose
        else
            deploy_with_docker
        fi
        ;;
    "logs")
        show_logs
        ;;
    "stop")
        stop_app
        ;;
    "status")
        show_status
        ;;
    "restart")
        stop_app
        sleep 2
        if [ "$USE_COMPOSE" = true ]; then
            deploy_with_compose
        else
            deploy_with_docker
        fi
        ;;
    *)
        echo "Usage: $0 {build|deploy|logs|stop|status|restart}"
        echo ""
        echo "Commands:"
        echo "  build/deploy  - Build and deploy the application"
        echo "  logs          - Show application logs"
        echo "  stop          - Stop the application"
        echo "  status        - Show application status"
        echo "  restart       - Restart the application"
        echo ""
        echo "Examples:"
        echo "  $0 deploy     # Deploy the application"
        echo "  $0 logs       # View logs"
        echo "  $0 stop       # Stop the application"
        exit 1
        ;;
esac