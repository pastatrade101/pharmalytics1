#!/bin/bash

# Firebase Indexes Fix Script
# This script will deploy the required Firebase indexes to fix the "failed-precondition" errors

echo "🔧 Firebase Indexes Fix Script"
echo "================================"

# Check if Firebase CLI is installed
if ! command -v firebase &> /dev/null; then
    echo "❌ Firebase CLI is not installed. Please install it first:"
    echo "   npm install -g firebase-tools"
    exit 1
fi

# Check if firebase.json exists
if [ ! -f "firebase.json" ]; then
    echo "❌ firebase.json not found. Make sure you're in the project root directory."
    exit 1
fi

# Check if firestore.indexes.json exists
if [ ! -f "firestore.indexes.json" ]; then
    echo "❌ firestore.indexes.json not found. Creating it now..."
    
    cat > firestore.indexes.json << 'EOF'
{
  "indexes": [
    {
      "collectionGroup": "sales",
      "queryScope": "COLLECTION",
      "fields": [
        {
          "fieldPath": "shop_id",
          "order": "ASCENDING"
        },
        {
          "fieldPath": "timestamp",
          "order": "DESCENDING"
        }
      ]
    },
    {
      "collectionGroup": "sales",
      "queryScope": "COLLECTION",
      "fields": [
        {
          "fieldPath": "shop_id",
          "order": "ASCENDING"
        },
        {
          "fieldPath": "created_at",
          "order": "DESCENDING"
        }
      ]
    },
    {
      "collectionGroup": "products",
      "queryScope": "COLLECTION",
      "fields": [
        {
          "fieldPath": "shop_id",
          "order": "ASCENDING"
        },
        {
          "fieldPath": "status",
          "order": "ASCENDING"
        }
      ]
    },
    {
      "collectionGroup": "products",
      "queryScope": "COLLECTION",
      "fields": [
        {
          "fieldPath": "shop_id",
          "order": "ASCENDING"
        },
        {
          "fieldPath": "expiry_date",
          "order": "ASCENDING"
        }
      ]
    },
    {
      "collectionGroup": "users",
      "queryScope": "COLLECTION",
      "fields": [
        {
          "fieldPath": "shop_id",
          "order": "ASCENDING"
        },
        {
          "fieldPath": "role",
          "order": "ASCENDING"
        }
      ]
    },
    {
      "collectionGroup": "profiles",
      "queryScope": "COLLECTION",
      "fields": [
        {
          "fieldPath": "shop_id",
          "order": "ASCENDING"
        },
        {
          "fieldPath": "created_at",
          "order": "DESCENDING"
        }
      ]
    },
    {
      "collectionGroup": "profiles", 
      "queryScope": "COLLECTION",
      "fields": [
        {
          "fieldPath": "role",
          "order": "ASCENDING"
        },
        {
          "fieldPath": "created_at",
          "order": "DESCENDING"
        }
      ]
    }
  ],
  "fieldOverrides": []
}
EOF
    
    echo "✅ Created firestore.indexes.json with required indexes"
fi

echo ""
echo "📋 Indexes to be deployed:"
echo "   - sales collection: shop_id + timestamp"
echo "   - sales collection: shop_id + created_at" 
echo "   - products collection: shop_id + status"
echo "   - products collection: shop_id + expiry_date"
echo "   - users collection: shop_id + role"
echo "   - profiles collection: shop_id + created_at (DESC)"
echo "   - profiles collection: role + created_at (DESC)"
echo ""

# Login check
echo "🔐 Checking Firebase authentication..."
if ! firebase projects:list &> /dev/null; then
    echo "❌ Not logged in to Firebase. Please login first:"
    echo "   firebase login"
    exit 1
fi

# Get current project
PROJECT_ID=$(firebase use --json 2>/dev/null | jq -r '.result.project // empty')
if [ -z "$PROJECT_ID" ]; then
    echo "❌ No Firebase project set. Please set your project first:"
    echo "   firebase use <your-project-id>"
    exit 1
fi

echo "✅ Using Firebase project: $PROJECT_ID"
echo ""

# Deploy indexes
echo "🚀 Deploying Firestore indexes..."
echo "   This may take several minutes to complete..."
echo ""

if firebase deploy --only firestore:indexes; then
    echo ""
    echo "✅ SUCCESS: Firestore indexes deployed successfully!"
    echo ""
    echo "📝 Next steps:"
    echo "   1. Wait 5-10 minutes for indexes to build completely"
    echo "   2. Check index status in Firebase Console:"
    echo "      https://console.firebase.google.com/project/$PROJECT_ID/firestore/indexes"
    echo "   3. Refresh your application to test the queries"
    echo ""
    echo "🔗 You can also view the specific error index URL if provided in the error message."
    echo ""
else
    echo ""
    echo "❌ FAILED: Error deploying Firestore indexes"
    echo ""
    echo "🔧 Troubleshooting:"
    echo "   1. Make sure you have sufficient permissions on the Firebase project"
    echo "   2. Check if firestore.indexes.json has valid JSON syntax"
    echo "   3. Try deploying manually:"
    echo "      firebase deploy --only firestore:indexes"
    echo "   4. Check Firebase Console for any existing conflicting indexes"
    echo ""
    exit 1
fi

echo "🎉 Firebase indexes fix completed!"
echo "   Remember: Index building takes time. Your queries will work once indexes are ready."