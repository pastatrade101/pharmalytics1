#!/bin/bash

# Fix Product Permission Errors - Immediate Deployment Script
# Specifically addresses: "Permission denied - Firebase rules not deployed"

echo "🚨 FIXING PRODUCT PERMISSION ERRORS"
echo "==================================="
echo ""
echo "Current Errors Being Fixed:"
echo "❌ Paracetamol 500mg (PAR-001): Permission denied"
echo "❌ Amoxicillin 250mg (AMX-002): Permission denied" 
echo "❌ Vitamin C Tablets (VIT-003): Permission denied"
echo ""

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Check directory and files
if [ ! -f "firestore.rules" ]; then
    echo -e "${RED}❌ ERROR: firestore.rules not found!${NC}"
    echo "Run this script from your project root directory."
    exit 1
fi

# Validate rules contain product permissions
if ! grep -q "PRODUCTS COLLECTION" firestore.rules; then
    echo -e "${RED}❌ ERROR: Product rules missing from firestore.rules!${NC}"
    exit 1
fi

# Check for correct role permissions
if grep -q "hasAnyRole.*manager.*product_manager" firestore.rules; then
    echo -e "${GREEN}✅ Found updated product management roles${NC}"
else
    echo -e "${YELLOW}⚠️ Product rules may need role updates${NC}"
fi

echo -e "${BLUE}📋 Role-Based Product Permissions:${NC}"
echo "   ✅ Product Manager: Complete catalog management"
echo "   ✅ Manager: Product & inventory management + sales"
echo "   ✅ Admin: Full system access"
echo "   ❌ Owner: Analytics only (no product management)"
echo "   ❌ Salesman: Sales only (no product management)"
echo ""

# Firebase CLI check
if ! command -v firebase &> /dev/null; then
    echo -e "${YELLOW}📦 Installing Firebase CLI...${NC}"
    npm install -g firebase-tools
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Firebase CLI installation failed${NC}"
        echo "Manual install: npm install -g firebase-tools"
        exit 1
    fi
fi

# Authentication check
echo -e "${BLUE}🔐 Checking Firebase authentication...${NC}"
if ! firebase projects:list &> /dev/null; then
    echo -e "${YELLOW}🔑 Firebase login required...${NC}"
    firebase login
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Firebase login failed${NC}"
        exit 1
    fi
fi

# Show current project
echo -e "${BLUE}📍 Firebase Project:${NC}"
firebase use
echo ""

# Validate rules file size
RULES_SIZE=$(wc -l < firestore.rules)
if [ $RULES_SIZE -lt 300 ]; then
    echo -e "${YELLOW}⚠️ WARNING: Rules file seems incomplete (${RULES_SIZE} lines)${NC}"
    read -p "Continue deployment? (y/N): " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
else
    echo -e "${GREEN}✅ Rules file validated (${RULES_SIZE} lines)${NC}"
fi

echo ""
echo -e "${PURPLE}🚀 DEPLOYING FIREBASE RULES...${NC}"
echo "This will immediately fix your product permission errors."
echo ""

# Deploy rules
firebase deploy --only firestore:rules

# Check deployment result
if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}🎉 SUCCESS! PRODUCT PERMISSIONS FIXED!${NC}"
    echo ""
    echo -e "${GREEN}✅ WHAT'S NOW WORKING:${NC}"
    echo "   ✅ Product creation (Paracetamol, Amoxicillin, Vitamin C)"
    echo "   ✅ Product import from CSV files"
    echo "   ✅ Inventory management for managers/product managers"
    echo "   ✅ Product catalog management"
    echo "   ✅ POS system product scanning"
    echo ""
    echo -e "${BLUE}📋 IMMEDIATE NEXT STEPS:${NC}"
    echo "1. 🔄 Refresh your pharmacy app (Ctrl+F5 / Cmd+Shift+R)"
    echo "2. 📦 Try importing products again"
    echo "3. ➕ Test creating new products manually"
    echo "4. 👤 Verify your user role is 'manager' or 'product_manager'"
    echo ""
    
    # Verify deployment
    echo -e "${BLUE}🔍 Verifying deployment...${NC}"
    if firebase firestore:rules:get > /dev/null 2>&1; then
        echo -e "${GREEN}✅ Deployment verified successfully${NC}"
    else
        echo -e "${YELLOW}⚠️ Verification inconclusive (but deployment likely successful)${NC}"
    fi
    
    echo ""
    echo -e "${PURPLE}🏥 PHARMACY SYSTEM READY!${NC}"
    echo ""
    echo -e "${BLUE}💡 TROUBLESHOOTING TIPS:${NC}"
    echo "   • Wait 30-60 seconds for Firebase propagation"
    echo "   • Clear browser cache if still seeing errors"
    echo "   • Check user role in app settings"
    echo "   • Try incognito/private browsing mode"
    
else
    echo ""
    echo -e "${RED}❌ DEPLOYMENT FAILED${NC}"
    echo ""
    echo -e "${YELLOW}🔧 MANUAL DEPLOYMENT OPTIONS:${NC}"
    echo ""
    echo "1. Firebase Console Method:"
    echo "   → https://console.firebase.google.com"
    echo "   → Your Project → Firestore Database → Rules"
    echo "   → Copy all content from firestore.rules file"
    echo "   → Paste and click 'Publish'"
    echo ""
    echo "2. Debug Deployment:"
    echo "   firebase deploy --only firestore:rules --debug"
    echo ""
    echo "3. Check Project Selection:"
    echo "   firebase use your-project-id"
    echo ""
    
    exit 1
fi

echo ""
echo "================================================"
echo -e "${GREEN}🚀 PRODUCT PERMISSIONS DEPLOYED SUCCESSFULLY!${NC}"
echo "================================================"
echo ""
echo -e "${BLUE}Your Paracetamol, Amoxicillin, and Vitamin C products${NC}"
echo -e "${BLUE}can now be created and managed! 🎉${NC}"