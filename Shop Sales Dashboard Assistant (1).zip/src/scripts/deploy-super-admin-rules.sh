#!/bin/bash

# Super Admin Firebase Rules Deployment Script
# This script deploys the updated Firestore rules that include super_admin permissions

echo "🛡️ Deploying Super Admin Firebase Security Rules..."
echo "================================================="

# Check if Firebase CLI is installed
if ! command -v firebase &> /dev/null; then
    echo "❌ Firebase CLI is not installed!"
    echo "Please install it first:"
    echo "npm install -g firebase-tools"
    echo ""
    echo "Then run: firebase login"
    exit 1
fi

# Check if user is logged in to Firebase
if ! firebase projects:list &> /dev/null; then
    echo "❌ You are not logged in to Firebase!"
    echo "Please run: firebase login"
    exit 1
fi

# Check if firebase.json exists
if [ ! -f "firebase.json" ]; then
    echo "❌ firebase.json not found!"
    echo "Please run this script from your project root directory."
    exit 1
fi

# Check if firestore.rules exists
if [ ! -f "firestore.rules" ]; then
    echo "❌ firestore.rules not found!"
    echo "Please ensure the rules file exists in your project root."
    exit 1
fi

echo "📋 Pre-deployment checks..."
echo "✅ Firebase CLI installed"
echo "✅ User logged in to Firebase"
echo "✅ firebase.json found"
echo "✅ firestore.rules found"
echo ""

# Show current project
echo "🎯 Current Firebase project:"
firebase use --current
echo ""

# Confirm deployment
echo "⚠️  IMPORTANT: This will update your Firestore security rules!"
echo "The new rules include:"
echo "  • Super Admin (super_admin) role permissions"
echo "  • System-wide data access for super admins"
echo "  • Cross-pharmacy analytics and reporting"
echo "  • Enhanced admin role management"
echo ""

read -p "Do you want to proceed with the deployment? (y/N): " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ Deployment cancelled."
    exit 1
fi

echo ""
echo "🚀 Deploying Firestore security rules..."
echo "========================================"

# Deploy the rules
if firebase deploy --only firestore:rules; then
    echo ""
    echo "✅ SUCCESS: Super Admin Firebase rules deployed!"
    echo "================================================"
    echo ""
    echo "🛡️ Super Admin features now enabled:"
    echo "  ✅ Access to all pharmacy data"
    echo "  ✅ System-wide analytics and metrics"
    echo "  ✅ Cross-pharmacy user management"
    echo "  ✅ Global system settings access"
    echo "  ✅ Comprehensive audit log access"
    echo ""
    echo "🔄 Please refresh your Super Admin Dashboard to see the changes."
    echo ""
    echo "📋 Next steps:"
    echo "  1. Sign in as a super admin user"
    echo "  2. Navigate to the Super Admin Dashboard"
    echo "  3. Verify that real data is now loading"
    echo "  4. Check that all pharmacy metrics are displayed"
    echo ""
else
    echo ""
    echo "❌ FAILED: Rules deployment failed!"
    echo "=================================="
    echo ""
    echo "🔧 Troubleshooting steps:"
    echo "  1. Check your internet connection"
    echo "  2. Verify you have the correct Firebase project selected"
    echo "  3. Ensure you have the necessary permissions for this project"
    echo "  4. Check the firestore.rules file for syntax errors"
    echo ""
    echo "💡 You can also deploy manually:"
    echo "  firebase deploy --only firestore:rules"
    echo ""
    exit 1
fi

echo "🎉 Super Admin Firebase rules deployment complete!"