#!/bin/bash

# EMERGENCY Firebase Permission Fix - Deploy Immediately
# This script will restore your pharmacy system functionality

set -e  # Exit on any error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${RED}🚨 EMERGENCY FIREBASE PERMISSION FIX${NC}"
echo -e "${RED}====================================${NC}"
echo -e "${YELLOW}⚠️  This will immediately restore your pharmacy system${NC}"
echo -e "${BLUE}📅 $(date)${NC}"
echo ""

# Check if Firebase CLI is installed
if ! command -v firebase &> /dev/null; then
    echo -e "${RED}❌ Firebase CLI not found. Installing...${NC}"
    npm install -g firebase-tools
fi

# Check if user is logged in
echo -e "${BLUE}🔐 Checking Firebase authentication...${NC}"
if ! firebase projects:list &> /dev/null; then
    echo -e "${RED}❌ Not logged in to Firebase. Please login:${NC}"
    firebase login --reauth
fi

echo -e "${BLUE}📋 Current Firebase project:${NC}"
firebase use --current

# Backup current rules
BACKUP_TIME=$(date +"%Y%m%d_%H%M%S")
if [ -f "firestore.rules" ]; then
    echo -e "${BLUE}📦 Creating backup: firestore.rules.backup.${BACKUP_TIME}${NC}"
    cp firestore.rules "firestore.rules.backup.${BACKUP_TIME}"
fi

echo ""
echo -e "${YELLOW}🚨 CRITICAL SYSTEM REPAIR${NC}"
echo -e "${YELLOW}Choose your emergency fix:${NC}"
echo "1. Deploy emergency permissive rules (IMMEDIATE ACCESS)"
echo "2. Deploy improved rules with better error handling"
echo "3. Deploy both (recommended)"
echo ""
read -p "Enter choice (1-3): " choice

case $choice in
    1)
        echo -e "${BLUE}🚀 Deploying emergency permissive rules...${NC}"
        cp firestore.emergency.rules firestore.rules
        ;;
    2)
        echo -e "${BLUE}🚀 Deploying improved rules...${NC}"
        cp firestore.rules.fixed firestore.rules
        ;;
    3)
        echo -e "${BLUE}🚀 Deploying emergency rules first, then improved rules...${NC}"
        # Deploy emergency rules first
        cp firestore.emergency.rules firestore.rules
        firebase deploy --only firestore:rules --force
        echo -e "${GREEN}✅ Emergency rules deployed!${NC}"
        echo -e "${BLUE}🔄 Now deploying improved rules...${NC}"
        sleep 2
        cp firestore.rules.fixed firestore.rules
        ;;
    *)
        echo -e "${RED}❌ Invalid choice. Exiting.${NC}"
        exit 1
        ;;
esac

# Deploy the rules
echo -e "${BLUE}🔄 Deploying Firebase security rules...${NC}"
firebase deploy --only firestore:rules --force

# Check deployment status
if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✅ EMERGENCY FIX DEPLOYED SUCCESSFULLY!${NC}"
    echo -e "${GREEN}🎉 Your pharmacy system should now work!${NC}"
    echo ""
    echo -e "${BLUE}📋 IMMEDIATE NEXT STEPS:${NC}"
    echo "1. ✅ Hard refresh your browser (Ctrl+F5 or Cmd+Shift+R)"
    echo "2. ✅ Clear browser cache and cookies if needed"
    echo "3. ✅ Sign out and sign back in"
    echo "4. ✅ Test system functionality"
    echo ""
    echo -e "${BLUE}🔍 VERIFICATION:${NC}"
    echo "- Check browser console for errors"
    echo "- Try accessing products, sales, and user management"
    echo "- Verify all features work properly"
    echo ""
    echo -e "${YELLOW}⚠️  IMPORTANT SECURITY NOTE:${NC}"
    if [ "$choice" = "1" ] || [ "$choice" = "3" ]; then
        echo -e "${YELLOW}Emergency permissive rules are deployed for immediate access.${NC}"
        echo -e "${YELLOW}Consider deploying more restrictive rules later for security.${NC}"
    fi
    echo ""
    echo -e "${GREEN}🏥 Pharmacy Management System - EMERGENCY FIX COMPLETE${NC}"
else
    echo ""
    echo -e "${RED}❌ DEPLOYMENT FAILED!${NC}"
    echo ""
    echo -e "${YELLOW}🔧 MANUAL DEPLOYMENT STEPS:${NC}"
    echo "1. Go to Firebase Console: https://console.firebase.google.com"
    echo "2. Select your project"
    echo "3. Go to Firestore Database > Rules"
    echo "4. Copy the emergency rules and paste them"
    echo "5. Click Publish"
    echo ""
    echo -e "${RED}EMERGENCY RULES TO COPY:${NC}"
    echo "-----------------------------------"
    cat firestore.emergency.rules
    echo "-----------------------------------"
    exit 1
fi