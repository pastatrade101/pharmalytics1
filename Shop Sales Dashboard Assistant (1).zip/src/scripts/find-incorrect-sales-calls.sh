#!/bin/bash

echo "🔍 Searching for incorrect SalesService method calls..."
echo "======================================================="

# Search for getSales() calls without parameters in TypeScript files
echo "1. Checking for getSales() calls without shopId parameter:"
echo ""

grep -rn "SalesService\.getSales()" components/ lib/ 2>/dev/null | while read line; do
    echo "   ❌ Found: $line"
done

grep -rn "SalesService\.getSales(\s*)" components/ lib/ 2>/dev/null | while read line; do
    echo "   ❌ Found: $line"
done

# Search for any SalesService imports and usage
echo ""
echo "2. Checking all SalesService imports:"
echo ""

grep -rn "import.*SalesService" components/ lib/ 2>/dev/null | while read line; do
    echo "   📁 Import: $line"
done

echo ""
echo "3. Checking all SalesService method calls:"
echo ""

grep -rn "SalesService\." components/ lib/ 2>/dev/null | while read line; do
    echo "   🔍 Call: $line"
done

echo ""
echo "4. Specific patterns to look for:"
echo ""

# Check for common incorrect patterns
echo "   Looking for 'SalesService.getSales()' without parameters..."
if grep -r "SalesService\.getSales()" components/ lib/ >/dev/null 2>&1; then
    echo "   ❌ Found calls to getSales() without parameters"
    grep -rn "SalesService\.getSales()" components/ lib/ 2>/dev/null
else
    echo "   ✅ No calls to getSales() without parameters found"
fi

echo ""
echo "   Looking for 'await SalesService.getSales()' patterns..."
if grep -r "await SalesService\.getSales()" components/ lib/ >/dev/null 2>&1; then
    echo "   ❌ Found await calls to getSales() without parameters"
    grep -rn "await SalesService\.getSales()" components/ lib/ 2>/dev/null
else
    echo "   ✅ No await calls to getSales() without parameters found"
fi

echo ""
echo "5. Recommended fixes:"
echo ""
echo "   Replace any instances of:"
echo "     SalesService.getSales()"
echo "   With:"
echo "     SalesService.getSalesByShop(shopId)"
echo ""
echo "   Or for super admin access:"
echo "     SalesService.getSales(100) // with limit parameter"
echo ""

echo "🎯 Search completed!"