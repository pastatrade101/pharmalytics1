#!/bin/bash

# Emergency Firebase Rules Deployment Script
# This script will deploy Firebase rules and verify the deployment

set -e  # Exit on any error

echo "🚨 EMERGENCY FIREBASE RULES DEPLOYMENT"
echo "====================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

function log() {
    echo -e "${1}${2}${NC}"
}

function log_error() {
    log "${RED}" "❌ ${1}"
}

function log_success() {
    log "${GREEN}" "✅ ${1}"
}

function log_warning() {
    log "${YELLOW}" "⚠️ ${1}"
}

function log_info() {
    log "${BLUE}" "ℹ️ ${1}"
}

echo "🔍 Checking system requirements..."

# Check if we're in a Firebase project
if [ ! -f "firebase.json" ]; then
    log_error "firebase.json not found - not in Firebase project directory"
    exit 1
fi

# Check if firestore.rules exists
if [ ! -f "firestore.rules" ]; then
    log_error "firestore.rules file not found"
    echo ""
    log_info "Creating basic firestore.rules file..."
    
    cat > firestore.rules << 'EOF'
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Helper functions
    function isAuthenticated() {
      return request.auth != null;
    }
    
    function getUserProfile() {
      return get(/databases/$(database)/documents/profiles/$(request.auth.uid)).data;
    }
    
    function hasRole(role) {
      return isAuthenticated() && getUserProfile().role == role;
    }
    
    function hasAnyRole(roles) {
      return isAuthenticated() && getUserProfile().role in roles;
    }
    
    function belongsToShop(shopId) {
      return isAuthenticated() && 
             (getUserProfile().shop_id == shopId || hasRole('admin'));
    }
    
    // User profiles
    match /profiles/{userId} {
      allow read, write: if isAuthenticated() && request.auth.uid == userId;
      allow read, write: if hasRole('admin');
      allow read: if isAuthenticated() && hasRole('owner') && 
                     resource.data.shop_id == getUserProfile().shop_id;
    }
    
    // Shops
    match /shops/{shopId} {
      allow read, write: if hasRole('admin');
      allow read, write: if isAuthenticated() && hasRole('owner') && 
                            resource.data.owner_id == request.auth.uid;
      allow read: if belongsToShop(shopId);
    }
    
    // Products
    match /products/{productId} {
      allow read, write: if hasRole('admin');
      allow read: if belongsToShop(resource.data.shop_id);
      allow create, update: if isAuthenticated() && 
                               hasAnyRole(['manager', 'owner', 'admin']) &&
                               belongsToShop(resource.data.shop_id);
    }
    
    // Sales
    match /sales/{saleId} {
      allow read, write: if hasRole('admin');
      allow read: if belongsToShop(resource.data.shop_id);
      allow create: if isAuthenticated() && 
                       hasAnyRole(['seller', 'cashier', 'pharmacist', 'pharmacy_assistant', 'manager', 'owner']) &&
                       belongsToShop(resource.data.shop_id);
    }
    
    // System settings
    match /system_settings/{settingId} {
      allow read: if isAuthenticated();
      allow write: if hasRole('admin');
    }
    
    // Default fallback
    match /{collection}/{document} {
      allow read, write: if hasRole('admin');
    }
  }
}
EOF
    
    log_success "Created basic firestore.rules file"
fi

log_success "Project structure verified"

# Check Firebase CLI
if ! command -v firebase &> /dev/null; then
    log_error "Firebase CLI not found"
    echo ""
    log_info "Install Firebase CLI:"
    echo "npm install -g firebase-tools"
    exit 1
fi

log_success "Firebase CLI found"

# Check login status
log_info "Checking Firebase authentication..."
if ! firebase projects:list &> /dev/null; then
    log_warning "Not logged in to Firebase"
    echo ""
    log_info "Logging in to Firebase..."
    firebase login
fi

log_success "Firebase authentication verified"

# Get current project
CURRENT_PROJECT=$(firebase use --current 2>/dev/null || echo "No project selected")
if [ "$CURRENT_PROJECT" = "No project selected" ]; then
    log_error "No Firebase project selected"
    echo ""
    log_info "Available projects:"
    firebase projects:list
    echo ""
    log_info "Select a project:"
    echo "firebase use <project-id>"
    exit 1
fi

log_success "Using Firebase project: $CURRENT_PROJECT"

# Deploy rules
echo ""
log_info "Deploying Firestore security rules..."
echo ""

if firebase deploy --only firestore:rules; then
    echo ""
    log_success "🎉 Rules deployed successfully!"
    
    # Wait a moment for propagation
    echo ""
    log_info "Waiting for rules to propagate..."
    sleep 3
    
    # Verify deployment
    log_info "Verifying deployment..."
    if firebase firestore:rules:get > /dev/null 2>&1; then
        log_success "Rules deployment verified"
    else
        log_warning "Could not verify deployment (may still be working)"
    fi
    
    echo ""
    log_success "🚀 EMERGENCY FIX COMPLETE!"
    echo ""
    echo "Next steps:"
    echo "1. Refresh your web application"
    echo "2. Run the Firebase Permission Tester"
    echo "3. Try creating products again"
    echo ""
    log_success "Your pharmacy management system should now be fully functional!"
    
else
    echo ""
    log_error "❌ Rules deployment failed"
    echo ""
    echo "Troubleshooting:"
    echo "1. Check firestore.rules file for syntax errors"
    echo "2. Verify you have proper permissions on the Firebase project" 
    echo "3. Try: firebase login --reauth"
    echo "4. Check internet connection"
    echo ""
    exit 1
fi