#!/bin/bash

# Deploy Existing Super Admin Firebase Rules Script
# This script deploys the already-enhanced Firestore rules that include super_admin permissions

echo "🛡️ Deploying Existing Super Admin Firebase Security Rules..."
echo "============================================================="

# Check if Firebase CLI is installed
if ! command -v firebase &> /dev/null; then
    echo "❌ Firebase CLI is not installed!"
    echo "Please install it first:"
    echo "npm install -g firebase-tools"
    echo ""
    echo "Then run: firebase login"
    exit 1
fi

# Check if user is logged in to Firebase
if ! firebase projects:list &> /dev/null; then
    echo "❌ You are not logged in to Firebase!"
    echo "Please run: firebase login"
    exit 1
fi

# Check if firebase.json exists
if [ ! -f "firebase.json" ]; then
    echo "❌ firebase.json not found!"
    echo "Please run this script from your project root directory."
    exit 1
fi

# Check if firestore.rules exists
if [ ! -f "firestore.rules" ]; then
    echo "❌ firestore.rules not found!"
    echo "Please ensure the rules file exists in your project root."
    exit 1
fi

echo "📋 Pre-deployment checks..."
echo "✅ Firebase CLI installed"
echo "✅ User logged in to Firebase"
echo "✅ firebase.json found"
echo "✅ firestore.rules found"
echo ""

# Show current project
echo "🎯 Current Firebase project:"
firebase use --current
echo ""

# Validate rules contain super admin functions
echo "🔍 Validating firestore.rules contains super admin functionality..."

if grep -q "function isSuperAdmin()" firestore.rules; then
    echo "✅ isSuperAdmin() function found"
else
    echo "❌ isSuperAdmin() function missing"
    echo "Please ensure your firestore.rules file contains the super admin functions."
    exit 1
fi

if grep -q "function isAdmin()" firestore.rules; then
    echo "✅ isAdmin() function found"
else
    echo "❌ isAdmin() function missing"
    echo "Please ensure your firestore.rules file contains the enhanced admin functions."
    exit 1
fi

if grep -q "system_metrics" firestore.rules; then
    echo "✅ Super admin collections found"
else
    echo "❌ Super admin collections missing"
    echo "Please ensure your firestore.rules file contains the super admin collections."
    exit 1
fi

echo ""

# Show what's included in the rules
echo "📋 Super Admin features in current rules:"
echo "  ✅ isSuperAdmin() role function"
echo "  ✅ Enhanced isAdmin() to include super_admin"
echo "  ✅ System-wide access to all collections"
echo "  ✅ Cross-pharmacy data access"
echo "  ✅ Super admin specific collections"
echo "  ✅ Global system settings access"
echo ""

# Confirm deployment
echo "⚠️  IMPORTANT: This will deploy your Firestore security rules!"
echo "The current rules already include:"
echo "  • Super Admin (super_admin) role permissions"
echo "  • System-wide data access for super admins"
echo "  • Cross-pharmacy analytics and reporting"
echo "  • Enhanced admin role management"
echo ""

read -p "Do you want to proceed with the deployment? (y/N): " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ Deployment cancelled."
    exit 1
fi

echo ""
echo "🚀 Deploying Firestore security rules and indexes..."
echo "===================================================="

# Deploy both rules and indexes
if firebase deploy --only firestore; then
    echo ""
    echo "✅ SUCCESS: Super Admin Firebase rules and indexes deployed!"
    echo "==========================================================="
    echo ""
    echo "🛡️ Super Admin features now enabled:"
    echo "  ✅ Access to all pharmacy data"
    echo "  ✅ System-wide analytics and metrics"
    echo "  ✅ Cross-pharmacy user management"
    echo "  ✅ Global system settings access"
    echo "  ✅ Comprehensive audit log access"
    echo ""
    echo "📊 Database indexes created:"
    echo "  ✅ Shops collection - optimized for Super Admin queries"
    echo "  ✅ Products collection - enhanced search and filtering"
    echo "  ✅ Sales collection - improved analytics performance"
    echo "  ✅ Profiles collection - optimized user management"
    echo ""
    echo "🔄 Please refresh your Super Admin Dashboard to see the changes."
    echo ""
    echo "📋 Next steps:"
    echo "  1. Sign in as a super admin user"
    echo "  2. Navigate to the Super Admin Dashboard"
    echo "  3. Verify that real data is now loading"
    echo "  4. Check that all pharmacy metrics are displayed"
    echo ""
    echo "🔧 If you still get permission errors:"
    echo "  1. Check that your user role is 'super_admin' in Firebase Console"
    echo "  2. Verify your account email ends with authorized domain"
    echo "  3. Clear browser cache and try again"
    echo ""
else
    echo ""
    echo "❌ FAILED: Rules deployment failed!"
    echo "=================================="
    echo ""
    echo "🔧 Troubleshooting steps:"
    echo "  1. Check your internet connection"
    echo "  2. Verify you have the correct Firebase project selected"
    echo "  3. Ensure you have the necessary permissions for this project"
    echo "  4. Check the firestore.rules file for syntax errors"
    echo ""
    echo "💡 You can also deploy manually:"
    echo "  firebase deploy --only firestore:rules"
    echo "  firebase deploy --only firestore:indexes"
    echo "  # Or both at once:"
    echo "  firebase deploy --only firestore"
    echo ""
    echo "🔍 To validate your rules locally:"
    echo "  firebase firestore:rules:get"
    echo ""
    exit 1
fi

echo "🎉 Super Admin Firebase rules deployment complete!"
echo ""
echo "📊 Your Super Admin Dashboard should now show:"
echo "  • Real pharmacy count and status"
echo "  • Actual user metrics across all pharmacies"
echo "  • Live revenue calculations from sales data"
echo "  • Dynamic system health assessments"
echo "  • Comprehensive pharmacy management table"
echo ""
echo "🚀 The permission errors should be resolved!"