#!/bin/bash

# Complete Firebase Setup Deployment Script
# This script deploys both Firestore rules and indexes for the Super Admin Dashboard

echo "🚀 Deploying Complete Firebase Setup (Rules + Indexes)..."
echo "========================================================"

# Check if Firebase CLI is installed
if ! command -v firebase &> /dev/null; then
    echo "❌ Firebase CLI is not installed!"
    echo "Please install it first:"
    echo "npm install -g firebase-tools"
    echo ""
    echo "Then run: firebase login"
    exit 1
fi

# Check if user is logged in to Firebase
if ! firebase projects:list &> /dev/null; then
    echo "❌ You are not logged in to Firebase!"
    echo "Please run: firebase login"
    exit 1
fi

# Check if firebase.json exists
if [ ! -f "firebase.json" ]; then
    echo "❌ firebase.json not found!"
    echo "Please run this script from your project root directory."
    exit 1
fi

# Check if required files exist
if [ ! -f "firestore.rules" ]; then
    echo "❌ firestore.rules not found!"
    echo "Please ensure the rules file exists in your project root."
    exit 1
fi

if [ ! -f "firestore.indexes.json" ]; then
    echo "❌ firestore.indexes.json not found!"
    echo "Please ensure the indexes file exists in your project root."
    exit 1
fi

echo "📋 Pre-deployment checks..."
echo "✅ Firebase CLI installed"
echo "✅ User logged in to Firebase"
echo "✅ firebase.json found"
echo "✅ firestore.rules found"
echo "✅ firestore.indexes.json found"
echo ""

# Show current project
echo "🎯 Current Firebase project:"
firebase use --current
echo ""

# Validate rules contain super admin functions
echo "🔍 Validating firestore.rules contains super admin functionality..."

if grep -q "function isSuperAdmin()" firestore.rules; then
    echo "✅ isSuperAdmin() function found"
else
    echo "❌ isSuperAdmin() function missing"
    echo "Please ensure your firestore.rules file contains the super admin functions."
    exit 1
fi

if grep -q "function isAdmin()" firestore.rules; then
    echo "✅ isAdmin() function found"
else
    echo "❌ isAdmin() function missing"
    echo "Please ensure your firestore.rules file contains the enhanced admin functions."
    exit 1
fi

# Check indexes file contains shops indexes
echo "🔍 Validating firestore.indexes.json contains required indexes..."

if grep -q '"collectionGroup": "shops"' firestore.indexes.json; then
    echo "✅ Shops collection indexes found"
else
    echo "❌ Shops collection indexes missing"
    echo "Please ensure your firestore.indexes.json file contains the shops indexes."
    exit 1
fi

echo ""

# Show what will be deployed
echo "📋 What will be deployed:"
echo "🛡️  Firestore Security Rules:"
echo "  ✅ Super Admin (super_admin) role permissions"
echo "  ✅ System-wide data access for super admins"
echo "  ✅ Cross-pharmacy analytics and reporting"
echo "  ✅ Enhanced admin role management"
echo ""
echo "📊 Firestore Indexes:"
echo "  ✅ Shops collection indexes for Super Admin Dashboard"
echo "  ✅ Products collection indexes for inventory management"
echo "  ✅ Sales collection indexes for analytics"
echo "  ✅ Profiles collection indexes for user management"
echo ""

# Confirm deployment
echo "⚠️  IMPORTANT: This will deploy Firestore rules and indexes!"
echo ""

read -p "Do you want to proceed with the complete deployment? (y/N): " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ Deployment cancelled."
    exit 1
fi

echo ""
echo "🚀 Deploying Firestore rules and indexes..."
echo "============================================"

# Deploy both rules and indexes
if firebase deploy --only firestore; then
    echo ""
    echo "✅ SUCCESS: Complete Firebase setup deployed!"
    echo "============================================="
    echo ""
    echo "🛡️ Super Admin features now enabled:"
    echo "  ✅ Access to all pharmacy data"
    echo "  ✅ System-wide analytics and metrics"
    echo "  ✅ Cross-pharmacy user management"
    echo "  ✅ Global system settings access"
    echo "  ✅ Comprehensive audit log access"
    echo ""
    echo "📊 Database indexes created:"
    echo "  ✅ Shops collection - status and created_at ordering"
    echo "  ✅ Shops collection - owner_id and created_at ordering"
    echo "  ✅ Products collection - enhanced querying capabilities"
    echo "  ✅ Sales collection - improved analytics performance"
    echo "  ✅ Profiles collection - optimized user management"
    echo ""
    echo "🔄 Please refresh your Super Admin Dashboard to see the changes."
    echo ""
    echo "📋 Next steps:"
    echo "  1. Sign in as a super admin user"
    echo "  2. Navigate to the Super Admin Dashboard"
    echo "  3. Verify that real data is now loading"
    echo "  4. Check that all pharmacy metrics are displayed"
    echo "  5. Confirm no permission or index errors appear"
    echo ""
    echo "🔧 If you still get errors:"
    echo "  1. Check that your user role is 'super_admin' in Firebase Console"
    echo "  2. Verify your account email ends with authorized domain"
    echo "  3. Clear browser cache and try again"
    echo "  4. Check browser console for any remaining errors"
    echo ""
else
    echo ""
    echo "❌ FAILED: Deployment failed!"
    echo "============================"
    echo ""
    echo "🔧 Troubleshooting steps:"
    echo "  1. Check your internet connection"
    echo "  2. Verify you have the correct Firebase project selected"
    echo "  3. Ensure you have the necessary permissions for this project"
    echo "  4. Check the firestore.rules file for syntax errors"
    echo "  5. Check the firestore.indexes.json file for syntax errors"
    echo ""
    echo "💡 You can also deploy manually:"
    echo "  firebase deploy --only firestore:rules"
    echo "  firebase deploy --only firestore:indexes"
    echo ""
    echo "🔍 To validate your setup locally:"
    echo "  firebase firestore:rules:get"
    echo "  firebase firestore:indexes:list"
    echo ""
    exit 1
fi

echo "🎉 Complete Firebase setup deployment finished!"
echo ""
echo "🎯 Quick verification steps:"
echo "  1. Open your Super Admin Dashboard"
echo "  2. Check that pharmacy data loads without errors"
echo "  3. Verify system metrics display real numbers"
echo "  4. Confirm no 'index required' errors appear"
echo ""
echo "✨ Your Super Admin Dashboard should now work perfectly!"