#!/usr/bin/env node

/**
 * Firebase Permissions Test Script
 * Tests if Firebase rules are properly deployed and working
 */

const { initializeApp } = require('firebase/app');
const { getFirestore, collection, doc, setDoc, getDoc, deleteDoc, query, where, getDocs } = require('firebase/firestore');
const { getAuth, signInWithEmailAndPassword } = require('firebase/auth');

// Colors for console output
const colors = {
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m',
  reset: '\x1b[0m'
};

function log(color, message) {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

// Firebase configuration - you'll need to replace this with your actual config
const firebaseConfig = {
  // Add your Firebase config here
  // You can find this in your Firebase Console -> Project Settings -> General -> Your apps
  apiKey: "your-api-key",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "123456789",
  appId: "your-app-id"
};

// Test credentials - replace with actual test user
const testUser = {
  email: "test@example.com",
  password: "testpassword123"
};

async function testFirebasePermissions() {
  log('cyan', '🚀 Starting Firebase Permissions Test...');
  log('white', '==========================================');
  
  try {
    // Initialize Firebase
    log('blue', '📱 Initializing Firebase...');
    const app = initializeApp(firebaseConfig);
    const db = getFirestore(app);
    const auth = getAuth(app);
    
    log('green', '✅ Firebase initialized successfully');
    
    // Test 1: Authentication
    log('blue', '\n🔐 Testing Authentication...');
    
    try {
      const userCredential = await signInWithEmailAndPassword(auth, testUser.email, testUser.password);
      log('green', `✅ Authentication successful: ${userCredential.user.email}`);
    } catch (authError) {
      log('red', `❌ Authentication failed: ${authError.message}`);
      log('yellow', '⚠️ You may need to create a test user or update credentials');
      log('yellow', '   Continuing tests without authentication...');
    }
    
    // Test 2: Read Permissions
    log('blue', '\n📖 Testing Read Permissions...');
    
    try {
      const testQuery = query(collection(db, 'products'), where('status', '==', 'active'));
      const querySnapshot = await getDocs(testQuery);
      log('green', `✅ Read permissions working: Found ${querySnapshot.size} products`);
    } catch (readError) {
      log('red', `❌ Read permissions failed: ${readError.message}`);
      if (readError.code === 'permission-denied') {
        log('yellow', '🚨 CRITICAL: Firebase rules not deployed!');
        log('yellow', '   Run: firebase deploy --only firestore:rules');
      }
    }
    
    // Test 3: Write Permissions
    log('blue', '\n✏️ Testing Write Permissions...');
    
    const testProductId = `test-product-${Date.now()}`;
    const testProduct = {
      name: 'TEST - Permission Test Product',
      sku: `TEST-${Date.now()}`,
      category: 'otc',
      price: 1000,
      cost: 800,
      stock_quantity: 1,
      min_stock_level: 1,
      status: 'active',
      shop_id: 'test-shop-id',
      description: 'Test product for permission verification',
      created_at: new Date(),
      updated_at: new Date()
    };
    
    try {
      await setDoc(doc(db, 'products', testProductId), testProduct);
      log('green', `✅ Write permissions working: Created test product ${testProductId}`);
      
      // Test 4: Read the created document
      log('blue', '\n🔍 Testing Document Read...');
      const docSnap = await getDoc(doc(db, 'products', testProductId));
      
      if (docSnap.exists()) {
        log('green', `✅ Document read successful: ${docSnap.data().name}`);
      } else {
        log('red', '❌ Document read failed: Document not found');
      }
      
      // Test 5: Delete (cleanup)
      log('blue', '\n🗑️ Cleaning up test data...');
      await deleteDoc(doc(db, 'products', testProductId));
      log('green', '✅ Cleanup successful: Test product deleted');
      
    } catch (writeError) {
      log('red', `❌ Write permissions failed: ${writeError.message}`);
      
      if (writeError.code === 'permission-denied') {
        log('yellow', '🚨 CRITICAL: Firebase rules not deployed or insufficient permissions!');
        log('yellow', '   Solutions:');
        log('yellow', '   1. Run: firebase deploy --only firestore:rules');
        log('yellow', '   2. Ensure user has role: manager, owner, or admin');
        log('yellow', '   3. Verify user has shop_id assigned');
      }
    }
    
    // Test 6: Profile Collection Access
    log('blue', '\n👤 Testing Profile Access...');
    
    try {
      const currentUser = auth.currentUser;
      if (currentUser) {
        const profileDoc = await getDoc(doc(db, 'profiles', currentUser.uid));
        if (profileDoc.exists()) {
          const profile = profileDoc.data();
          log('green', `✅ Profile access successful: ${profile.full_name}`);
          log('white', `   Role: ${profile.role}`);
          log('white', `   Shop ID: ${profile.shop_id || 'Not assigned'}`);
          
          // Check if user has required permissions
          const allowedRoles = ['manager', 'owner', 'admin'];
          if (allowedRoles.includes(profile.role)) {
            log('green', '✅ User has required role for product management');
          } else {
            log('red', `❌ User role '${profile.role}' insufficient. Required: ${allowedRoles.join(', ')}`);
          }
          
          if (profile.shop_id) {
            log('green', '✅ User has shop assignment');
          } else {
            log('red', '❌ User missing shop assignment');
          }
          
        } else {
          log('red', '❌ Profile document not found');
        }
      } else {
        log('yellow', '⚠️ No authenticated user - skipping profile test');
      }
    } catch (profileError) {
      log('red', `❌ Profile access failed: ${profileError.message}`);
    }
    
    // Final Results
    log('white', '\n==========================================');
    log('cyan', '📋 TEST SUMMARY');
    log('white', '==========================================');
    
    log('green', '✅ If all tests passed: Your Firebase setup is working correctly!');
    log('green', '   You should be able to import products successfully.');
    
    log('yellow', '⚠️ If tests failed:');
    log('yellow', '   1. Deploy rules: firebase deploy --only firestore:rules');
    log('yellow', '   2. Check user role and shop assignment');
    log('yellow', '   3. Verify Firebase project configuration');
    
    log('cyan', '\n🎉 Test completed!');
    
  } catch (error) {
    log('red', `❌ Test script failed: ${error.message}`);
    log('yellow', '\nTroubleshooting:');
    log('yellow', '1. Update firebaseConfig with your actual Firebase configuration');
    log('yellow', '2. Update testUser with valid credentials');
    log('yellow', '3. Ensure Firebase CLI is installed and you\'re logged in');
    log('yellow', '4. Run: npm install firebase');
  }
}

// Check if Firebase config is properly set
if (firebaseConfig.apiKey === "your-api-key") {
  log('red', '❌ ERROR: Firebase configuration not set!');
  log('yellow', 'Please update the firebaseConfig object in this script with your actual Firebase configuration.');
  log('yellow', 'You can find this in Firebase Console -> Project Settings -> General -> Your apps');
  process.exit(1);
}

// Run the test
testFirebasePermissions().catch(console.error);