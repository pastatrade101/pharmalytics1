#!/bin/bash

# Urgent Firebase Rules Deployment Script
# Fixes permission-denied errors for product creation and management

echo "🚨 URGENT: Fixing Firebase Permission Errors..."
echo "=============================================="
echo ""
echo "Current errors being fixed:"
echo "❌ Error creating product: permission-denied"
echo "❌ Failed to import products: permission-denied"
echo "❌ Firebase permission denied in unknown operation"
echo ""

# Color codes for better output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check if we're in the correct directory
if [ ! -f "firestore.rules" ]; then
    echo -e "${RED}❌ ERROR: firestore.rules file not found!${NC}"
    echo "Please run this script from your project root directory."
    echo "Expected files: firestore.rules, firebase.json"
    exit 1
fi

# Check if firebase.json exists, create if missing
if [ ! -f "firebase.json" ]; then
    echo -e "${YELLOW}⚠️ firebase.json missing - creating...${NC}"
    cat > firebase.json << 'EOF'
{
  "firestore": {
    "rules": "firestore.rules",
    "indexes": "firestore.indexes.json"
  }
}
EOF
    echo -e "${GREEN}✅ Created firebase.json${NC}"
fi

# Check Firebase CLI installation
if ! command -v firebase &> /dev/null; then
    echo -e "${YELLOW}🔧 Installing Firebase CLI...${NC}"
    npm install -g firebase-tools
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Failed to install Firebase CLI${NC}"
        echo "Please install manually: npm install -g firebase-tools"
        exit 1
    fi
    echo -e "${GREEN}✅ Firebase CLI installed${NC}"
fi

# Check authentication
echo -e "${BLUE}🔍 Checking Firebase authentication...${NC}"
if ! firebase projects:list &> /dev/null; then
    echo -e "${YELLOW}🔑 Please login to Firebase...${NC}"
    firebase login
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Firebase login failed${NC}"
        exit 1
    fi
fi

# Show current project
echo -e "${BLUE}📍 Current Firebase project:${NC}"
firebase use
echo ""

# Validate rules file
RULES_SIZE=$(wc -l < firestore.rules)
echo -e "${BLUE}📋 Firestore rules validation:${NC}"
echo "   - File size: $RULES_SIZE lines"

if [ $RULES_SIZE -lt 400 ]; then
    echo -e "${YELLOW}⚠️ WARNING: Rules file seems incomplete (expected ~483 lines)${NC}"
    echo "First few lines:"
    head -n 3 firestore.rules
    echo ""
    read -p "Continue anyway? (y/N): " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
else
    echo -e "${GREEN}✅ Rules file appears complete${NC}"
fi

# Check for critical patterns in rules
if grep -q "hasAnyRole.*manager.*owner" firestore.rules; then
    echo -e "${GREEN}✅ Found product management permissions${NC}"
else
    echo -e "${YELLOW}⚠️ Product management rules may be missing${NC}"
fi

echo ""
echo -e "${BLUE}🚀 Deploying Firebase security rules...${NC}"
echo "This will fix your permission-denied errors..."
echo ""

# Deploy with error handling
firebase deploy --only firestore:rules

# Check deployment result
if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✅ SUCCESS! Firebase rules deployed successfully!${NC}"
    echo ""
    echo -e "${GREEN}🎉 PERMISSION ERRORS FIXED!${NC}"
    echo ""
    echo "📋 What's now working:"
    echo "   ✅ Product creation and management"
    echo "   ✅ Product import from CSV files" 
    echo "   ✅ Inventory management access"
    echo "   ✅ Manager and owner permissions"
    echo "   ✅ POS system functionality"
    echo ""
    echo -e "${BLUE}📋 NEXT STEPS:${NC}"
    echo "1. 🔄 Refresh your web application (Ctrl+F5 / Cmd+Shift+R)"
    echo "2. 🧪 Try importing products again"
    echo "3. ✅ Test creating a new product manually"
    echo "4. 👤 Verify your user role is 'manager', 'owner', or 'admin'"
    echo ""
    
    # Quick verification
    echo -e "${BLUE}🔍 Verifying deployment...${NC}"
    if firebase firestore:rules:get > /dev/null 2>&1; then
        echo -e "${GREEN}✅ Rules deployment verified${NC}"
    else
        echo -e "${YELLOW}⚠️ Could not verify deployment (but likely successful)${NC}"
    fi
    
    echo ""
    echo -e "${GREEN}🏥 Your pharmacy system is now fully functional!${NC}"
    echo ""
    echo "If you're still seeing permission errors:"
    echo "1. Wait 30-60 seconds for Firebase to propagate changes"
    echo "2. Clear browser cache or try incognito mode"
    echo "3. Check your user role in the app (should be manager/owner/admin)"
    
else
    echo ""
    echo -e "${RED}❌ DEPLOYMENT FAILED${NC}"
    echo ""
    echo -e "${YELLOW}🔧 TROUBLESHOOTING:${NC}"
    echo ""
    echo "1. Verify project selection:"
    echo "   firebase projects:list"
    echo "   firebase use your-project-id"
    echo ""
    echo "2. Check file exists:"
    echo "   ls -la firestore.rules"
    echo ""
    echo "3. Try manual deployment:"
    echo "   firebase deploy --only firestore:rules --debug"
    echo ""
    echo "4. Alternative: Use Firebase Console"
    echo "   → https://console.firebase.google.com"
    echo "   → Firestore Database → Rules"
    echo "   → Copy/paste your firestore.rules content"
    echo "   → Click Publish"
    echo ""
    
    exit 1
fi

echo ""
echo "=============================================="
echo -e "${GREEN}🚀 DEPLOYMENT COMPLETE - Test your app now!${NC}"
echo "=============================================="