#!/bin/bash

# ==============================================
# SHOP SALES DASHBOARD - QUICK START SCRIPT
# ==============================================
# This script helps you get the project running quickly
# Usage: bash scripts/quick-start.sh

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Helper functions
print_header() {
    echo -e "\n${PURPLE}==================================================${NC}"
    echo -e "${PURPLE}🚀 SHOP SALES DASHBOARD - QUICK START${NC}"
    echo -e "${PURPLE}==================================================${NC}\n"
}

print_step() {
    echo -e "${CYAN}🔄 $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Check if Node.js is installed
check_node() {
    print_step "Checking Node.js installation..."
    
    if ! command -v node &> /dev/null; then
        print_error "Node.js is not installed!"
        print_info "Please install Node.js 18+ from: https://nodejs.org/"
        exit 1
    fi
    
    NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
    if [ "$NODE_VERSION" -lt 18 ]; then
        print_error "Node.js version $NODE_VERSION is too old!"
        print_info "Please install Node.js 18+ from: https://nodejs.org/"
        exit 1
    fi
    
    print_success "Node.js $(node --version) is installed"
}

# Check if npm/yarn is available
check_package_manager() {
    print_step "Checking package manager..."
    
    if command -v yarn &> /dev/null; then
        PACKAGE_MANAGER="yarn"
        print_success "Using Yarn $(yarn --version)"
    elif command -v npm &> /dev/null; then
        PACKAGE_MANAGER="npm"
        print_success "Using npm $(npm --version)"
    else
        print_error "Neither npm nor yarn is installed!"
        exit 1
    fi
}

# Install dependencies
install_dependencies() {
    print_step "Installing dependencies..."
    
    if [ "$PACKAGE_MANAGER" = "yarn" ]; then
        if yarn install; then
            print_success "Dependencies installed successfully with Yarn"
        else
            print_error "Failed to install dependencies with Yarn"
            exit 1
        fi
    else
        if npm install; then
            print_success "Dependencies installed successfully with npm"
        else
            print_error "Failed to install dependencies with npm"
            exit 1
        fi
    fi
}

# Setup environment file
setup_environment() {
    print_step "Setting up environment configuration..."
    
    if [ ! -f ".env.local" ]; then
        if [ -f ".env.example" ]; then
            cp .env.example .env.local
            print_success "Created .env.local from .env.example"
            print_warning "Please edit .env.local with your actual configuration values"
            print_info "You need to add your Firebase and Gemini API credentials"
        else
            print_error ".env.example file not found!"
            exit 1
        fi
    else
        print_success ".env.local already exists"
    fi
}

# Check Firebase CLI
check_firebase_cli() {
    print_step "Checking Firebase CLI..."
    
    if ! command -v firebase &> /dev/null; then
        print_warning "Firebase CLI not found"
        print_info "Installing Firebase CLI globally..."
        
        if [ "$PACKAGE_MANAGER" = "yarn" ]; then
            yarn global add firebase-tools
        else
            npm install -g firebase-tools
        fi
        
        if command -v firebase &> /dev/null; then
            print_success "Firebase CLI installed successfully"
        else
            print_error "Failed to install Firebase CLI"
            print_info "Try manual installation: npm install -g firebase-tools"
        fi
    else
        print_success "Firebase CLI $(firebase --version) is installed"
    fi
}

# Run Firebase setup script
run_firebase_setup() {
    print_step "Running Firebase configuration check..."
    
    if [ -f "scripts/setup-firebase.js" ]; then
        node scripts/setup-firebase.js
    else
        print_warning "Firebase setup script not found"
        print_info "You may need to configure Firebase manually"
    fi
}

# Create necessary directories
create_directories() {
    print_step "Creating necessary directories..."
    
    directories=(
        "public/images"
        "lib/types"
        "components/modals"
        "hooks/mutations"
        "utils"
    )
    
    for dir in "${directories[@]}"; do
        if [ ! -d "$dir" ]; then
            mkdir -p "$dir"
        fi
    done
    
    print_success "Directory structure verified"
}

# Check TypeScript configuration
check_typescript() {
    print_step "Checking TypeScript configuration..."
    
    if [ ! -f "tsconfig.json" ]; then
        print_warning "tsconfig.json not found, creating basic configuration..."
        
        cat > tsconfig.json << EOL
{
  "compilerOptions": {
    "target": "es5",
    "lib": ["dom", "dom.iterable", "es6"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "forceConsistentCasingInFileNames": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "node",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "plugins": [
      {
        "name": "next"
      }
    ],
    "baseUrl": ".",
    "paths": {
      "@/*": ["./*"],
      "@/components/*": ["./components/*"],
      "@/lib/*": ["./lib/*"],
      "@/hooks/*": ["./hooks/*"]
    }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
  "exclude": ["node_modules"]
}
EOL
        
        print_success "Created basic tsconfig.json"
    else
        print_success "TypeScript configuration exists"
    fi
}

# Start development server
start_dev_server() {
    print_step "Starting development server..."
    
    print_info "Development server will start on http://localhost:3000"
    print_info "Make sure you've configured your .env.local file first!"
    
    echo -e "\n${YELLOW}Press Ctrl+C to stop the server${NC}\n"
    
    if [ "$PACKAGE_MANAGER" = "yarn" ]; then
        yarn dev
    else
        npm run dev
    fi
}

# Main execution
main() {
    print_header
    
    # Pre-flight checks
    check_node
    check_package_manager
    
    # Setup steps
    install_dependencies
    setup_environment
    create_directories
    check_typescript
    check_firebase_cli
    run_firebase_setup
    
    # Summary
    echo -e "\n${PURPLE}==================================================${NC}"
    echo -e "${PURPLE}📋 QUICK START COMPLETED${NC}"
    echo -e "${PURPLE}==================================================${NC}"
    
    print_success "Project setup completed successfully!"
    
    echo -e "\n${BLUE}📝 NEXT STEPS:${NC}"
    echo -e "${CYAN}1. Edit .env.local with your Firebase and Gemini API credentials${NC}"
    echo -e "${CYAN}2. Login to Firebase: firebase login${NC}"
    echo -e "${CYAN}3. Deploy Firestore rules: firebase deploy --only firestore:rules${NC}"
    echo -e "${CYAN}4. Start development: $PACKAGE_MANAGER dev${NC}"
    
    echo -e "\n${BLUE}📚 DOCUMENTATION:${NC}"
    echo -e "${CYAN}• Detailed setup: LOCAL_SETUP_GUIDE.md${NC}"
    echo -e "${CYAN}• Firebase setup: FIREBASE_SETUP.md${NC}"
    echo -e "${CYAN}• Troubleshooting: Check console logs${NC}"
    
    # Ask if user wants to start dev server now
    echo -e "\n${YELLOW}Would you like to start the development server now? (y/N)${NC}"
    read -r response
    
    if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
        start_dev_server
    else
        echo -e "\n${GREEN}Setup complete! Run '$PACKAGE_MANAGER dev' when ready.${NC}\n"
    fi
}

# Run main function
main "$@"