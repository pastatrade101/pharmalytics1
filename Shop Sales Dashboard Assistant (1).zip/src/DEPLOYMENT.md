# Shop Sales Dashboard - Deployment Guide

## Overview
This Next.js application provides a comprehensive sales management system with AI-powered analytics and MCP (Model Context Protocol) integrations for automated reporting.

## Prerequisites

### Required Services
1. **Firestore** - Real-time sales data storage
2. **Google Sheets API** - Automated report generation
3. **Email SMTP** - Daily report delivery
4. **WhatsApp Business API** - Mobile notifications
5. **OpenAI API** - AI-powered insights generation

### Environment Variables
Create a `.env.local` file with the following variables:

```bash
# OpenAI Configuration
OPENAI_API_KEY=your_openai_api_key_here

# Firestore Configuration
FIREBASE_PROJECT_ID=your_firebase_project_id
FIREBASE_API_KEY=your_firebase_api_key
FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
FIREBASE_DATABASE_URL=https://your_project.firebaseio.com
FIREBASE_STORAGE_BUCKET=your_project.appspot.com

# Google Sheets Configuration
GOOGLE_SHEETS_API_KEY=your_google_sheets_api_key
GOOGLE_SHEETS_SPREADSHEET_ID=your_spreadsheet_id

# Email Configuration (Gmail SMTP)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your_email@gmail.com
EMAIL_APP_PASSWORD=your_app_specific_password
OWNER_EMAIL=owner@yourshop.com
MANAGER_EMAIL=manager@yourshop.com

# WhatsApp Business API
WHATSAPP_BUSINESS_ACCOUNT_ID=your_business_account_id
WHATSAPP_ACCESS_TOKEN=your_access_token
OWNER_PHONE=+1234567890

# Application Settings
NEXT_PUBLIC_APP_URL=https://your-domain.com
NEXT_PUBLIC_SHOP_NAME=Your Shop Name
```

## Setup Instructions

### 1. Firebase/Firestore Setup
```bash
# Install Firebase Admin SDK
npm install firebase-admin

# Initialize Firebase in your project
# Create a service account key from Firebase Console
# Download the JSON key file and add to your project
```

### 2. Google Sheets API Setup
```bash
# Enable Google Sheets API in Google Cloud Console
# Create credentials (API Key or OAuth2)
# Create a master spreadsheet for reports
```

### 3. Email Configuration
```bash
# For Gmail:
# 1. Enable 2-factor authentication
# 2. Generate an App Password
# 3. Use the app password in EMAIL_APP_PASSWORD
```

### 4. WhatsApp Business API
```bash
# Register with WhatsApp Business API
# Get Business Account ID and Access Token
# Configure webhook endpoints (optional)
```

## MCP Integration Examples

### Firestore MCP Connector
```typescript
// lib/connectors/firestore-mcp.ts
import { FirestoreMCPConnector } from '../mcp-connectors';

const firestore = new FirestoreMCPConnector(
  process.env.FIREBASE_PROJECT_ID!,
  process.env.FIREBASE_API_KEY!
);

// Real-time sales updates
export async function setupRealtimeUpdates() {
  await firestore.getRealtimeUpdates((update) => {
    // Handle real-time sale updates
    console.log('New sale recorded:', update);
  });
}
```

### Google Sheets MCP Connector
```typescript
// lib/connectors/sheets-mcp.ts
import { GoogleSheetsMCPConnector } from '../mcp-connectors';

const sheets = new GoogleSheetsMCPConnector(
  process.env.GOOGLE_SHEETS_SPREADSHEET_ID!,
  process.env.GOOGLE_SHEETS_API_KEY!
);

// Generate daily report
export async function generateDailyReport(data: any) {
  const reportUrl = await sheets.createDailyReport(data);
  const pdfUrl = await sheets.exportToPDF(reportUrl);
  return { reportUrl, pdfUrl };
}
```

## Deployment Options

### 1. Vercel Deployment (Recommended)
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy to Vercel
vercel

# Set environment variables in Vercel Dashboard
# Configure custom domain (optional)
```

### 2. Docker Deployment
```dockerfile
# Dockerfile
FROM node:18-alpine

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

EXPOSE 3000
CMD ["npm", "start"]
```

```bash
# Build and run Docker container
docker build -t shop-sales-dashboard .
docker run -p 3000:3000 --env-file .env.local shop-sales-dashboard
```

### 3. Traditional VPS Deployment
```bash
# Install Node.js and PM2
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
npm install -g pm2

# Clone and setup project
git clone your-repo-url
cd shop-sales-dashboard
npm install
npm run build

# Start with PM2
pm2 start npm --name "sales-dashboard" -- start
pm2 save
pm2 startup
```

## Scheduled Tasks

### Daily Report Generation
```bash
# Add to crontab for daily reports at 8 PM
0 20 * * * curl -X POST https://your-domain.com/api/generate-report

# Or use Vercel Cron Jobs
# vercel.json
{
  "crons": [
    {
      "path": "/api/generate-report",
      "schedule": "0 20 * * *"
    }
  ]
}
```

## Monitoring and Logging

### Application Monitoring
```typescript
// lib/monitoring.ts
export function logSaleEvent(sale: any) {
  console.log('Sale recorded:', {
    id: sale.id,
    item: sale.item,
    total: sale.totalPrice,
    timestamp: sale.timestamp
  });
  
  // Send to monitoring service (optional)
  // analytics.track('sale_recorded', sale);
}
```

### Error Handling
```typescript
// lib/error-handler.ts
export function handleMCPError(error: any, connector: string) {
  console.error(`MCP ${connector} Error:`, error);
  
  // Send alert to owner
  // emailConnector.sendAlert(['owner@shop.com'], error.message, 'high');
}
```

## Security Considerations

### API Security
- Use environment variables for all API keys
- Implement rate limiting for API endpoints
- Use HTTPS in production
- Validate all input data

### Data Protection
- Encrypt sensitive data at rest
- Use secure connection strings
- Implement proper access controls
- Regular security audits

## Performance Optimization

### Caching Strategy
```typescript
// lib/cache.ts
import { Redis } from 'ioredis';

const redis = new Redis(process.env.REDIS_URL);

export async function cacheSalesData(key: string, data: any, ttl = 3600) {
  await redis.setex(key, ttl, JSON.stringify(data));
}

export async function getCachedSalesData(key: string) {
  const cached = await redis.get(key);
  return cached ? JSON.parse(cached) : null;
}
```

### Database Optimization
- Index frequently queried fields
- Use pagination for large datasets
- Implement data archiving strategy
- Monitor query performance

## Backup and Recovery

### Data Backup
```bash
# Automated Firestore backup
gcloud firestore export gs://your-backup-bucket/$(date +%Y%m%d)

# Scheduled backup script
#!/bin/bash
DATE=$(date +%Y%m%d)
gsutil -m cp -r gs://your-backup-bucket/$DATE ./backups/
```

### Recovery Procedures
1. Identify the backup date
2. Restore from Firestore export
3. Verify data integrity
4. Update application connections

## Support and Maintenance

### Regular Maintenance Tasks
- Monitor API rate limits
- Update dependencies monthly
- Review error logs weekly
- Test backup procedures quarterly

### Troubleshooting Common Issues
1. **MCP Connection Failures**: Check API keys and network connectivity
2. **Email Delivery Issues**: Verify SMTP credentials and spam filters
3. **WhatsApp API Limits**: Monitor message quotas and rate limits
4. **Chart Rendering Issues**: Check data format and browser compatibility

## Contact and Support
For technical support or questions about deployment:
- Create an issue in the project repository
- Contact the development team
- Review the troubleshooting guide

---

**Note**: This is a development framework. Replace all placeholder values with your actual service credentials and configurations.