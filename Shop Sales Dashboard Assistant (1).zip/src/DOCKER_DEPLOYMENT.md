# 🐳 Docker Deployment Guide

This guide explains how to deploy the Pharmacy Management System using Docker for production environments.

## 📋 Prerequisites

- Docker Engine 20.10+
- Docker Compose 2.0+ (optional but recommended)
- At least 2GB RAM
- 10GB disk space

## 🚀 Quick Start

### 1. Environment Setup

Copy the environment template and configure your settings:

```bash
cp .env.example .env.local
```

Edit `.env.local` with your actual configuration:

```bash
# Firebase Configuration (Required)
NEXT_PUBLIC_FIREBASE_API_KEY=your_firebase_api_key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_project_id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your_project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=123456789
NEXT_PUBLIC_FIREBASE_APP_ID=1:123456789:web:abcdef
NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID=G-XXXXXXXXXX

# AI Configuration (Optional)
GEMINI_API_KEY=your_gemini_api_key
OPENAI_API_KEY=your_openai_api_key

# Super Admin Configuration
NEXT_PUBLIC_SUPER_ADMIN_ACCESS_CODE=PHARMACY_MS_OWNER_2024

# App Configuration
NEXT_PUBLIC_APP_URL=https://your-domain.com
```

### 2. Deploy with Docker Compose (Recommended)

```bash
# Build and start the application
docker-compose up -d --build

# View logs
docker-compose logs -f pharmacy-ms

# Stop the application
docker-compose down
```

### 3. Deploy with Docker Commands

```bash
# Build the image
docker build -t pharmacy-ms .

# Run the container
docker run -d \
  --name pharmacy-ms-app \
  -p 3000:3000 \
  --env-file .env.local \
  --restart unless-stopped \
  pharmacy-ms

# View logs
docker logs -f pharmacy-ms-app

# Stop the container
docker stop pharmacy-ms-app
docker rm pharmacy-ms-app
```

### 4. Use Deployment Script

Make the script executable and run:

```bash
chmod +x scripts/deploy-docker.sh

# Deploy the application
./scripts/deploy-docker.sh deploy

# View logs
./scripts/deploy-docker.sh logs

# Stop the application
./scripts/deploy-docker.sh stop
```

## 🔧 Production Configuration

### SSL/HTTPS Setup

1. **Obtain SSL certificates** (Let's Encrypt, CloudFlare, etc.)

2. **Configure nginx for HTTPS**:
   - Place certificates in `./ssl/` directory
   - Uncomment HTTPS configuration in `nginx.conf`
   - Update `server_name` with your domain

3. **Deploy with nginx**:
   ```bash
   docker-compose --profile production up -d
   ```

### Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `NEXT_PUBLIC_FIREBASE_API_KEY` | Firebase API key | Yes |
| `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN` | Firebase auth domain | Yes |
| `NEXT_PUBLIC_FIREBASE_PROJECT_ID` | Firebase project ID | Yes |
| `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET` | Firebase storage bucket | Yes |
| `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID` | Firebase messaging sender ID | Yes |
| `NEXT_PUBLIC_FIREBASE_APP_ID` | Firebase app ID | Yes |
| `GEMINI_API_KEY` | Google Gemini API key | No |
| `OPENAI_API_KEY` | OpenAI API key | No |
| `NEXT_PUBLIC_SUPER_ADMIN_ACCESS_CODE` | Super admin access code | Yes |
| `NEXT_PUBLIC_APP_URL` | Application URL | Yes |

### Resource Requirements

| Environment | CPU | RAM | Storage |
|-------------|-----|-----|---------|
| Development | 1 core | 1GB | 5GB |
| Production | 2 cores | 2GB | 10GB |
| High Load | 4 cores | 4GB | 20GB |

## 🔍 Monitoring & Maintenance

### Health Checks

The application includes built-in health checks:

```bash
# Check application health
curl http://localhost:3000/api/health

# Docker health check
docker ps --format "table {{.Names}}\t{{.Status}}"
```

### Logs Management

```bash
# View real-time logs
docker-compose logs -f pharmacy-ms

# View logs from specific time
docker-compose logs --since "2h" pharmacy-ms

# Save logs to file
docker-compose logs pharmacy-ms > pharmacy-ms.log
```

### Backup & Updates

```bash
# Create backup (if using volumes)
docker run --rm -v pharmacy-ms_data:/data -v $(pwd):/backup alpine tar czf /backup/pharmacy-data.tar.gz /data

# Update application
git pull
docker-compose down
docker-compose up -d --build
```

## 🐛 Troubleshooting

### Common Issues

**1. Container won't start**
```bash
# Check logs
docker-compose logs pharmacy-ms

# Verify environment variables
docker exec pharmacy-ms env | grep FIREBASE
```

**2. Port already in use**
```bash
# Find process using port 3000
lsof -i :3000

# Kill process or change port in docker-compose.yml
```

**3. Firebase connection issues**
```bash
# Verify Firebase configuration
docker exec pharmacy-ms curl -f http://localhost:3000/api/health
```

**4. Out of memory**
```bash
# Check container memory usage
docker stats pharmacy-ms

# Increase memory limits in docker-compose.yml
```

### Performance Optimization

1. **Enable Gzip compression** (included in nginx.conf)
2. **Use Redis for caching** (optional)
3. **Configure CDN** for static assets
4. **Monitor resource usage** regularly

## 🔐 Security Considerations

1. **Use HTTPS in production**
2. **Keep containers updated**
3. **Limit exposed ports**
4. **Use secrets management**
5. **Regular security audits**

```bash
# Scan for vulnerabilities
docker scout cves pharmacy-ms

# Update base images
docker-compose pull
docker-compose up -d --build
```

## 📊 Scaling

### Horizontal Scaling

```yaml
# docker-compose.yml
services:
  pharmacy-ms:
    scale: 3
  nginx:
    depends_on:
      pharmacy-ms:
        condition: service_healthy
```

### Load Balancing

Configure nginx upstream with multiple backends:

```nginx
upstream pharmacy_ms {
    server pharmacy-ms_1:3000;
    server pharmacy-ms_2:3000;
    server pharmacy-ms_3:3000;
}
```

## 📞 Support

- **Application logs**: `docker-compose logs pharmacy-ms`
- **Health endpoint**: `http://localhost:3000/api/health`
- **Container status**: `docker-compose ps`

For production deployments, ensure proper monitoring, backup strategies, and security configurations are in place.