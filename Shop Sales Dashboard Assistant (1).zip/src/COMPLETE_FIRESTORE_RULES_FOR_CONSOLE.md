# 🚨 URGENT: Complete Firestore Rules for Console

Copy and paste these rules directly into the Firebase Console:

## Step 1: Go to Firebase Console
1. Open [Firebase Console](https://console.firebase.google.com)
2. Select your project
3. Go to **Firestore Database** → **Rules**
4. **Replace all existing content** with the rules below

## Step 2: Copy These Rules Exactly

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // ============================================================================
    // HELPER FUNCTIONS - Essential for role-based security
    // ============================================================================
    
    // Check if user is authenticated
    function isAuthenticated() {
      return request.auth != null;
    }
    
    // Get user profile with error handling
    function getUserProfile() {
      return get(/databases/$(database)/documents/profiles/$(request.auth.uid)).data;
    }
    
    // Check if user has specific role
    function hasRole(role) {
      return isAuthenticated() && getUserProfile().role == role;
    }
    
    // Check if user has any of the specified roles
    function hasAnyRole(roles) {
      return isAuthenticated() && getUserProfile().role in roles;
    }
    
    // Check if user belongs to shop
    function belongsToShop(shopId) {
      return isAuthenticated() && 
             (getUserProfile().shop_id == shopId || hasRole('admin'));
    }
    
    // Check if user is shop owner or admin
    function canManageShop(shopId) {
      return isAuthenticated() && 
             (hasRole('admin') || 
              (hasRole('owner') && belongsToShop(shopId)));
    }
    
    // Check if user can access reports
    function canAccessReports(shopId) {
      return isAuthenticated() && 
             (hasRole('admin') || 
              (hasAnyRole(['owner', 'manager']) && belongsToShop(shopId)));
    }
    
    // ============================================================================
    // USER PROFILES COLLECTION - Core authentication data
    // ============================================================================
    
    match /profiles/{userId} {
      // Users can always read and write their own profile
      allow read, write: if isAuthenticated() && request.auth.uid == userId;
      
      // Admins can read and write any profile
      allow read, write: if hasRole('admin');
      
      // Shop owners can read profiles of users in their shop
      allow read: if isAuthenticated() && 
                     hasRole('owner') && 
                     resource.data.shop_id == getUserProfile().shop_id;
      
      // Shop owners can update profiles of users in their shop (for role assignments)
      allow write: if isAuthenticated() && 
                      hasRole('owner') && 
                      (resource.data.shop_id == getUserProfile().shop_id || 
                       resource.data.shop_id == null) &&
                      // Prevent owners from creating admin accounts
                      request.resource.data.role != 'admin';
    }
    
    // ============================================================================
    // SHOPS COLLECTION - Shop information and settings
    // ============================================================================
    
    match /shops/{shopId} {
      // Admins have full access to all shops
      allow read, write: if hasRole('admin');
      
      // Shop owners can manage their own shop
      allow read, write: if isAuthenticated() && 
                            hasRole('owner') && 
                            resource.data.owner_id == request.auth.uid;
      
      // All shop members can read their shop information
      allow read: if belongsToShop(shopId);
      
      // Allow shop owners to create their shop during signup
      allow create: if isAuthenticated() && 
                       hasRole('owner') && 
                       request.auth.uid == resource.data.owner_id;
    }
    
    // ============================================================================
    // SALES COLLECTION - Critical for POS and transaction history
    // ============================================================================
    
    match /sales/{saleId} {
      // Admins have full access
      allow read, write: if hasRole('admin');
      
      // All shop members can read sales from their shop
      allow read: if belongsToShop(resource.data.shop_id);
      
      // Sales staff can create sales for their shop
      allow create: if isAuthenticated() && 
                       hasAnyRole(['seller', 'cashier', 'pharmacist', 'pharmacy_assistant', 'manager', 'owner']) &&
                       belongsToShop(resource.data.shop_id) &&
                       // Ensure the cashier_id matches current user (unless admin/owner)
                       (resource.data.cashier_id == request.auth.uid || 
                        hasAnyRole(['admin', 'owner', 'manager']));
      
      // Sales staff can update their own sales, managers/owners can update any
      allow update: if isAuthenticated() && 
                       belongsToShop(resource.data.shop_id) &&
                       ((resource.data.cashier_id == request.auth.uid && 
                         hasAnyRole(['cashier', 'seller', 'manager'])) ||
                        hasAnyRole(['admin', 'owner', 'manager']));
      
      // Only admins and owners can delete sales (void transactions)
      allow delete: if hasRole('admin') || canManageShop(resource.data.shop_id);
    }
    
    // ============================================================================
    // PRODUCTS COLLECTION - Pharmaceutical product catalog
    // ============================================================================
    
    match /products/{productId} {
      // Admins have full access
      allow read, write: if hasRole('admin');
      
      // All shop members can read products from their shop
      allow read: if belongsToShop(resource.data.shop_id);
      
      // Managers and owners can create and update products
      allow create, update: if isAuthenticated() && 
                               hasAnyRole(['manager', 'owner', 'admin']) &&
                               belongsToShop(resource.data.shop_id);
      
      // Only admins and owners can delete products
      allow delete: if hasRole('admin') || canManageShop(resource.data.shop_id);
    }
    
    // ============================================================================
    // CUSTOMERS COLLECTION - Customer accounts and information
    // ============================================================================
    
    match /customers/{customerId} {
      // Admins have full access
      allow read, write: if hasRole('admin');
      
      // Shop members can read customers from their shop
      allow read: if belongsToShop(resource.data.shop_id);
      
      // Sales staff and managers can create and update customers
      allow create, update: if isAuthenticated() && 
                               hasAnyRole(['seller', 'cashier', 'pharmacist', 'pharmacy_assistant', 'manager', 'owner', 'admin']) &&
                               belongsToShop(resource.data.shop_id);
      
      // Only admins and owners can delete customers
      allow delete: if hasRole('admin') || canManageShop(resource.data.shop_id);
    }
    
    // ============================================================================
    // PRESCRIPTIONS COLLECTION - Prescription tracking
    // ============================================================================
    
    match /prescriptions/{prescriptionId} {
      // Admins have full access
      allow read, write: if hasRole('admin');
      
      // Shop members can read prescriptions from their shop
      allow read: if belongsToShop(resource.data.shop_id);
      
      // Licensed staff can create and update prescriptions
      allow create, update: if isAuthenticated() && 
                               hasAnyRole(['cashier', 'pharmacist', 'pharmacy_assistant', 'manager', 'owner', 'admin']) &&
                               belongsToShop(resource.data.shop_id);
      
      // Managers, owners and admins can delete prescriptions
      allow delete: if hasRole('admin') || 
                       (isAuthenticated() && 
                        hasAnyRole(['owner', 'manager']) &&
                        belongsToShop(resource.data.shop_id));
    }
    
    // ============================================================================
    // PRODUCT BATCHES COLLECTION - Batch and expiry tracking
    // ============================================================================
    
    match /product_batches/{batchId} {
      // Admins have full access
      allow read, write: if hasRole('admin');
      
      // Shop members can read batches for their shop
      allow read: if belongsToShop(resource.data.shop_id);
      
      // Inventory staff and managers can manage batches
      allow create, update: if isAuthenticated() && 
                               hasAnyRole(['inventory_clerk', 'pharmacist', 'manager', 'owner', 'admin']) &&
                               belongsToShop(resource.data.shop_id);
      
      // Only admins and owners can delete batches
      allow delete: if hasRole('admin') || canManageShop(resource.data.shop_id);
    }
    
    // ============================================================================
    // SUPPLIERS COLLECTION - Supplier management
    // ============================================================================
    
    match /suppliers/{supplierId} {
      // Admins have full access
      allow read, write: if hasRole('admin');
      
      // Shop members can read suppliers from their shop
      allow read: if belongsToShop(resource.data.shop_id);
      
      // Managers and owners can create and update suppliers
      allow create, update: if isAuthenticated() && 
                               hasAnyRole(['manager', 'owner', 'admin']) &&
                               belongsToShop(resource.data.shop_id);
      
      // Only admins and owners can delete suppliers
      allow delete: if hasRole('admin') || canManageShop(resource.data.shop_id);
    }
    
    // ============================================================================
    // STOCK MOVEMENTS COLLECTION - Inventory tracking
    // ============================================================================
    
    match /stock_movements/{movementId} {
      // Admins have full access
      allow read, write: if hasRole('admin');
      
      // Shop members can read stock movements from their shop
      allow read: if belongsToShop(resource.data.shop_id);
      
      // Anyone who can process sales or manage inventory can create movements
      allow create: if isAuthenticated() && 
                       hasAnyRole(['seller', 'cashier', 'pharmacist', 'pharmacy_assistant', 'inventory_clerk', 'manager', 'owner', 'admin']) &&
                       belongsToShop(resource.data.shop_id) &&
                       resource.data.performed_by == request.auth.uid;
      
      // Only admins and owners can update/delete movements
      allow update, delete: if hasRole('admin') || canManageShop(resource.data.shop_id);
    }
    
    // ============================================================================
    // PURCHASE ORDERS COLLECTION - Purchasing management
    // ============================================================================
    
    match /purchase_orders/{poId} {
      // Admins have full access
      allow read, write: if hasRole('admin');
      
      // Shop members can read purchase orders from their shop
      allow read: if belongsToShop(resource.data.shop_id);
      
      // Managers and owners can create and update purchase orders
      allow create, update: if isAuthenticated() && 
                               hasAnyRole(['manager', 'owner', 'admin']) &&
                               belongsToShop(resource.data.shop_id);
      
      // Only admins and owners can delete purchase orders
      allow delete: if hasRole('admin') || canManageShop(resource.data.shop_id);
    }
    
    // ============================================================================
    // STOCK TRANSFERS COLLECTION - Inter-branch transfers
    // ============================================================================
    
    match /stock_transfers/{transferId} {
      // Admins have full access
      allow read, write: if hasRole('admin');
      
      // Shop members can read transfers from their shop
      allow read: if belongsToShop(resource.data.shop_id);
      
      // Managers and owners can create and update transfers
      allow create, update: if isAuthenticated() && 
                               hasAnyRole(['manager', 'owner', 'admin']) &&
                               belongsToShop(resource.data.shop_id);
      
      // Only admins and owners can delete transfers
      allow delete: if hasRole('admin') || canManageShop(resource.data.shop_id);
    }
    
    // ============================================================================
    // RETURN TRANSACTIONS COLLECTION - Returns and refunds
    // ============================================================================
    
    match /return_transactions/{returnId} {
      // Admins have full access
      allow read, write: if hasRole('admin');
      
      // Shop members can read returns from their shop
      allow read: if belongsToShop(resource.data.shop_id);
      
      // Staff who handle sales can create and update returns
      allow create, update: if isAuthenticated() && 
                               hasAnyRole(['cashier', 'pharmacist', 'pharmacy_assistant', 'manager', 'owner', 'admin']) &&
                               belongsToShop(resource.data.shop_id);
      
      // Only admins and owners can delete returns
      allow delete: if hasRole('admin') || canManageShop(resource.data.shop_id);
    }
    
    // ============================================================================
    // BRANCHES COLLECTION - Multi-branch support
    // ============================================================================
    
    match /branches/{branchId} {
      // Admins have full access
      allow read, write: if hasRole('admin');
      
      // Shop owners can manage branches in their shops
      allow read, write: if isAuthenticated() && 
                            hasRole('owner') && 
                            belongsToShop(resource.data.shop_id);
      
      // All shop members can read branch info
      allow read: if belongsToShop(resource.data.shop_id);
    }
    
    // ============================================================================
    // DAILY REPORTS COLLECTION - AI-generated reports
    // ============================================================================
    
    match /daily_reports/{reportId} {
      // Admins have full access
      allow read, write: if hasRole('admin');
      
      // Users who can access reports can read them
      allow read: if canAccessReports(resource.data.shop_id);
      
      // System and owners can create daily reports
      allow create: if hasRole('admin') || canManageShop(resource.data.shop_id);
      
      // Only admins and owners can update/delete reports
      allow update, delete: if hasRole('admin') || canManageShop(resource.data.shop_id);
    }
    
    // ============================================================================
    // NOTIFICATIONS COLLECTION - System alerts
    // ============================================================================
    
    match /notifications/{notificationId} {
      // Users can read their own notifications
      allow read: if isAuthenticated() && 
                     (resource.data.user_id == request.auth.uid || 
                      resource.data.user_id == null);
      
      // Users can update their own notifications (mark as read)
      allow update: if isAuthenticated() && 
                       resource.data.user_id == request.auth.uid;
      
      // System and managers can create notifications
      allow create: if isAuthenticated() && 
                       hasAnyRole(['admin', 'owner', 'manager', 'pharmacist']);
      
      // Admins can manage all notifications
      allow read, write: if hasRole('admin');
    }
    
    // ============================================================================
    // AUDIT LOGS COLLECTION - Security and compliance
    // ============================================================================
    
    match /audit_logs/{logId} {
      // Only admins and owners can read audit logs
      allow read: if hasRole('admin') || 
                     (hasRole('owner') && belongsToShop(resource.data.shop_id));
      
      // System can create audit logs
      allow create: if isAuthenticated();
      
      // Only admins can delete audit logs
      allow delete: if hasRole('admin');
    }
    
    // ============================================================================
    // INSURANCE CLAIMS COLLECTION - Insurance billing
    // ============================================================================
    
    match /insurance_claims/{claimId} {
      // Admins have full access
      allow read, write: if hasRole('admin');
      
      // Shop members can read claims from their shop
      allow read: if belongsToShop(resource.data.shop_id);
      
      // Licensed staff and managers can create and update insurance claims
      allow create, update: if isAuthenticated() && 
                               hasAnyRole(['cashier', 'pharmacist', 'pharmacy_assistant', 'manager', 'owner', 'admin']) &&
                               belongsToShop(resource.data.shop_id);
      
      // Only admins and owners can delete claims
      allow delete: if hasRole('admin') || canManageShop(resource.data.shop_id);
    }
    
    // ============================================================================
    // SYSTEM SETTINGS COLLECTION - Application configuration
    // ============================================================================
    
    match /system_settings/{settingId} {
      // All authenticated users can read system settings
      allow read: if isAuthenticated();
      
      // Only admins can modify system settings
      allow write: if hasRole('admin');
    }
    
    // ============================================================================
    // OFFLINE TRANSACTIONS COLLECTION - Offline mode support
    // ============================================================================
    
    match /offline_transactions/{transactionId} {
      // Admins have full access
      allow read, write: if hasRole('admin');
      
      // Users can read and manage their own offline transactions
      allow read: if isAuthenticated() && 
                     resource.data.user_id == request.auth.uid;
      
      // Users can create their own offline transactions
      allow create: if isAuthenticated() && 
                       resource.data.user_id == request.auth.uid &&
                       belongsToShop(resource.data.shop_id);
      
      // System can update sync status
      allow update: if isAuthenticated() && 
                       (resource.data.user_id == request.auth.uid || hasRole('admin'));
    }
    
    // ============================================================================
    // LEGACY COLLECTIONS - For backward compatibility
    // ============================================================================
    
    // Legacy inventory collection
    match /inventory/{inventoryId} {
      allow read: if isAuthenticated() && belongsToShop(resource.data.shop_id);
      allow create, update: if isAuthenticated() && 
                               hasAnyRole(['inventory_clerk', 'pharmacist', 'manager', 'owner', 'admin']) &&
                               belongsToShop(resource.data.shop_id);
      allow delete: if hasRole('admin') || canManageShop(resource.data.shop_id);
    }
    
    // Legacy analytics collection
    match /analytics/{analyticsId} {
      allow read: if canAccessReports(resource.data.shop_id);
      allow write: if hasRole('admin') || canManageShop(resource.data.shop_id);
    }
    
    // Legacy user sessions collection
    match /user_sessions/{sessionId} {
      allow read, write: if isAuthenticated() && 
                            resource.data.user_id == request.auth.uid;
    }
    
    // ============================================================================
    // CATCH-ALL RULES - For any additional collections
    // ============================================================================
    
    // Default rule for any other collections that might be added
    match /{collection}/{document} {
      // Admins can access everything
      allow read, write: if hasRole('admin');
      
      // For collections with shop_id field, apply shop-based access
      allow read: if isAuthenticated() && 
                     resource.data.keys().hasAny(['shop_id']) &&
                     belongsToShop(resource.data.shop_id);
    }
  }
}
```

## Step 3: Publish the Rules
1. Click **Publish** in the Firebase Console
2. Wait for "Rules published successfully" message
3. **Refresh your web application**
4. Try creating products again

## Step 4: Verify Success
- The permission errors should immediately disappear
- Product import should work without errors
- All Firebase operations should function normally

## Troubleshooting
If you still get errors after publishing:
1. **Wait 1-2 minutes** for rules to propagate
2. **Clear browser cache** and refresh
3. **Check your user profile** has:
   - `role`: 'admin', 'owner', or 'manager' 
   - `shop_id`: Valid shop ID
4. **Run the Firebase Permission Tester** in your app