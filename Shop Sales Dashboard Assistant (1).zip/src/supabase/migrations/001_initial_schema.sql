-- Create tables for Shop Sales Dashboard

-- Enable Row Level Security
ALTER DEFAULT PRIVILEGES REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;

-- Create shops table
CREATE TABLE shops (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  owner_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  settings JSONB DEFAULT '{"timezone": "UTC", "currency": "USD", "report_time": "20:00"}'::JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create profiles table (extends auth.users)
CREATE TABLE profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email TEXT NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('owner', 'seller', 'manager')),
  shop_id UUID REFERENCES shops(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create sales table
CREATE TABLE sales (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  item TEXT NOT NULL,
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  unit_price DECIMAL(10,2) NOT NULL CHECK (unit_price > 0),
  total_price DECIMAL(10,2) NOT NULL CHECK (total_price > 0),
  timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  seller_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  shop_id UUID REFERENCES shops(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create daily_reports table
CREATE TABLE daily_reports (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  date DATE NOT NULL,
  total_sales INTEGER NOT NULL DEFAULT 0,
  total_revenue DECIMAL(10,2) NOT NULL DEFAULT 0,
  average_transaction DECIMAL(10,2) NOT NULL DEFAULT 0,
  top_selling_item TEXT,
  insights TEXT[] DEFAULT '{}',
  recommendations TEXT[] DEFAULT '{}',
  trends JSONB DEFAULT '{"salesTrend": "stable", "peakHours": "N/A", "slowPeriods": "N/A"}'::JSONB,
  alerts TEXT[] DEFAULT '{}',
  shop_id UUID REFERENCES shops(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(date, shop_id)
);

-- Create indexes for better performance
CREATE INDEX idx_sales_shop_id ON sales(shop_id);
CREATE INDEX idx_sales_timestamp ON sales(timestamp);
CREATE INDEX idx_sales_seller_id ON sales(seller_id);
CREATE INDEX idx_daily_reports_shop_id ON daily_reports(shop_id);
CREATE INDEX idx_daily_reports_date ON daily_reports(date);
CREATE INDEX idx_profiles_shop_id ON profiles(shop_id);

-- Create updated_at triggers
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_shops_updated_at BEFORE UPDATE ON shops
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_sales_updated_at BEFORE UPDATE ON sales
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_daily_reports_updated_at BEFORE UPDATE ON daily_reports
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Enable Row Level Security
ALTER TABLE shops ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_reports ENABLE ROW LEVEL SECURITY;

-- RLS Policies for shops
CREATE POLICY "Shop owners can manage their shops" ON shops
  FOR ALL USING (owner_id = auth.uid());

CREATE POLICY "Shop members can view their shop" ON shops
  FOR SELECT USING (
    id IN (
      SELECT shop_id FROM profiles WHERE id = auth.uid()
    )
  );

-- RLS Policies for profiles
CREATE POLICY "Users can view and update their own profile" ON profiles
  FOR ALL USING (id = auth.uid());

CREATE POLICY "Shop owners can view all profiles in their shop" ON profiles
  FOR SELECT USING (
    shop_id IN (
      SELECT id FROM shops WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "Shop owners can update profiles in their shop" ON profiles
  FOR UPDATE USING (
    shop_id IN (
      SELECT id FROM shops WHERE owner_id = auth.uid()
    )
  );

-- RLS Policies for sales
CREATE POLICY "Users can view sales from their shop" ON sales
  FOR SELECT USING (
    shop_id IN (
      SELECT shop_id FROM profiles WHERE id = auth.uid()
    )
  );

CREATE POLICY "Sellers can create sales for their shop" ON sales
  FOR INSERT WITH CHECK (
    shop_id IN (
      SELECT shop_id FROM profiles WHERE id = auth.uid()
    ) AND
    seller_id = auth.uid()
  );

CREATE POLICY "Shop owners can manage all sales in their shop" ON sales
  FOR ALL USING (
    shop_id IN (
      SELECT id FROM shops WHERE owner_id = auth.uid()
    )
  );

-- RLS Policies for daily_reports
CREATE POLICY "Users can view reports from their shop" ON daily_reports
  FOR SELECT USING (
    shop_id IN (
      SELECT shop_id FROM profiles WHERE id = auth.uid()
    )
  );

CREATE POLICY "Shop owners can manage reports for their shop" ON daily_reports
  FOR ALL USING (
    shop_id IN (
      SELECT id FROM shops WHERE owner_id = auth.uid()
    )
  );

-- Function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'Anonymous User'),
    COALESCE(NEW.raw_user_meta_data->>'role', 'seller')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to automatically create profile on signup
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Function to generate daily reports
CREATE OR REPLACE FUNCTION generate_daily_report(shop_uuid UUID, report_date DATE)
RETURNS daily_reports AS $$
DECLARE
  report_record daily_reports;
  sales_data RECORD;
  top_product TEXT;
BEGIN
  -- Calculate daily metrics
  SELECT 
    COUNT(*) as total_sales,
    COALESCE(SUM(total_price), 0) as total_revenue,
    COALESCE(AVG(total_price), 0) as average_transaction
  INTO sales_data
  FROM sales 
  WHERE shop_id = shop_uuid 
    AND DATE(timestamp) = report_date;

  -- Get top selling item
  SELECT item INTO top_product
  FROM sales 
  WHERE shop_id = shop_uuid 
    AND DATE(timestamp) = report_date
  GROUP BY item 
  ORDER BY SUM(quantity) DESC 
  LIMIT 1;

  -- Insert or update daily report
  INSERT INTO daily_reports (
    date, 
    total_sales, 
    total_revenue, 
    average_transaction, 
    top_selling_item, 
    shop_id,
    insights,
    recommendations,
    trends
  ) VALUES (
    report_date,
    sales_data.total_sales,
    sales_data.total_revenue,
    sales_data.average_transaction,
    COALESCE(top_product, 'No sales'),
    shop_uuid,
    CASE 
      WHEN sales_data.total_sales = 0 THEN ARRAY['No sales recorded for this date']
      WHEN sales_data.total_revenue > 1000 THEN ARRAY['Exceptional performance! Revenue exceeded $1,000']
      WHEN sales_data.total_revenue > 500 THEN ARRAY['Strong performance with solid revenue above $500']
      ELSE ARRAY['Moderate sales performance with room for growth']
    END,
    CASE 
      WHEN sales_data.total_sales = 0 THEN ARRAY['Check system functionality and consider promotional activities']
      WHEN sales_data.average_transaction < 10 THEN ARRAY['Focus on upselling to increase average transaction value']
      ELSE ARRAY['Continue current sales strategies and monitor trends']
    END,
    jsonb_build_object(
      'salesTrend', 
      CASE 
        WHEN sales_data.total_revenue > 300 THEN 'increasing'
        WHEN sales_data.total_revenue > 150 THEN 'stable'
        ELSE 'declining'
      END,
      'peakHours', 'Analysis requires more data',
      'slowPeriods', 'Analysis requires more data'
    )
  )
  ON CONFLICT (date, shop_id) 
  DO UPDATE SET
    total_sales = EXCLUDED.total_sales,
    total_revenue = EXCLUDED.total_revenue,
    average_transaction = EXCLUDED.average_transaction,
    top_selling_item = EXCLUDED.top_selling_item,
    insights = EXCLUDED.insights,
    recommendations = EXCLUDED.recommendations,
    trends = EXCLUDED.trends,
    updated_at = NOW()
  RETURNING * INTO report_record;

  RETURN report_record;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;