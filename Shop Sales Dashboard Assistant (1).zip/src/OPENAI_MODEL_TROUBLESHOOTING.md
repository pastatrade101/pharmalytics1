# OpenAI Model Access & Troubleshooting Guide

This guide helps resolve OpenAI API model access issues in the Shop Sales Dashboard.

## 🔧 Common Error: Model Not Found

**Error Message:**
```
OpenAI API Error: 404 {
    "error": {
        "message": "The model `gpt-4` does not exist or you do not have access to it.",
        "type": "invalid_request_error",
        "param": null,
        "code": "model_not_found"
    }
}
```

## ✅ Solutions

### 1. **Automatic Model Fallback (Already Implemented)**

The app now automatically tries multiple models in order of accessibility:

1. `gpt-4o-mini` (Most accessible, cost-effective)
2. `gpt-3.5-turbo` (Widely available fallback)
3. `gpt-4o` (Latest GPT-4, if available)
4. `gpt-3.5-turbo-1106` (Additional fallback)
5. `gpt-4` (Original GPT-4, least accessible)

### 2. **Check Your OpenAI API Access**

**Free Tier Limitations:**
- Free tier accounts may only have access to `gpt-3.5-turbo`
- GPT-4 models require a paid account with usage credits

**How to Check:**
1. Visit [OpenAI Platform](https://platform.openai.com/account/usage)
2. Check your account type and available models
3. Verify you have sufficient credits/quota

### 3. **Update Your Configuration**

The environment is already configured with accessible models:

```env
OPENAI_MODEL=gpt-4o-mini          # Primary model (most accessible)
OPENAI_FALLBACK_MODEL=gpt-3.5-turbo  # Fallback model
```

### 4. **Verify API Key**

Ensure your API key is valid:
- Should start with `sk-`
- Should be from your OpenAI account
- Should have appropriate permissions

## 📊 Model Comparison

| Model | Accessibility | Cost | Performance | Best For |
|-------|--------------|------|-------------|----------|
| `gpt-4o-mini` | ⭐⭐⭐⭐⭐ | $ | ⭐⭐⭐⭐ | **Recommended** - Great balance |
| `gpt-3.5-turbo` | ⭐⭐⭐⭐⭐ | $ | ⭐⭐⭐ | Budget-friendly, reliable |
| `gpt-4o` | ⭐⭐⭐ | $$$ | ⭐⭐⭐⭐⭐ | Premium performance |
| `gpt-4` | ⭐⭐ | $$$$ | ⭐⭐⭐⭐⭐ | Legacy premium model |

## 🎯 App Behavior

### **With Working OpenAI API:**
✅ Real AI-generated insights and recommendations  
✅ Personalized business analysis  
✅ Dynamic report generation  
✅ Context-aware suggestions  

### **With Enhanced Mock Mode:**
✅ Intelligent mock analysis based on real data patterns  
✅ Realistic business insights and recommendations  
✅ Comprehensive reporting with detailed analysis  
✅ All features remain fully functional  

## 🔍 Testing Your Setup

1. **Check Model Access:**
   ```bash
   curl https://api.openai.com/v1/models \
     -H "Authorization: Bearer YOUR_API_KEY"
   ```

2. **Test a Simple Request:**
   ```bash
   curl https://api.openai.com/v1/chat/completions \
     -H "Content-Type: application/json" \
     -H "Authorization: Bearer YOUR_API_KEY" \
     -d '{
       "model": "gpt-4o-mini",
       "messages": [{"role": "user", "content": "Hello!"}],
       "max_tokens": 10
     }'
   ```

## 📈 Upgrading Your OpenAI Access

To access premium models:

1. **Add Payment Method:**
   - Go to [OpenAI Billing](https://platform.openai.com/account/billing)
   - Add a payment method
   - Set usage limits

2. **Purchase Credits:**
   - Buy credits for API usage
   - Monitor your usage patterns

3. **Request Model Access:**
   - Some models may require separate access requests
   - Check the [OpenAI Models page](https://platform.openai.com/docs/models)

## 🛠️ Advanced Configuration

### Custom Model Priority

You can customize the model fallback order by modifying `OPENAI_MODELS` in `/lib/openai-mcp.ts`:

```typescript
const OPENAI_MODELS = [
  'your-preferred-model',
  'gpt-4o-mini',
  'gpt-3.5-turbo',
  // ... other models
];
```

### Environment Variables

```env
# Primary model to try first
OPENAI_MODEL=gpt-4o-mini

# Fallback if primary fails
OPENAI_FALLBACK_MODEL=gpt-3.5-turbo

# Creativity level (0.0-2.0)
OPENAI_TEMPERATURE=0.7
```

## 🚨 Troubleshooting Steps

1. **Check Console Logs:**
   - Look for model names being tried
   - Check for specific error messages

2. **Verify API Key:**
   - Ensure it's correctly set in `.env.local`
   - Test with OpenAI's API directly

3. **Check Account Status:**
   - Verify billing status
   - Check usage quotas

4. **Test Fallback:**
   - The app should automatically fall back to mock mode
   - All features should remain available

## 💡 Best Practices

1. **Start with Accessible Models:**
   - Use `gpt-4o-mini` for most use cases
   - Only upgrade if you need premium features

2. **Monitor Usage:**
   - Track your API costs
   - Set reasonable usage limits

3. **Test Regularly:**
   - Verify your models are working
   - Check for any access changes

## 📞 Support

If you continue experiencing issues:

1. **Check OpenAI Status:** [status.openai.com](https://status.openai.com)
2. **Review Documentation:** [platform.openai.com/docs](https://platform.openai.com/docs)
3. **Contact OpenAI Support:** Through their platform
4. **Use Demo Mode:** The app works perfectly without OpenAI access!

Remember: **The Shop Sales Dashboard provides full functionality in mock mode** - OpenAI integration is an enhancement, not a requirement!