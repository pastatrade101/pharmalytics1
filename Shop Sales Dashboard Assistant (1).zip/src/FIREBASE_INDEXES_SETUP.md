# Firebase Firestore Indexes Setup Guide

The Shop Sales Dashboard requires specific Firestore indexes for optimal performance. Here's how to set them up:

## 🏗️ Required Composite Indexes

### 1. Shop Name Availability Index (CRITICAL - REQUIRED FOR PHARMACY CREATION)
**Collection:** `shops`  
**Fields:**
- `name` (Ascending)
- `status` (Ascending)
- `__name__` (Ascending)

**Purpose:** Enables checking if pharmacy names are available during registration.

**Direct Creation Link:** https://console.firebase.google.com/v1/r/project/shopsalesai/firestore/indexes?create_composite=Cklwcm9qZWN0cy9zaG9wc2FsZXNhaS9kYXRhYmFzZXMvKGRlZmF1bHQpL2NvbGxlY3Rpb25Hcm91cHMvc2hvcHMvaW5kZXhlcy9fEAEaCAoEbmFtZRABGgoKBnN0YXR1cxABGgwKCF9fbmFtZV9fEAE

### 2. Sales Collection Index
**Collection:** `sales`  
**Fields:**
- `shop_id` (Ascending)
- `timestamp` (Descending)

**Purpose:** Enables efficient querying of sales by shop with chronological ordering.

### 3. Daily Reports Collection Index (Optional)
**Collection:** `daily_reports`  
**Fields:**
- `shop_id` (Ascending)
- `date` (Descending)

**Purpose:** Enables efficient querying of reports by shop with date ordering.

## 🚀 Quick Setup Methods

### Method 1: Use Firebase Console Links (Recommended)

When you see the error in your browser console, Firebase provides direct links to create the indexes:

1. **Copy the URL from the error message** (starts with `https://console.firebase.google.com/...`)
2. **Open the URL in your browser** - this will take you directly to the index creation page
3. **Click "Create Index"** - Firebase will automatically configure the index with the correct fields
4. **Wait for creation** - indexes usually take a few minutes to build

### Method 2: Manual Creation via Firebase Console

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Select your "shopsalesai" project
3. Navigate to **Firestore Database** > **Indexes**
4. Click **Create Index**
5. Configure the index:
   - **Collection ID:** `sales`
   - **Field 1:** `shop_id` (Ascending)
   - **Field 2:** `timestamp` (Descending)
6. Click **Create**

### Method 3: Using Firebase CLI

If you have the Firebase CLI installed:

```bash
# Install Firebase CLI if not already installed
npm install -g firebase-tools

# Login to Firebase
firebase login

# Initialize Firestore in your project directory
firebase init firestore

# Create firestore.indexes.json file with:
{
  "indexes": [
    {
      "collectionGroup": "shops",
      "queryScope": "COLLECTION",
      "fields": [
        {
          "fieldPath": "name",
          "order": "ASCENDING"
        },
        {
          "fieldPath": "status",
          "order": "ASCENDING"
        },
        {
          "fieldPath": "__name__",
          "order": "ASCENDING"
        }
      ]
    },
    {
      "collectionGroup": "sales",
      "queryScope": "COLLECTION",
      "fields": [
        {
          "fieldPath": "shop_id",
          "order": "ASCENDING"
        },
        {
          "fieldPath": "timestamp",
          "order": "DESCENDING"
        }
      ]
    },
    {
      "collectionGroup": "daily_reports",
      "queryScope": "COLLECTION", 
      "fields": [
        {
          "fieldPath": "shop_id",
          "order": "ASCENDING"
        },
        {
          "fieldPath": "date",
          "order": "DESCENDING"
        }
      ]
    }
  ],
  "fieldOverrides": []
}

# Deploy the indexes
firebase deploy --only firestore:indexes
```

## ⏱️ Index Creation Time

- **Simple indexes:** Usually 1-2 minutes
- **Composite indexes:** Can take 5-15 minutes depending on existing data
- **Large collections:** May take longer

## 🔍 Verifying Index Status

1. Go to **Firebase Console** > **Firestore Database** > **Indexes**
2. Check that indexes show status: **Enabled** ✅
3. If status shows **Building** ⏳, wait for completion
4. If status shows **Error** ❌, review the configuration

## 🎯 App Behavior Without Indexes

**Good News:** The Shop Sales Dashboard is designed to work perfectly even without indexes!

### What Happens Without Indexes:
- ✅ **App continues to work** - Automatic fallback to Demo Mode
- ✅ **All features available** - Sales recording, AI analysis, dashboard
- ✅ **Realistic demo data** - Generated automatically for testing
- ✅ **No crashes or errors** - Graceful error handling

### What Happens With Indexes:
- 🚀 **Better performance** - Faster queries, especially with large datasets
- 🔄 **Real-time sync** - Live updates across multiple devices
- 💾 **Persistent data** - Data saved to Firebase cloud database
- 📊 **Multi-user access** - Multiple team members can access same data

## 🛠️ Troubleshooting

### Index Creation Failed
- **Check permissions:** Ensure you have Editor/Owner role on the Firebase project
- **Verify project:** Make sure you're in the correct Firebase project
- **Try again:** Index creation occasionally fails, retry after a few minutes

### Indexes Not Working
- **Clear browser cache:** Force refresh the application
- **Check index status:** Verify indexes show "Enabled" status in console
- **Wait longer:** Large datasets may need more time for index building

### App Still in Demo Mode
- **Refresh application:** Hard refresh (Ctrl+Shift+R / Cmd+Shift+R)
- **Check authentication:** Sign out and sign back in
- **Verify rules:** Ensure Firestore security rules are properly configured

## 📋 Performance Tips

1. **Create indexes early:** Set up indexes before adding large amounts of data
2. **Monitor usage:** Use Firebase console to track query performance
3. **Optimize queries:** Avoid queries that require multiple indexes
4. **Test with data:** Verify performance with realistic data volumes

## 🔧 Development vs Production

### Development
- Use simplified security rules for testing
- Indexes are less critical with small datasets
- Demo mode is perfectly suitable for development

### Production
- Implement proper security rules
- All indexes should be created and enabled
- Monitor performance and costs regularly

## 📞 Need Help?

If you're having trouble with index setup:

1. **Check the error message** - Firebase provides specific index creation links
2. **Use demo mode** - The app works perfectly without Firebase setup
3. **Review documentation** - Firebase has excellent documentation on indexes
4. **Contact support** - Firebase support can help with complex index issues

Remember: **The app works great in Demo Mode** - indexes are for performance optimization, not core functionality!