// This file is not needed - Firestore rules should be applied in Firebase Console
// See FIRESTORE_RULES_FOR_CONSOLE.md for instructions

export {}; // Make this a valid TypeScript module