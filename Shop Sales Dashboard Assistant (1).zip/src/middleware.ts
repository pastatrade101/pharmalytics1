import { NextRequest, NextResponse } from 'next/server';

export function middleware(request: NextRequest) {
  console.log('🔄 Middleware processing:', request.nextUrl.pathname, request.method);
  
  // For API routes, handle CORS and pass through to App Router
  if (request.nextUrl.pathname.startsWith('/api/')) {
    console.log('📡 API route detected:', request.nextUrl.pathname, request.method);
    console.log('📡 Full URL:', request.url);
    console.log('📡 Next URL pathname:', request.nextUrl.pathname);
    console.log('📡 Headers:', Object.fromEntries(request.headers.entries()));
    
    // Debug specific routes
    if (request.nextUrl.pathname === '/api/generate-report') {
      console.log('🎯 /api/generate-report route detected - checking App Router file...');
      console.log('🎯 Expected file: /app/api/generate-report/route.ts');
    }
    
    // Handle preflight OPTIONS requests for all API routes
    if (request.method === 'OPTIONS') {
      console.log('🔧 Handling OPTIONS preflight request');
      return new Response(null, { 
        status: 200, 
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type, Authorization',
          'Access-Control-Max-Age': '86400', // 24 hours
        }
      });
    }
    
    // For non-OPTIONS requests, continue to App Router with CORS headers
    const response = NextResponse.next();
    response.headers.set('Access-Control-Allow-Origin', '*');
    response.headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    console.log('✅ API request passed through middleware to App Router');
    console.log('✅ Response status will be determined by App Router route handler');
    return response;
  }
  
  // For non-API routes, just pass through
  return NextResponse.next();
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public folder
     */
    '/((?!_next/static|_next/image|favicon.ico|public/).*)' 
  ],
};