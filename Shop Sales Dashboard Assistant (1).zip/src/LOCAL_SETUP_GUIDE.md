# Shop Sales Dashboard Assistant - Local Setup Guide

This guide will help you clone and run the Shop Sales Dashboard Assistant in your local development environment.

## Prerequisites

Before starting, ensure you have the following installed:

- **Node.js** (version 18.0 or higher)
- **npm** or **yarn** package manager
- **Git** for cloning the repository
- A **Firebase account** for backend services
- A **Google Cloud account** for Gemini AI API access

## Step 1: Clone and Install Dependencies

```bash
# Clone the repository
git clone <your-repository-url>
cd shop-sales-dashboard

# Install dependencies
npm install
# or if using yarn
yarn install
```

## Step 2: Firebase Project Setup

### 2.1 Create Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click "Create a project"
3. Enter project name (e.g., "shop-sales-dashboard")
4. Enable Google Analytics (optional)
5. Create project

### 2.2 Enable Required Services

In your Firebase project console:

1. **Authentication**
   - Go to Authentication > Sign-in method
   - Enable "Email/Password" provider
   - Optionally enable other providers (Google, etc.)

2. **Firestore Database**
   - Go to Firestore Database
   - Click "Create database"
   - Choose "Start in test mode" (we'll update rules later)
   - Select your preferred location

3. **Firebase Hosting** (optional)
   - Go to Hosting
   - Click "Get started"
   - Follow setup instructions

### 2.3 Get Firebase Configuration

1. Go to Project Settings (gear icon)
2. Scroll to "Your apps" section
3. Click "Add app" > Web app
4. Register app with a nickname
5. Copy the Firebase configuration object

## Step 3: Gemini AI API Setup

### 3.1 Enable Gemini API

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Select your project (or create a new one)
3. Enable the "Generative Language API"
4. Go to "Credentials"
5. Create an API key
6. Restrict the API key to "Generative Language API" for security

## Step 4: Environment Configuration

### 4.1 Create Environment File

Copy the example environment file:

```bash
cp .env.example .env.local
```

### 4.2 Configure Environment Variables

Edit `.env.local` with your actual values:

```env
# Firebase Configuration
NEXT_PUBLIC_FIREBASE_API_KEY=your_firebase_api_key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_project_id.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_project_id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your_project_id.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
NEXT_PUBLIC_FIREBASE_APP_ID=your_app_id

# Gemini AI Configuration
NEXT_PUBLIC_GEMINI_API_KEY=your_gemini_api_key

# Application Settings
NEXT_PUBLIC_APP_ENV=development
NEXT_PUBLIC_DEBUG_MODE=true
```

## Step 5: Firebase Rules and Indexes Setup

### 5.1 Deploy Firestore Rules

The app includes a `firestore.rules` file. Deploy it using Firebase CLI:

```bash
# Install Firebase CLI globally
npm install -g firebase-tools

# Login to Firebase
firebase login

# Initialize Firebase in your project
firebase init

# Select:
# - Firestore: Configure rules and indexes files
# - Hosting: Configure files for Firebase Hosting (optional)

# Deploy rules
firebase deploy --only firestore:rules
```

### 5.2 Create Required Firestore Indexes

The app requires several composite indexes. Create them manually in the Firebase Console or use the indexes file:

1. Go to Firestore Database > Indexes
2. Create the following composite indexes:

**Sales Collection:**
- Fields: `shop_id` (Ascending), `date` (Descending)
- Fields: `shop_id` (Ascending), `seller_id` (Ascending), `date` (Descending)

**Products Collection:**
- Fields: `shop_id` (Ascending), `category` (Ascending)
- Fields: `shop_id` (Ascending), `status` (Ascending)

**Users Collection:**
- Fields: `shop_id` (Ascending), `role` (Ascending)

## Step 6: Initial Data Setup

### 6.1 Create Admin User

1. Start the development server (see Step 7)
2. Register as the first user (this will be the shop owner)
3. Complete the shop registration process

### 6.2 Sample Data (Optional)

The app includes mock data for development. You can populate sample data by:

1. Accessing the admin panel in the app
2. Using the built-in data generation features
3. Importing sample products and sales data

## Step 7: Run the Application

### 7.1 Development Mode

```bash
npm run dev
# or
yarn dev
```

The application will be available at `http://localhost:3000`

### 7.2 Build for Production

```bash
npm run build
npm run start
# or
yarn build
yarn start
```

## Step 8: Verify Setup

### 8.1 Check Application Status

1. Open `http://localhost:3000`
2. Verify the loading screen shows no critical errors
3. Register a new account
4. Check that authentication works
5. Verify dashboard loads correctly

### 8.2 Test Key Features

- **Authentication**: Register and sign in
- **Role Management**: Create users with different roles
- **Sales Recording**: Add sample sales data
- **Dashboard**: View analytics and reports
- **AI Integration**: Test report generation

## Troubleshooting

### Common Issues

**1. Firebase Permission Errors**
```
Error: permission-denied
```
**Solution**: Deploy Firestore rules using `firebase deploy --only firestore:rules`

**2. Gemini API Errors**
```
Error: API key not valid
```
**Solution**: 
- Verify API key is correct in `.env.local`
- Enable "Generative Language API" in Google Cloud Console
- Check API key restrictions

**3. Build Errors**
```
Module not found: Can't resolve 'package'
```
**Solution**: 
- Delete `node_modules` and `package-lock.json`
- Run `npm install` again
- Check for version conflicts

**4. Firestore Index Errors**
```
The query requires an index
```
**Solution**: Create the required composite indexes in Firebase Console

**5. Environment Variables Not Loading**
```
process.env.NEXT_PUBLIC_* is undefined
```
**Solution**: 
- Ensure `.env.local` exists in root directory
- Verify variable names start with `NEXT_PUBLIC_`
- Restart development server

### Debug Mode

The app includes comprehensive debugging:

1. Set `NEXT_PUBLIC_DEBUG_MODE=true` in `.env.local`
2. Open browser developer tools
3. Check console for detailed logs
4. Use the debug panel in the app interface

### Performance Optimization

For better development experience:

1. **Firebase Emulator** (optional):
```bash
firebase emulators:start
```

2. **Hot Reload**: Ensure you're using `npm run dev` for hot reloading

3. **Error Boundary**: The app includes error boundaries for better debugging

## Project Structure Overview

```
shop-sales-dashboard/
├── components/          # React components
├── lib/                # Utility functions and services
├── hooks/              # Custom React hooks
├── contexts/           # React contexts
├── styles/             # Global styles (Tailwind v4)
├── api/                # API routes
└── public/             # Static assets
```

## Next Steps

After successful setup:

1. **Customize Business Settings**: Configure your shop details
2. **Add Team Members**: Create user accounts for your team
3. **Import Products**: Add your product catalog
4. **Configure Integrations**: Set up Google Sheets and notification APIs
5. **Deploy to Production**: Use Firebase Hosting or Vercel

## Support

If you encounter issues:

1. Check the console logs in debug mode
2. Verify all environment variables are set correctly
3. Ensure Firebase rules and indexes are deployed
4. Check the project's documentation files:
   - `FIREBASE_SETUP.md`
   - `FIRESTORE_RULES_DEPLOYMENT_GUIDE.md`
   - `DEPLOYMENT.md`

## Security Notes

- Never commit `.env.local` to version control
- Use Firebase Security Rules in production
- Restrict API keys to specific services
- Regularly rotate API keys
- The app is designed to not collect PII beyond necessary business operations