# Firestore Security Rules for Firebase Console

⚠️ **IMPORTANT**: These rules must be applied in the Firebase Console, not as a file in your project.

## How to Apply These Rules:

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Select your "shopsalesai" project
3. Navigate to **Firestore Database** > **Rules**
4. Replace the existing rules with the content below
5. Click **Publish**

## Firestore Rules (Copy and paste into Firebase Console):

```javascript
rules_version = '2';

service cloud.firestore {
  match /databases/{database}/documents {
    // Allow read/write access to all authenticated users
    // This is a simplified ruleset for development
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

## For Production Use (More Secure Rules):

Once your app is working, replace with these more secure rules:

```javascript
rules_version = '2';

service cloud.firestore {
  match /databases/{database}/documents {
    // Users can read and write their own profile
    match /profiles/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Allow authenticated users to create and read shops
    match /shops/{shopId} {
      allow read, write: if request.auth != null;
    }
    
    // Allow authenticated users to create and read sales
    match /sales/{saleId} {
      allow read, write: if request.auth != null;
    }
    
    // Allow authenticated users to create and read reports
    match /daily_reports/{reportId} {
      allow read, write: if request.auth != null;
    }
  }
}
```

## Testing Your Rules:

1. After applying the rules, try signing in to your app
2. Try creating a sale to test write permissions
3. Check the browser console for any remaining permission errors

## If Rules Don't Work:

The app includes comprehensive demo mode fallback, so it will continue to work even if Firebase permissions are not configured properly. All features will be available in demo mode.

## Demo Mode vs Firebase Mode:

- **Demo Mode**: All data is stored locally in memory, perfect for testing
- **Firebase Mode**: Real-time data sync across devices, persistent storage
- **Automatic Fallback**: App automatically switches to demo mode if Firebase permissions fail

Your app will work perfectly in either mode!