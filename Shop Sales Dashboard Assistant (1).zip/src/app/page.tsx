'use client';

import App from '../App';

export default function HomePage() {
  return <App />;
}