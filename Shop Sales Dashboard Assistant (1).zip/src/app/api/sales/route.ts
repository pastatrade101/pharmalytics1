import { NextRequest, NextResponse } from 'next/server';

// Handle OPTIONS preflight requests
export async function OPTIONS(request: NextRequest) {
  console.log('🔧 Sales API OPTIONS preflight request received');
  
  return new Response(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Max-Age': '86400', // 24 hours
    },
  });
}

export async function GET(request: NextRequest) {
  console.log('🛒 Sales API GET called');
  console.log('📍 URL:', request.url);
  
  const response = NextResponse.json({
    message: 'Sales API endpoint is operational',
    timestamp: new Date().toISOString(),
    status: 'ready',
    endpoint: '/api/sales',
    source: 'app-router',
    methods: ['GET', 'POST', 'OPTIONS']
  });
  
  response.headers.set('Cache-Control', 'no-store');
  response.headers.set('Access-Control-Allow-Origin', '*');
  response.headers.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  return response;
}

export async function POST(request: NextRequest) {
  console.log('🛒 Sales API POST called');
  
  try {
    const body = await request.json();
    console.log('📊 Sales data received:', body);
    
    // Here you would typically process the sales data
    // For now, just return a success response
    
    const response = NextResponse.json({
      success: true,
      message: 'Sales data processed successfully',
      timestamp: new Date().toISOString(),
      receivedData: body,
      source: 'app-router',
      methods: ['GET', 'POST', 'OPTIONS']
    });
    
    response.headers.set('Access-Control-Allow-Origin', '*');
    response.headers.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    return response;
  } catch (error: any) {
    console.error('❌ Sales API error:', error);
    
    const response = NextResponse.json(
      { error: 'Failed to process sales data', message: error.message },
      { status: 500 }
    );
    response.headers.set('Access-Control-Allow-Origin', '*');
    
    return response;
  }
}