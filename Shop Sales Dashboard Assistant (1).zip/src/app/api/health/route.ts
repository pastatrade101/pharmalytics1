import { NextRequest, NextResponse } from 'next/server';

// Handle OPTIONS preflight requests
export async function OPTIONS(request: NextRequest) {
  console.log('🔧 Health API OPTIONS preflight request received');
  
  return new Response(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Max-Age': '86400', // 24 hours
    },
  });
}

export async function GET(request: NextRequest) {
  console.log('🔍 Health check API called');
  console.log('📍 URL:', request.url);
  console.log('📍 Method:', request.method);
  console.log('🎯 App Router route.ts handler executing successfully');
  
  try {
    const response = NextResponse.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      message: 'App Router API is working correctly',
      endpoint: '/api/health',
      source: 'app-router',
      file: '/app/api/health/route.ts',
      methods: ['GET', 'POST', 'OPTIONS'],
      debug: {
        nodeEnv: process.env.NODE_ENV,
        requestMethod: request.method,
        requestUrl: request.url,
        pathname: request.nextUrl.pathname
      }
    });
    
    response.headers.set('Cache-Control', 'no-store');
    response.headers.set('Access-Control-Allow-Origin', '*');
    response.headers.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    console.log('✅ Health check response prepared successfully');
    return response;
  } catch (error) {
    console.error('❌ Health check error:', error);
    return NextResponse.json(
      { error: 'Health check failed', message: error.message },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  console.log('🔍 Health check POST called');
  
  try {
    const body = await request.json();
    
    const response = NextResponse.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      message: 'App Router API POST is working correctly',
      receivedData: body,
      endpoint: '/api/health',
      source: 'app-router',
      methods: ['GET', 'POST', 'OPTIONS']
    });
    
    response.headers.set('Access-Control-Allow-Origin', '*');
    response.headers.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    return response;
  } catch (error: any) {
    console.error('❌ Health API POST error:', error);
    
    const response = NextResponse.json(
      { error: 'Failed to process request', message: error.message },
      { status: 400 }
    );
    response.headers.set('Access-Control-Allow-Origin', '*');
    
    return response;
  }
}