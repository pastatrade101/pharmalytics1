// This file has been moved to /middleware.ts at the root level
// Middleware in Next.js App Router should be at the root, not in api directory