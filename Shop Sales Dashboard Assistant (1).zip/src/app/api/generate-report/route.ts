import { NextRequest, NextResponse } from 'next/server';

interface BusinessData {
  pharmacyName: string;
  timeframe: string;
  metrics: {
    revenue: number;
    transactions: number;
    products: number;
    activeProducts: number;
    lowStock: number;
    expiring: number;
    expired: number;
    avgTransactionValue: number;
    monthlyGrowth: number;
  };
  topProducts: Array<{
    name: string;
    sales: number;
    revenue: number;
  }>;
  recentActivity: number;
}

interface UserContext {
  role: string;
  pharmacyType: string;
}

// Handle OPTIONS preflight requests
export async function OPTIONS(request: NextRequest) {
  console.log('🔧 OPTIONS preflight request received');
  
  return new Response(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Max-Age': '86400', // 24 hours
    },
  });
}

export async function POST(request: NextRequest) {
  console.log('🚀🚀🚀 APP ROUTER POST /api/generate-report endpoint called successfully');
  console.log('📍 This is the App Router endpoint at /app/api/generate-report/route.ts');
  console.log('📡 Request URL:', request.url);
  console.log('📡 Request method:', request.method);
  console.log('📡 Headers:', Object.fromEntries(request.headers.entries()));
  console.log('📡 Timestamp:', new Date().toISOString());
  console.log('🔧 App Router working correctly - this is the right endpoint');
  console.log('⚡ POST handler is executing - API route is definitely accessible');
  console.log('✨ SYNTAX ERROR FIXED - POST should now work correctly');
  
  let businessData: BusinessData | null = null;
  
  try {
    console.log('📥 Parsing request body...');
    
    // Check if request has a body
    const contentLength = request.headers.get('content-length');
    console.log('📏 Content-Length:', contentLength);
    
    if (!contentLength || contentLength === '0') {
      const response = NextResponse.json(
        { error: 'Request body is required' },
        { status: 400 }
      );
      response.headers.set('Access-Control-Allow-Origin', '*');
      return response;
    }
    
    let requestBody;
    try {
      requestBody = await request.json();
      console.log('📊 Request body received:', JSON.stringify(requestBody, null, 2));
    } catch (parseError) {
      console.error('❌ Failed to parse request JSON:', parseError);
      const response = NextResponse.json(
        { error: 'Invalid JSON in request body' },
        { status: 400 }
      );
      response.headers.set('Access-Control-Allow-Origin', '*');
      return response;
    }
    
    const { type, data, userProfile } = requestBody;

    if (type !== 'business_intelligence') {
      console.error('❌ Invalid report type received:', type);
      const response = NextResponse.json(
        { error: `Invalid report type: ${type}. Expected: business_intelligence` },
        { status: 400 }
      );
      response.headers.set('Access-Control-Allow-Origin', '*');
      return response;
    }

    console.log('✅ Valid business intelligence request received');

    businessData = data as BusinessData;
    const userContext = userProfile as UserContext;

    // Check if Gemini API is available
    console.log('🔑 Checking Gemini API key availability...');
    console.log('🔑 GEMINI_API_KEY exists:', !!process.env.GEMINI_API_KEY);
    console.log('🔑 GEMINI_API_KEY length:', process.env.GEMINI_API_KEY?.length || 0);
    
    if (!process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY.trim() === '') {
      console.log('🔑 Gemini API key not found, using fallback analysis');
      const response = NextResponse.json({
        summary: generateFallbackSummary(businessData),
        insights: generateFallbackInsights(businessData),
        recommendations: generateFallbackRecommendations(businessData),
        predictions: generateFallbackPredictions(businessData),
        source: 'fallback-no-key'
      });
      response.headers.set('Access-Control-Allow-Origin', '*');
      response.headers.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
      response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
      return response;
    }

    // Generate AI analysis using Gemini
    console.log('🤖 Generating AI business intelligence report with Gemini...');
    console.log('🔧 Initializing Gemini model...');
    
    let genAI: any;
    let model: any;
    
    try {
      console.log('🔧 Attempting to import Google Generative AI package...');
      const { GoogleGenerativeAI } = await import('@google/generative-ai');
      console.log('✅ Google Generative AI package imported successfully');
      
      genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');
      console.log('✅ Gemini client initialized');
      
      model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
      console.log('✅ Gemini model initialized successfully');
    } catch (initError: any) {
      console.error('❌ Failed to initialize Gemini model:', initError);
      console.error('❌ Error type:', typeof initError);
      console.error('❌ Error message:', initError.message);
      console.error('❌ Error code:', initError.code);
      console.error('❌ Error stack:', initError.stack);
      
      // If Gemini package is not available, use fallback
      if (initError.message?.includes('Cannot resolve module') || 
          initError.message?.includes('Module not found') ||
          initError.code === 'MODULE_NOT_FOUND' ||
          initError.message?.includes('@google/generative-ai')) {
        console.log('📦 Gemini package not available, using intelligent fallback analysis');
        const response = NextResponse.json({
          summary: generateFallbackSummary(businessData),
          insights: generateFallbackInsights(businessData),
          recommendations: generateFallbackRecommendations(businessData),
          predictions: generateFallbackPredictions(businessData),
          source: 'fallback-no-package'
        });
        response.headers.set('Access-Control-Allow-Origin', '*');
        response.headers.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
        response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
        return response;
      }
      
      throw new Error(`Gemini initialization failed: ${initError.message}`);
    }

    const prompt = `
You are an AI business analyst specializing in pharmacy operations in Tanzania. Analyze the following pharmacy business data and provide strategic insights for a ${userContext.role} of a ${userContext.pharmacyType}.

PHARMACY DATA:
- Pharmacy: ${businessData.pharmacyName}
- Analysis Period: ${businessData.timeframe}
- Total Revenue: TZS ${businessData.metrics.revenue.toLocaleString()}
- Transactions: ${businessData.metrics.transactions}
- Products: ${businessData.metrics.products} total (${businessData.metrics.activeProducts} active)
- Low Stock Items: ${businessData.metrics.lowStock}
- Expiring Items: ${businessData.metrics.expiring}
- Expired Items: ${businessData.metrics.expired}
- Average Transaction: TZS ${businessData.metrics.avgTransactionValue.toLocaleString()}
- Monthly Growth: ${businessData.metrics.monthlyGrowth.toFixed(1)}%

TOP PRODUCTS:
${businessData.topProducts.map(p => `- ${p.name}: ${p.sales} sales, TZS ${p.revenue.toLocaleString()} revenue`).join('\n')}

Please provide a comprehensive business intelligence report in the following JSON format:

{
  "summary": "A comprehensive 2-3 sentence executive summary of the pharmacy's current performance and key findings",
  "insights": [
    {
      "type": "opportunity|risk|trend|recommendation",
      "title": "Insight Title",
      "description": "Detailed description of the insight with specific numbers",
      "impact": "high|medium|low",
      "actionable": true|false,
      "metrics": ["relevant metric names"]
    }
  ],
  "recommendations": [
    "Specific actionable recommendations based on the data (5-7 recommendations)"
  ],
  "predictions": [
    "Data-driven predictions about future performance and trends (3-5 predictions)"
  ]
}

Focus on:
1. Tanzania pharmacy market context (currency TZS, local market conditions)
2. Inventory optimization (especially expiry management in tropical climate)
3. Revenue growth opportunities
4. Risk mitigation strategies
5. Operational efficiency improvements
6. Customer satisfaction and loyalty
7. Supply chain optimization for pharmacy products

Provide specific, actionable insights that a pharmacy owner can implement immediately. Consider seasonal factors, local competition, and regulatory requirements for pharmacies in Tanzania.
`;

    console.log('📝 Sending prompt to Gemini API...');
    console.log('📝 Prompt length:', prompt.length);
    
    const result = await model.generateContent(prompt);
    console.log('✅ Gemini API response received');
    
    const response = result.response;
    console.log('✅ Response object extracted');
    
    const text = response.text();
    console.log('✅ Response text extracted, length:', text.length);
    console.log('📄 Raw response preview:', text.substring(0, 200) + '...');

    // Parse the JSON response
    try {
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error('No JSON found in response');
      }

      const aiAnalysis = JSON.parse(jsonMatch[0]);
      
      console.log('✅ Gemini AI analysis generated successfully');
      
      const response = NextResponse.json({
        ...aiAnalysis,
        source: 'gemini'
      });
      
      // Add CORS headers
      response.headers.set('Access-Control-Allow-Origin', '*');
      response.headers.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
      response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
      
      return response;

    } catch (parseError) {
      console.error('❌ Failed to parse Gemini response:', parseError);
      console.log('Raw Gemini response:', text);
      
      // Fall back to intelligent parsing if JSON parsing fails
      const response = NextResponse.json({
        summary: extractSummaryFromText(text, businessData),
        insights: generateFallbackInsights(businessData),
        recommendations: extractRecommendationsFromText(text, businessData),
        predictions: generateFallbackPredictions(businessData),
        source: 'gemini-parsed'
      });
      response.headers.set('Access-Control-Allow-Origin', '*');
      return response;
    }

  } catch (error: any) {
    console.error('❌ Error generating AI report:', error);
    console.error('Error details:', {
      message: error.message,
      stack: error.stack,
      name: error.name
    });

    // Use the businessData variable that should be available in this scope
    const fallbackData = businessData || {
      pharmacyName: 'Your Pharmacy',
      timeframe: 'Recent period',
      metrics: {
        revenue: 0,
        transactions: 0,
        products: 0,
        activeProducts: 0,
        lowStock: 0,
        expiring: 0,
        expired: 0,
        avgTransactionValue: 0,
        monthlyGrowth: 0
      },
      topProducts: [],
      recentActivity: 0
    };

    // Check for specific Gemini API errors
    if (error?.message?.includes('quota')) {
      console.log('💰 Gemini API quota exceeded, using intelligent fallback');
      const response = NextResponse.json({
        summary: generateFallbackSummary(fallbackData),
        insights: generateFallbackInsights(fallbackData),
        recommendations: generateFallbackRecommendations(fallbackData),
        predictions: generateFallbackPredictions(fallbackData),
        source: 'fallback-quota'
      });
      response.headers.set('Access-Control-Allow-Origin', '*');
      return response;
    }

    if (error?.message?.includes('API key')) {
      console.log('🔑 Gemini API authentication error, using fallback');
      const response = NextResponse.json({
        summary: generateFallbackSummary(fallbackData),
        insights: generateFallbackInsights(fallbackData),
        recommendations: generateFallbackRecommendations(fallbackData),
        predictions: generateFallbackPredictions(fallbackData),
        source: 'fallback-auth'
      });
      response.headers.set('Access-Control-Allow-Origin', '*');
      return response;
    }

    // Check for network/connection errors
    if (error?.message?.includes('fetch') || error?.message?.includes('network') || error?.message?.includes('ENOTFOUND')) {
      console.log('🌐 Network error connecting to Gemini API, using fallback');
      const response = NextResponse.json({
        summary: generateFallbackSummary(fallbackData),
        insights: generateFallbackInsights(fallbackData),
        recommendations: generateFallbackRecommendations(fallbackData),
        predictions: generateFallbackPredictions(fallbackData),
        source: 'fallback-network'
      });
      response.headers.set('Access-Control-Allow-Origin', '*');
      return response;
    }

    // Generic fallback for any other errors
    console.log('🔄 Using intelligent fallback analysis due to unexpected error');
    const response = NextResponse.json({
      summary: generateFallbackSummary(fallbackData),
      insights: generateFallbackInsights(fallbackData),
      recommendations: generateFallbackRecommendations(fallbackData),
      predictions: generateFallbackPredictions(fallbackData),
      source: 'fallback-error'
    });
    response.headers.set('Access-Control-Allow-Origin', '*');
    return response;
  }
}

// Fallback analysis functions
function generateFallbackSummary(data: BusinessData): string {
  const growthText = data.metrics.monthlyGrowth > 0 ? 'growing' : 
                   data.metrics.monthlyGrowth < 0 ? 'declining' : 'stable';
  
  return `${data.pharmacyName} has generated TZS ${data.metrics.revenue.toLocaleString()} in total revenue from ${data.metrics.transactions} transactions. Monthly performance is ${growthText} with ${data.metrics.monthlyGrowth > 0 ? '+' : ''}${data.metrics.monthlyGrowth.toFixed(1)}% change. Key attention areas include ${data.metrics.lowStock} low-stock items and ${data.metrics.expiring} products expiring soon, presenting both operational risks and optimization opportunities.`;
}

function generateFallbackInsights(data: BusinessData): Array<any> {
  const insights = [];

  // Growth analysis
  if (data.metrics.monthlyGrowth > 10) {
    insights.push({
      type: 'opportunity',
      title: 'Exceptional Growth Momentum',
      description: `Revenue is growing at ${data.metrics.monthlyGrowth.toFixed(1)}% monthly, significantly above pharmacy industry average. This indicates strong market position and customer satisfaction.`,
      impact: 'high',
      actionable: true,
      metrics: ['Monthly Growth', 'Revenue']
    });
  } else if (data.metrics.monthlyGrowth > 0) {
    insights.push({
      type: 'trend',
      title: 'Positive Growth Trend',
      description: `Steady growth of ${data.metrics.monthlyGrowth.toFixed(1)}% monthly shows healthy business trajectory. Consider strategies to accelerate growth.`,
      impact: 'medium',
      actionable: true,
      metrics: ['Monthly Growth']
    });
  } else if (data.metrics.monthlyGrowth < -5) {
    insights.push({
      type: 'risk',
      title: 'Revenue Decline Alert',
      description: `Revenue is declining at ${Math.abs(data.metrics.monthlyGrowth).toFixed(1)}% monthly. Immediate intervention required to identify and address root causes.`,
      impact: 'high',
      actionable: true,
      metrics: ['Monthly Growth', 'Revenue']
    });
  }

  // Inventory management
  if (data.metrics.lowStock > data.metrics.activeProducts * 0.1) {
    insights.push({
      type: 'risk',
      title: 'Critical Inventory Shortage',
      description: `${data.metrics.lowStock} products (${(data.metrics.lowStock / data.metrics.activeProducts * 100).toFixed(1)}%) are running low. This high percentage indicates systemic inventory management issues.`,
      impact: 'high',
      actionable: true,
      metrics: ['Low Stock Items', 'Inventory Turnover']
    });
  } else if (data.metrics.lowStock > 5) {
    insights.push({
      type: 'risk',
      title: 'Inventory Restocking Required',
      description: `${data.metrics.lowStock} products require immediate reordering to prevent stockouts and maintain customer satisfaction.`,
      impact: 'medium',
      actionable: true,
      metrics: ['Low Stock Items']
    });
  }

  // Expiry management
  if (data.metrics.expiring > 0) {
    const expiryRatio = data.metrics.expiring / data.metrics.activeProducts;
    const impact = expiryRatio > 0.05 ? 'high' : 'medium';
    
    insights.push({
      type: 'risk',
      title: 'Product Expiry Management',
      description: `${data.metrics.expiring} products are expiring soon (${(expiryRatio * 100).toFixed(1)}% of active inventory). In Tanzania's climate, proper expiry management is crucial for regulatory compliance and profitability.`,
      impact,
      actionable: true,
      metrics: ['Expiring Products', 'Inventory Management']
    });
  }

  return insights;
}

function generateFallbackRecommendations(data: BusinessData): string[] {
  const recommendations = [];

  if (data.metrics.lowStock > 0) {
    recommendations.push(`Implement automated reorder points for ${data.metrics.lowStock} low-stock items to prevent future stockouts`);
    recommendations.push('Establish relationships with multiple suppliers to ensure consistent product availability');
  }

  if (data.metrics.expiring > 0) {
    recommendations.push(`Create promotional campaigns for ${data.metrics.expiring} expiring products to minimize waste and recover costs`);
    recommendations.push('Implement FEFO (First Expired, First Out) inventory rotation system');
  }

  if (data.metrics.monthlyGrowth > 5) {
    recommendations.push('Leverage current growth momentum by expanding successful product categories and services');
  } else if (data.metrics.monthlyGrowth < 0) {
    recommendations.push('Conduct customer survey to identify service gaps and competitive disadvantages');
  }

  recommendations.push('Install pharmacy management software to track sales patterns and automate inventory management');
  recommendations.push('Consider offering mobile money payment options (M-Pesa, Tigo Pesa) to attract more customers');

  return recommendations.slice(0, 7);
}

function generateFallbackPredictions(data: BusinessData): string[] {
  const predictions = [];

  if (data.metrics.monthlyGrowth > 0) {
    const projectedRevenue = data.metrics.revenue * (1 + data.metrics.monthlyGrowth / 100);
    predictions.push(`Based on current ${data.metrics.monthlyGrowth.toFixed(1)}% growth rate, next month's revenue may reach TZS ${projectedRevenue.toLocaleString()}`);
  }

  if (data.metrics.lowStock > 0) {
    const reorderQuantity = Math.floor(data.metrics.lowStock * 1.3);
    predictions.push(`Inventory analysis suggests reordering ${reorderQuantity} items within the next week to maintain optimal stock levels`);
  }

  if (data.metrics.expiring > 0) {
    const potentialLoss = data.metrics.expiring * 15000;
    predictions.push(`Without action, approximately TZS ${potentialLoss.toLocaleString()} worth of inventory may expire, impacting profitability`);
  }

  predictions.push('Customer visit patterns suggest potential for extending operating hours or adding weekend services');

  return predictions.slice(0, 5);
}

// Helper functions for parsing Gemini text responses
function extractSummaryFromText(text: string, data: BusinessData): string {
  const summaryMatch = text.match(/summary["\s]*:[\s]*["']([^"']+)["']/i);
  return summaryMatch ? summaryMatch[1] : generateFallbackSummary(data);
}

function extractRecommendationsFromText(text: string, data: BusinessData): string[] {
  const recommendationMatches = text.match(/recommendation[s]?["\s]*:[\s]*\[(.*?)\]/is);
  if (recommendationMatches) {
    try {
      return JSON.parse(`[${recommendationMatches[1]}]`);
    } catch (e) {
      const lines = recommendationMatches[1].split('\n')
        .map(line => line.trim().replace(/^["'-]*/, '').replace(/["'-]*$/, ''))
        .filter(line => line.length > 10);
      
      if (lines.length > 0) {
        return lines.slice(0, 7);
      }
    }
  }
  
  return generateFallbackRecommendations(data);
}

export async function GET(request: NextRequest) {
  console.log('🚀🚀🚀 APP ROUTER GET /api/generate-report endpoint hit - SUCCESS!');
  console.log('📍 Request URL:', request.url);
  console.log('📍 Request method:', request.method);
  console.log('📍 This is the App Router endpoint at /app/api/generate-report/route.ts');
  console.log('📍 Timestamp:', new Date().toISOString());
  console.log('🚀 Confirming API route is accessible and functional');
  console.log('⚡ GET handler is executing - API route definitely exists and works');
  console.log('✨ SYNTAX ERROR FIXED - Route should now be accessible');
  
  try {
    const response = NextResponse.json({ 
      message: '🎉 AI Business Intelligence API endpoint is operational via App Router',
      timestamp: new Date().toISOString(),
      status: 'ready',
      endpoint: '/api/generate-report',
      methods: ['GET', 'POST', 'OPTIONS'],
      source: 'app-router',
      file: '/app/api/generate-report/route.ts',
      success: true,
      fixed: 'Syntax error in route.ts has been resolved',
      geminiSupport: !!process.env.GEMINI_API_KEY,
      debug: {
        nodeEnv: process.env.NODE_ENV,
        requestMethod: request.method,
        requestUrl: request.url,
        pathname: request.nextUrl.pathname,
        searchParams: Object.fromEntries(request.nextUrl.searchParams.entries()),
        userAgent: request.headers.get('user-agent') || 'unknown',
        hasGeminiKey: !!process.env.GEMINI_API_KEY,
        geminiKeyLength: process.env.GEMINI_API_KEY?.length || 0
      }
    });
    
    // Add headers to prevent caching issues
    response.headers.set('Cache-Control', 'no-store, no-cache, must-revalidate');
    response.headers.set('Access-Control-Allow-Origin', '*');
    response.headers.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    console.log('✅ Generate report GET response prepared successfully');
    return response;
  } catch (error: any) {
    console.error('❌ Generate report GET error:', error);
    return NextResponse.json(
      { 
        error: 'Generate report GET failed', 
        message: error.message,
        stack: error.stack,
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    );
  }
}