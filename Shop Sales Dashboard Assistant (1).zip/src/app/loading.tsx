import { LoadingScreen } from '../components/LoadingScreen';

export default function Loading() {
  return (
    <LoadingScreen 
      aiSystemStatus="connecting" 
      errors={[]}
      hasPermissionErrors={false}
      permissionErrorsCount={0}
    />
  );
}