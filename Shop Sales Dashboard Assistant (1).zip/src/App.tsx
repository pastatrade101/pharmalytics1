import React, { useState, useEffect } from 'react';
import { ErrorBoundary } from './components/ErrorBoundary';
import { ErrorProvider } from './contexts/ErrorContext';
import { AppScreenRouter } from './components/AppScreenRouter';
import { auth } from './lib/firebase';
import { useAIConnection } from './hooks/useAIConnection';
import { useAuthState } from './hooks/useAuthState';
import { useUserProfile } from './hooks/useUserProfile';
import { useErrorState } from './hooks/useErrorState';
import { View, isDevelopment, isSuperAdmin } from './lib/app-constants';

// Import migration utilities for browser console access (only when Firebase is working)
// Note: The migration utilities will check for permissions before executing
import './lib/migrate-existing-products';

// Emergency fix for product manager permissions
if (typeof window !== 'undefined') {
  // Apply emergency fix for product_manager import permissions
  (window as any).canImportProducts = (role: string) => {
    return ['product_manager', 'owner', 'admin', 'super_admin'].includes(role);
  };

  // CRITICAL: Much more conservative emergency modal cleanup utility
  (window as any).emergencyModalCleanup = () => {
    console.log('🚨 Emergency modal cleanup initiated...');
    
    // Remove all stuck overlays
    const overlays = document.querySelectorAll('[data-radix-dialog-overlay], [data-radix-portal]');
    if (overlays.length > 0) {
      console.log(`  - Found ${overlays.length} overlay(s) to remove`);
      overlays.forEach((overlay, index) => {
        console.log(`  - Removing overlay ${index + 1}:`, overlay);
        overlay.remove();
      });
    }
    
    // Reset body classes and styles
    document.body.style.overflow = 'auto';
    document.body.style.touchAction = 'auto';
    document.body.style.pointerEvents = 'auto';
    document.body.classList.remove('no-scroll', 'modal-stuck');
    
    // Force re-enable all interactions
    const blockedElements = document.querySelectorAll('[style*="pointer-events: none"]');
    if (blockedElements.length > 0) {
      console.log(`  - Re-enabling ${blockedElements.length} blocked element(s)`);
      blockedElements.forEach((el) => {
        const element = el as HTMLElement;
        element.style.pointerEvents = 'auto';
      });
    }
    
    console.log('✅ Emergency modal cleanup completed');
  };

  // CRITICAL: Much more conservative auto-detect system - Only run when explicitly needed
  (window as any).enableModalDetection = () => {
    let consecutiveDetections = 0;
    const requiredConsecutiveDetections = 5; // Require 5 consecutive detections
    const checkInterval = 5000; // Check every 5 seconds (much less frequent)
    const maxChecks = 12; // Check for max 60 seconds
    let checkCount = 0;
    let isCheckingActive = false;

    const checkForStuckModals = () => {
      if (!isCheckingActive) return;
      
      checkCount++;
      
      // Stop checking after max attempts
      if (checkCount > maxChecks) {
        console.log('🔍 Modal detection: Max checks reached, stopping detection');
        isCheckingActive = false;
        return;
      }

      try {
        // Only check for very obvious stuck states
        const openDialogs = document.querySelectorAll('[data-state="open"]');
        const visibleOverlays = document.querySelectorAll('[data-radix-dialog-overlay][data-state="open"]:not([style*="display: none"])');
        const allOverlays = document.querySelectorAll('[data-radix-dialog-overlay]');
        
        // Much more conservative detection - only trigger on severe issues
        const hasMultipleStuckOverlays = allOverlays.length > 2; // More than 2 overlays is definitely wrong
        const hasBodyStuckForLong = document.body.style.overflow === 'hidden' && 
                                   openDialogs.length === 0 && 
                                   visibleOverlays.length === 0;

        const isSeverelyStuck = hasMultipleStuckOverlays || hasBodyStuckForLong;

        if (isSeverelyStuck) {
          consecutiveDetections++;
          console.log(`🔍 Modal detection: Severe stuck state detected (${consecutiveDetections}/${requiredConsecutiveDetections})`, {
            allOverlays: allOverlays.length,
            openDialogs: openDialogs.length,
            visibleOverlays: visibleOverlays.length,
            bodyOverflow: document.body.style.overflow
          });

          // Only trigger cleanup after many consecutive detections
          if (consecutiveDetections >= requiredConsecutiveDetections) {
            console.warn('🚨 SEVERE stuck modal state confirmed, triggering cleanup...');
            (window as any).emergencyModalCleanup();
            consecutiveDetections = 0;
            isCheckingActive = false; // Stop checking after cleanup
            return;
          }
        } else {
          // Reset counter if no severe stuck state detected
          if (consecutiveDetections > 0) {
            console.log('🔍 Modal detection: No severe stuck state, resetting counter');
            consecutiveDetections = 0;
          }
        }

        // Continue checking
        if (isCheckingActive) {
          setTimeout(checkForStuckModals, checkInterval);
        }
      } catch (error) {
        console.warn('🔍 Modal detection: Error during check:', error);
        consecutiveDetections = 0;
        if (isCheckingActive) {
          setTimeout(checkForStuckModals, checkInterval);
        }
      }
    };

    // Start the checking process
    if (!isCheckingActive) {
      isCheckingActive = true;
      checkCount = 0;
      consecutiveDetections = 0;
      console.log('🔍 Modal detection: Starting conservative auto-detection (manual)');
      setTimeout(checkForStuckModals, checkInterval);
    }

    // Return a function to stop the detection
    return () => {
      isCheckingActive = false;
      console.log('🔍 Modal detection: Stopped auto-detection');
    };
  };

  // Enhanced touch event debugging with more detailed info
  (window as any).debugTouchEvents = () => {
    console.log('🔍 Touch Events Debug Info:');
    console.log('- Document body overflow:', document.body.style.overflow);
    console.log('- Document body pointer-events:', document.body.style.pointerEvents);
    console.log('- Document body touch-action:', document.body.style.touchAction);
    console.log('- Document body classes:', Array.from(document.body.classList));
    
    const openDialogs = document.querySelectorAll('[data-state="open"]');
    const allDialogs = document.querySelectorAll('[data-state]');
    const overlays = document.querySelectorAll('[data-radix-dialog-overlay]');
    const portals = document.querySelectorAll('[data-radix-portal]');
    
    console.log('- Open dialogs:', openDialogs.length, Array.from(openDialogs));
    console.log('- All dialogs:', allDialogs.length, Array.from(allDialogs).map(el => ({ element: el, state: el.getAttribute('data-state') })));
    console.log('- Visible overlays:', overlays.length, Array.from(overlays));
    console.log('- Portal elements:', portals.length, Array.from(portals));
    
    // Check for high z-index elements that might be blocking
    const highZElements = Array.from(document.querySelectorAll('*')).filter(el => {
      const style = window.getComputedStyle(el);
      const zIndex = style.zIndex;
      return zIndex && parseInt(zIndex) > 1000;
    }).map(el => ({
      element: el,
      zIndex: window.getComputedStyle(el).zIndex,
      position: window.getComputedStyle(el).position,
      pointerEvents: window.getComputedStyle(el).pointerEvents
    }));
    
    console.log('- High z-index elements:', highZElements.length, highZElements);
    
    // Check for elements with pointer-events: none
    const blockedElements = Array.from(document.querySelectorAll('*')).filter(el => {
      const style = window.getComputedStyle(el);
      return style.pointerEvents === 'none';
    });
    
    console.log('- Elements with pointer-events: none:', blockedElements.length, blockedElements.slice(0, 10));
  };

  // Add a function to manually reset modal state
  (window as any).resetModalState = () => {
    console.log('🔄 Manually resetting modal state...');
    
    // Remove all data-state attributes that might be stuck
    const elementsWithState = document.querySelectorAll('[data-state="open"]');
    if (elementsWithState.length > 0) {
      console.log(`  - Found ${elementsWithState.length} element(s) with stuck open state`);
      elementsWithState.forEach(el => {
        console.log('  - Closing element with stuck open state:', el);
        el.setAttribute('data-state', 'closed');
        // Force remove if it's an overlay or portal
        if (el.hasAttribute('data-radix-dialog-overlay') || el.hasAttribute('data-radix-portal')) {
          el.remove();
        }
      });
    }
    
    (window as any).emergencyModalCleanup();
    console.log('✅ Modal state reset completed');
  };

  // Add console help
  (window as any).modalHelp = () => {
    console.log('🆘 Modal Debugging Help:');
    console.log('Available commands:');
    console.log('- window.debugTouchEvents() - Show detailed touch/modal debug info');
    console.log('- window.resetModalState() - Gently reset stuck modal states');
    console.log('- window.emergencyModalCleanup() - Force cleanup all modals');
    console.log('- window.enableModalDetection() - Enable auto-detection (manual)');
    console.log('- window.modalHelp() - Show this help');
  };
}

function AppContent() {
  const [currentView, setCurrentView] = useState<View>('home');
  const [showDebugPanel, setShowDebugPanel] = useState(isDevelopment);

  // Use custom hooks for state management
  const aiSystemStatus = useAIConnection();
  const authState = useAuthState();
  const userProfileState = useUserProfile();
  const errorState = useErrorState();

  // CRITICAL: Removed automatic modal detection - only manual activation now
  useEffect(() => {
    if (typeof window !== 'undefined') {
      // Only show help in development mode
      if (isDevelopment) {
        console.log('🔍 Modal Detection: Available manually via window.enableModalDetection()');
        console.log('🆘 For help with modal issues, run: window.modalHelp()');
      }

      // Add window focus listener for basic cleanup only
      const handleWindowFocus = () => {
        // Only do basic body state cleanup on focus
        if (document.body.style.overflow === 'hidden' && 
            document.querySelectorAll('[data-state="open"]').length === 0) {
          console.log('🔄 Window focus: Cleaning up stuck body scroll state');
          document.body.style.overflow = 'auto';
          document.body.style.touchAction = 'auto';
        }
      };

      window.addEventListener('focus', handleWindowFocus);

      // Cleanup listeners
      return () => {
        window.removeEventListener('focus', handleWindowFocus);
      };
    }
  }, []);

  // CRITICAL: Much more conservative global error handler
  useEffect(() => {
    const handleGlobalError = (event: ErrorEvent) => {
      // Only handle very specific modal-related errors
      if (event.error?.message?.includes('radix') && 
          (event.error?.message?.includes('Cannot read') || 
           event.error?.message?.includes('Cannot access'))) {
        console.warn('🚨 Detected critical modal-related error:', event.error.message);
        if (typeof window !== 'undefined') {
          // Use the gentle reset first
          (window as any).resetModalState();
        }
      }
    };

    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      // Only handle very specific modal-related promise rejections
      if (event.reason?.message?.includes('radix') && 
          event.reason?.message?.includes('portal')) {
        console.warn('🚨 Detected critical modal-related promise rejection:', event.reason.message);
        if (typeof window !== 'undefined') {
          (window as any).resetModalState();
        }
      }
    };

    window.addEventListener('error', handleGlobalError);
    window.addEventListener('unhandledrejection', handleUnhandledRejection);
    
    return () => {
      window.removeEventListener('error', handleGlobalError);
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
    };
  }, []);

  // Enhanced profile loading when auth state changes
  useEffect(() => {
    if (authState.isAuthenticated && auth.currentUser) {
      // Load profile regardless of verification for super admin check, or if email is verified
      const shouldLoadProfile = auth.currentUser.emailVerified || !auth.currentUser.emailVerified; // Always load initially to check role
      
      if (shouldLoadProfile) {
        userProfileState.loadUserProfile(auth.currentUser.uid);
      }
    } else if (!authState.isAuthenticated) {
      // Reset profile state when not authenticated
      userProfileState.resetProfile();
    }
  }, [authState.isAuthenticated, userProfileState]);

  // Set email verified state when auth state changes
  useEffect(() => {
    if (authState.emailVerified !== null) {
      // Email verification state is managed by auth hook
    }
  }, [authState.emailVerified]);

  // Set default view based on user role
  useEffect(() => {
    if (userProfileState.userProfile) {
      if (isSuperAdmin(userProfileState.userProfile.role)) {
        setCurrentView('super-admin-dashboard');
      } else {
        setCurrentView('home');
        // Fix: Ensure proper layout initialization for dashboard view
        console.log('🏠 App: Setting default dashboard view - ensuring proper layout');
      }
    }
  }, [userProfileState.userProfile]);

  // Enhanced handlers that integrate auth and profile state
  const handleEmailVerified = async () => {
    authState.setEmailVerified(true);
    await userProfileState.handleEmailVerified();
  };

  const handleShopActivated = async () => {
    await userProfileState.handleShopActivated();
  };

  return (
    <AppScreenRouter
      // Auth state
      isAuthenticated={authState.isAuthenticated}
      isLoading={authState.isLoading}
      emailVerified={authState.emailVerified}
      authMode={authState.authMode}
      
      // User state
      userProfile={userProfileState.userProfile}
      shopActivated={userProfileState.shopActivated}
      
      // Current view
      currentView={currentView}
      setCurrentView={setCurrentView}
      
      // AI system status
      aiSystemStatus={aiSystemStatus}
      
      // Error state
      errorState={errorState}
      
      // Handlers
      onSignOut={authState.handleSignOut}
      onAuthSuccess={authState.handleAuthSuccess}
      onSuperAdminAuthSuccess={authState.handleSuperAdminAuthSuccess}
      onSwitchToSuperAdmin={authState.handleSwitchToSuperAdmin}
      onBackToRegular={authState.handleBackToRegular}
      onEmailVerified={handleEmailVerified}
      onShopActivated={handleShopActivated}
      
      // Debug state
      showDebugPanel={showDebugPanel}
    />
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ErrorProvider>
        <AppContent />
      </ErrorProvider>
    </ErrorBoundary>
  );
}