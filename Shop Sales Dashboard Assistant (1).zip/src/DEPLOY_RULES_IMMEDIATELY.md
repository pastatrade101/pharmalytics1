# 🚨 URGENT: Deploy Firebase Rules to Fix Permission Errors

## **Current Status**
Your app is showing these critical errors:
```
❌ Error creating product: FirebaseError: [code=permission-denied]: Missing or insufficient permissions.
❌ Failed to import product: Error: 🚨 CRITICAL: Firebase permission denied in unknown operation.
```

**ROOT CAUSE:** Firebase security rules are not deployed to your Firebase project.

---

## 🎯 **IMMEDIATE FIX - Deploy Rules Now**

### **Option 1: Automated Script (Recommended)**
Run the deployment script in your terminal:

```bash
# Make script executable
chmod +x scripts/deploy-firebase-rules.sh

# Run the deployment script
./scripts/deploy-firebase-rules.sh
```

### **Option 2: Manual Firebase CLI**
If you prefer manual deployment:

```bash
# Install Firebase CLI if not installed
npm install -g firebase-tools

# Login to Firebase
firebase login

# Set your project (replace with your actual project ID)
firebase use your-project-id

# Deploy rules and indexes
firebase deploy --only firestore:rules,firestore:indexes

# Verify deployment
firebase firestore:rules:get
```

### **Option 3: Firebase Console (Manual)**
If CLI doesn't work, use the web console:

1. **Go to:** https://console.firebase.google.com/project/your-project-id/firestore/rules
2. **Copy the entire content** from your `/firestore.rules` file
3. **Replace all existing rules** in the console editor
4. **Click "Publish"**
5. **Wait for "Rules published successfully"**

---

## 🔧 **What These Rules Fix**

### Product Management Permissions
The rules allow:
- **Managers** and **owners** to create, read, update products
- **All shop members** to read products from their shop
- **Admins** full access to all products

### Key Rule for Products:
```javascript
match /products/{productId} {
  // Managers and owners can create and update products
  allow create, update: if isAuthenticated() && 
                           hasAnyRole(['manager', 'owner', 'admin']) &&
                           belongsToShop(resource.data.shop_id);
  
  // All shop members can read products
  allow read: if belongsToShop(resource.data.shop_id);
}
```

### User Role Requirements:
Your user account needs one of these roles for product management:
- **`manager`** - Can manage products and inventory
- **`owner`** - Full pharmacy management access  
- **`admin`** - System administrator access

---

## ✅ **After Deployment - Expected Results**

Once rules are deployed, you should see:
- **✅ Product creation works** - No more permission-denied errors
- **✅ Product import succeeds** - CSV imports process correctly
- **✅ Inventory management active** - Full product catalog access
- **✅ POS system functional** - Barcode scanning and sales recording
- **✅ User management working** - Role assignments and shop access

---

## 🔍 **Verify Deployment Success**

### 1. Check Firebase Console
- Go to: https://console.firebase.google.com/project/your-project-id/firestore/rules
- Verify you see the complete rules (483 lines)
- Status should show "Published" with recent timestamp

### 2. Test in Your App
- Refresh your application (Ctrl+F5 / Cmd+Shift+R)
- Try creating a new product
- Try importing the sample products
- Check for permission error toasts

### 3. Verify User Role
Check your user profile has the correct role:
- **Manager** or **Owner** role required for product management
- **Admin** role has full system access
- **Salesman** role only allows sales recording (not product management)

---

## 🚨 **Still Getting Errors?**

### Troubleshooting Steps:

**1. Wait for Propagation (1-2 minutes)**
Firebase rules can take time to propagate globally.

**2. Clear Browser Cache**
- Try incognito/private browsing mode
- Hard refresh: Ctrl+F5 (Windows) / Cmd+Shift+R (Mac)

**3. Verify Project Selection**
```bash
firebase projects:list
firebase use your-project-id
```

**4. Check Deployment Logs**
```bash
firebase deploy --only firestore:rules --debug
```

**5. Manual Console Verification**
- Firebase Console → Firestore Database → Rules
- Verify rules contain your complete 483-line rule set
- Check "Published" status and timestamp

---

## 📞 **Need Help?**

If you're still getting permission errors after deployment:

1. **Check the browser console** for detailed error messages
2. **Verify your user role** in the profile section
3. **Ensure your user is assigned to a pharmacy** (shop_id exists)
4. **Try creating a simple product** to isolate the issue

**The rules in your `/firestore.rules` file are complete and correct. The issue is simply that they need to be deployed to Firebase.**

Deploy now to restore full functionality! 🚀