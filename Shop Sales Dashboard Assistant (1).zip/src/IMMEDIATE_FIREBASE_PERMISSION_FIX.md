# IMMEDIATE Firebase Permission Fix Guide

## 🚨 CRITICAL ISSUE
Your pharmacy management system is showing Firebase permission errors. This guide provides the fastest fix.

## ⚡ FASTEST FIX (2 minutes)

### Step 1: Deploy Firebase Rules
```bash
# Run this command in your project directory:
chmod +x scripts/deploy-firebase-rules.sh
./scripts/deploy-firebase-rules.sh
```

### Step 2: If the script fails, manual deployment:
```bash
# Login to Firebase
firebase login

# Check your project
firebase projects:list
firebase use your-project-id

# Deploy rules
firebase deploy --only firestore:rules
```

### Step 3: Verify in Firebase Console
1. Go to [Firebase Console](https://console.firebase.google.com)
2. Select your project
3. Go to Firestore Database > Rules
4. Verify rules are deployed and published
5. Click "Publish" if needed

## 🔍 WHAT THE ERRORS MEAN

```
❌ Error getting shop: [code=permission-denied]
❌ Permission error: Firebase security rules are not deployed
❌ User assigned to non-existent shop
❌ Failed to load assigned users
```

**Root Cause:** Firebase Firestore security rules are either:
- Not deployed
- Too restrictive
- Missing critical permissions

## 🛠️ IMMEDIATE VERIFICATION

After deploying rules, test in your browser console:

```javascript
// Test 1: Check authentication
console.log('User:', firebase.auth().currentUser);

// Test 2: Try reading a document
firebase.firestore().collection('shops').limit(1).get()
  .then(snapshot => console.log('✅ Shop access works:', snapshot.size))
  .catch(error => console.log('❌ Still blocked:', error.code));

// Test 3: Check user profile
firebase.firestore().collection('profiles').doc('your-user-id').get()
  .then(doc => console.log('✅ Profile access works:', doc.exists))
  .catch(error => console.log('❌ Profile blocked:', error.code));
```

## 📋 POST-FIX CHECKLIST

After deploying rules:

- [ ] ✅ Refresh your web application (hard refresh: Ctrl+F5)
- [ ] ✅ Clear browser cache and cookies
- [ ] ✅ Sign out and sign back in
- [ ] ✅ Test shop data loading
- [ ] ✅ Test user management
- [ ] ✅ Test product access
- [ ] ✅ Verify no console errors

## 🚨 IF ERRORS PERSIST

### Option 1: Wait and Retry
- Rules take 1-2 minutes to propagate
- Hard refresh browser after waiting

### Option 2: Emergency Fallback Rules
If you need immediate access, temporarily use these permissive rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // TEMPORARY - Allow all authenticated users full access
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

**⚠️ WARNING:** Only use emergency rules temporarily for testing!

### Option 3: Check Firebase Console Logs
1. Go to Firebase Console > Firestore > Usage
2. Check for rule evaluation errors
3. Look for specific permission denials

## 🔧 ADVANCED TROUBLESHOOTING

### Check Rules Deployment Status
```bash
# Get current rules
firebase firestore:rules:get

# Test rules deployment
firebase firestore:rules:test --project=your-project-id
```

### Verify Project Configuration
```bash
# List all projects
firebase projects:list

# Check current project
firebase use

# Switch project if needed
firebase use your-correct-project-id
```

### Manual Rules Deployment
```bash
# Force deployment with debug info
firebase deploy --only firestore:rules --debug --force

# Check deployment logs
firebase deploy --only firestore:rules --debug 2>&1 | tee deployment.log
```

## 📞 EMERGENCY CONTACTS

If the issue persists after trying all steps:

1. **Check Firebase Status**: [Firebase Status Page](https://status.firebase.google.com)
2. **Firebase Support**: [Firebase Help Center](https://firebase.google.com/support)
3. **Community Help**: [Firebase Discord](https://firebase.google.com/community)

## ✅ SUCCESS INDICATORS

You'll know the fix worked when you see:

- ✅ No permission errors in browser console
- ✅ Shop data loads successfully
- ✅ User profiles are accessible
- ✅ Product management works
- ✅ Sales system functions normally

## 🎯 QUICK TEST COMMANDS

After fixing, run these in browser console to verify:

```javascript
// Test all core collections
const testCollections = ['shops', 'profiles', 'products', 'sales'];
testCollections.forEach(collection => {
  firebase.firestore().collection(collection).limit(1).get()
    .then(() => console.log(`✅ ${collection} accessible`))
    .catch(e => console.log(`❌ ${collection} blocked:`, e.code));
});
```

---

**🏥 Pharmacy Management System**  
*Critical Support Guide - Get your system running in 2 minutes*