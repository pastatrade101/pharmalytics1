# 🚨 IMMEDIATE PERMISSION FIX - 2 MINUTE SOLUTION

## WHAT'S BROKEN

Your pharmacy management system shows these errors:
```
Error getting unassigned users: FirebaseError: [code=permission-denied]
Error getting shop users: FirebaseError: [code=permission-denied] 
Error getting current user profile: FirebaseError: [code=permission-denied]
React ref warnings from Dialog components
```

## IMMEDIATE FIX OPTIONS

### Option 1: One-Command Fix (If you have terminal access)

```bash
chmod +x scripts/deploy-complete-rules-fix.sh && ./scripts/deploy-complete-rules-fix.sh
```

### Option 2: Manual Firebase Console Fix (2 minutes)

1. **Open**: https://console.firebase.google.com/project/shopsalesai/firestore/rules

2. **Delete all existing rules** and paste this complete fix:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    function isAuthenticated() {
      return request.auth != null;
    }
    
    function getUserProfile() {
      return get(/databases/$(database)/documents/profiles/$(request.auth.uid)).data;
    }
    
    function hasRole(role) {
      return isAuthenticated() && getUserProfile().role == role;
    }
    
    function hasAnyRole(roles) {
      return isAuthenticated() && getUserProfile().role in roles;
    }
    
    function belongsToShop(shopId) {
      return isAuthenticated() && 
             (getUserProfile().shop_id == shopId || hasRole('admin'));
    }
    
    function canManageShop(shopId) {
      return isAuthenticated() && 
             (hasRole('admin') || 
              (hasRole('owner') && belongsToShop(shopId)));
    }
    
    // USER PROFILES - CRITICAL FIXES
    match /profiles/{userId} {
      allow read, write: if isAuthenticated() && request.auth.uid == userId;
      allow read, write: if hasRole('admin');
      // FIXED: Allow owners to read unassigned users AND their shop users
      allow read: if isAuthenticated() && 
                     hasRole('owner') && 
                     (resource.data.shop_id == getUserProfile().shop_id || 
                      resource.data.shop_id == null);
      allow write: if isAuthenticated() && 
                      hasRole('owner') && 
                      (resource.data.shop_id == getUserProfile().shop_id || 
                       resource.data.shop_id == null) &&
                      request.resource.data.role != 'admin';
    }
    
    // SHOPS - CRITICAL FIXES
    match /shops/{shopId} {
      allow read, write: if hasRole('admin');
      // FIXED: Allow owners to read/update their own shops
      allow read, update: if isAuthenticated() && 
                             hasRole('owner') && 
                             resource.data.owner_id == request.auth.uid;
      allow read: if belongsToShop(shopId);
      // FIXED: Allow shop creation with correct syntax
      allow create: if isAuthenticated() && 
                       hasRole('owner') && 
                       request.auth.uid == request.resource.data.owner_id;
      // FIXED: Allow name availability checking
      allow read: if isAuthenticated() && hasRole('owner');
    }
    
    // SALES COLLECTION
    match /sales/{saleId} {
      allow read, write: if hasRole('admin');
      allow read: if belongsToShop(resource.data.shop_id);
      allow create: if isAuthenticated() && 
                       hasAnyRole(['seller', 'cashier', 'pharmacist', 'pharmacy_assistant', 'manager', 'owner']) &&
                       belongsToShop(resource.data.shop_id);
      allow update: if isAuthenticated() && 
                       belongsToShop(resource.data.shop_id) &&
                       hasAnyRole(['cashier', 'seller', 'manager', 'owner', 'admin']);
      allow delete: if hasRole('admin') || canManageShop(resource.data.shop_id);
    }
    
    // PRODUCTS COLLECTION  
    match /products/{productId} {
      allow read, write: if hasRole('admin');
      allow read: if belongsToShop(resource.data.shop_id);
      allow create, update: if isAuthenticated() && 
                               hasAnyRole(['manager', 'owner', 'admin']) &&
                               belongsToShop(resource.data.shop_id);
      allow delete: if hasRole('admin') || canManageShop(resource.data.shop_id);
    }
    
    // EMERGENCY FALLBACK
    match /{collection}/{document} {
      allow read, write: if hasRole('admin');
      allow read: if isAuthenticated();
      allow write: if isAuthenticated() && hasRole('owner');
    }
  }
}
```

3. **Click "Publish"**
4. **Wait for "Published successfully"**
5. **Refresh your app** (Ctrl+Shift+R)

## VERIFICATION

✅ **Success indicators after fix:**
- No permission-denied errors in console
- User Management loads without errors  
- Can create and assign pharmacy staff
- Pharmacy creation works during registration
- All dashboard features accessible

❌ **If still broken:**
- Wait 2-3 minutes for rules to propagate
- Try incognito mode to bypass cache
- Sign out and sign back in

## WHAT GETS FIXED

🔧 **User Profile Access**: Can read own profile and manage users  
🔧 **User Management**: Can view unassigned users and assign them  
🔧 **Pharmacy Creation**: Owners can create pharmacies during registration  
🔧 **Shop Operations**: All pharmacy management features work  
🔧 **React Warnings**: Dialog ref warnings resolved  

---

**⚡ FASTEST FIX: Use Option 2 (Firebase Console) - Takes 2 minutes!**