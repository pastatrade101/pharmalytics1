import React, { useState } from 'react';
import { LogOut, Shield, Database, Building2, Plus, ExternalLink } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { CriticalFirebaseRulesModal } from './CriticalFirebaseRulesModal';
import { DebugPanel } from './DebugPanel';
import { Toaster } from './Toaster';
import { getRoleDisplayName } from '../lib/app-helpers';
import { isDevelopment } from '../lib/app-constants';
import { UserProfile as UserProfileType, FirebaseService } from '../lib/firebase';
import { toast } from 'sonner';

interface ShopAssignmentScreenProps {
  userProfile: UserProfileType;
  errors: any[];
  hasPermissionErrors: boolean;
  hasIndexErrors: boolean;
  permissionErrorsLength: number;
  onSignOut: () => void;
}

export function ShopAssignmentScreen({ 
  userProfile, 
  errors, 
  hasPermissionErrors, 
  hasIndexErrors, 
  permissionErrorsLength,
  onSignOut 
}: ShopAssignmentScreenProps) {
  const [isCreatingShop, setIsCreatingShop] = useState(false);
  const [shopName, setShopName] = useState('');
  const [showCreateShopForm, setShowCreateShopForm] = useState(false);
  const [showIndexHelper, setShowIndexHelper] = useState(false);

  const isOwner = userProfile.role === 'owner';

  const handleCreateShop = async () => {
    if (!shopName.trim()) {
      toast.error('Please enter a pharmacy name');
      return;
    }

    setIsCreatingShop(true);
    try {
      console.log('🏪 Creating new shop for owner:', userProfile.email);
      
      // Try to check if shop name is available, but handle permission errors gracefully
      try {
        const isAvailable = await FirebaseService.isShopNameAvailable(shopName.trim());
        if (!isAvailable) {
          toast.error('This pharmacy name is already taken. Please choose a different name.');
          setIsCreatingShop(false);
          return;
        }
        console.log('✅ Shop name availability confirmed');
      } catch (nameCheckError: any) {
        // If we get a permission error checking name availability, proceed anyway
        // The server-side validation will catch duplicate names
        if (nameCheckError.code === 'permission-denied') {
          console.warn('⚠️ Cannot check shop name availability due to permissions, proceeding with creation');
          toast.warning('Cannot verify name availability. If name is taken, creation will fail.');
        } else {
          // For other errors, still proceed but log them
          console.warn('⚠️ Error checking name availability:', nameCheckError);
        }
      }

      // Create the shop
      const shopData = {
        name: shopName.trim(),
        owner_id: userProfile.uid,
        description: `${shopName.trim()} - Pharmacy Management System`,
        category: 'pharmacy' as const,
        address: '',
        phone: '',
        settings: {
          timezone: 'Africa/Dar_es_Salaam',
          currency: 'TZS',
          report_time: '20:00'
        }
      };

      const createdShop = await FirebaseService.createShop(shopData);
      console.log('✅ Shop created successfully:', createdShop.id);

      // Assign the user to the new shop
      await FirebaseService.assignUserToShop(userProfile.uid, createdShop.id);
      console.log('✅ User assigned to new shop');

      toast.success(`Pharmacy "${shopName}" created successfully! Redirecting to dashboard...`);
      
      // The user profile will be reloaded automatically by the auth listener
      // which will detect the new shop assignment and redirect to the dashboard
      setTimeout(() => {
        window.location.reload();
      }, 2000);

    } catch (error: any) {
      console.error('❌ Error creating pharmacy:', error);
      
      if (error.code === 'permission-denied') {
        toast.error('Permission denied. Please ensure Firebase security rules are deployed.');
      } else if (error.code === 'failed-precondition') {
        toast.error('Database index required. Click to see instructions.', {
          action: {
            label: 'Show Fix',
            onClick: () => setShowIndexHelper(true)
          }
        });
      } else if (error.message?.includes('already exists') || error.message?.includes('already taken')) {
        toast.error('This pharmacy name is already taken. Please choose a different name.');
      } else if (error.name === 'IndexRequiredError') {
        toast.error('Database index required. Please check the setup guide for instructions.');
      } else {
        toast.error(error.message || 'Failed to create pharmacy. Please try again.');
      }
    } finally {
      setIsCreatingShop(false);
    }
  };

  return (
    <>
      {/* Critical Firebase Rules Modal - HIGHEST PRIORITY */}
      <CriticalFirebaseRulesModal 
        hasPermissionErrors={hasPermissionErrors}
        errorCount={permissionErrorsLength}
      />
      
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <Card className="max-w-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              {isOwner ? 'Pharmacy Setup Required' : 'Shop Assignment Required'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {hasPermissionErrors && (
              <Alert variant="destructive" className="bg-red-50 border-red-300 mb-4">
                <Shield className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800 text-sm">
                  <strong>🚨 CRITICAL:</strong> Firebase rules must be deployed before accessing any features. 
                  Deploy rules using the modal above first.
                </AlertDescription>
              </Alert>
            )}
            
            {hasIndexErrors && (
              <Alert className="bg-yellow-50 border-yellow-300 mb-4">
                <Database className="h-4 w-4 text-yellow-600" />
                <AlertDescription className="text-yellow-800 text-sm">
                  <strong>🔧 DATABASE INDEXES NEEDED:</strong> Analytics require Firestore indexes to load properly.
                </AlertDescription>
              </Alert>
            )}
            
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <p className="text-amber-900 text-sm">
                <strong>Account Setup Incomplete:</strong> {isOwner 
                  ? 'Create your pharmacy to access the dashboard.' 
                  : 'Your account needs to be assigned to a pharmacy to access the dashboard.'
                }
              </p>
            </div>
            
            {/* User Details */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <p className="text-blue-800 text-sm">
                <strong>Your Account Details:</strong>
              </p>
              <div className="text-blue-700 text-xs mt-1 space-y-1">
                <div>Email: {userProfile.email}</div>
                <div>Role: {getRoleDisplayName(userProfile.role)}</div>
                <div>User ID: {userProfile.id}</div>
                <div>Pharmacy Assignment: None</div>
              </div>
            </div>
            
            {/* Owner-specific shop creation */}
            {isOwner ? (
              <div className="space-y-4">
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <p className="text-green-800 text-sm">
                    <strong>Welcome, Pharmacy Owner!</strong> As an owner, you can create your own pharmacy to get started.
                  </p>
                </div>

                {!showCreateShopForm ? (
                  <Button 
                    onClick={() => setShowCreateShopForm(true)}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Create My Pharmacy
                  </Button>
                ) : (
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="shopName">Pharmacy Name</Label>
                      <Input
                        id="shopName"
                        type="text"
                        value={shopName}
                        onChange={(e) => setShopName(e.target.value)}
                        placeholder="Enter your pharmacy name"
                        className="mt-1"
                        disabled={isCreatingShop}
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        This will be the name of your pharmacy in the system
                      </p>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button 
                        onClick={handleCreateShop}
                        disabled={isCreatingShop || !shopName.trim()}
                        className="flex-1 bg-green-600 hover:bg-green-700"
                      >
                        {isCreatingShop ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2" />
                            Creating...
                          </>
                        ) : (
                          <>
                            <Building2 className="mr-2 h-4 w-4" />
                            Create Pharmacy
                          </>
                        )}
                      </Button>
                      
                      <Button 
                        onClick={() => {
                          setShowCreateShopForm(false);
                          setShopName('');
                        }}
                        variant="outline"
                        disabled={isCreatingShop}
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                )}
                
                {/* Index Helper Modal */}
                {showIndexHelper && (
                  <div className="mt-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-medium text-blue-900">Quick Fix: Create Database Index</h4>
                      <button 
                        onClick={() => setShowIndexHelper(false)}
                        className="text-blue-600 hover:text-blue-800"
                      >
                        ×
                      </button>
                    </div>
                    <p className="text-sm text-blue-800 mb-3">
                      A database index is required to check pharmacy name availability. Follow these steps:
                    </p>
                    <ol className="list-decimal list-inside text-sm text-blue-800 space-y-1 mb-3">
                      <li>Click the link below to open Firebase Console</li>
                      <li>Click "Create Index" on the page that opens</li>
                      <li>Wait for the index to be created (1-2 minutes)</li>
                      <li>Return here and try creating your pharmacy again</li>
                    </ol>
                    <a
                      href="https://console.firebase.google.com/v1/r/project/shopsalesai/firestore/indexes?create_composite=Cklwcm9qZWN0cy9zaG9wc2FsZXNhaS9kYXRhYmFzZXMvKGRlZmF1bHQpL2NvbGxlY3Rpb25Hcm91cHMvc2hvcHMvaW5kZXhlcy9fEAEaCAoEbmFtZRABGgoKBnN0YXR1cxABGgwKCF9fbmFtZV9fEAE"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm"
                    >
                      Create Database Index
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-gray-600">
                  To gain access to the dashboard:
                </p>
                
                <ol className="list-decimal list-inside space-y-2 text-sm text-gray-700 ml-4">
                  <li>Contact your pharmacy owner to assign you to their pharmacy</li>
                  <li>Make sure they have your correct email address</li>
                  <li>Ask them to check their User Management system</li>
                </ol>
                
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                  <p className="text-blue-800 text-sm">
                    <strong>For Pharmacy Owners:</strong> Use the User Management system to assign existing users or create new team member accounts with immediate access.
                  </p>
                </div>
              </div>
            )}
            
            <Button onClick={onSignOut} variant="outline" className="w-full">
              <LogOut className="mr-2 h-4 w-4" />
              Sign Out
            </Button>
          </CardContent>
        </Card>
      </div>
      <DebugPanel userProfile={userProfile} errors={errors} isVisible={isDevelopment} />
      <Toaster />
    </>
  );
}