import React, { useState, useEffect, useMemo } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Checkbox } from './ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { BarcodeScanner } from './BarcodeScanner';
import { 
  Plus, 
  Package, 
  Edit, 
  Trash2, 
  Search, 
  ArrowLeft, 
  Save, 
  AlertTriangle, 
  Loader2, 
  Download, 
  Upload, 
  Database,
  ChevronLeft,
  ChevronRight,
  MoreHorizontal,
  X,
  Check,
  Archive,
  FileEdit,
  Trash,
  Camera,
  Scan,
  Zap,
  Hash
} from 'lucide-react';
import { toast } from 'sonner';
import { UserProfile, Product, FirebaseService } from '../lib/firebase';
import { useError } from '../contexts/ErrorContext';
import { ErrorDisplay } from './ErrorDisplay';
import { formatTZS } from '../lib/currency-utils';
import { FileImportDialog } from './FileImportDialog';
import { canImportProducts, canManageProducts } from '../lib/app-constants';

interface ProductManagerProps {
  onBack: () => void;
  userProfile: UserProfile | null;
}

interface ScannedProductData {
  barcode: string;
  productName?: string;
  brand?: string;
  category?: string;
  manufacturer?: string;
  description?: string;
  suggestedSku: string;
  confidence: 'high' | 'medium' | 'low';
  rawData: string;
}

const CATEGORIES = [
  'Prescription Medicines',
  'Over-the-Counter',
  'Pain Relief',
  'Antibiotics',
  'Vitamins & Supplements',
  'Cold & Flu',
  'Digestive Health',
  'Dermatological',
  'Baby & Child Care',
  'Medical Devices',
  'First Aid',
  'Personal Care'
];

const PAGE_SIZE_OPTIONS = [10, 20, 50, 100];

export function ProductManager({ onBack, userProfile }: ProductManagerProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [loading, setLoading] = useState(true);
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [showScanner, setShowScanner] = useState(false);
  
  // Selection and Pagination State
  const [selectedProductIds, setSelectedProductIds] = useState<Set<string>>(new Set());
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [isProcessingBulk, setIsProcessingBulk] = useState(false);

  const { 
    addError, 
    addSuccess, 
    addWarning, 
    clearErrorsByContext, 
    hasErrorsInContext
  } = useError();

  const [productForm, setProductForm] = useState({
    name: '',
    generic_name: '',
    brand_name: '',
    description: '',
    retail_price: '',
    cost_price: '',
    category: 'Over-the-Counter',
    strength: '',
    manufacturer: '',
    stock_quantity: '',
    min_stock_level: '',
    sku: '',
    barcode: '',
    expiry_date: '',
    status: 'active' as const,
    scanned: false,
    confidence: '' as 'high' | 'medium' | 'low' | ''
  });

  useEffect(() => {
    loadProducts();
  }, [userProfile]);

  const loadProducts = async () => {
    setLoading(true);
    clearErrorsByContext('Product Loading');
    
    try {
      const loadedProducts = await FirebaseService.getProductsForCurrentUser();
      setProducts(loadedProducts);
    } catch (error: any) {
      if (error.message?.includes('No pharmacy associated')) {
        addWarning('No pharmacy associated with your account', 'Product Loading');
      } else {
        addError(error, 'Product Loading', 'Failed to load products from database.');
      }
    } finally {
      setLoading(false);
    }
  };

  // Auto-generate SKU function
  const generateAutoSku = (productName: string, category: string, barcode?: string): string => {
    const timestamp = Date.now().toString().slice(-4);
    const categoryPrefix = category.split(' ')[0].substring(0, 3).toUpperCase();
    const namePrefix = productName.replace(/[^a-zA-Z0-9]/g, '').substring(0, 3).toUpperCase();
    const barcodeHash = barcode ? barcode.slice(-2) : Math.random().toString(36).substr(2, 2).toUpperCase();
    
    return `${categoryPrefix}${namePrefix}${barcodeHash}${timestamp}`;
  };

  // Handle successful barcode scan
  const handleScanSuccess = (scannedData: ScannedProductData) => {
    console.log('📱 Scan successful:', scannedData);
    
    // Pre-fill form with scanned data
    setProductForm({
      ...productForm,
      name: scannedData.productName || '',
      generic_name: scannedData.productName || '',
      brand_name: scannedData.brand || '',
      description: scannedData.description || '',
      category: scannedData.category || 'Medicine',
      manufacturer: scannedData.manufacturer || '',
      sku: scannedData.suggestedSku,
      barcode: scannedData.barcode,
      scanned: true,
      confidence: scannedData.confidence
    });
    
    // Show add product form with pre-filled data
    setIsAddingProduct(true);
    setEditingProduct(null);
    
    toast.success('Product scanned successfully!', {
      description: `Auto-generated SKU: ${scannedData.suggestedSku}`,
      duration: 5000
    });
  };

  // Handle scan error
  const handleScanError = (error: string) => {
    console.error('❌ Scan error:', error);
    addError(new Error(error), 'Barcode Scanning', 'Failed to scan barcode. Please try again.');
  };

  // Generate SKU manually
  const handleGenerateSkuManually = () => {
    if (!productForm.name || !productForm.category) {
      toast.error('Please enter product name and category first');
      return;
    }
    
    const newSku = generateAutoSku(productForm.name, productForm.category, productForm.barcode);
    setProductForm({ ...productForm, sku: newSku });
    
    toast.success('SKU generated successfully!', {
      description: `Generated: ${newSku}`
    });
  };

  // Check if SKU is unique
  const isSkuUnique = (sku: string, excludeProductId?: string): boolean => {
    return !products.some(product => 
      product.sku === sku && product.id !== excludeProductId
    );
  };

  // Filtered and paginated products
  const filteredProducts = useMemo(() => {
    return products.filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           product.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           product.generic_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           product.brand_name?.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [products, searchTerm, selectedCategory]);

  const paginatedProducts = useMemo(() => {
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    return filteredProducts.slice(startIndex, endIndex);
  }, [filteredProducts, currentPage, pageSize]);

  const totalPages = Math.ceil(filteredProducts.length / pageSize);

  // Selection handlers
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedProductIds(new Set(paginatedProducts.map(p => p.id)));
    } else {
      setSelectedProductIds(new Set());
    }
  };

  const handleSelectProduct = (productId: string, checked: boolean) => {
    const newSelection = new Set(selectedProductIds);
    if (checked) {
      newSelection.add(productId);
    } else {
      newSelection.delete(productId);
    }
    setSelectedProductIds(newSelection);
  };

  const isAllSelected = paginatedProducts.length > 0 && 
                       paginatedProducts.every(p => selectedProductIds.has(p.id));
  const isIndeterminate = selectedProductIds.size > 0 && !isAllSelected;

  // Bulk actions
  const handleBulkDelete = async () => {
    const selectedProducts = products.filter(p => selectedProductIds.has(p.id));
    const productNames = selectedProducts.map(p => p.name).join(', ');
    
    if (!confirm(`Are you sure you want to delete ${selectedProductIds.size} selected products?\n\nProducts: ${productNames}`)) {
      return;
    }

    setIsProcessingBulk(true);
    clearErrorsByContext('Bulk Deletion');

    try {
      let successCount = 0;
      let failedCount = 0;
      const errors: string[] = [];

      for (const productId of selectedProductIds) {
        try {
          await FirebaseService.deleteProduct(productId);
          successCount++;
        } catch (error: any) {
          failedCount++;
          const product = products.find(p => p.id === productId);
          errors.push(`${product?.name || productId}: ${error.message}`);
        }
      }

      // Update products list
      setProducts(prev => prev.filter(p => !selectedProductIds.has(p.id)));
      setSelectedProductIds(new Set());

      if (successCount > 0) {
        addSuccess(`Successfully deleted ${successCount} products`, 'Bulk Deletion');
      }

      if (failedCount > 0) {
        addError(new Error(`Failed to delete ${failedCount} products`), 'Bulk Deletion', errors.join('\n'));
      }

    } catch (error) {
      addError(error, 'Bulk Deletion', 'Failed to complete bulk deletion');
    } finally {
      setIsProcessingBulk(false);
    }
  };

  const handleBulkStatusChange = async (newStatus: 'active' | 'inactive') => {
    setIsProcessingBulk(true);
    clearErrorsByContext('Bulk Update');

    try {
      let successCount = 0;
      let failedCount = 0;

      for (const productId of selectedProductIds) {
        try {
          await FirebaseService.updateProduct(productId, { 
            status: newStatus,
            updated_by: userProfile?.id 
          });
          successCount++;
        } catch (error) {
          failedCount++;
        }
      }

      // Update products list
      setProducts(prev => prev.map(p => 
        selectedProductIds.has(p.id) ? { ...p, status: newStatus } : p
      ));
      setSelectedProductIds(new Set());

      if (successCount > 0) {
        addSuccess(`Successfully updated ${successCount} products to ${newStatus}`, 'Bulk Update');
      }

      if (failedCount > 0) {
        addWarning(`Failed to update ${failedCount} products`, 'Bulk Update');
      }

    } catch (error) {
      addError(error, 'Bulk Update', 'Failed to complete bulk status update');
    } finally {
      setIsProcessingBulk(false);
    }
  };

  // Pagination handlers
  const handlePageChange = (newPage: number) => {
    setCurrentPage(newPage);
    setSelectedProductIds(new Set()); // Clear selections when changing pages
  };

  const handlePageSizeChange = (newPageSize: string) => {
    setPageSize(parseInt(newPageSize));
    setCurrentPage(1);
    setSelectedProductIds(new Set());
  };

  // Rest of the existing handlers (validation, CRUD operations, etc.)
  const validateProductForm = (): string[] => {
    const errors: string[] = [];
    
    if (!productForm.name.trim()) errors.push('Product name is required');
    if (!productForm.sku.trim()) errors.push('SKU is required');
    if (!productForm.retail_price || parseFloat(productForm.retail_price) <= 0) {
      errors.push('Valid retail price is required');
    }
    if (!productForm.cost_price || parseFloat(productForm.cost_price) < 0) {
      errors.push('Valid cost price is required');
    }
    if (!productForm.manufacturer.trim()) errors.push('Manufacturer is required');
    if (!productForm.stock_quantity || parseInt(productForm.stock_quantity) < 0) {
      errors.push('Valid stock quantity is required');
    }
    if (!productForm.min_stock_level || parseInt(productForm.min_stock_level) < 0) {
      errors.push('Valid minimum stock level is required');
    }
    
    // Check SKU uniqueness
    if (!isSkuUnique(productForm.sku, editingProduct?.id)) {
      errors.push('SKU must be unique - this SKU already exists');
    }
    
    return errors;
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitting(true);
    clearErrorsByContext('Product Creation');
    
    try {
      const validationErrors = validateProductForm();
      if (validationErrors.length > 0) {
        validationErrors.forEach(error => {
          addError(new Error(error), 'Product Creation', error);
        });
        return;
      }

      const newProduct = await FirebaseService.createProduct({
        name: productForm.name.trim(),
        generic_name: productForm.generic_name.trim() || undefined,
        brand_name: productForm.brand_name.trim() || undefined,
        description: productForm.description.trim() || undefined,
        category: productForm.category,
        strength: productForm.strength.trim() || undefined,
        manufacturer: productForm.manufacturer.trim(),
        sku: productForm.sku.trim(),
        barcode: productForm.barcode.trim() || undefined,
        cost_price: parseFloat(productForm.cost_price),
        retail_price: parseFloat(productForm.retail_price),
        stock_quantity: parseInt(productForm.stock_quantity),
        min_stock_level: parseInt(productForm.min_stock_level),
        expiry_date: productForm.expiry_date ? new Date(productForm.expiry_date) : undefined,
        status: productForm.status,
        created_by: userProfile?.id
      });

      setProducts(prev => [newProduct, ...prev]);
      resetProductForm();
      setIsAddingProduct(false);
      
      const successMessage = productForm.scanned ? 
        `Scanned product "${newProduct.name}" added successfully with auto-generated SKU` :
        `Product "${newProduct.name}" added successfully`;
        
      addSuccess(successMessage, 'Product Creation');
      
    } catch (error) {
      addError(error, 'Product Creation', `Failed to add product "${productForm.name}".`);
    } finally {
      setFormSubmitting(false);
    }
  };

  const handleUpdateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitting(true);
    clearErrorsByContext('Product Update');
    
    try {
      if (!editingProduct) {
        addError(new Error('No product selected'), 'Product Update', 'No product selected for editing');
        return;
      }

      const validationErrors = validateProductForm();
      if (validationErrors.length > 0) {
        validationErrors.forEach(error => {
          addError(new Error(error), 'Product Update', error);
        });
        return;
      }

      const updatedProduct = await FirebaseService.updateProduct(editingProduct.id, {
        name: productForm.name.trim(),
        generic_name: productForm.generic_name.trim() || undefined,
        brand_name: productForm.brand_name.trim() || undefined,
        description: productForm.description.trim() || undefined,
        category: productForm.category,
        strength: productForm.strength.trim() || undefined,
        manufacturer: productForm.manufacturer.trim(),
        sku: productForm.sku.trim(),
        barcode: productForm.barcode.trim() || undefined,
        cost_price: parseFloat(productForm.cost_price),
        retail_price: parseFloat(productForm.retail_price),
        stock_quantity: parseInt(productForm.stock_quantity),
        min_stock_level: parseInt(productForm.min_stock_level),
        expiry_date: productForm.expiry_date ? new Date(productForm.expiry_date) : undefined,
        status: productForm.status,
        updated_by: userProfile?.id
      });

      if (updatedProduct) {
        setProducts(prev => prev.map(p => p.id === editingProduct.id ? updatedProduct : p));
        resetProductForm();
        setEditingProduct(null);
        addSuccess(`Product "${updatedProduct.name}" updated successfully`, 'Product Update');
      }
      
    } catch (error) {
      addError(error, 'Product Update', `Failed to update product "${productForm.name}".`);
    } finally {
      setFormSubmitting(false);
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    const product = products.find(p => p.id === productId);
    const productName = product?.name || 'Unknown Product';
    
    if (!confirm(`Are you sure you want to delete "${productName}"?`)) return;

    clearErrorsByContext('Product Deletion');
    
    try {
      await FirebaseService.deleteProduct(productId);
      setProducts(prev => prev.filter(p => p.id !== productId));
      addSuccess(`Product "${productName}" deleted successfully`, 'Product Deletion');
    } catch (error) {
      addError(error, 'Product Deletion', `Failed to delete product "${productName}".`);
    }
  };

  const resetProductForm = () => {
    setProductForm({
      name: '',
      generic_name: '',
      brand_name: '',
      description: '',
      retail_price: '',
      cost_price: '',
      category: 'Over-the-Counter',
      strength: '',
      manufacturer: '',
      stock_quantity: '',
      min_stock_level: '',
      sku: '',
      barcode: '',
      expiry_date: '',
      status: 'active',
      scanned: false,
      confidence: ''
    });
  };

  const startEditing = (product: Product) => {
    clearErrorsByContext('Product Update');
    setEditingProduct(product);
    setProductForm({
      name: product.name,
      generic_name: product.generic_name || '',
      brand_name: product.brand_name || '',
      description: product.description || '',
      retail_price: product.retail_price.toString(),
      cost_price: product.cost_price.toString(),
      category: product.category,
      strength: product.strength || '',
      manufacturer: product.manufacturer,
      stock_quantity: product.stock_quantity.toString(),
      min_stock_level: product.min_stock_level.toString(),
      sku: product.sku,
      barcode: (product as any).barcode || '',
      expiry_date: product.expiry_date ? new Date(product.expiry_date).toISOString().split('T')[0] : '',
      status: product.status,
      scanned: false,
      confidence: ''
    });
    setIsAddingProduct(false);
  };

  const cancelEditing = () => {
    setEditingProduct(null);
    setIsAddingProduct(false);
    resetProductForm();
    clearErrorsByContext('Product Creation');
    clearErrorsByContext('Product Update');
  };

  const handleImportComplete = () => {
    setShowImportDialog(false);
    loadProducts();
  };

  const categoriesWithCounts = CATEGORIES.map(category => ({
    name: category,
    count: products.filter(p => p.category === category).length
  }));

  const hasLoadingErrors = hasErrorsInContext('Product Loading');
  const hasCreationErrors = hasErrorsInContext('Product Creation');
  const hasUpdateErrors = hasErrorsInContext('Product Update');
  const hasDeletionErrors = hasErrorsInContext('Product Deletion');

  const getCategoryColor = (category: string): string => {
    const colors: { [key: string]: string } = {
      'Prescription Medicines': 'text-red-700 bg-red-50',
      'Over-the-Counter': 'text-blue-700 bg-blue-50',
      'Pain Relief': 'text-orange-700 bg-orange-50',
      'Antibiotics': 'text-purple-700 bg-purple-50',
      'Vitamins & Supplements': 'text-yellow-700 bg-yellow-50',
      'Cold & Flu': 'text-teal-700 bg-teal-50',
      'Digestive Health': 'text-green-700 bg-green-50',
      'Dermatological': 'text-pink-700 bg-pink-50',
      'Baby & Child Care': 'text-indigo-700 bg-indigo-50',
      'Medical Devices': 'text-gray-700 bg-gray-50',
      'First Aid': 'text-red-700 bg-red-50',
      'Personal Care': 'text-cyan-700 bg-cyan-50'
    };
    return colors[category] || 'text-gray-700 bg-gray-50';
  };

  const getConfidenceBadgeColor = (confidence: 'high' | 'medium' | 'low' | '') => {
    switch (confidence) {
      case 'high': return 'bg-green-50 text-green-700 border-green-200';
      case 'medium': return 'bg-yellow-50 text-yellow-700 border-yellow-200';
      case 'low': return 'bg-orange-50 text-orange-700 border-orange-200';
      default: return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  const stats = React.useMemo(() => {
    const totalProducts = products.length;
    const lowStockItems = products.filter(p => p.stock_quantity <= p.min_stock_level && p.stock_quantity > 0);
    const outOfStockItems = products.filter(p => p.stock_quantity === 0);
    const totalValue = products.reduce((sum, p) => sum + (p.stock_quantity * p.cost_price), 0);
    
    const expiringSoonItems = products.filter(p => {
      if (!p.expiry_date) return false;
      const expiryDate = new Date(p.expiry_date);
      const today = new Date();
      const daysUntilExpiry = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      return daysUntilExpiry <= 30 && daysUntilExpiry > 0;
    });
    
    return {
      totalProducts,
      lowStockCount: lowStockItems.length,
      outOfStockCount: outOfStockItems.length,
      expiringSoonCount: expiringSoonItems.length,
      totalValue
    };
  }, [products]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="flex items-center">
              <Package className="h-8 w-8 text-indigo-600 mr-2" />
              <h1 className="text-3xl font-bold text-gray-900">Product Management</h1>
            </div>
            <p className="text-gray-600 mt-1">
              Manage your pharmacy's product catalog and inventory
            </p>
          </div>
          <div className="flex gap-3">
            <Button 
              onClick={() => setShowScanner(true)}
              className="bg-green-600 hover:bg-green-700"
              disabled={!userProfile?.shop_id}
            >
              <Camera className="mr-2 h-4 w-4" />
              Scan Product
            </Button>
            <Button 
              onClick={() => {
                setIsAddingProduct(true);
                setEditingProduct(null);
                resetProductForm();
                clearErrorsByContext('Product Creation');
              }}
              className="bg-indigo-600 hover:bg-indigo-700"
              disabled={!userProfile?.shop_id}
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Product
            </Button>
            <Button 
              onClick={() => {
                const allowedRoles = ['product_manager', 'owner', 'admin', 'super_admin'];
                const hasPermission = userProfile && allowedRoles.includes(userProfile.role);
                
                if (!hasPermission) {
                  toast.error('Permission Denied', {
                    description: `Your role (${userProfile?.role || 'unknown'}) doesn't have permission to import products. Required roles: ${allowedRoles.join(', ')}`,
                    duration: 8000
                  });
                  return;
                }
                setShowImportDialog(true);
              }}
              className="bg-purple-600 hover:bg-purple-700"
              disabled={!userProfile || !['product_manager', 'owner', 'admin', 'super_admin'].includes(userProfile.role)}
            >
              <Upload className="mr-2 h-4 w-4" />
              Import from File
            </Button>
          </div>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Products</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalProducts.toLocaleString()}</p>
                  <p className="text-xs text-gray-500 mt-1">Active products</p>
                </div>
                <Package className="h-8 w-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Low Stock</p>
                  <p className="text-2xl font-bold text-orange-600">{stats.lowStockCount}</p>
                  <p className="text-xs text-gray-500 mt-1">Requires attention</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-orange-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Out of Stock</p>
                  <p className="text-2xl font-bold text-red-600">{stats.outOfStockCount}</p>
                  <p className="text-xs text-gray-500 mt-1">Urgent reorder</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Expiring Soon</p>
                  <p className="text-2xl font-bold text-yellow-600">{stats.expiringSoonCount}</p>
                  <p className="text-xs text-gray-500 mt-1">Within 30 days</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Value</p>
                  <p className="text-2xl font-bold text-green-600">{formatTZS(stats.totalValue)}</p>
                  <p className="text-xs text-gray-500 mt-1">Current inventory</p>
                </div>
                <Package className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Start Banner */}
        {products.length === 0 && !loading && (
          <div className="bg-gradient-to-r from-green-50 to-blue-50 border border-green-200 rounded-lg p-6 mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Camera className="h-8 w-8 text-green-500 mr-3" />
                <div>
                  <h3 className="font-semibold text-green-900">Quick Start with Barcode Scanning</h3>
                  <p className="text-green-700 text-sm mt-1">
                    Scan product barcodes or QR codes to automatically populate product information.
                  </p>
                </div>
              </div>
              <Button 
                onClick={() => setShowScanner(true)}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                <Camera className="mr-2 h-4 w-4" />
                Start Scanning
              </Button>
            </div>
          </div>
        )}

        {/* Error Displays */}
        <div className="space-y-4 mb-6">
          {hasLoadingErrors && <ErrorDisplay context="Product Loading" compact />}
          {hasCreationErrors && <ErrorDisplay context="Product Creation" compact />}
          {hasUpdateErrors && <ErrorDisplay context="Product Update" compact />}
          {hasDeletionErrors && <ErrorDisplay context="Product Deletion" compact />}
        </div>

        {/* Main Content */}
        <Card>
          <CardHeader>
            <CardTitle>Product Overview</CardTitle>
          </CardHeader>
          <CardContent>
            {/* Search and Filter Controls */}
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Search products by name, SKU, or barcode..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="flex gap-2">
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All Categories ({products.length})</SelectItem>
                    {categoriesWithCounts.map(category => (
                      <SelectItem key={category.name} value={category.name}>
                        {category.name} ({category.count})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </div>
            </div>

            {/* Selection Status and Bulk Actions */}
            {selectedProductIds.size > 0 && (
              <Alert className="mb-4 bg-blue-50 border-blue-200">
                <Check className="h-4 w-4" />
                <AlertDescription>
                  <div className="flex items-center justify-between">
                    <span className="font-medium">
                      {selectedProductIds.size} product{selectedProductIds.size > 1 ? 's' : ''} selected
                    </span>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleBulkStatusChange('active')}
                        disabled={isProcessingBulk}
                      >
                        <FileEdit className="h-3 w-3 mr-1" />
                        Activate
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleBulkStatusChange('inactive')}
                        disabled={isProcessingBulk}
                      >
                        <Archive className="h-3 w-3 mr-1" />
                        Deactivate
                      </Button>
                      <Button 
                        size="sm" 
                        variant="destructive"
                        onClick={handleBulkDelete}
                        disabled={isProcessingBulk}
                      >
                        {isProcessingBulk ? (
                          <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                        ) : (
                          <Trash className="h-3 w-3 mr-1" />
                        )}
                        Delete
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost"
                        onClick={() => setSelectedProductIds(new Set())}
                      >
                        <X className="h-3 w-3 mr-1" />
                        Clear
                      </Button>
                    </div>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            {/* Loading State */}
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <div className="text-center">
                  <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-indigo-600" />
                  <p className="text-gray-600">Loading products...</p>
                </div>
              </div>
            ) : (
              <>
                {/* Products Table */}
                <div className="rounded-md border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-12">
                          <Checkbox
                            checked={isAllSelected}
                            ref={(ref) => {
                              if (ref) ref.indeterminate = isIndeterminate;
                            }}
                            onCheckedChange={handleSelectAll}
                          />
                        </TableHead>
                        <TableHead>Product</TableHead>
                        <TableHead>SKU/Barcode</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Stock</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {paginatedProducts.length > 0 ? (
                        paginatedProducts.map((product) => (
                          <TableRow key={product.id}>
                            <TableCell>
                              <Checkbox
                                checked={selectedProductIds.has(product.id)}
                                onCheckedChange={(checked) => 
                                  handleSelectProduct(product.id, checked as boolean)
                                }
                              />
                            </TableCell>
                            <TableCell>
                              <div className="space-y-1">
                                <div className="font-medium">{product.name}</div>
                                {product.generic_name && (
                                  <div className="text-sm text-gray-500">{product.generic_name}</div>
                                )}
                                {product.brand_name && (
                                  <Badge variant="outline" className="text-xs">
                                    {product.brand_name}
                                  </Badge>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="space-y-1">
                                <div className="font-mono text-sm">{product.sku}</div>
                                {(product as any).barcode && (
                                  <div className="font-mono text-xs text-gray-500">
                                    <Scan className="h-3 w-3 inline mr-1" />
                                    {(product as any).barcode}
                                  </div>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge className={getCategoryColor(product.category)}>
                                {product.category}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="space-y-1">
                                <div className={`font-medium ${
                                  product.stock_quantity <= product.min_stock_level 
                                    ? product.stock_quantity === 0 ? 'text-red-600' : 'text-orange-600'
                                    : 'text-gray-900'
                                }`}>
                                  {product.stock_quantity}
                                </div>
                                <div className="text-xs text-gray-500">
                                  Min: {product.min_stock_level}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="space-y-1">
                                <div className="font-medium">{formatTZS(product.retail_price)}</div>
                                <div className="text-xs text-gray-500">
                                  Cost: {formatTZS(product.cost_price)}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant={product.status === 'active' ? 'default' : 'secondary'}>
                                {product.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => startEditing(product)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleDeleteProduct(product.id)}
                                  className="text-red-600 hover:text-red-800"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={8} className="text-center py-12">
                            <div className="space-y-4">
                              <Package className="h-16 w-16 text-gray-400 mx-auto" />
                              <div>
                                <h3 className="font-medium text-gray-900 mb-2">No products found</h3>
                                <p className="text-gray-600 mb-4">
                                  {searchTerm || selectedCategory !== 'All' 
                                    ? 'Try adjusting your search or filters'
                                    : 'Get started by adding your first product or scanning a barcode'
                                  }
                                </p>
                                <div className="flex justify-center gap-2">
                                  <Button
                                    onClick={() => setShowScanner(true)}
                                    className="bg-green-600 hover:bg-green-700"
                                  >
                                    <Camera className="mr-2 h-4 w-4" />
                                    Scan Product
                                  </Button>
                                  <Button
                                    onClick={() => {
                                      setIsAddingProduct(true);
                                      resetProductForm();
                                    }}
                                  >
                                    <Plus className="mr-2 h-4 w-4" />
                                    Add Manually
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-between mt-4">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-gray-600">
                        Showing {((currentPage - 1) * pageSize) + 1} to{' '}
                        {Math.min(currentPage * pageSize, filteredProducts.length)} of{' '}
                        {filteredProducts.length} products
                      </span>
                      <Select value={pageSize.toString()} onValueChange={handlePageSizeChange}>
                        <SelectTrigger className="w-20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {PAGE_SIZE_OPTIONS.map(size => (
                            <SelectItem key={size} value={size.toString()}>
                              {size}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <span className="text-sm text-gray-600">per page</span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePageChange(currentPage - 1)}
                        disabled={currentPage === 1}
                      >
                        <ChevronLeft className="h-4 w-4" />
                        Previous
                      </Button>
                      
                      <div className="flex gap-1">
                        {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                          let pageNumber;
                          if (totalPages <= 5) {
                            pageNumber = i + 1;
                          } else if (currentPage <= 3) {
                            pageNumber = i + 1;
                          } else if (currentPage >= totalPages - 2) {
                            pageNumber = totalPages - 4 + i;
                          } else {
                            pageNumber = currentPage - 2 + i;
                          }
                          
                          return (
                            <Button
                              key={pageNumber}
                              variant={pageNumber === currentPage ? "default" : "outline"}
                              size="sm"
                              onClick={() => handlePageChange(pageNumber)}
                              className="w-10"
                            >
                              {pageNumber}
                            </Button>
                          );
                        })}
                      </div>
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePageChange(currentPage + 1)}
                        disabled={currentPage === totalPages}
                      >
                        Next
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Product Form Dialog */}
      <Dialog open={isAddingProduct || editingProduct !== null} onOpenChange={() => !formSubmitting && cancelEditing()}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              {editingProduct ? 'Edit Product' : 'Add Product'}
              {productForm.scanned && (
                <Badge className={`ml-2 ${getConfidenceBadgeColor(productForm.confidence)}`}>
                  Scanned ({productForm.confidence} confidence)
                </Badge>
              )}
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={editingProduct ? handleUpdateProduct : handleAddProduct} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Product Name *</Label>
                <Input
                  id="name"
                  value={productForm.name}
                  onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                  placeholder="Enter product name"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="category">Category *</Label>
                <Select 
                  value={productForm.category} 
                  onValueChange={(value) => setProductForm({ ...productForm, category: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map(category => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="generic_name">Generic Name</Label>
                <Input
                  id="generic_name"
                  value={productForm.generic_name}
                  onChange={(e) => setProductForm({ ...productForm, generic_name: e.target.value })}
                  placeholder="Generic name"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="brand_name">Brand Name</Label>
                <Input
                  id="brand_name"
                  value={productForm.brand_name}
                  onChange={(e) => setProductForm({ ...productForm, brand_name: e.target.value })}
                  placeholder="Brand name"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={productForm.description}
                onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                placeholder="Product description"
                rows={3}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="manufacturer">Manufacturer *</Label>
                <Input
                  id="manufacturer"
                  value={productForm.manufacturer}
                  onChange={(e) => setProductForm({ ...productForm, manufacturer: e.target.value })}
                  placeholder="Manufacturer name"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="strength">Strength</Label>
                <Input
                  id="strength"
                  value={productForm.strength}
                  onChange={(e) => setProductForm({ ...productForm, strength: e.target.value })}
                  placeholder="e.g., 500mg, 10ml"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="sku">SKU *</Label>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={handleGenerateSkuManually}
                    disabled={!productForm.name || !productForm.category}
                  >
                    <Hash className="h-3 w-3 mr-1" />
                    Generate
                  </Button>
                </div>
                <Input
                  id="sku"
                  value={productForm.sku}
                  onChange={(e) => setProductForm({ ...productForm, sku: e.target.value })}
                  placeholder="Stock Keeping Unit"
                  className="font-mono"
                  required
                />
                {productForm.sku && !isSkuUnique(productForm.sku, editingProduct?.id) && (
                  <p className="text-sm text-red-600">SKU already exists - must be unique</p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="barcode">Barcode</Label>
                <Input
                  id="barcode"
                  value={productForm.barcode}
                  onChange={(e) => setProductForm({ ...productForm, barcode: e.target.value })}
                  placeholder="Barcode number"
                  className="font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="cost_price">Cost Price (TZS) *</Label>
                <Input
                  id="cost_price"
                  type="number"
                  step="0.01"
                  min="0"
                  value={productForm.cost_price}
                  onChange={(e) => setProductForm({ ...productForm, cost_price: e.target.value })}
                  placeholder="0.00"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="retail_price">Retail Price (TZS) *</Label>
                <Input
                  id="retail_price"
                  type="number"
                  step="0.01"
                  min="0"
                  value={productForm.retail_price}
                  onChange={(e) => setProductForm({ ...productForm, retail_price: e.target.value })}
                  placeholder="0.00"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="stock_quantity">Stock Quantity *</Label>
                <Input
                  id="stock_quantity"
                  type="number"
                  min="0"
                  value={productForm.stock_quantity}
                  onChange={(e) => setProductForm({ ...productForm, stock_quantity: e.target.value })}
                  placeholder="0"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="min_stock_level">Minimum Stock Level *</Label>
                <Input
                  id="min_stock_level"
                  type="number"
                  min="0"
                  value={productForm.min_stock_level}
                  onChange={(e) => setProductForm({ ...productForm, min_stock_level: e.target.value })}
                  placeholder="0"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="expiry_date">Expiry Date</Label>
                <Input
                  id="expiry_date"
                  type="date"
                  value={productForm.expiry_date}
                  onChange={(e) => setProductForm({ ...productForm, expiry_date: e.target.value })}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select 
                  value={productForm.status} 
                  onValueChange={(value: 'active' | 'inactive') => 
                    setProductForm({ ...productForm, status: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={cancelEditing}
                disabled={formSubmitting}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={formSubmitting}>
                {formSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {editingProduct ? 'Updating...' : 'Adding...'}
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    {editingProduct ? 'Update Product' : 'Add Product'}
                  </>
                )}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* File Import Dialog */}
      <FileImportDialog
        open={showImportDialog}
        onOpenChange={setShowImportDialog}
        userProfile={userProfile}
        onImportComplete={handleImportComplete}
      />

      {/* Barcode Scanner */}
      <BarcodeScanner
        isOpen={showScanner}
        onClose={() => setShowScanner(false)}
        onScanSuccess={handleScanSuccess}
        onError={handleScanError}
      />
    </div>
  );
}