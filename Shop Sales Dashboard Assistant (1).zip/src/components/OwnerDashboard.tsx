import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { PageHeader } from './PageHeader';
import { 
  Download, 
  Mail, 
  MessageSquare, 
  BarChart3, 
  TrendingUp, 
  DollarSign, 
  Package,
  Loader2,
  Sparkles,
  Brain,
  Users,
  UserPlus,
  AlertTriangle
} from 'lucide-react';
import { DashboardCharts } from './DashboardCharts';
import { ReportsTable } from './ReportsTable';
import { UserManagement } from './UserManagement';
import { FirebaseService, UserProfile, Sale, DailyReport } from '../lib/firebase';
import { geminiConnector } from '../lib/gemini-mcp';
import { useError } from '../contexts/ErrorContext';
import { formatTZS, formatCompactTZS } from '../lib/currency-utils';
import { toast } from 'sonner@2.0.3';

interface OwnerDashboardProps {
  onBack: () => void;
  userProfile: UserProfile | null;
}

export function OwnerDashboard({ onBack, userProfile }: OwnerDashboardProps) {
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);
  const [isLoadingData, setIsLoadingData] = useState(true);
  const [todaysSales, setTodaysSales] = useState<Sale[]>([]);
  const [dailyReports, setDailyReports] = useState<DailyReport[]>([]);
  const [salesAnalytics, setSalesAnalytics] = useState<any[]>([]);
  const [topProducts, setTopProducts] = useState<any[]>([]);
  const [aiInsights, setAiInsights] = useState<any>(null);
  const [activeTab, setActiveTab] = useState('analytics');
  const [lastReportError, setLastReportError] = useState<string | null>(null);

  // Use error context for better error handling
  const { addError, addWarning, addSuccess, getErrorsByContext, clearErrorsByContext } = useError();

  // Calculated metrics
  const todaysSalesCount = todaysSales.length;
  const todaysRevenue = todaysSales.reduce((sum, sale) => sum + parseFloat(sale.total_price.toString()), 0);
  const averageTransaction = todaysSalesCount > 0 ? todaysRevenue / todaysSalesCount : 0;

  useEffect(() => {
    if (userProfile?.shop_id) {
      loadDashboardData();
    }
  }, [userProfile]);

  const loadDashboardData = async () => {
    if (!userProfile?.shop_id) return;

    try {
      setIsLoadingData(true);
      clearErrorsByContext('Dashboard Data Loading');
      
      console.log('📊 Loading dashboard data for shop:', userProfile.shop_id);
      
      // Load all dashboard data in parallel with individual error handling
      const dataPromises = [
        FirebaseService.getTodaysSales(userProfile.shop_id).catch(error => {
          console.error('Error loading today\'s sales:', error);
          addWarning('Failed to load today\'s sales', 'Dashboard Data Loading', 'Some sales data may be missing. This could be due to Firebase rules or connectivity issues.');
          return [];
        }),
        FirebaseService.getDailyReports(userProfile.shop_id, 30).catch(error => {
          console.error('Error loading daily reports:', error);
          addWarning('Failed to load daily reports', 'Dashboard Data Loading', 'Historical reports unavailable. This may be due to Firebase rules or index requirements.');
          return [];
        }),
        FirebaseService.getSalesAnalytics(userProfile.shop_id, 30).catch(error => {
          console.error('Error loading sales analytics:', error);
          addWarning('Failed to load sales analytics', 'Dashboard Data Loading', 'Analytics charts may be incomplete. This could be due to Firebase rules or index requirements.');
          return [];
        }),
        FirebaseService.getTopProducts(userProfile.shop_id, 30).catch(error => {
          console.error('Error loading top products:', error);
          addWarning('Failed to load top products', 'Dashboard Data Loading', 'Product performance data unavailable.');
          return [];
        })
      ];

      const [
        todaysData,
        reportsData,
        analyticsData,
        topProductsData
      ] = await Promise.all(dataPromises);

      setTodaysSales(todaysData || []);
      setDailyReports(reportsData || []);
      setSalesAnalytics(analyticsData || []);
      setTopProducts(topProductsData || []);

      console.log('✅ Dashboard data loaded:', {
        todaysSales: todaysData?.length || 0,
        reports: reportsData?.length || 0,
        analytics: analyticsData?.length || 0,
        products: topProductsData?.length || 0
      });

      // Generate AI insights for today's data if we have sales
      if (todaysData && todaysData.length > 0) {
        await generateTodaysAIInsights(todaysData);
      } else {
        console.log('📊 No sales today - skipping AI insights generation');
        setAiInsights({
          summary: "No sales recorded today. This could indicate a system issue or unusual market conditions.",
          insights: [
            "No sales activity detected for today's date range.",
            "This could indicate system connectivity issues, operational challenges, or external market factors.",
            "Immediate investigation recommended to ensure proper sales recording functionality."
          ],
          recommendations: [
            "Verify POS system functionality and network connectivity.",
            "Check store operational status and staff availability.",
            "Review sales recording procedures and staff training.",
            "Consider promotional activities or customer outreach campaigns."
          ],
          alerts: [
            "Zero sales detected - immediate management attention required"
          ],
          trends: {
            salesTrend: 'requires investigation',
            peakHours: 'No data available',
            slowPeriods: 'All operational hours'
          }
        });
      }

    } catch (error) {
      console.error('🚨 Critical error loading dashboard data:', error);
      addError(error, 'Dashboard Data Loading', 'Failed to load dashboard data. This may be due to Firebase rules or connectivity issues.');
    } finally {
      setIsLoadingData(false);
    }
  };

  const generateTodaysAIInsights = async (salesData: Sale[]) => {
    try {
      console.log('🤖 Generating AI insights for', salesData.length, 'sales...');
      clearErrorsByContext('AI Insights Generation');

      const formattedSales = salesData.map(sale => ({
        item: sale.item,
        quantity: sale.quantity,
        unitPrice: sale.unit_price,
        totalPrice: sale.total_price,
        timestamp: sale.timestamp,
        hour: new Date(sale.timestamp).getHours()
      }));

      const insights = await geminiConnector.generateSalesSummary({
        salesData: formattedSales,
        dateRange: 'today',
        previousPeriodData: salesAnalytics.slice(-7)
      });

      setAiInsights(insights);
      console.log('✅ AI insights generated successfully');
      
      // Add success message for real AI vs fallback
      if (insights.alerts?.some((alert: string) => alert.includes('quota') || alert.includes('unavailable'))) {
        addWarning('AI insights using fallback analysis', 'AI Insights Generation', 'Gemini API unavailable. Using intelligent fallback analysis.');
      } else {
        addSuccess('AI insights generated successfully', 'AI Insights Generation');
      }

    } catch (error: any) {
      console.error('🚨 Error generating AI insights:', error);
      
      // Enhanced error handling for specific Gemini issues
      const errorMessage = error?.message || String(error);
      
      if (errorMessage.includes('quota') || errorMessage.includes('429')) {
        addWarning('Gemini quota exceeded - using fallback analysis', 'AI Insights Generation', 'Gemini API quota has been exceeded. AI insights are using intelligent fallback analysis. Please check your Google Cloud billing plan.');
        setLastReportError('Gemini quota exceeded. Fallback analysis will be used for reports.');
      } else if (errorMessage.includes('authentication') || errorMessage.includes('401')) {
        addWarning('Gemini authentication failed - using fallback analysis', 'AI Insights Generation', 'Gemini API authentication failed. Using intelligent fallback analysis. Please check your API key.');
        setLastReportError('Gemini authentication issue. Fallback analysis will be used.');
      } else if (errorMessage.includes('network') || errorMessage.includes('fetch')) {
        addWarning('Network connectivity issues - using fallback analysis', 'AI Insights Generation', 'Network issues prevented Gemini API access. Using intelligent fallback analysis.');
        setLastReportError('Network connectivity issues with Gemini API.');
      } else {
        addError(error, 'AI Insights Generation', 'Failed to generate AI insights. Using fallback analysis.');
        setLastReportError('AI insights generation failed. Fallback analysis available.');
      }
      
      // Set fallback insights
      setAiInsights({
        summary: `AI analysis temporarily unavailable. Today's performance: ${salesData.length} transactions generating ${formatTZS(salesData.reduce((sum, sale) => sum + parseFloat(sale.total_price.toString()), 0))} in revenue.`,
        insights: [
          'AI analysis system temporarily unavailable due to service issues.',
          `Basic performance: ${salesData.length} transactions recorded today.`,
          'Fallback analysis indicates ' + (salesData.length > 10 ? 'good activity levels' : 'potential for improvement') + '.'
        ],
        recommendations: [
          'AI recommendations temporarily unavailable - using standard business practices.',
          'Continue monitoring sales patterns manually during AI system recovery.',
          'Ensure all transactions are properly recorded for future AI analysis.'
        ],
        alerts: [
          'AI analysis temporarily unavailable - manual oversight recommended.'
        ],
        trends: {
          salesTrend: 'manual monitoring required',
          peakHours: 'Analysis unavailable',
          slowPeriods: 'Analysis unavailable'
        }
      });
    }
  };

  const handleGenerateReport = async () => {
    if (!userProfile?.shop_id) {
      toast.error('Shop information not available');
      return;
    }

    setIsGeneratingReport(true);
    setLastReportError(null);
    
    try {
      console.log('🤖 Starting AI-powered daily report generation...');
      clearErrorsByContext('AI Report Generation');
      
      // Generate comprehensive AI report with enhanced error handling
      const aiReport = await FirebaseService.generateAIDailySummary(userProfile.shop_id);
      
      if (aiReport) {
        console.log('📊 AI report generated successfully:', aiReport.id);
        
        // Check if using real Gemini or fallback
        const isUsingFallback = aiReport.aiAnalysis?.quotaExceeded || 
                               aiReport.aiAnalysis?.isMockData || 
                               aiReport.alerts?.some(alert => alert.includes('unavailable') || alert.includes('quota'));
        
        if (isUsingFallback) {
          addWarning('Daily report generated with fallback analysis', 'AI Report Generation', 'Gemini API unavailable. Report created using intelligent fallback analysis.');
          toast.success('Daily report generated successfully!', {
            description: 'Using enhanced fallback analysis due to Gemini API limitations.',
            duration: 6000
          });
        } else {
          addSuccess('AI-powered daily report generated successfully', 'AI Report Generation');
          toast.success('AI-powered daily report generated successfully!', {
            description: 'Real Gemini analysis completed - report saved and ready for distribution.',
            duration: 5000
          });
        }

        // Refresh the reports data
        const updatedReports = await FirebaseService.getDailyReports(userProfile.shop_id, 30);
        setDailyReports(updatedReports || []);
        
      } else {
        throw new Error('Report generation returned no data');
      }
      
    } catch (error: any) {
      console.error('🚨 Error generating report:', error);
      
      const errorMessage = error?.message || String(error);
      
      // Enhanced error handling for specific issues
      if (errorMessage.includes('quota') || errorMessage.includes('429')) {
        setLastReportError('Gemini quota exceeded - reports will use fallback analysis until quota is restored.');
        addError(error, 'AI Report Generation', 'Gemini quota exceeded - cannot generate AI-powered reports. Please check your Google Cloud billing plan.');
        toast.error('Gemini quota exceeded', {
          description: 'Reports will use fallback analysis. Check your billing plan.',
          duration: 10000
        });
      } else if (errorMessage.includes('authentication') || errorMessage.includes('401')) {
        setLastReportError('Gemini authentication failed - check API key configuration.');
        addError(error, 'AI Report Generation', 'Gemini authentication failed. Please verify your API key configuration.');
        toast.error('Gemini authentication failed', {
          description: 'Please verify your API key configuration.',
          duration: 8000
        });
      } else if (errorMessage.includes('permission') || errorMessage.includes('denied')) {
        setLastReportError('Firebase permission denied - deploy security rules to enable reports.');
        addError(error, 'AI Report Generation', 'Firebase permission denied. Please deploy security rules to enable report generation.');
        toast.error('Permission denied', {
          description: 'Deploy Firebase security rules to enable report generation.',
          duration: 8000
        });
      } else if (errorMessage.includes('network') || errorMessage.includes('fetch')) {
        setLastReportError('Network connectivity issues preventing report generation.');
        addError(error, 'AI Report Generation', 'Network connectivity issues. Please check your internet connection and try again.');
        toast.error('Network connectivity issues', {
          description: 'Please check your internet connection and try again.',
          duration: 6000
        });
      } else {
        setLastReportError('Report generation failed due to system error.');
        addError(error, 'AI Report Generation', 'Failed to generate daily report. This may be due to system issues or configuration problems.');
        toast.error('Failed to generate daily report', {
          description: 'System error occurred. Please try again or contact support.',
          duration: 8000
        });
      }
    } finally {
      setIsGeneratingReport(false);
    }
  };

  const handleQuickAction = (action: string) => {
    switch (action) {
      case 'email':
        toast.info('Email integration would send reports to configured recipients');
        break;
      case 'whatsapp':
        toast.info('WhatsApp Business API would send notifications to management');
        break;
      case 'export':
        toast.info('Excel/PDF export functionality would download comprehensive reports');
        break;
      default:
        break;
    }
  };

  if (isLoadingData) {
    return (
      <div className="min-h-screen bg-gray-50 p-4 flex items-center justify-center">
        <div className="text-center space-y-4">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Loading dashboard data...</p>
          <div className="text-xs text-gray-500 space-y-1">
            <div>Fetching sales data, analytics, and reports...</div>
            <div>This may take a moment due to Firebase indexing...</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      {/* Page Header with Navigation */}
      <PageHeader
        title="Owner Dashboard"
        description={`${userProfile?.shop?.name} • AI-Powered Analytics • TZS Currency`}
        breadcrumbs={[{ label: 'Analytics Dashboard', icon: <BarChart3 className="h-4 w-4" /> }]}
        badge={{ text: 'Owner Access', variant: 'secondary' }}
        action={{
          label: isGeneratingReport ? 'Generating AI Report...' : 'Generate AI Report',
          onClick: handleGenerateReport,
          variant: 'default'
        }}
      />

      {/* Error Alert for Report Generation Issues */}
      {lastReportError && (
        <Alert className="mb-6 bg-amber-50 border-amber-300">
          <AlertTriangle className="h-4 w-4 text-amber-600" />
          <AlertDescription>
            <div className="flex items-center justify-between">
              <div>
                <strong className="text-amber-900">Report Generation Notice:</strong>{' '}
                <span className="text-amber-800">{lastReportError}</span>
              </div>
              <Button 
                onClick={() => setLastReportError(null)} 
                variant="outline" 
                size="sm"
                className="border-amber-300 text-amber-700 hover:bg-amber-100"
              >
                Dismiss
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* AI Insights Alert */}
      {aiInsights && (
        <Alert className="mb-6 bg-blue-50 border-blue-200">
          <Sparkles className="h-4 w-4 text-blue-600" />
          <AlertDescription>
            <div className="flex items-center justify-between">
              <div>
                <strong className="text-blue-900">AI Insight:</strong>{' '}
                <span className="text-blue-800">
                  {aiInsights.insights[0] || 'Sales analysis completed for today.'}
                </span>
              </div>
              <Badge className="bg-blue-100 text-blue-800">
                {aiInsights.alerts?.some((alert: string) => alert.includes('unavailable') || alert.includes('quota')) ? 
                  'Fallback Analysis' : 'Powered by Gemini'}
              </Badge>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Key Metrics */}
      <div className="grid md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Today's Sales</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{todaysSalesCount}</div>
            <p className="text-xs text-muted-foreground">transactions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Today's Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{formatTZS(todaysRevenue)}</div>
            <p className="text-xs text-muted-foreground">daily earnings (TZS)</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Avg Transaction</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{formatTZS(averageTransaction)}</div>
            <p className="text-xs text-muted-foreground">per sale (TZS)</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Top Product</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-lg">{topProducts[0]?.name || 'No sales yet'}</div>
            <p className="text-xs text-muted-foreground">
              {topProducts[0] ? `${topProducts[0].quantity} sold` : 'Start recording sales'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* User Management Shortcut */}
      <Alert className="mb-6 bg-orange-50 border-orange-300">
        <UserPlus className="h-4 w-4 text-orange-600" />
        <AlertDescription>
          <div className="flex items-center justify-between">
            <div>
              <strong className="text-orange-900">User Management:</strong>{' '}
              <span className="text-orange-800">
                Need to assign users to your shop? Check the User Management tab below to set up your team.
              </span>
            </div>
            <Button 
              onClick={() => setActiveTab('users')} 
              variant="outline" 
              size="sm"
              className="border-orange-300 text-orange-700 hover:bg-orange-100"
            >
              <Users className="h-4 w-4 mr-2" />
              Go to User Management
            </Button>
          </div>
        </AlertDescription>
      </Alert>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-5 lg:grid-cols-5">
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="ai-insights">AI Insights</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="users" className="bg-orange-100 text-orange-900 data-[state=active]:bg-orange-500 data-[state=active]:text-white">
            <Users className="h-4 w-4 mr-1" />
            Users
          </TabsTrigger>
        </TabsList>

        <TabsContent value="analytics" className="space-y-4">
          <DashboardCharts salesData={salesAnalytics} />
        </TabsContent>

        <TabsContent value="ai-insights" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center">
                    <Brain className="h-5 w-5 mr-2 text-blue-600" />
                    AI-Powered Business Insights
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Real-time analysis and recommendations powered by Google Gemini
                  </p>
                </div>
                <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                  <Sparkles className="h-3 w-3 mr-1" />
                  {aiInsights?.alerts?.some((alert: string) => alert.includes('unavailable') || alert.includes('quota')) ? 
                    'Fallback Analysis' : 'Live AI Analysis'}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              {aiInsights ? (
                <div className="space-y-6">
                  {/* Summary */}
                  <div>
                    <h4 className="mb-2 flex items-center">
                      <BarChart3 className="h-4 w-4 mr-2" />
                      Executive Summary
                    </h4>
                    <p className="text-gray-700 bg-gray-50 p-3 rounded-lg">{aiInsights.summary}</p>
                  </div>

                  {/* Key Insights */}
                  <div>
                    <h4 className="mb-3 flex items-center">
                      <Sparkles className="h-4 w-4 mr-2" />
                      Key Insights
                    </h4>
                    <div className="space-y-2">
                      {aiInsights.insights.map((insight: string, index: number) => (
                        <div key={index} className="flex items-start p-3 bg-blue-50 rounded-lg">
                          <div className="bg-blue-100 rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-0.5">
                            <span className="text-xs text-blue-800">{index + 1}</span>
                          </div>
                          <p className="text-blue-900">{insight}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Recommendations */}
                  <div>
                    <h4 className="mb-3 flex items-center">
                      <TrendingUp className="h-4 w-4 mr-2" />
                      AI Recommendations
                    </h4>
                    <div className="space-y-2">
                      {aiInsights.recommendations.map((rec: string, index: number) => (
                        <div key={index} className="flex items-start p-3 bg-green-50 rounded-lg">
                          <div className="bg-green-100 rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-0.5">
                            <span className="text-xs text-green-800">✓</span>
                          </div>
                          <p className="text-green-900">{rec}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Alerts */}
                  {aiInsights.alerts && aiInsights.alerts.length > 0 && (
                    <div>
                      <h4 className="mb-3 flex items-center text-orange-700">
                        <AlertTriangle className="h-4 w-4 mr-2" />
                        Attention Required
                      </h4>
                      <div className="space-y-2">
                        {aiInsights.alerts.map((alert: string, index: number) => (
                          <div key={index} className="flex items-start p-3 bg-orange-50 rounded-lg border border-orange-200">
                            <div className="bg-orange-100 rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-0.5">
                              <span className="text-xs text-orange-800">!</span>
                            </div>
                            <p className="text-orange-900">{alert}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Brain className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500 mb-2">No AI insights available yet</p>
                  <p className="text-sm text-gray-400">Record some sales to generate AI-powered insights</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="h-5 w-5 mr-2 text-green-600" />
                    Daily Reports & AI Analysis
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Comprehensive daily reports with AI-powered insights and recommendations
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button onClick={() => handleQuickAction('email')} variant="outline" size="sm">
                    <Mail className="h-4 w-4 mr-2" />
                    Email
                  </Button>
                  <Button onClick={() => handleQuickAction('whatsapp')} variant="outline" size="sm">
                    <MessageSquare className="h-4 w-4 mr-2" />
                    WhatsApp
                  </Button>
                  <Button onClick={() => handleQuickAction('export')} variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ReportsTable reports={dailyReports} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="products" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Package className="h-5 w-5 mr-2 text-purple-600" />
                Top Products Performance
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Best performing products based on sales volume and revenue
              </p>
            </CardHeader>
            <CardContent>
              {topProducts.length > 0 ? (
                <div className="space-y-4">
                  {topProducts.slice(0, 10).map((product, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <div className="bg-purple-100 rounded-full w-8 h-8 flex items-center justify-center mr-3">
                          <span className="text-sm text-purple-800">{index + 1}</span>
                        </div>
                        <div>
                          <p className="text-sm">{product.name}</p>
                          <p className="text-xs text-gray-500">{product.quantity} units sold</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm">{formatTZS(product.revenue)}</p>
                        <p className="text-xs text-gray-500">revenue</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500 mb-2">No product data available</p>
                  <p className="text-sm text-gray-400">Start recording sales to see top products</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="h-5 w-5 mr-2 text-orange-600" />
                User Management
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Manage your shop team members and their access levels
              </p>
            </CardHeader>
            <CardContent>
              <UserManagement userProfile={userProfile} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}