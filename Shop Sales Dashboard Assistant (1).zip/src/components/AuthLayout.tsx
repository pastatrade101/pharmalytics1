import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { 
  Store, 
  Zap, 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  Sparkles,
  DollarSign,
  Crown,
  BarChart3,
  Users,
  Stethoscope,
  Scan,
  TrendingUp,
  Layers,
  Star,
  ArrowRight,
  Lock,
  Globe,
  Zap as Lightning
} from 'lucide-react';
import { AuthForm } from './AuthForm';
import { ErrorDisplay } from './ErrorDisplay';
import { FirebasePermissionTester } from './FirebasePermissionTester';
import { CriticalFirebaseFixPanel } from './CriticalFirebaseFixPanel';
import { UserProfile as UserProfileType, AppError } from '../lib/firebase';
import { AIConnectionStatus } from '../hooks/useAIConnection';
import { getAIStatusDisplay } from '../lib/app-helpers';

interface AuthLayoutProps {
  aiSystemStatus: AIConnectionStatus;
  errors: AppError[];
  userProfile: UserProfileType | null;
  hasPermissionErrors: boolean;
  permissionErrorsCount: number;
  onAuthSuccess: () => void;
  onSwitchToSuperAdmin?: () => void;
}

export function AuthLayout({ 
  aiSystemStatus, 
  errors, 
  userProfile, 
  hasPermissionErrors, 
  permissionErrorsCount,
  onAuthSuccess,
  onSwitchToSuperAdmin
}: AuthLayoutProps) {
  const [showPermissionTester, setShowPermissionTester] = useState(false);
  const [showCriticalFix, setShowCriticalFix] = useState(false);

  // Get AI status display configuration
  const aiStatus = getAIStatusDisplay(aiSystemStatus);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-slate-100/20"></div>
      
      {/* Floating Elements - Hidden on small screens for performance */}
      <div className="hidden sm:block absolute top-20 left-10 w-20 h-20 bg-blue-200/20 rounded-full blur-xl animate-pulse"></div>
      <div className="hidden sm:block absolute top-40 right-20 w-32 h-32 bg-purple-200/20 rounded-full blur-xl animate-pulse delay-1000"></div>
      <div className="hidden sm:block absolute bottom-20 left-1/4 w-16 h-16 bg-indigo-200/20 rounded-full blur-xl animate-pulse delay-2000"></div>

      <div className="relative flex items-center justify-center min-h-screen p-4 sm:p-6 lg:p-8">
        <div className="w-full max-w-7xl grid lg:grid-cols-2 gap-6 sm:gap-8 lg:gap-12 items-start lg:items-center">
          
          {/* Left Side - Hero Section */}
          <div className="space-y-6 sm:space-y-8 order-2 lg:order-1">
            {/* Main Hero */}
            <div className="space-y-4 sm:space-y-6 text-center lg:text-left">
              <div className="flex items-center gap-3 mb-4 sm:mb-6 justify-center lg:justify-start">
                <div className="p-2 sm:p-3 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl sm:rounded-2xl shadow-lg">
                  <Store className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
                </div>
                <div className="hidden lg:block h-px flex-1 bg-gradient-to-r from-blue-500/50 to-transparent"></div>
              </div>
              
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-800 bg-clip-text text-transparent leading-tight">
                Pharmacy Management System
              </h1>
              
              <p className="text-lg sm:text-xl text-slate-600 leading-relaxed max-w-xl mx-auto lg:mx-0">
                Transform your pharmacy operations with our comprehensive AI-powered management solution. 
                Streamline inventory, boost sales, and deliver exceptional patient care.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3 sm:gap-4 pt-2 sm:pt-4">
                <div className="flex items-center gap-2 text-sm text-slate-500">
                  <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                  <span>Trusted by 500+ Pharmacies</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-500">
                  <Star className="h-4 w-4 text-yellow-500 fill-current flex-shrink-0" />
                  <span>4.9/5 Rating</span>
                </div>
              </div>
            </div>

            {/* Features Grid - Mobile Optimized */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
              <div className="bg-white/60 backdrop-blur-sm border border-white/20 rounded-xl p-3 sm:p-4 shadow-sm hover:shadow-md transition-all duration-300 btn-press">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-100 rounded-lg flex-shrink-0">
                    <BarChart3 className="h-5 w-5 text-blue-600" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-semibold text-slate-800 text-sm sm:text-base">Smart Analytics</h3>
                    <p className="text-xs text-slate-500">Real-time insights</p>
                  </div>
                </div>
              </div>

              <div className="bg-white/60 backdrop-blur-sm border border-white/20 rounded-xl p-3 sm:p-4 shadow-sm hover:shadow-md transition-all duration-300 btn-press">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-green-100 rounded-lg flex-shrink-0">
                    <Scan className="h-5 w-5 text-green-600" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-semibold text-slate-800 text-sm sm:text-base">Barcode POS</h3>
                    <p className="text-xs text-slate-500">Quick checkout</p>
                  </div>
                </div>
              </div>

              <div className="bg-white/60 backdrop-blur-sm border border-white/20 rounded-xl p-3 sm:p-4 shadow-sm hover:shadow-md transition-all duration-300 btn-press sm:col-span-2 lg:col-span-1">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-purple-100 rounded-lg flex-shrink-0">
                    <Stethoscope className="h-5 w-5 text-purple-600" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-semibold text-slate-800 text-sm sm:text-base">Prescriptions</h3>
                    <p className="text-xs text-slate-500">Patient care</p>
                  </div>
                </div>
              </div>

              <div className="bg-white/60 backdrop-blur-sm border border-white/20 rounded-xl p-3 sm:p-4 shadow-sm hover:shadow-md transition-all duration-300 btn-press">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-orange-100 rounded-lg flex-shrink-0">
                    <Users className="h-5 w-5 text-orange-600" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-semibold text-slate-800 text-sm sm:text-base">Multi-User</h3>
                    <p className="text-xs text-slate-500">Role management</p>
                  </div>
                </div>
              </div>

              <div className="bg-white/60 backdrop-blur-sm border border-white/20 rounded-xl p-3 sm:p-4 shadow-sm hover:shadow-md transition-all duration-300 btn-press">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-100 rounded-lg flex-shrink-0">
                    <Layers className="h-5 w-5 text-indigo-600" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-semibold text-slate-800 text-sm sm:text-base">Inventory</h3>
                    <p className="text-xs text-slate-500">Smart tracking</p>
                  </div>
                </div>
              </div>

              <div className="bg-white/60 backdrop-blur-sm border border-white/20 rounded-xl p-3 sm:p-4 shadow-sm hover:shadow-md transition-all duration-300 btn-press sm:col-span-2 lg:col-span-1">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-yellow-100 rounded-lg flex-shrink-0">
                    <Sparkles className="h-5 w-5 text-yellow-600" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-semibold text-slate-800 text-sm sm:text-base">AI Powered</h3>
                    <p className="text-xs text-slate-500">Intelligence</p>
                  </div>
                </div>
              </div>
            </div>

            {/* AI Status Card - Condensed for mobile */}
            <Card className="bg-white/80 backdrop-blur-sm border-white/20 shadow-xl">
              <CardContent className="p-4 sm:p-6">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-4 mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex-shrink-0">
                      <Lightning className="h-5 w-5 text-white" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-semibold text-slate-800 text-sm sm:text-base">AI System Status</h3>
                      <p className="text-sm text-slate-500">Business intelligence ready</p>
                    </div>
                  </div>
                  <Badge 
                    variant="secondary" 
                    className={`${aiStatus.bgColor} ${aiStatus.textColor} border-0 px-3 py-1 flex-shrink-0`}
                  >
                    {aiStatus.icon}
                    {aiStatus.label}
                  </Badge>
                </div>
                
                <div className="bg-slate-50 rounded-lg p-3 sm:p-4">
                  <p className="text-sm text-slate-600">
                    {aiStatus.description}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* System Health Alert - Mobile optimized */}
            {hasPermissionErrors && (
              <Alert className="bg-amber-50 border-amber-200 shadow-lg">
                <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0" />
                <AlertDescription className="text-amber-800">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <div className="min-w-0">
                      <strong>System Setup Required:</strong> {permissionErrorsCount} configuration 
                      issue{permissionErrorsCount !== 1 ? 's' : ''} detected.
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={() => setShowCriticalFix(true)}
                        size="sm"
                        className="bg-amber-600 hover:bg-amber-700 text-white btn-press min-h-[44px] min-w-[44px] sm:min-h-auto sm:min-w-auto"
                      >
                        Fix Now
                      </Button>
                    </div>
                  </div>
                </AlertDescription>
              </Alert>
            )}
          </div>

          {/* Right Side - Authentication - Mobile First */}
          <div className="space-y-4 sm:space-y-6 order-1 lg:order-2 w-full">
            {/* Critical Errors Display */}
            {errors.length > 0 && (
              <ErrorDisplay 
                context="Authentication" 
                compact={true}
                className="mb-4 sm:mb-6"
              />
            )}

            {/* Main Auth Card - Mobile Optimized */}
            <Card className="bg-white/90 backdrop-blur-xl border-white/20 shadow-2xl">
              <CardHeader className="text-center space-y-3 sm:space-y-4 pb-4 sm:pb-6 px-4 sm:px-6">
                <div className="flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-3">
                  <div className="p-2 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex-shrink-0">
                    <Store className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                  </div>
                  <h2 className="text-lg sm:text-xl lg:text-2xl font-bold text-slate-800 leading-tight">
                    Pharmacy Management System
                  </h2>
                </div>
                <p className="text-sm sm:text-base text-slate-600">AI-Powered Pharmacy Sales & Inventory Management</p>
              </CardHeader>

              <CardContent className="space-y-4 sm:space-y-6 px-4 sm:px-6">
                {/* Mobile-optimized auth toggle */}
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-8 mb-4 sm:mb-6">
                  <div className="text-center w-full sm:w-auto">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-blue-600 hover:text-blue-700 hover:bg-blue-50 w-full sm:w-auto min-h-[44px] btn-press"
                    >
                      Sign In
                    </Button>
                  </div>
                  <div className="hidden sm:block w-px h-6 bg-slate-200"></div>
                  <div className="block sm:hidden w-full h-px bg-slate-200"></div>
                  <div className="text-center w-full sm:w-auto">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-slate-500 hover:text-slate-700 hover:bg-slate-50 w-full sm:w-auto min-h-[44px] text-xs sm:text-sm btn-press"
                    >
                      Create Pharmacy & Owner Account
                    </Button>
                  </div>
                </div>

                <AuthForm onAuthSuccess={onAuthSuccess} />

                <div className="text-center">
                  <button className="text-sm text-blue-600 hover:text-blue-700 hover:underline min-h-[44px] flex items-center justify-center mx-auto btn-press">
                    ▶ Need help with setup?
                  </button>
                </div>
              </CardContent>
            </Card>

            {/* Super Admin Access - Mobile Responsive */}
            {onSwitchToSuperAdmin && (
              <>
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-slate-200"></div>
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="bg-slate-50 px-4 text-slate-500">Advanced Access</span>
                  </div>
                </div>

                <Card className="bg-gradient-to-br from-purple-50 to-indigo-50 border-purple-200/50 shadow-lg">
                  <CardContent className="p-4 sm:p-6">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                      <div className="flex items-start sm:items-center gap-3 sm:gap-4 min-w-0">
                        <div className="p-2 sm:p-3 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl shadow-lg flex-shrink-0">
                          <Crown className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                        </div>
                        <div className="min-w-0">
                          <h3 className="font-semibold text-purple-900 text-base sm:text-lg">Software Owner Portal</h3>
                          <p className="text-purple-700 text-sm">
                            Access the super admin dashboard to manage all pharmacies
                          </p>
                        </div>
                      </div>
                      <Button
                        onClick={onSwitchToSuperAdmin}
                        className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white shadow-lg btn-press min-h-[44px] w-full sm:w-auto"
                      >
                        <Shield className="h-4 w-4 mr-2" />
                        Super Admin
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}

            {/* Footer - Mobile Responsive */}
            <div className="text-center space-y-2">
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-6 text-sm text-slate-500">
                <div className="flex items-center gap-2">
                  <Lock className="h-4 w-4 flex-shrink-0" />
                  <span>Secure</span>
                </div>
                <div className="flex items-center gap-2">
                  <Globe className="h-4 w-4 flex-shrink-0" />
                  <span>Reliable</span>
                </div>
                <div className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4 flex-shrink-0" />
                  <span>AI-Powered</span>
                </div>
              </div>
              
              <p className="text-slate-400 text-sm">
                Pharmacy Management System v2.1.0
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Diagnostic Modals */}
      {showPermissionTester && (
        <FirebasePermissionTester onClose={() => setShowPermissionTester(false)} />
      )}
      
      {showCriticalFix && (
        <CriticalFirebaseFixPanel onClose={() => setShowCriticalFix(false)} />
      )}
    </div>
  );
}