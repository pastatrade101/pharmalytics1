import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { 
  Shield, 
  AlertTriangle, 
  Terminal, 
  Copy, 
  CheckCircle, 
  ExternalLink,
  Zap,
  Clock,
  Database,
  Settings,
  Loader2
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface CriticalFirebaseRulesModalProps {
  hasPermissionErrors: boolean;
  errorCount: number;
  isOpen?: boolean;
  onClose?: () => void;
}

export function CriticalFirebaseRulesModal({ 
  hasPermissionErrors, 
  errorCount, 
  isOpen = false,
  onClose 
}: CriticalFirebaseRulesModalProps) {
  const [activeStep, setActiveStep] = useState(1);
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null);
  const [deploymentStatus, setDeploymentStatus] = useState<'idle' | 'checking' | 'success' | 'failed'>('idle');

  // Auto-open modal when permission errors are detected
  const [modalOpen, setModalOpen] = useState(false);

  useEffect(() => {
    if (hasPermissionErrors && errorCount > 0) {
      setModalOpen(true);
    }
  }, [hasPermissionErrors, errorCount]);

  const handleClose = () => {
    setModalOpen(false);
    onClose?.();
  };

  const copyToClipboard = async (text: string, commandName: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedCommand(commandName);
      toast.success(`${commandName} copied to clipboard!`);
      setTimeout(() => setCopiedCommand(null), 2000);
    } catch (error) {
      toast.error('Failed to copy to clipboard');
    }
  };

  const checkDeploymentStatus = () => {
    setDeploymentStatus('checking');
    
    // Simulate checking deployment status
    setTimeout(() => {
      // In a real implementation, this would check if the rules are actually deployed
      setDeploymentStatus('success');
      toast.success('🎉 Firebase rules appear to be working! Try refreshing the page.');
    }, 3000);
  };

  const firebaseRules = `rules_version = '2';

service cloud.firestore {
  match /databases/{database}/documents {
    // Allow authenticated users to read/write their own profile
    match /profiles/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Allow shop owners and managers to manage their shop data
    match /shops/{shopId} {
      allow read, write: if request.auth != null && 
        (get(/databases/$(database)/documents/profiles/$(request.auth.uid)).data.role == 'owner' ||
         get(/databases/$(database)/documents/profiles/$(request.auth.uid)).data.role == 'manager') &&
        get(/databases/$(database)/documents/profiles/$(request.auth.uid)).data.shop_id == shopId;
    }
    
    // Sales data - allow read/write for users assigned to the shop
    match /sales/{saleId} {
      allow read, write: if request.auth != null && 
        get(/databases/$(database)/documents/profiles/$(request.auth.uid)).data.shop_id == resource.data.shop_id;
    }
    
    // Products - allow read/write for shop users
    match /products/{productId} {
      allow read, write: if request.auth != null && 
        get(/databases/$(database)/documents/profiles/$(request.auth.uid)).data.shop_id == resource.data.shop_id;
    }
    
    // Daily reports - allow read/write for shop users  
    match /daily_reports/{reportId} {
      allow read, write: if request.auth != null && 
        get(/databases/$(database)/documents/profiles/$(request.auth.uid)).data.shop_id == resource.data.shop_id;
    }
  }
}`;

  const deploymentCommands = [
    {
      name: 'Install Firebase CLI',
      command: 'npm install -g firebase-tools',
      description: 'Install the Firebase CLI globally'
    },
    {
      name: 'Login to Firebase',
      command: 'firebase login',
      description: 'Authenticate with your Firebase account'
    },
    {
      name: 'Initialize Firebase (if needed)',
      command: 'firebase init firestore',
      description: 'Initialize Firestore in your project (skip if already done)'
    },
    {
      name: 'Deploy Rules',
      command: 'firebase deploy --only firestore:rules',
      description: 'Deploy the security rules to Firebase'
    }
  ];

  return (
    <Dialog open={modalOpen || isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center text-2xl text-red-900">
            <Shield className="h-6 w-6 mr-2 text-red-600" />
            🚨 CRITICAL: Firebase Security Rules Required
          </DialogTitle>
          <DialogDescription>
            Firebase security rules must be deployed to enable all Shop Sales Dashboard features. This modal will guide you through the quick deployment process.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Status Alert */}
          <Alert variant="destructive" className="bg-red-50 border-red-300">
            <AlertTriangle className="h-5 w-5 text-red-600" />
            <AlertDescription>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <strong className="text-red-900 text-lg">Shop Sales Dashboard is BLOCKED</strong>
                  <Badge variant="destructive" className="animate-pulse">
                    {errorCount} Permission Error{errorCount !== 1 ? 's' : ''}
                  </Badge>
                </div>
                <p className="text-red-800">
                  Firebase security rules are not deployed. All sales recording, real-time updates, 
                  and data access features are disabled until you complete the deployment below.
                </p>
                <div className="flex items-center gap-2 text-sm text-red-700 mt-2">
                  <Clock className="h-4 w-4" />
                  <span><strong>Estimated fix time:</strong> 3-5 minutes</span>
                </div>
              </div>
            </AlertDescription>
          </Alert>

          {/* Quick Fix Overview */}
          <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle className="flex items-center text-blue-900">
                <Zap className="h-5 w-5 mr-2" />
                Quick Fix Overview
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div className="flex items-center">
                  <div className="bg-blue-100 rounded-full w-8 h-8 flex items-center justify-center mr-3">
                    <span className="text-blue-800 font-bold">1</span>
                  </div>
                  <span>Copy Firebase rules</span>
                </div>
                <div className="flex items-center">
                  <div className="bg-blue-100 rounded-full w-8 h-8 flex items-center justify-center mr-3">
                    <span className="text-blue-800 font-bold">2</span>
                  </div>
                  <span>Run deployment commands</span>
                </div>
                <div className="flex items-center">
                  <div className="bg-blue-100 rounded-full w-8 h-8 flex items-center justify-center mr-3">
                    <span className="text-blue-800 font-bold">3</span>
                  </div>
                  <span>Refresh the page</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Step-by-step instructions */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-semibold">Step-by-Step Fix</h3>
              <Badge variant="secondary">Required</Badge>
            </div>

            {/* Step 1: Copy Rules */}
            <Card className={`border-2 ${activeStep === 1 ? 'border-blue-500 bg-blue-50' : 'border-gray-200'}`}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="bg-blue-600 text-white rounded-full w-8 h-8 flex items-center justify-center mr-3">
                      1
                    </div>
                    Copy Firebase Security Rules
                  </div>
                  <Button
                    onClick={() => copyToClipboard(firebaseRules, 'Firebase Rules')}
                    variant="outline"
                    size="sm"
                    className="flex items-center gap-2"
                  >
                    <Copy className="h-4 w-4" />
                    {copiedCommand === 'Firebase Rules' ? 'Copied!' : 'Copy Rules'}
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <p className="text-sm text-gray-600 mb-3">
                    Create a file called <code className="bg-gray-100 px-2 py-1 rounded">firestore.rules</code> in your project root and paste these rules:
                  </p>
                  <div className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto">
                    <pre className="text-xs">
                      <code>{firebaseRules}</code>
                    </pre>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Step 2: Deploy Rules */}
            <Card className={`border-2 ${activeStep === 2 ? 'border-blue-500 bg-blue-50' : 'border-gray-200'}`}>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <div className="bg-blue-600 text-white rounded-full w-8 h-8 flex items-center justify-center mr-3">
                    2
                  </div>
                  Deploy Rules to Firebase
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <p className="text-sm text-gray-600">
                    Run these commands in your terminal (in order):
                  </p>
                  
                  <div className="space-y-3">
                    {deploymentCommands.map((cmd, index) => (
                      <div key={index} className="border rounded-lg p-3 bg-gray-50">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium text-sm">{cmd.name}</span>
                          <Button
                            onClick={() => copyToClipboard(cmd.command, cmd.name)}
                            variant="outline"
                            size="sm"
                            className="h-7 px-2"
                          >
                            <Copy className="h-3 w-3 mr-1" />
                            {copiedCommand === cmd.name ? 'Copied!' : 'Copy'}
                          </Button>
                        </div>
                        <div className="bg-gray-900 text-gray-100 p-2 rounded text-sm font-mono">
                          {cmd.command}
                        </div>
                        <p className="text-xs text-gray-600 mt-1">{cmd.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Step 3: Verify Deployment */}
            <Card className={`border-2 ${activeStep === 3 ? 'border-blue-500 bg-blue-50' : 'border-gray-200'}`}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="bg-blue-600 text-white rounded-full w-8 h-8 flex items-center justify-center mr-3">
                      3
                    </div>
                    Verify Deployment
                  </div>
                  <Button
                    onClick={checkDeploymentStatus}
                    disabled={deploymentStatus === 'checking'}
                    variant="outline"
                    size="sm"
                  >
                    {deploymentStatus === 'checking' ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Checking...
                      </>
                    ) : deploymentStatus === 'success' ? (
                      <>
                        <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                        Success!
                      </>
                    ) : (
                      <>
                        <Database className="h-4 w-4 mr-2" />
                        Test Connection
                      </>
                    )}
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <p className="text-sm text-gray-600">
                    After running the deployment commands:
                  </p>
                  <ol className="list-decimal list-inside space-y-2 text-sm">
                    <li>Wait for the deployment to complete (you'll see "Deploy complete" message)</li>
                    <li>Click "Test Connection" above to verify the rules are working</li>
                    <li>Refresh this page to start using the Shop Sales Dashboard</li>
                  </ol>
                  
                  {deploymentStatus === 'success' && (
                    <Alert className="bg-green-50 border-green-200">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <AlertDescription className="text-green-800">
                        <strong>Success!</strong> Firebase rules appear to be deployed correctly. 
                        Refresh the page to start using all features.
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          <Separator />

          {/* Additional Help */}
          <Card className="bg-amber-50 border-amber-200">
            <CardHeader>
              <CardTitle className="flex items-center text-amber-900">
                <Settings className="h-5 w-5 mr-2" />
                Need Additional Help?
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <h4 className="font-medium mb-2">Common Issues:</h4>
                  <ul className="space-y-1 text-amber-800">
                    <li>• Make sure you're in the correct project directory</li>
                    <li>• Ensure you're logged into the correct Firebase account</li>
                    <li>• Check that your Firebase project ID matches</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Resources:</h4>
                  <div className="space-y-2">
                    <Button variant="outline" size="sm" className="w-full justify-start">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Firebase Console
                    </Button>
                    <Button variant="outline" size="sm" className="w-full justify-start">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Firebase CLI Docs
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="flex gap-3 justify-end">
            <Button
              onClick={handleClose}
              variant="outline"
              className="px-6"
            >
              I'll Fix This Later
            </Button>
            <Button
              onClick={() => window.location.reload()}
              className="px-6 bg-green-600 hover:bg-green-700"
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              I've Deployed Rules - Refresh Page
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}