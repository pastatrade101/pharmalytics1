import React, { useState } from 'react';
import { Package, AlertTriangle, TrendingUp, TrendingDown, Search, Filter, Plus, Scan, Download, ArrowLeft } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Alert, AlertDescription } from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { formatTZS } from '../lib/currency-utils';

interface InventoryManagerProps {
  userProfile: any;
  onBack: () => void;
  onSetCurrentView: (view: any) => void;
}

export function InventoryManager({ userProfile, onBack, onSetCurrentView }: InventoryManagerProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [activeTab, setActiveTab] = useState('overview');
  
  // Debug tab changes
  const handleTabChange = (value: string) => {
    console.log('📊 Inventory tab changed to:', value);
    console.log('📊 Previous tab was:', activeTab);
    setActiveTab(value);
  };

  // Debug current tab state
  React.useEffect(() => {
    console.log('🔄 Current active tab:', activeTab);
  }, [activeTab]);

  // Sample inventory items for overview table
  const allInventoryItems = [
    {
      id: '1',
      name: 'Teething Gel',
      sku: 'TEE75',
      category: 'Baby & Child Care',
      price: 1200,
      cost: 800,
      stock: 25,
      status: 'active',
      minLevel: 10
    },
    {
      id: '2',
      name: 'Diaper Rash Cream',
      sku: 'DIA48',
      category: 'Baby & Child Care',
      price: 1800,
      cost: 1200,
      stock: 0,
      status: 'active',
      minLevel: 5
    },
    {
      id: '3',
      name: 'Oral Rehydration Salts',
      sku: 'ORS1',
      category: 'Baby & Child Care',
      price: 350,
      cost: 200,
      stock: 4,
      status: 'active',
      minLevel: 10
    },
    {
      id: '4',
      name: "Children's Multivitamin Gummies",
      sku: 'CHGUM',
      category: 'Baby & Child Care',
      price: 2600,
      cost: 1800,
      stock: 60,
      status: 'active',
      minLevel: 20
    },
    {
      id: '5',
      name: 'Infant Paracetamol Drops',
      sku: 'PAR128',
      category: 'Baby & Child Care',
      price: 2200,
      cost: 1500,
      stock: 15,
      status: 'active',
      minLevel: 8
    }
  ];

  // Mock data for demonstration
  const inventoryStats = {
    totalProducts: 1247,
    lowStockItems: 23,
    outOfStock: 5,
    expiringItems: 12,
    totalValue: 2847500
  };

  const lowStockItems = [
    {
      id: '1',
      name: 'Paracetamol 500mg Tablets',
      sku: 'PAR500',
      currentStock: 8,
      minLevel: 20,
      maxLevel: 100,
      category: 'Pain Relief',
      lastRestocked: '2024-01-10',
      supplier: 'MedSupply Ltd'
    },
    {
      id: '2', 
      name: 'Amoxicillin 250mg Capsules',
      sku: 'AMX250',
      currentStock: 5,
      minLevel: 15,
      maxLevel: 80,
      category: 'Antibiotics',
      lastRestocked: '2024-01-08',
      supplier: 'PharmaCorp'
    },
    {
      id: '3',
      name: 'Vitamin C 1000mg Tablets',
      sku: 'VTC1000',
      currentStock: 12,
      minLevel: 25,
      maxLevel: 150,
      category: 'Vitamins & Supplements',
      lastRestocked: '2024-01-12',
      supplier: 'HealthPlus'
    }
  ];

  const recentMovements = [
    {
      id: '1',
      product: 'Paracetamol 500mg',
      type: 'sale',
      quantity: -10,
      timestamp: '2024-01-15 14:30',
      reference: 'SALE-001234'
    },
    {
      id: '2',
      product: 'Cough Syrup 100ml',
      type: 'purchase',
      quantity: +50,
      timestamp: '2024-01-15 10:15',
      reference: 'PO-5678'
    },
    {
      id: '3',
      product: 'Bandages 5cm',
      type: 'adjustment',
      quantity: -2,
      timestamp: '2024-01-15 09:45',
      reference: 'ADJ-001'
    }
  ];

  const getStockStatus = (current: number, min: number) => {
    if (current === 0) return { status: 'out-of-stock', color: 'destructive', text: 'Out of Stock' };
    if (current <= min) return { status: 'low-stock', color: 'warning', text: 'Low Stock' };
    return { status: 'in-stock', color: 'default', text: 'In Stock' };
  };

  // Filter inventory items based on current filters
  const filteredInventoryItems = allInventoryItems.filter(item => {
    const matchesSearch = searchQuery === '' || 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.sku.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = filterCategory === 'all' || item.category.toLowerCase().includes(filterCategory);
    
    const stockStatus = getStockStatus(item.stock, item.minLevel);
    const matchesStatus = filterStatus === 'all' || stockStatus.status === filterStatus;
    
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const getMovementIcon = (type: string) => {
    switch (type) {
      case 'sale':
        return <TrendingDown className="h-4 w-4 text-red-500" />;
      case 'purchase':
        return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'adjustment':
        return <Package className="h-4 w-4 text-blue-500" />;
      default:
        return <Package className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Navigation Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="px-6 py-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={onBack}
              className="hover:bg-gray-100"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
            <div className="h-6 w-px bg-gray-300" />
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Inventory Management</h1>
              <p className="text-gray-600">Monitor and manage your pharmacy inventory</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="p-6 space-y-6">
      {/* Inventory Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Products</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{inventoryStats.totalProducts.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Active products</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Low Stock</CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{inventoryStats.lowStockItems}</div>
            <p className="text-xs text-muted-foreground">Requires attention</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Out of Stock</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{inventoryStats.outOfStock}</div>
            <p className="text-xs text-muted-foreground">Urgent reorder</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Expiring Soon</CardTitle>
            <AlertTriangle className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{inventoryStats.expiringItems}</div>
            <p className="text-xs text-muted-foreground">Within 30 days</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Value</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{formatTZS(inventoryStats.totalValue)}</div>
            <p className="text-xs text-muted-foreground">Current inventory</p>
          </CardContent>
        </Card>
      </div>

      {/* Critical Alerts */}
      {(inventoryStats.outOfStock > 0 || inventoryStats.lowStockItems > 0) && (
        <Alert className="border-orange-200 bg-orange-50">
          <AlertTriangle className="h-4 w-4 text-orange-600" />
          <AlertDescription>
            <div className="flex items-center justify-between">
              <div>
                <strong className="text-orange-900">Inventory Alert:</strong>{' '}
                {inventoryStats.outOfStock > 0 && (
                  <span className="text-red-700">{inventoryStats.outOfStock} items out of stock, </span>
                )}
                <span className="text-orange-700">{inventoryStats.lowStockItems} items below minimum levels.</span>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => onSetCurrentView('reorder-management')}
              >
                Manage Reorders
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <TabsList>
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="low-stock">Low Stock</TabsTrigger>
              <TabsTrigger value="movements">Stock Movements</TabsTrigger>
              <TabsTrigger value="reports">Reports</TabsTrigger>
            </TabsList>
            <div className="text-sm text-gray-500">
              Active: <span className="font-medium capitalize">{activeTab}</span>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button variant="outline" size="sm">
              <Scan className="h-4 w-4 mr-2" />
              Quick Count
            </Button>
            <Button size="sm" onClick={() => onSetCurrentView('product-management')}>
              <Plus className="h-4 w-4 mr-2" />
              Add Product
            </Button>
          </div>
        </div>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          {/* Search and Filters */}
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search products by name, SKU, or barcode..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="All Categories (103)" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories (103)</SelectItem>
                <SelectItem value="baby">Baby & Child Care</SelectItem>
                <SelectItem value="prescription">Prescription Medicines</SelectItem>
                <SelectItem value="otc">Over-the-Counter</SelectItem>
                <SelectItem value="antibiotics">Antibiotics</SelectItem>
                <SelectItem value="vitamins">Vitamins & Supplements</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="in-stock">In Stock</SelectItem>
                <SelectItem value="low-stock">Low Stock</SelectItem>
                <SelectItem value="out-of-stock">Out of Stock</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Products Table */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Products (103)</span>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Import Catalog
                  </Button>
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Download Catalog
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product Name</TableHead>
                    <TableHead>SKU</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Stock</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredInventoryItems.map((item) => {
                    const stockStatus = getStockStatus(item.stock, item.minLevel);
                    return (
                      <TableRow key={item.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{item.name}</div>
                            <div className="text-sm text-gray-500">Generic: Benzocaine • Brand: Orajel Baby</div>
                          </div>
                        </TableCell>
                        <TableCell className="font-mono text-sm">{item.sku}</TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                            {item.category}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium text-green-600">{formatTZS(item.price)}</div>
                            <div className="text-sm text-gray-500">Cost: {formatTZS(item.cost)}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">
                            {item.stock}
                            {item.stock === 0 && <span className="text-red-500 ml-2">⚠</span>}
                            {item.stock > 0 && item.stock <= item.minLevel && <span className="text-orange-500 ml-2">��</span>}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant={stockStatus.color === 'warning' ? 'secondary' : 
                                   stockStatus.color === 'destructive' ? 'destructive' : 'default'}
                            className={
                              stockStatus.color === 'warning' ? 'bg-orange-100 text-orange-800' : 
                              stockStatus.status === 'out-of-stock' ? 'bg-red-100 text-red-800' :
                              'bg-green-100 text-green-800'
                            }
                          >
                            {stockStatus.text}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button variant="ghost" size="sm">
                              <Package className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <TrendingUp className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" className="text-red-600">
                              <AlertTriangle className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Low Stock Tab */}
        <TabsContent value="low-stock" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-orange-600" />
                Low Stock Items ({lowStockItems.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="text-sm text-gray-600">
                  Items below minimum stock levels that require immediate attention
                </div>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product</TableHead>
                      <TableHead>SKU</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Current Stock</TableHead>
                      <TableHead>Min Level</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Last Restocked</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {lowStockItems.map((item) => {
                      const stockStatus = getStockStatus(item.currentStock, item.minLevel);
                      return (
                        <TableRow key={item.id}>
                          <TableCell className="font-medium">{item.name}</TableCell>
                          <TableCell className="font-mono text-sm">{item.sku}</TableCell>
                          <TableCell>
                            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                              {item.category}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <span className="font-medium text-orange-600">{item.currentStock}</span>
                          </TableCell>
                          <TableCell>{item.minLevel}</TableCell>
                          <TableCell>
                            <Badge 
                              variant={stockStatus.color === 'warning' ? 'secondary' : 
                                     stockStatus.color === 'destructive' ? 'destructive' : 'default'}
                              className={
                                stockStatus.color === 'warning' ? 'bg-orange-100 text-orange-800' : 
                                stockStatus.status === 'out-of-stock' ? 'bg-red-100 text-red-800' :
                                'bg-green-100 text-green-800'
                              }
                            >
                              {stockStatus.text}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm text-gray-500">{item.lastRestocked}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Button size="sm" variant="outline" className="text-blue-600 border-blue-300">
                                <Plus className="h-4 w-4 mr-1" />
                                Reorder
                              </Button>
                              <Button size="sm" variant="ghost">
                                <TrendingUp className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Stock Movements Tab */}
        <TabsContent value="movements" className="space-y-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Stock Movements</h3>
              <p className="text-sm text-gray-600">Track all inventory changes and transactions</p>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-blue-600" />
                Recent Stock Movements ({recentMovements.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <Card className="p-4">
                    <div className="flex items-center gap-3">
                      <TrendingDown className="h-8 w-8 text-red-500" />
                      <div>
                        <div className="text-sm text-gray-500">Sales Today</div>
                        <div className="text-xl font-bold">-127</div>
                      </div>
                    </div>
                  </Card>
                  <Card className="p-4">
                    <div className="flex items-center gap-3">
                      <TrendingUp className="h-8 w-8 text-green-500" />
                      <div>
                        <div className="text-sm text-gray-500">Restocked</div>
                        <div className="text-xl font-bold">+89</div>
                      </div>
                    </div>
                  </Card>
                  <Card className="p-4">
                    <div className="flex items-center gap-3">
                      <Package className="h-8 w-8 text-blue-500" />
                      <div>
                        <div className="text-sm text-gray-500">Adjustments</div>
                        <div className="text-xl font-bold">-5</div>
                      </div>
                    </div>
                  </Card>
                </div>
                
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Type</TableHead>
                      <TableHead>Product</TableHead>
                      <TableHead>Quantity</TableHead>
                      <TableHead>Timestamp</TableHead>
                      <TableHead>Reference</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentMovements.map((movement) => (
                      <TableRow key={movement.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getMovementIcon(movement.type)}
                            <span className="capitalize font-medium">{movement.type}</span>
                          </div>
                        </TableCell>
                        <TableCell className="font-medium">{movement.product}</TableCell>
                        <TableCell>
                          <span className={`font-bold ${movement.quantity > 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {movement.quantity > 0 ? '+' : ''}{movement.quantity}
                          </span>
                        </TableCell>
                        <TableCell className="text-sm text-gray-600">{movement.timestamp}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="font-mono text-xs">
                            {movement.reference}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm">
                            <TrendingUp className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Reports Tab */}
        <TabsContent value="reports" className="space-y-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Inventory Reports</h3>
              <p className="text-sm text-gray-600">Generate comprehensive inventory analytics and reports</p>
            </div>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export All Reports
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => onSetCurrentView('inventory-reports')}>
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <TrendingUp className="h-8 w-8 text-blue-600" />
                  <div>
                    <h3 className="font-medium">Inventory Analysis</h3>
                    <p className="text-sm text-gray-500">Detailed inventory reports and trends</p>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t">
                  <div className="text-xs text-gray-500">Last updated: Today</div>
                </div>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <Download className="h-8 w-8 text-green-600" />
                  <div>
                    <h3 className="font-medium">Export Data</h3>
                    <p className="text-sm text-gray-500">Download inventory data in various formats</p>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t">
                  <div className="text-xs text-gray-500">Available: CSV, Excel, PDF</div>
                </div>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <AlertTriangle className="h-8 w-8 text-orange-600" />
                  <div>
                    <h3 className="font-medium">Stock Alerts</h3>
                    <p className="text-sm text-gray-500">Low stock and expiry notifications</p>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t">
                  <div className="text-xs text-orange-600">23 items need attention</div>
                </div>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <Package className="h-8 w-8 text-purple-600" />
                  <div>
                    <h3 className="font-medium">Valuation Report</h3>
                    <p className="text-sm text-gray-500">Current inventory value analysis</p>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t">
                  <div className="text-xs text-green-600">Total: {formatTZS(inventoryStats.totalValue)}</div>
                </div>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <TrendingDown className="h-8 w-8 text-red-600" />
                  <div>
                    <h3 className="font-medium">Movement History</h3>
                    <p className="text-sm text-gray-500">Stock movement detailed reports</p>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t">
                  <div className="text-xs text-gray-500">Last 30 days activity</div>
                </div>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <Search className="h-8 w-8 text-indigo-600" />
                  <div>
                    <h3 className="font-medium">Custom Reports</h3>
                    <p className="text-sm text-gray-500">Build your own inventory reports</p>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t">
                  <div className="text-xs text-gray-500">Create custom queries</div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Stats */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Inventory Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{inventoryStats.totalProducts}</div>
                  <div className="text-sm text-blue-800">Total Products</div>
                </div>
                <div className="text-center p-4 bg-orange-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">{inventoryStats.lowStockItems}</div>
                  <div className="text-sm text-orange-800">Low Stock Items</div>
                </div>
                <div className="text-center p-4 bg-red-50 rounded-lg">
                  <div className="text-2xl font-bold text-red-600">{inventoryStats.outOfStock}</div>
                  <div className="text-sm text-red-800">Out of Stock</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">{formatTZS(inventoryStats.totalValue)}</div>
                  <div className="text-sm text-green-800">Total Value</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      </main>
    </div>
  );
}