import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Truck, TrendingUp, AlertTriangle, BarChart3 } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';

interface SupplierReportsProps {
  userProfile: any;
  onBack: () => void;
  onSetCurrentView: (view: any) => void;
}

export function SupplierReports({ userProfile, onBack, onSetCurrentView }: SupplierReportsProps) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center">
            <Truck className="h-6 w-6 mr-2" />
            Supplier Reports
          </h1>
          <p className="text-gray-600 mt-1">Supplier performance and relationship analysis</p>
        </div>
        <Button onClick={onBack} variant="outline">Back to Dashboard</Button>
      </div>

      <Alert className="border-blue-200 bg-blue-50">
        <AlertTriangle className="h-4 w-4 text-blue-600" />
        <AlertDescription>
          <strong className="text-blue-900">Supplier Analytics Coming Soon</strong>
          <br />
          <span className="text-blue-800">Supplier performance tracking and relationship management</span>
        </AlertDescription>
      </Alert>

      <div className="text-center py-12">
        <Truck className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-600 mb-2">Supplier Analytics</h3>
        <p className="text-gray-500 mb-6">Supplier performance and procurement insights</p>
        <Button onClick={() => onSetCurrentView('inventory')} variant="outline">View Inventory Management</Button>
      </div>
    </div>
  );
}