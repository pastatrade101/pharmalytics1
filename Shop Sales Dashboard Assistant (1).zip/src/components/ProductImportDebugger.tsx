import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { Code, Search, RefreshCw, AlertTriangle } from 'lucide-react';
import { UserProfile } from '../lib/firebase';
import { canImportProducts } from '../lib/app-constants';

interface ProductImportDebuggerProps {
  userProfile: UserProfile | null;
}

export function ProductImportDebugger({ userProfile }: ProductImportDebuggerProps) {
  const [debugResults, setDebugResults] = useState<any>(null);

  const runDebugTests = () => {
    if (!userProfile) {
      setDebugResults({
        error: 'No user profile available',
        timestamp: new Date().toISOString()
      });
      return;
    }

    const results = {
      timestamp: new Date().toISOString(),
      userProfile: {
        id: userProfile.id,
        email: userProfile.email,
        role: userProfile.role,
        shop_id: userProfile.shop_id,
        email_verified: userProfile.email_verified
      },
      permissionChecks: {
        canImportProducts: canImportProducts(userProfile.role),
        userRole: userProfile.role,
        expectedRoles: ['product_manager', 'owner', 'admin', 'super_admin']
      },
      browserInfo: {
        userAgent: navigator.userAgent,
        localStorage: {
          hasFirebaseAuth: !!localStorage.getItem('firebase:authUser:undefined'),
          hasFirebaseConfig: !!localStorage.getItem('firebase:config'),
          allKeys: Object.keys(localStorage)
        },
        sessionStorage: {
          allKeys: Object.keys(sessionStorage)
        }
      },
      windowGlobals: {
        hasFirebase: !!(window as any).firebase,
        hasFirestore: !!(window as any).firebase?.firestore,
        hasAuth: !!(window as any).firebase?.auth
      }
    };

    setDebugResults(results);
  };

  const clearCache = () => {
    // Clear browser cache-related items
    localStorage.clear();
    sessionStorage.clear();
    
    // Clear any cached Firebase auth
    if ('caches' in window) {
      caches.keys().then(function(names) {
        for (let name of names) {
          caches.delete(name);
        }
      });
    }
    
    // Force reload with cache bypass
    window.location.reload();
  };

  const testActualImportFunction = async () => {
    if (!userProfile) {
      setDebugResults({
        error: 'No user profile available for testing',
        timestamp: new Date().toISOString()
      });
      return;
    }

    try {
      // Test the actual import permission function
      const { canImportProducts } = await import('../lib/app-constants');
      const hasPermission = canImportProducts(userProfile.role);
      
      // Test the firebase service
      const { FirebaseService } = await import('../lib/firebase');
      
      setDebugResults({
        timestamp: new Date().toISOString(),
        testResults: {
          canImportProductsResult: hasPermission,
          userRole: userProfile.role,
          expectedResult: ['product_manager', 'owner', 'admin', 'super_admin'].includes(userProfile.role),
          directFunctionTest: hasPermission,
          firebaseServiceAvailable: !!FirebaseService.createProduct
        },
        recommendation: hasPermission ? 
          'Permission function returns TRUE - if you still see errors, clear cache and reload' :
          'Permission function returns FALSE - this is the bug source'
      });
    } catch (error: any) {
      setDebugResults({
        error: `Test failed: ${error.message}`,
        timestamp: new Date().toISOString()
      });
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Code className="h-5 w-5" />
          Product Import Permission Debugger
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            This tool helps debug permission issues with product imports. 
            If you're seeing "Required roles: manager, owner, admin" error, 
            this may be due to cached validation logic.
          </AlertDescription>
        </Alert>

        <div className="flex gap-2">
          <Button onClick={runDebugTests} className="flex items-center gap-2">
            <Search className="h-4 w-4" />
            Run Debug Tests
          </Button>
          <Button onClick={testActualImportFunction} className="flex items-center gap-2 bg-green-600 hover:bg-green-700">
            <Code className="h-4 w-4" />
            Test Import Function
          </Button>
          <Button onClick={clearCache} variant="destructive" className="flex items-center gap-2">
            <RefreshCw className="h-4 w-4" />
            Clear Cache & Reload
          </Button>
        </div>

        {debugResults && (
          <>
            <Separator />
            <div className="space-y-4">
              <h3 className="font-semibold">Debug Results</h3>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium mb-2">User Profile</h4>
                <pre className="text-sm overflow-x-auto">
                  {JSON.stringify(debugResults.userProfile, null, 2)}
                </pre>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium mb-2">Permission Checks</h4>
                <pre className="text-sm overflow-x-auto">
                  {JSON.stringify(debugResults.permissionChecks, null, 2)}
                </pre>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium mb-2">Browser Storage</h4>
                <pre className="text-sm overflow-x-auto">
                  {JSON.stringify(debugResults.browserInfo, null, 2)}
                </pre>
              </div>

              {debugResults.error && (
                <Alert variant="destructive">
                  <AlertDescription>
                    Error: {debugResults.error}
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </>
        )}

        <Separator />
        
        <div className="space-y-2">
          <h4 className="font-medium">Troubleshooting Steps:</h4>
          <ol className="list-decimal list-inside space-y-1 text-sm text-gray-600">
            <li>First, run the debug tests above to see current permission state</li>
            <li>If canImportProducts shows 'false' for product_manager role, there's a code issue</li>
            <li>If canImportProducts shows 'true' but you still get errors, clear cache and reload</li>
            <li>Check that your user role is exactly 'product_manager' (case sensitive)</li>
            <li>Ensure you're logged in and have a valid shop_id assigned</li>
            <li>Try signing out completely and signing back in</li>
          </ol>
        </div>
      </CardContent>
    </Card>
  );
}