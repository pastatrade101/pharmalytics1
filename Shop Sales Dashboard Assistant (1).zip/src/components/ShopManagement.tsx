import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Alert, AlertDescription } from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Building2, 
  Search, 
  CheckCircle, 
  XCircle, 
  Clock, 
  RefreshCw,
  User,
  Mail,
  Phone,
  Calendar,
  AlertTriangle,
  Shield,
  Eye,
  Settings
} from 'lucide-react';
import { FirebaseService } from '../lib/firebase';
import { Shop, UserProfile } from '../lib/firebase-types';
import { toast } from 'sonner';

interface ShopManagementProps {
  userProfile: UserProfile | null;
}

interface ShopWithOwner extends Shop {
  owner?: UserProfile;
}

export function ShopManagement({ userProfile }: ShopManagementProps) {
  const [shops, setShops] = useState<ShopWithOwner[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'active' | 'inactive'>('all');
  const [selectedShop, setSelectedShop] = useState<ShopWithOwner | null>(null);
  const [isUpdating, setIsUpdating] = useState<string | null>(null);
  const [statistics, setStatistics] = useState({
    total: 0,
    active: 0,
    pending: 0,
    inactive: 0
  });

  // Load shops and statistics
  useEffect(() => {
    loadShops();
    loadStatistics();
  }, []);

  const loadShops = async () => {
    try {
      setIsLoading(true);
      const allShops = await FirebaseService.getAllShops();
      
      // Load owner information for each shop
      const shopsWithOwners = await Promise.all(
        allShops.map(async (shop) => {
          try {
            const owner = await FirebaseService.getUserById(shop.owner_id);
            return { ...shop, owner };
          } catch (error) {
            console.warn(`Failed to load owner for shop ${shop.id}:`, error);
            return shop;
          }
        })
      );

      setShops(shopsWithOwners);
    } catch (error: any) {
      console.error('Error loading shops:', error);
      toast.error('Failed to load pharmacy list');
    } finally {
      setIsLoading(false);
    }
  };

  const loadStatistics = async () => {
    try {
      const stats = await FirebaseService.getShopStatistics();
      setStatistics(stats);
    } catch (error: any) {
      console.error('Error loading statistics:', error);
    }
  };

  const handleStatusUpdate = async (shopId: string, newStatus: 'active' | 'inactive' | 'pending') => {
    setIsUpdating(shopId);
    
    try {
      await FirebaseService.updateShopStatus(shopId, newStatus);
      
      // Update local state
      setShops(prevShops => 
        prevShops.map(shop => 
          shop.id === shopId ? { ...shop, status: newStatus } : shop
        )
      );
      
      // Update statistics
      await loadStatistics();
      
      const actionText = {
        active: 'activated',
        inactive: 'deactivated',
        pending: 'set to pending'
      }[newStatus];
      
      toast.success(`✅ Pharmacy ${actionText} successfully`);
    } catch (error: any) {
      console.error('Error updating shop status:', error);
      toast.error('Failed to update pharmacy status');
    } finally {
      setIsUpdating(null);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800 border-green-300">Active</Badge>;
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">Pending</Badge>;
      case 'inactive':
        return <Badge variant="destructive">Inactive</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-yellow-600" />;
      case 'inactive':
        return <XCircle className="h-4 w-4 text-red-600" />;
      default:
        return <AlertTriangle className="h-4 w-4 text-gray-600" />;
    }
  };

  // Filter shops based on search and status
  const filteredShops = shops.filter(shop => {
    const matchesSearch = shop.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         shop.owner?.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         shop.owner?.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || shop.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Loading pharmacy management...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center">
            <Building2 className="h-6 w-6 mr-2" />
            Pharmacy Management
          </h2>
          <p className="text-gray-600">
            Manage pharmacy registrations, activations, and system access
          </p>
        </div>
        <Button onClick={loadShops} disabled={isLoading}>
          <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Pharmacies</p>
                <p className="text-2xl font-bold">{statistics.total}</p>
              </div>
              <Building2 className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active</p>
                <p className="text-2xl font-bold text-green-600">{statistics.active}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pending Approval</p>
                <p className="text-2xl font-bold text-yellow-600">{statistics.pending}</p>
              </div>
              <Clock className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Inactive</p>
                <p className="text-2xl font-bold text-red-600">{statistics.inactive}</p>
              </div>
              <XCircle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search by pharmacy name, owner name, or email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={(value: any) => setStatusFilter(value)}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Pending Approvals Alert */}
      {statistics.pending > 0 && (
        <Alert className="bg-yellow-50 border-yellow-200">
          <Clock className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-800">
            <strong>Action Required:</strong> {statistics.pending} pharmacy{statistics.pending !== 1 ? 'ies' : 'y'} awaiting approval.
          </AlertDescription>
        </Alert>
      )}

      {/* Pharmacies List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Pharmacy Directory ({filteredShops.length})</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredShops.length === 0 ? (
            <div className="text-center py-8">
              <Building2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No pharmacies found matching your criteria</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredShops.map((shop) => (
                <div key={shop.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 space-y-3">
                      {/* Shop Header */}
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-blue-100 rounded-lg">
                          <Building2 className="h-5 w-5 text-blue-600" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900">{shop.name}</h3>
                          <p className="text-sm text-gray-600">{shop.description}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          {getStatusIcon(shop.status)}
                          {getStatusBadge(shop.status)}
                        </div>
                      </div>

                      {/* Owner Information */}
                      {shop.owner && (
                        <div className="bg-gray-50 rounded-lg p-3">
                          <h4 className="text-sm font-medium text-gray-900 mb-2 flex items-center gap-2">
                            <User className="h-4 w-4" />
                            Pharmacy Owner
                          </h4>
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-sm">
                            <div className="flex items-center gap-2">
                              <span className="text-gray-600">Name:</span>
                              <span className="font-medium">{shop.owner.full_name}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Mail className="h-3 w-3 text-gray-400" />
                              <span className="truncate">{shop.owner.email}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Calendar className="h-3 w-3 text-gray-400" />
                              <span>Joined {formatDate(shop.owner.created_at)}</span>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Shop Details */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Created:</span>
                          <p className="font-medium">{formatDate(shop.created_at)}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Category:</span>
                          <p className="font-medium capitalize">{shop.category}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Currency:</span>
                          <p className="font-medium">{shop.settings.currency}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Timezone:</span>
                          <p className="font-medium">{shop.settings.timezone}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="mt-4 flex flex-wrap gap-2 pt-3 border-t">
                    {shop.status === 'pending' && (
                      <Button
                        onClick={() => handleStatusUpdate(shop.id, 'active')}
                        disabled={isUpdating === shop.id}
                        size="sm"
                        className="bg-green-600 hover:bg-green-700"
                      >
                        {isUpdating === shop.id ? (
                          <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        ) : (
                          <CheckCircle className="h-4 w-4 mr-2" />
                        )}
                        Activate Pharmacy
                      </Button>
                    )}
                    
                    {shop.status === 'active' && (
                      <Button
                        onClick={() => handleStatusUpdate(shop.id, 'inactive')}
                        disabled={isUpdating === shop.id}
                        size="sm"
                        variant="destructive"
                      >
                        {isUpdating === shop.id ? (
                          <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        ) : (
                          <XCircle className="h-4 w-4 mr-2" />
                        )}
                        Deactivate
                      </Button>
                    )}
                    
                    {shop.status === 'inactive' && (
                      <>
                        <Button
                          onClick={() => handleStatusUpdate(shop.id, 'active')}
                          disabled={isUpdating === shop.id}
                          size="sm"
                          className="bg-green-600 hover:bg-green-700"
                        >
                          {isUpdating === shop.id ? (
                            <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                          ) : (
                            <CheckCircle className="h-4 w-4 mr-2" />
                          )}
                          Reactivate
                        </Button>
                        <Button
                          onClick={() => handleStatusUpdate(shop.id, 'pending')}
                          disabled={isUpdating === shop.id}
                          size="sm"
                          variant="outline"
                        >
                          {isUpdating === shop.id ? (
                            <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                          ) : (
                            <Clock className="h-4 w-4 mr-2" />
                          )}
                          Set Pending
                        </Button>
                      </>
                    )}
                    
                    <Button
                      onClick={() => setSelectedShop(shop)}
                      size="sm"
                      variant="outline"
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      View Details
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}