import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Checkbox } from './ui/checkbox';
import { 
  Users, 
  UserPlus, 
  Search, 
  Mail, 
  Calendar, 
  Package, 
  User, 
  Shield, 
  CheckCircle,
  XCircle,
  Clock,
  Loader2,
  AlertCircle,
  Plus,
  Eye,
  EyeOff,
  Copy,
  Send,
  Stethoscope,
  Pill,
  ClipboardList,
  ShoppingCart,
  X,
  Lock
} from 'lucide-react';
import { FirebaseService, UserProfile } from '../lib/firebase';
import { toast } from 'sonner';
import { UserCreationManager } from '../lib/user-creation-manager';
import { 
  UserRole, 
  OWNER_CREATABLE_ROLES, 
  ROLE_DISPLAY_NAMES, 
  ROLE_DESCRIPTIONS,
  ROLE_COLORS,
  LICENSED_ROLES,
  ROLE_REQUIREMENTS,
  isSuperAdmin
} from '../lib/app-constants';

interface UserManagementProps {
  userProfile: UserProfile | null;
}

interface UnassignedUser {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  created_at: string;
  shop_id?: string;
  status: 'pending' | 'assigned' | 'rejected';
}

interface CreateUserForm {
  full_name: string;
  email: string;
  role: UserRole;
  password: string;
  send_email: boolean;
  license_number?: string;
  certification_number?: string;
  experience_years?: number;
}

export function UserManagement({ userProfile }: UserManagementProps) {
  const [unassignedUsers, setUnassignedUsers] = useState<UnassignedUser[]>([]);
  const [assignedUsers, setAssignedUsers] = useState<UserProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [hasPermissionError, setHasPermissionError] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState<string>('all');
  const [isAssigning, setIsAssigning] = useState<{[key: string]: boolean}>({});
  
  // Create User Dialog State
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [createForm, setCreateForm] = useState<CreateUserForm>({
    full_name: '',
    email: '',
    role: 'salesman',
    password: '',
    send_email: true
  });
  const [createdUserCredentials, setCreatedUserCredentials] = useState<{email: string, password: string} | null>(null);

  // Check if current user is super admin
  const isCurrentUserSuperAdmin = userProfile && isSuperAdmin(userProfile.role);

  // Helper function to check if a user can be removed
  const canRemoveUser = (userId: string, userToRemove: UserProfile): boolean => {
    // Prevent users from removing themselves
    if (userProfile?.uid === userId) {
      return false;
    }
    
    // Prevent removal of owners (business rule - owners should transfer ownership first)
    if (userToRemove.role === 'owner') {
      return false;
    }
    
    // Super admins can remove anyone except themselves
    if (isCurrentUserSuperAdmin) {
      return userProfile?.uid !== userId;
    }
    
    // Regular users can remove subordinates but not themselves or owners
    return userProfile?.uid !== userId && userToRemove.role !== 'owner';
  };

  // Helper function to get removal restriction reason
  const getRemovalRestrictionReason = (userId: string, userToRemove: UserProfile): string | null => {
    if (userProfile?.uid === userId) {
      return "You cannot remove yourself from the pharmacy";
    }
    
    if (userToRemove.role === 'owner') {
      return "Pharmacy owners cannot be removed. Transfer ownership first if needed.";
    }
    
    return null;
  };

  useEffect(() => {
    if (userProfile?.shop_id || isCurrentUserSuperAdmin) {
      loadUsers();
    }
  }, [userProfile, isCurrentUserSuperAdmin]);

  const loadUsers = async () => {
    try {
      setIsLoading(true);
      console.log('🔄 Loading users for pharmacy:', userProfile?.shop_id);
      
      // Only load assigned users for regular pharmacy users
      // Only super admins can see unassigned users across all pharmacies
      if (isCurrentUserSuperAdmin) {
        // Super admin can see all unassigned users and users from all pharmacies
        const [unassigned, assigned] = await Promise.allSettled([
          FirebaseService.getUnassignedUsers(),
          userProfile?.shop_id ? FirebaseService.getShopUsers(userProfile.shop_id) : Promise.resolve([])
        ]);

        // Handle unassigned users result (super admin only)
        if (unassigned.status === 'fulfilled') {
          setUnassignedUsers(unassigned.value || []);
          setHasPermissionError(false);
          console.log('✅ Super admin loaded unassigned users:', unassigned.value?.length || 0);
        } else {
          console.error('❌ Failed to load unassigned users:', unassigned.reason);
          setUnassignedUsers([]);
          
          if (unassigned.reason?.code === 'permission-denied') {
            setHasPermissionError(true);
            console.log('🚨 Permission error detected - Firebase rules need deployment');
          }
        }

        // Handle assigned users result
        if (assigned.status === 'fulfilled') {
          setAssignedUsers(assigned.value || []);
          console.log('✅ Super admin loaded assigned users:', assigned.value?.length || 0);
        } else {
          console.error('❌ Failed to load assigned users:', assigned.reason);
          setAssignedUsers([]);
        }
      } else {
        // Regular pharmacy users only see their own pharmacy staff
        if (!userProfile?.shop_id) {
          console.warn('⚠️ No shop_id available for regular user');
          setUnassignedUsers([]);
          setAssignedUsers([]);
          setIsLoading(false);
          return;
        }

        try {
          const assignedResult = await FirebaseService.getShopUsers(userProfile.shop_id);
          setAssignedUsers(assignedResult || []);
          setUnassignedUsers([]); // Regular users don't see unassigned users
          setHasPermissionError(false);
          console.log('✅ Regular user loaded assigned users:', assignedResult?.length || 0);
        } catch (error) {
          console.error('❌ Failed to load assigned users for regular user:', error);
          setAssignedUsers([]);
          setUnassignedUsers([]);
          
          if ((error as any)?.code === 'permission-denied') {
            setHasPermissionError(true);
            console.log('🚨 Permission error detected - Firebase rules need deployment');
          }
        }
      }

    } catch (error) {
      console.error('❌ Critical error loading users:', error);
      
      // Set empty arrays as fallback
      setUnassignedUsers([]);
      setAssignedUsers([]);
      
      // Only show toast for actionable errors
      if ((error as any)?.code === 'permission-denied') {
        setHasPermissionError(true);
        console.log('🚨 Critical permission error - Firebase rules deployment required');
      } else {
        console.warn('⚠️ Non-permission error loading users:', error);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleAssignUser = async (userId: string, userName: string) => {
    if (!userProfile?.shop_id) {
      toast.error('Shop information not available');
      return;
    }

    setIsAssigning(prev => ({ ...prev, [userId]: true }));

    try {
      await FirebaseService.assignUserToShop(userId, userProfile.shop_id);
      
      toast.success(`Successfully assigned ${userName} to your pharmacy`);
      
      // Reload users data
      await loadUsers();
    } catch (error) {
      console.error('Error assigning user:', error);
      toast.error(`Failed to assign ${userName} to your pharmacy`);
    } finally {
      setIsAssigning(prev => ({ ...prev, [userId]: false }));
    }
  };

  const handleRemoveUser = async (userId: string, userName: string) => {
    // Find the user to remove
    const userToRemove = assignedUsers.find(user => user.uid === userId);
    if (!userToRemove) {
      toast.error('User not found');
      return;
    }

    // Check if removal is allowed
    if (!canRemoveUser(userId, userToRemove)) {
      const reason = getRemovalRestrictionReason(userId, userToRemove);
      toast.error(reason || 'Cannot remove this user');
      return;
    }

    if (!userProfile?.shop_id) {
      toast.error('Shop information not available');
      return;
    }

    setIsAssigning(prev => ({ ...prev, [userId]: true }));

    try {
      await FirebaseService.removeUserFromShop(userId);
      
      toast.success(`Successfully removed ${userName} from your pharmacy`);
      
      // Reload users data
      await loadUsers();
    } catch (error) {
      console.error('Error removing user:', error);
      toast.error(`Failed to remove ${userName} from your pharmacy`);
    } finally {
      setIsAssigning(prev => ({ ...prev, [userId]: false }));
    }
  };

  const generatePassword = () => {
    // Generate a secure password
    const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
    let password = '';
    for (let i = 0; i < 12; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
  };

  const handleCreateUser = async () => {
    if (!userProfile?.shop_id) {
      toast.error('Shop information not available');
      return;
    }

    // Validate form
    if (!createForm.full_name || !createForm.email || !createForm.password) {
      toast.error('Please fill in all required fields');
      return;
    }

    // Validate license requirements
    if (LICENSED_ROLES.includes(createForm.role as UserRole)) {
      if (!createForm.license_number) {
        toast.error(`${ROLE_DISPLAY_NAMES[createForm.role as UserRole]} requires a license number`);
        return;
      }
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(createForm.email)) {
      toast.error('Please enter a valid email address');
      return;
    }

    setIsCreating(true);
    
    // Set global user creation flag
    UserCreationManager.setUserCreationInProgress(true);
    
    // Show initial progress notification
    const creatingToastId = toast.loading('Creating user account...', {
      description: 'Setting up authentication and profile'
    });

    try {
      // Create user account and assign to shop
      const newUser = await FirebaseService.createUserAccount({
        email: createForm.email,
        password: createForm.password,
        full_name: createForm.full_name,
        role: createForm.role,
        shop_id: userProfile.shop_id,
        license_number: createForm.license_number,
        certification_number: createForm.certification_number,
        experience_years: createForm.experience_years
      });

      // Dismiss the loading toast
      toast.dismiss(creatingToastId);

      // Store credentials for display
      setCreatedUserCredentials({
        email: createForm.email,
        password: createForm.password
      });

      // Show success message with important note about sign-in
      toast.success(`✅ User account created successfully!`, {
        description: `${createForm.full_name} (${ROLE_DISPLAY_NAMES[createForm.role as UserRole]}) can now access the pharmacy system.`,
        duration: 8000
      });

      // Show informational message about temporary logout
      setTimeout(() => {
        toast.info('📋 Sign-in Required', {
          description: 'You may need to sign back in to continue managing your pharmacy. This is normal after creating user accounts.',
          duration: 10000
        });
      }, 1000);

      // Send email notification if requested
      if (createForm.send_email) {
        try {
          await FirebaseService.sendUserCredentials({
            email: createForm.email,
            full_name: createForm.full_name,
            password: createForm.password,
            shop_name: userProfile.shop?.name || 'your pharmacy',
            role: createForm.role
          });
          toast.success('📧 Login credentials sent via email');
        } catch (emailError) {
          console.error('Error sending email:', emailError);
          toast.warning('User created successfully, but email notification failed');
        }
      }

      // Reset form
      setCreateForm({
        full_name: '',
        email: '',
        role: 'salesman',
        password: '',
        send_email: true
      });

      // Close dialog
      setIsCreateDialogOpen(false);

      // Reload users data with a delay to allow for auth state settling
      setTimeout(async () => {
        try {
          await loadUsers();
        } catch (reloadError) {
          console.warn('User list reload failed, but user was created successfully:', reloadError);
        }
      }, 2000);
      
    } catch (error: any) {
      console.error('Error creating user:', error);
      
      // Dismiss the loading toast
      toast.dismiss(creatingToastId);
      
      // Show specific error message
      const errorMessage = error.message || 'Failed to create user account';
      toast.error('❌ User Creation Failed', {
        description: errorMessage,
        duration: 8000
      });
    } finally {
      setIsCreating(false);
      
      // Clear global user creation flag after a delay
      setTimeout(() => {
        UserCreationManager.setUserCreationInProgress(false);
      }, 3000);
    }
  };

  const handleGeneratePassword = () => {
    const newPassword = generatePassword();
    setCreateForm(prev => ({ ...prev, password: newPassword }));
  };

  const handleCopyCredentials = () => {
    if (createdUserCredentials) {
      const credentials = `Email: ${createdUserCredentials.email}\nPassword: ${createdUserCredentials.password}`;
      navigator.clipboard.writeText(credentials);
      toast.success('Credentials copied to clipboard');
    }
  };

  const getRoleIcon = (role: UserRole) => {
    switch (role) {
      case 'salesman': return ShoppingCart;
      case 'product_manager': return Package;
      case 'owner': return Shield;
      case 'admin': return Shield;
      case 'super_admin': return Shield;
      default: return User;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  // Filter users based on search and role
  const filteredUnassignedUsers = unassignedUsers.filter(user => {
    const matchesSearch = user.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = filterRole === 'all' || user.role === filterRole;
    return matchesSearch && matchesRole;
  });

  const filteredAssignedUsers = assignedUsers.filter(user => {
    const matchesSearch = user.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = filterRole === 'all' || user.role === filterRole;
    return matchesSearch && matchesRole;
  });

  // Check if selected role requires additional fields
  const selectedRoleRequirements = ROLE_REQUIREMENTS[createForm.role as keyof typeof ROLE_REQUIREMENTS];
  const isLicensedRole = LICENSED_ROLES.includes(createForm.role as UserRole);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Loading pharmacy staff management...</p>
        </div>
      </div>
    );
  }

  // Show Firebase rules deployment message if permission errors detected
  if (hasPermissionError) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold flex items-center">
              <Users className="h-6 w-6 mr-2" />
              Pharmacy Staff Management
            </h2>
            <p className="text-gray-600">Create and manage pharmacy staff accounts with specialized roles</p>
          </div>
        </div>

        {/* Firebase Rules Required Alert */}
        <Alert className="border-red-200 bg-red-50">
          <Shield className="h-4 w-4 text-red-600" />
          <AlertDescription>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-red-900 mb-2">🚨 Firebase Security Rules Required</h3>
                <p className="text-red-800 text-sm mb-3">
                  User management is blocked because Firebase security rules are not deployed. 
                  This prevents accessing user profiles and pharmacy staff data.
                </p>
              </div>
              
              <div className="bg-white border border-red-200 rounded-lg p-4">
                <h4 className="font-medium text-red-900 mb-2">Quick Fix (2 minutes):</h4>
                <ol className="list-decimal list-inside text-sm text-red-800 space-y-1">
                  <li>Open Firebase Console (button below will open it)</li>
                  <li>Navigate to Firestore → Rules</li>
                  <li>Replace all rules with the complete rules from COMPLETE_FIREBASE_RULES_FIX.md</li>
                  <li>Click "Publish" and wait for confirmation</li>
                  <li>Refresh this page</li>
                </ol>
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={() => window.open('https://console.firebase.google.com/project/shopsalesai/firestore/rules', '_blank')}
                  className="bg-red-600 hover:bg-red-700"
                >
                  <Shield className="h-4 w-4 mr-2" />
                  Open Firebase Console
                </Button>
                <Button
                  onClick={() => window.location.reload()}
                  variant="outline"
                  className="border-red-300 text-red-700 hover:bg-red-50"
                >
                  Refresh Page
                </Button>
              </div>
            </div>
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center">
            <Users className="h-6 w-6 mr-2" />
            {isCurrentUserSuperAdmin ? 'System User Management' : 'Pharmacy Staff Management'}
          </h2>
          <p className="text-gray-600">
            {isCurrentUserSuperAdmin 
              ? 'Manage all users across the pharmacy management system'
              : 'Create and manage pharmacy staff accounts with specialized roles'
            }
          </p>
        </div>
        
        {/* Create User Dialog - Only for users with shop_id */}
        {userProfile?.shop_id && (
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="h-4 w-4 mr-2" />
                Add Staff Member
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2 text-lg">
                  <UserPlus className="h-5 w-5" />
                  Add New Pharmacy Staff Member
                </DialogTitle>
                <DialogDescription className="text-sm text-gray-600">
                  Create a new staff account and assign them to your pharmacy with the appropriate role.
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                {/* Full Name */}
                <div className="space-y-2">
                  <Label htmlFor="full_name" className="text-sm font-medium">
                    Full Name *
                  </Label>
                  <Input
                    id="full_name"
                    placeholder="Enter full name"
                    value={createForm.full_name}
                    onChange={(e) => setCreateForm(prev => ({ ...prev, full_name: e.target.value }))}
                    className="w-full"
                  />
                </div>
                
                {/* Email Address */}
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium">
                    Email Address *
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="owner@gmail.com"
                    value={createForm.email}
                    onChange={(e) => setCreateForm(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full"
                  />
                </div>
                
                {/* Staff Role */}
                <div className="space-y-2">
                  <Label htmlFor="role" className="text-sm font-medium">
                    Staff Role *
                  </Label>
                  <Select value={createForm.role} onValueChange={(value: UserRole) => setCreateForm(prev => ({ ...prev, role: value }))}>
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {OWNER_CREATABLE_ROLES.map((role) => {
                        const Icon = getRoleIcon(role);
                        return (
                          <SelectItem key={role} value={role}>
                            <div className="flex items-center gap-2">
                              <Icon className="h-4 w-4" />
                              <span>{ROLE_DISPLAY_NAMES[role]}</span>
                            </div>
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                  
                  {/* Role Description */}
                  <div className="text-xs text-gray-600 p-2 bg-gray-50 rounded-md">
                    <span className="font-medium">{ROLE_DISPLAY_NAMES[createForm.role as UserRole]}:</span> {ROLE_DESCRIPTIONS[createForm.role as UserRole]}
                  </div>
                </div>

                {/* License Requirements for Licensed Roles */}
                {isLicensedRole && (
                  <div className="space-y-3 p-3 bg-blue-50 border border-blue-200 rounded-md">
                    <div className="flex items-center gap-2 text-blue-800">
                      <Stethoscope className="h-4 w-4" />
                      <span className="text-sm font-medium">Professional License Required</span>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="license_number" className="text-sm font-medium">
                        License Number *
                      </Label>
                      <Input
                        id="license_number"
                        placeholder="Enter professional license number"
                        value={createForm.license_number || ''}
                        onChange={(e) => setCreateForm(prev => ({ ...prev, license_number: e.target.value }))}
                        className="w-full"
                      />
                    </div>

                    {selectedRoleRequirements?.minimum_experience_years && (
                      <div className="space-y-2">
                        <Label htmlFor="experience_years" className="text-sm font-medium">
                          Years of Experience
                        </Label>
                        <Input
                          id="experience_years"
                          type="number"
                          min="0"
                          placeholder={`Minimum ${selectedRoleRequirements.minimum_experience_years} years required`}
                          value={createForm.experience_years || ''}
                          onChange={(e) => setCreateForm(prev => ({ ...prev, experience_years: parseInt(e.target.value) || 0 }))}
                          className="w-full"
                        />
                      </div>
                    )}
                  </div>
                )}

                {/* Certification Requirements */}
                {selectedRoleRequirements?.certification_required && (
                  <div className="space-y-3 p-3 bg-green-50 border border-green-200 rounded-md">
                    <div className="flex items-center gap-2 text-green-800">
                      <Pill className="h-4 w-4" />
                      <span className="text-sm font-medium">Certification Required</span>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="certification_number" className="text-sm font-medium">
                        Certification Number
                      </Label>
                      <Input
                        id="certification_number"
                        placeholder="Enter certification number"
                        value={createForm.certification_number || ''}
                        onChange={(e) => setCreateForm(prev => ({ ...prev, certification_number: e.target.value }))}
                        className="w-full"
                      />
                    </div>
                  </div>
                )}
                
                {/* Password */}
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm font-medium">
                    Password *
                  </Label>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Input
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Enter password"
                        value={createForm.password}
                        onChange={(e) => setCreateForm(prev => ({ ...prev, password: e.target.value }))}
                        className="pr-10"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={handleGeneratePassword}
                      className="px-3"
                    >
                      Generate
                    </Button>
                  </div>
                </div>
                
                {/* Send Email Checkbox */}
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="send_email"
                    checked={createForm.send_email}
                    onCheckedChange={(checked) => setCreateForm(prev => ({ ...prev, send_email: !!checked }))}
                  />
                  <Label htmlFor="send_email" className="text-sm">
                    Send login credentials via email
                  </Label>
                </div>
              </div>
              
              {/* Dialog Actions */}
              <div className="flex gap-3 pt-4 border-t">
                <Button
                  onClick={() => setIsCreateDialogOpen(false)}
                  variant="outline"
                  className="flex-1"
                  disabled={isCreating}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleCreateUser}
                  disabled={isCreating}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  {isCreating ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    <>
                      <UserPlus className="h-4 w-4 mr-2" />
                      Add Staff Member
                    </>
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Created User Credentials Display */}
      {createdUserCredentials && (
        <Alert className="bg-green-50 border-green-200">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription>
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="font-medium text-green-900 mb-1">Staff Member Created Successfully!</div>
                <div className="space-y-1 text-sm text-green-800">
                  <p><span className="font-medium">Email:</span> {createdUserCredentials.email}</p>
                  <p><span className="font-medium">Password:</span> {createdUserCredentials.password}</p>
                  <div className="mt-2 p-2 bg-green-100 rounded text-xs">
                    💡 <strong>Important:</strong> Save these credentials securely. The password will not be shown again.
                  </div>
                </div>
              </div>
              <div className="flex gap-2 ml-4">
                <Button
                  onClick={handleCopyCredentials}
                  variant="outline"
                  size="sm"
                  className="border-green-300 text-green-700 hover:bg-green-100"
                >
                  <Copy className="h-4 w-4 mr-1" />
                  Copy
                </Button>
                <Button
                  onClick={() => setCreatedUserCredentials(null)}
                  variant="ghost"
                  size="sm"
                  className="text-green-700 hover:bg-green-100"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Search and Filter Controls */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search by name or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={filterRole} onValueChange={setFilterRole}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Filter by role" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem key="all" value="all">All Roles</SelectItem>
            {Object.entries(ROLE_DISPLAY_NAMES).map(([role, displayName]) => (
              <SelectItem key={role} value={role}>
                {displayName}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Unassigned Users Section - Only for Super Admin */}
      {isCurrentUserSuperAdmin && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Unassigned Users ({filteredUnassignedUsers.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {filteredUnassignedUsers.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Clock className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                <p>No unassigned users found</p>
                <p className="text-sm">All users are assigned to pharmacies</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredUnassignedUsers.map((user) => {
                  const RoleIcon = getRoleIcon(user.role);
                  const isAssigningUser = isAssigning[user.id];
                  
                  return (
                    <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 bg-gray-100 rounded-full flex items-center justify-center">
                          <RoleIcon className="h-5 w-5 text-gray-600" />
                        </div>
                        <div>
                          <div className="font-medium">{user.full_name}</div>
                          <div className="text-sm text-gray-600">{user.email}</div>
                        </div>
                        <Badge 
                          className={`${ROLE_COLORS[user.role as keyof typeof ROLE_COLORS] || 'bg-gray-100 text-gray-800'}`}
                        >
                          {ROLE_DISPLAY_NAMES[user.role as keyof typeof ROLE_DISPLAY_NAMES] || user.role}
                        </Badge>
                        <div className="text-xs text-gray-500">
                          Joined {formatDate(user.created_at)}
                        </div>
                      </div>
                      <Button
                        onClick={() => handleAssignUser(user.id, user.full_name)}
                        disabled={isAssigningUser || !userProfile?.shop_id}
                        size="sm"
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        {isAssigningUser ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Assigning...
                          </>
                        ) : (
                          <>
                            <UserPlus className="h-4 w-4 mr-2" />
                            Assign
                          </>
                        )}
                      </Button>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Your Pharmacy Staff Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Your Pharmacy Staff ({filteredAssignedUsers.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredAssignedUsers.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Users className="h-12 w-12 mx-auto mb-3 text-gray-300" />
              <p>No staff members found</p>
              <p className="text-sm">Add staff members to manage your pharmacy operations</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredAssignedUsers.map((user) => {
                const RoleIcon = getRoleIcon(user.role);
                const isAssigningUser = isAssigning[user.uid];
                const isCurrentUser = userProfile?.uid === user.uid;
                const canRemove = canRemoveUser(user.uid, user);
                const removalReason = getRemovalRestrictionReason(user.uid, user);
                
                return (
                  <div key={user.uid} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 bg-gray-100 rounded-full flex items-center justify-center">
                        <RoleIcon className="h-5 w-5 text-gray-600" />
                      </div>
                      <div>
                        <div className="font-medium flex items-center gap-2">
                          {user.full_name}
                          {isCurrentUser && (
                            <Badge variant="outline" className="text-xs">
                              You
                            </Badge>
                          )}
                        </div>
                        <div className="text-sm text-gray-600">{user.email}</div>
                      </div>
                      <Badge 
                        className={`${ROLE_COLORS[user.role as keyof typeof ROLE_COLORS] || 'bg-gray-100 text-gray-800'}`}
                      >
                        {ROLE_DISPLAY_NAMES[user.role as keyof typeof ROLE_DISPLAY_NAMES] || user.role}
                      </Badge>
                      <div className="text-xs text-gray-500">
                        Joined {formatDate(user.created_at)}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {!canRemove && removalReason ? (
                        <div className="flex items-center gap-2">
                          <div className="relative group">
                            <Button
                              disabled
                              variant="outline"
                              size="sm"
                              className="text-gray-400 border-gray-200 cursor-not-allowed"
                            >
                              <Lock className="h-4 w-4 mr-2" />
                              Protected
                            </Button>
                            <div className="absolute bottom-full mb-2 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white text-xs rounded py-1 px-2 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-200 z-50">
                              {removalReason}
                              <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-gray-900"></div>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <Button
                          onClick={() => handleRemoveUser(user.uid, user.full_name)}
                          disabled={isAssigningUser}
                          variant="outline"
                          size="sm"
                          className="text-red-600 border-red-200 hover:bg-red-50"
                        >
                          {isAssigningUser ? (
                            <>
                              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                              Removing...
                            </>
                          ) : (
                            <>
                              <XCircle className="h-4 w-4 mr-2" />
                              Remove
                            </>
                          )}
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}