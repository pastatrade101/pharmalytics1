import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  RefreshCw, 
  Terminal, 
  Copy, 
  ExternalLink,
  User,
  Database,
  Shield,
  Zap
} from 'lucide-react';
import { auth, db, FirebaseService } from '../lib/firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { toast } from 'sonner@2.0.3';

interface CriticalFirebaseFixPanelProps {
  onFixed?: () => void;
}

export function CriticalFirebaseFixPanel({ onFixed }: CriticalFirebaseFixPanelProps) {
  const [activeTab, setActiveTab] = useState('diagnosis');
  const [testing, setTesting] = useState(false);
  const [results, setResults] = useState<{
    authCheck: 'pending' | 'success' | 'error';
    profileCheck: 'pending' | 'success' | 'error';
    rulesCheck: 'pending' | 'success' | 'error';
    shopCheck: 'pending' | 'success' | 'error';
    productCheck: 'pending' | 'success' | 'error';
    details: string[];
    fixes: string[];
  }>({
    authCheck: 'pending',
    profileCheck: 'pending', 
    rulesCheck: 'pending',
    shopCheck: 'pending',
    productCheck: 'pending',
    details: [],
    fixes: []
  });

  // Comprehensive diagnostic test
  const runComprehensiveDiagnostic = async () => {
    setTesting(true);
    const details: string[] = [];
    const fixes: string[] = [];

    try {
      // Reset results
      setResults({
        authCheck: 'pending',
        profileCheck: 'pending',
        rulesCheck: 'pending',
        shopCheck: 'pending',
        productCheck: 'pending',
        details: [],
        fixes: []
      });

      details.push('🔍 Starting comprehensive Firebase diagnostic...');
      
      // Test 1: Authentication Check
      details.push('\n=== AUTHENTICATION TEST ===');
      let authStatus: 'success' | 'error' = 'error';
      
      if (!auth.currentUser) {
        details.push('❌ No authenticated user found');
        fixes.push('Please sign in to your account');
        authStatus = 'error';
      } else {
        details.push(`✅ User authenticated: ${auth.currentUser.email}`);
        details.push(`🔑 User ID: ${auth.currentUser.uid}`);
        
        try {
          await auth.currentUser.getIdToken(true);
          details.push('✅ Auth token is valid');
          authStatus = 'success';
        } catch (tokenError) {
          details.push('❌ Auth token is invalid');
          fixes.push('Sign out and sign in again');
          authStatus = 'error';
        }
      }
      
      setResults(prev => ({ ...prev, authCheck: authStatus, details: [...details] }));
      
      if (authStatus === 'error') {
        setTesting(false);
        return;
      }

      // Test 2: Profile Check with Direct Firestore Access
      details.push('\n=== PROFILE ACCESS TEST ===');
      let profileStatus: 'success' | 'error' = 'error';
      let userProfile: any = null;
      
      try {
        const profileRef = doc(db, 'profiles', auth.currentUser!.uid);
        const profileDoc = await getDoc(profileRef);
        
        if (!profileDoc.exists()) {
          details.push('❌ Profile document does not exist');
          fixes.push('Creating missing profile document...');
          
          // Try to create a basic profile
          try {
            const basicProfile = {
              email: auth.currentUser!.email,
              full_name: auth.currentUser!.displayName || 'Unknown User',
              role: 'admin', // Default to admin for testing
              shop_id: 'test-shop-001',
              created_at: serverTimestamp(),
              updated_at: serverTimestamp()
            };
            
            await setDoc(profileRef, basicProfile);
            details.push('✅ Created basic profile with admin role');
            userProfile = basicProfile;
            profileStatus = 'success';
          } catch (createError) {
            details.push('❌ Failed to create profile - rules not deployed');
            fixes.push('Deploy Firebase security rules immediately');
            profileStatus = 'error';
          }
        } else {
          userProfile = profileDoc.data();
          details.push('✅ Profile document found');
          details.push(`👤 Name: ${userProfile.full_name}`);
          details.push(`🔑 Role: ${userProfile.role}`);
          details.push(`🏪 Shop ID: ${userProfile.shop_id || 'Not assigned'}`);
          
          // Validate profile data
          if (!userProfile.role) {
            details.push('⚠️ Missing role in profile');
            fixes.push('Update profile to include role');
            profileStatus = 'error';
          } else if (!['admin', 'owner', 'manager'].includes(userProfile.role)) {
            details.push(`❌ Role '${userProfile.role}' cannot create products`);
            fixes.push('Change role to admin, owner, or manager');
            profileStatus = 'error';
          } else if (!userProfile.shop_id) {
            details.push('❌ No shop assignment');
            fixes.push('Assign user to a shop');
            profileStatus = 'error';
          } else {
            details.push('✅ Profile data is valid for product creation');
            profileStatus = 'success';
          }
        }
      } catch (profileError: any) {
        details.push(`❌ Profile access failed: ${profileError.code}`);
        if (profileError.code === 'permission-denied') {
          details.push('🚨 CRITICAL: Permission denied accessing profiles');
          fixes.push('Firebase security rules are not deployed');
          fixes.push('Run: firebase deploy --only firestore:rules');
        }
        profileStatus = 'error';
      }
      
      setResults(prev => ({ ...prev, profileCheck: profileStatus, details: [...details] }));

      // Test 3: Rules Deployment Check
      details.push('\n=== FIREBASE RULES TEST ===');
      let rulesStatus: 'success' | 'error' = 'error';
      
      try {
        // Try to access system settings (should work with proper rules)
        const testRef = doc(db, 'system_settings', 'test');
        await getDoc(testRef);
        details.push('✅ System collections accessible');
        
        // Try to access products collection
        if (userProfile?.shop_id) {
          const products = await FirebaseService.getProducts(userProfile.shop_id);
          details.push('✅ Products collection accessible');
          details.push(`📦 Found ${products.length} products`);
        }
        
        details.push('✅ Firebase security rules are deployed');
        rulesStatus = 'success';
      } catch (rulesError: any) {
        if (rulesError.code === 'permission-denied' || rulesError.message?.includes('permission-denied')) {
          details.push('❌ Permission denied - Rules not deployed');
          details.push('🚨 CRITICAL: Firebase security rules missing');
          fixes.push('URGENT: Deploy Firebase security rules');
          fixes.push('Command: firebase deploy --only firestore:rules');
        } else {
          details.push(`❌ Rules test failed: ${rulesError.message}`);
        }
        rulesStatus = 'error';
      }
      
      setResults(prev => ({ ...prev, rulesCheck: rulesStatus, details: [...details] }));

      setResults(prev => ({ 
        ...prev, 
        shopCheck: shopStatus, 
        productCheck: productStatus, 
        details: [...details],
        fixes: [...fixes]
      }));

      // Test 4: Shop Creation Test
      details.push('\n=== SHOP CREATION TEST ===');
      let shopStatus: 'success' | 'error' = 'error';
      
      if (rulesStatus === 'success' && profileStatus === 'success' && userProfile) {
        try {
          const testShop = {
            name: `Diagnostic Test Shop ${Date.now()}`,
            owner_id: auth.currentUser!.uid,
            description: 'Test shop for diagnostic purposes - safe to delete',
            category: 'pharmacy' as const,
            address: 'Test Address',
            phone: '+255123456789',
            settings: {
              timezone: 'Africa/Dar_es_Salaam',
              currency: 'TZS',
              report_time: '20:00'
            }
          };
          
          const createdShop = await FirebaseService.createShop(testShop);
          details.push('✅ Test shop created successfully!');
          details.push(`🏪 Shop ID: ${createdShop.id}`);
          details.push(`📍 Shop Name: ${createdShop.name}`);
          
          shopStatus = 'success';
          
        } catch (createError: any) {
          details.push('❌ Shop creation failed');
          details.push(`Error: ${createError.message}`);
          
          if (createError.message?.includes('permission-denied')) {
            fixes.push('Firebase rules still not properly deployed');
            fixes.push('Wait 1-2 minutes after deployment');
            fixes.push('Clear browser cache and refresh');
          }
          shopStatus = 'error';
        }
      } else {
        details.push('❌ Skipped - previous tests failed');
        shopStatus = 'error';
      }
      
      // Test 5: Product Creation Test
      details.push('\n=== PRODUCT CREATION TEST ===');
      let productStatus: 'success' | 'error' = 'error';
      
      if (rulesStatus === 'success' && profileStatus === 'success' && userProfile && shopStatus === 'success') {
        try {
          const testProduct = {
            name: `DIAGNOSTIC_TEST_${Date.now()}`,
            sku: `DIAG-${Date.now()}`,
            category: 'otc' as const,
            cost_price: 800,
            retail_price: 1000,
            stock_quantity: 1,
            min_stock_level: 1,
            reorder_quantity: 5,
            unit_of_measure: 'tablets',
            dosage_form: 'tablet',
            manufacturer: 'Test Pharma',
            markup_percentage: 25,
            requires_prescription: false,
            controlled_substance: false,
            status: 'active' as const,
            shop_id: userProfile.shop_id,
            description: 'Diagnostic test product - safe to delete',
            created_by: auth.currentUser!.uid
          };
          
          const createdProduct = await FirebaseService.createProduct(testProduct);
          details.push('✅ Test product created successfully!');
          details.push(`📦 Product ID: ${createdProduct.id}`);
          
          // Clean up test product
          try {
            await FirebaseService.deleteProduct(createdProduct.id);
            details.push('✅ Test product cleaned up');
          } catch (cleanupError) {
            details.push('⚠️ Test product cleanup failed (not critical)');
          }
          
          details.push('🎉 ALL TESTS PASSED - System is fully functional!');
          productStatus = 'success';
          
          // Notify parent that fix is complete
          onFixed?.();
          
        } catch (createError: any) {
          details.push('❌ Product creation failed');
          details.push(`Error: ${createError.message}`);
          
          if (createError.message?.includes('permission-denied')) {
            fixes.push('Firebase rules still not properly deployed');
            fixes.push('Wait 1-2 minutes after deployment');
            fixes.push('Clear browser cache and refresh');
          }
          productStatus = 'error';
        }
      } else {
        details.push('❌ Skipped - previous tests failed');
        productStatus = 'error';
      }
      


    } catch (error: any) {
      details.push(`❌ Diagnostic failed: ${error.message}`);
      setResults(prev => ({ ...prev, details: [...details], fixes: [...fixes] }));
    } finally {
      setTesting(false);
    }
  };

  // Fix missing profile
  const fixUserProfile = async () => {
    if (!auth.currentUser) {
      toast.error('Not authenticated');
      return;
    }

    try {
      const profileRef = doc(db, 'profiles', auth.currentUser.uid);
      const fixedProfile = {
        email: auth.currentUser.email,
        full_name: auth.currentUser.displayName || 'System User',
        role: 'admin', // Set as admin for testing
        shop_id: 'test-shop-001', // Default test shop
        created_at: serverTimestamp(),
        updated_at: serverTimestamp()
      };

      await setDoc(profileRef, fixedProfile);
      toast.success('Profile created successfully');
      
      // Re-run diagnostic
      await runComprehensiveDiagnostic();
    } catch (error: any) {
      toast.error(`Failed to create profile: ${error.message}`);
    }
  };

  const copyRulesCommand = () => {
    navigator.clipboard.writeText('firebase deploy --only firestore:rules');
    toast.success('Command copied to clipboard');
  };

  const getStatusIcon = (status: 'pending' | 'success' | 'error') => {
    switch (status) {
      case 'success': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'error': return <XCircle className="h-4 w-4 text-red-600" />;
      default: return <RefreshCw className="h-4 w-4 text-gray-400" />;
    }
  };

  const criticalIssues = [
    results.rulesCheck === 'error',
    results.profileCheck === 'error',
    results.shopCheck === 'error',
    results.productCheck === 'error'
  ].filter(Boolean).length;

  return (
    <Card className="border-red-200 bg-red-50 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center">
          <AlertTriangle className="h-5 w-5 text-red-600 mr-2" />
          🚨 Critical Firebase Permission Error Fix
        </CardTitle>
        <p className="text-sm text-red-800">
          Product creation is completely blocked. This diagnostic will identify and fix all permission issues.
        </p>
      </CardHeader>
      
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="diagnosis">Diagnosis</TabsTrigger>
            <TabsTrigger value="fixes">Quick Fixes</TabsTrigger>
            <TabsTrigger value="rules">Rules Setup</TabsTrigger>
          </TabsList>

          <TabsContent value="diagnosis" className="space-y-4">
            {/* Test Status */}
            <div className="grid grid-cols-2 gap-3">
              <div className="flex items-center space-x-2 p-2 border rounded">
                {getStatusIcon(results.authCheck)}
                <span className="text-sm">Authentication</span>
              </div>
              <div className="flex items-center space-x-2 p-2 border rounded">
                {getStatusIcon(results.profileCheck)}
                <span className="text-sm">User Profile</span>
              </div>
              <div className="flex items-center space-x-2 p-2 border rounded">
                {getStatusIcon(results.rulesCheck)}
                <span className="text-sm">Firebase Rules</span>
              </div>
              <div className="flex items-center space-x-2 p-2 border rounded">
                {getStatusIcon(results.shopCheck)}
                <span className="text-sm">Shop Creation</span>
              </div>
              <div className="flex items-center space-x-2 p-2 border rounded">
                {getStatusIcon(results.productCheck)}
                <span className="text-sm">Product Creation</span>
              </div>
            </div>

            {/* Run Diagnostic Button */}
            <Button 
              onClick={runComprehensiveDiagnostic}
              disabled={testing}
              className="w-full"
              variant="destructive"
            >
              {testing ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Running Diagnostic...
                </>
              ) : (
                <>
                  <Zap className="mr-2 h-4 w-4" />
                  Run Complete Diagnostic
                </>
              )}
            </Button>

            {/* Results */}
            {results.details.length > 0 && (
              <div className="bg-gray-900 text-green-400 p-4 rounded text-xs font-mono max-h-80 overflow-y-auto">
                {results.details.map((detail, index) => (
                  <div key={index} className={detail.startsWith('===') ? 'text-yellow-400 font-bold mt-2' : ''}>
                    {detail}
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="fixes" className="space-y-4">
            {results.fixes.length > 0 ? (
              <div className="space-y-3">
                <h3 className="font-semibold text-red-900">Required Fixes:</h3>
                {results.fixes.map((fix, index) => (
                  <Alert key={index} className="border-yellow-300 bg-yellow-50">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>{fix}</AlertDescription>
                  </Alert>
                ))}
              </div>
            ) : (
              <p className="text-gray-600">Run diagnostic first to identify issues</p>
            )}

            {/* Quick Fix Buttons */}
            <div className="space-y-2">
              {results.profileCheck === 'error' && (
                <Button onClick={fixUserProfile} className="w-full" variant="outline">
                  <User className="mr-2 h-4 w-4" />
                  Fix User Profile
                </Button>
              )}
              
              {results.rulesCheck === 'error' && (
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <code className="flex-1 bg-red-100 px-3 py-2 rounded text-red-900">
                      firebase deploy --only firestore:rules
                    </code>
                    <Button size="sm" variant="outline" onClick={copyRulesCommand}>
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => window.open('/FIREBASE_PERMISSION_FIX_GUIDE.md', '_blank')}
                  >
                    <ExternalLink className="mr-2 h-4 w-4" />
                    View Complete Fix Guide
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="rules" className="space-y-4">
            <div className="bg-blue-50 border border-blue-200 rounded p-4">
              <h3 className="font-semibold text-blue-900 mb-2">Firebase Console Method (Recommended)</h3>
              <ol className="text-sm text-blue-800 space-y-1">
                <li>1. Go to <a href="https://console.firebase.google.com" target="_blank" className="underline">Firebase Console</a></li>
                <li>2. Select your project → Firestore Database → Rules</li>
                <li>3. Copy the rules from the guide and paste them</li>
                <li>4. Click "Publish" and wait for success message</li>
                <li>5. Refresh this page and test again</li>
              </ol>
            </div>

            <div className="bg-gray-50 border border-gray-200 rounded p-4">
              <h3 className="font-semibold text-gray-900 mb-2">Command Line Method</h3>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <code className="flex-1 bg-gray-100 px-2 py-1 rounded text-xs">
                    firebase deploy --only firestore:rules
                  </code>
                  <Button size="sm" variant="outline" onClick={copyRulesCommand}>
                    <Copy className="h-3 w-3" />
                  </Button>
                </div>
                <p className="text-xs text-gray-600">
                  Run this in your project directory after ensuring firestore.rules file is present
                </p>
              </div>
            </div>

            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => window.open('/COMPLETE_FIRESTORE_RULES_FOR_CONSOLE.md', '_blank')}
            >
              <Database className="mr-2 h-4 w-4" />
              Get Complete Rules for Console
            </Button>
          </TabsContent>
        </Tabs>

        {/* Critical Status Summary */}
        {criticalIssues > 0 && (
          <div className="mt-4 p-3 bg-red-100 border border-red-300 rounded">
            <div className="flex items-center">
              <AlertTriangle className="h-4 w-4 text-red-600 mr-2" />
              <span className="font-semibold text-red-900">
                {criticalIssues} Critical Issue{criticalIssues > 1 ? 's' : ''} Found
              </span>
            </div>
            <p className="text-sm text-red-800 mt-1">
              Product creation will remain blocked until all issues are resolved.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}