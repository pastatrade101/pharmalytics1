import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { ArrowRightLeft, AlertTriangle, Building, Truck } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';

interface StockTransfersProps {
  userProfile: any;
  onBack: () => void;
  onSetCurrentView: (view: any) => void;
}

export function StockTransfers({ userProfile, onBack, onSetCurrentView }: StockTransfersProps) {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center">
            <ArrowRightLeft className="h-6 w-6 mr-2" />
            Stock Transfers
          </h1>
          <p className="text-gray-600 mt-1">Manage inter-branch stock movements and transfers</p>
        </div>
        <Button onClick={onBack} variant="outline">
          Back to Dashboard
        </Button>
      </div>

      {/* Feature Coming Soon */}
      <Alert className="border-blue-200 bg-blue-50">
        <AlertTriangle className="h-4 w-4 text-blue-600" />
        <AlertDescription>
          <strong className="text-blue-900">Stock Transfer System Coming Soon</strong>
          <br />
          <span className="text-blue-800">
            This feature will enable seamless stock transfers between pharmacy branches 
            with approval workflows and tracking.
          </span>
        </AlertDescription>
      </Alert>

      {/* Placeholder Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="cursor-pointer hover:shadow-md transition-shadow opacity-60">
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <ArrowRightLeft className="h-8 w-8 text-blue-600" />
              <div>
                <h3 className="font-medium">Transfer Requests</h3>
                <p className="text-sm text-gray-500">Manage transfer requests</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow opacity-60">
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <Building className="h-8 w-8 text-green-600" />
              <div>
                <h3 className="font-medium">Branch Inventory</h3>
                <p className="text-sm text-gray-500">View branch stock levels</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow opacity-60">
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <Truck className="h-8 w-8 text-orange-600" />
              <div>
                <h3 className="font-medium">Transfer History</h3>
                <p className="text-sm text-gray-500">Track completed transfers</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="text-center py-12">
        <ArrowRightLeft className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-600 mb-2">Stock Transfer Management</h3>
        <p className="text-gray-500 mb-6">
          Inter-branch stock transfer system coming soon
        </p>
        <Button onClick={() => onSetCurrentView('branch-management')} variant="outline">
          View Branch Management
        </Button>
      </div>
    </div>
  );
}