import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { 
  Building2, 
  Clock, 
  Shield, 
  AlertTriangle, 
  RefreshCw,
  LogOut,
  Phone,
  Mail,
  User
} from 'lucide-react';
import { UserProfile as UserProfileType, FirebaseService } from '../lib/firebase';
import { toast } from 'sonner';

interface ShopActivationScreenProps {
  userProfile: UserProfileType;
  onSignOut: () => void;
  onShopActivated: () => void;
}

export function ShopActivationScreen({ 
  userProfile, 
  onSignOut, 
  onShopActivated 
}: ShopActivationScreenProps) {
  const [isChecking, setIsChecking] = useState(false);
  const [shopStatus, setShopStatus] = useState<'pending' | 'active' | 'inactive'>('pending');
  const [lastChecked, setLastChecked] = useState<Date>(new Date());

  // Auto-check shop status every 30 seconds
  useEffect(() => {
    const checkShopStatus = async () => {
      if (!userProfile.shop_id) return;

      try {
        const shop = await FirebaseService.getShopById(userProfile.shop_id);
        if (shop && shop.status) {
          setShopStatus(shop.status as 'pending' | 'active' | 'inactive');
          setLastChecked(new Date());
          
          if (shop.status === 'active') {
            toast.success('🎉 Your pharmacy has been activated!', {
              description: 'You can now access all pharmacy management features.'
            });
            onShopActivated();
          } else if (shop.status === 'inactive') {
            toast.error('❌ Your pharmacy has been deactivated', {
              description: 'Please contact support for assistance.'
            });
          }
        }
      } catch (error) {
        console.error('Error checking shop status:', error);
      }
    };

    // Initial check
    checkShopStatus();

    // Set up interval for periodic checks
    const interval = setInterval(checkShopStatus, 30000);

    return () => clearInterval(interval);
  }, [userProfile.shop_id, onShopActivated]);

  const handleManualCheck = async () => {
    setIsChecking(true);
    
    try {
      if (!userProfile.shop_id) {
        toast.error('Shop information not found');
        return;
      }

      const shop = await FirebaseService.getShopById(userProfile.shop_id);
      if (shop && shop.status) {
        setShopStatus(shop.status as 'pending' | 'active' | 'inactive');
        setLastChecked(new Date());
        
        if (shop.status === 'active') {
          toast.success('🎉 Your pharmacy has been activated!');
          onShopActivated();
        } else if (shop.status === 'inactive') {
          toast.error('Your pharmacy is currently deactivated');
        } else {
          toast.info('Your pharmacy is still pending activation');
        }
      } else {
        toast.warning('Unable to retrieve shop status');
      }
    } catch (error: any) {
      console.error('Error checking shop status:', error);
      toast.error('Failed to check activation status');
    } finally {
      setIsChecking(false);
    }
  };

  const getStatusBadge = () => {
    switch (shopStatus) {
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-300">Pending Activation</Badge>;
      case 'active':
        return <Badge variant="default" className="bg-green-50 text-green-700 border-green-300">Active</Badge>;
      case 'inactive':
        return <Badge variant="destructive">Deactivated</Badge>;
      default:
        return <Badge variant="secondary">Unknown Status</Badge>;
    }
  };

  const getStatusIcon = () => {
    switch (shopStatus) {
      case 'pending':
        return <Clock className="h-8 w-8 text-yellow-600" />;
      case 'active':
        return <Building2 className="h-8 w-8 text-green-600" />;
      case 'inactive':
        return <AlertTriangle className="h-8 w-8 text-red-600" />;
      default:
        return <Building2 className="h-8 w-8 text-gray-600" />;
    }
  };

  const getStatusMessage = () => {
    switch (shopStatus) {
      case 'pending':
        return {
          title: 'Pharmacy Activation Pending',
          description: 'Your pharmacy registration is complete and waiting for approval from our team.',
          details: 'Our software administrators need to verify and activate your pharmacy before you can access all features.'
        };
      case 'inactive':
        return {
          title: 'Pharmacy Deactivated',
          description: 'Your pharmacy access has been temporarily suspended.',
          details: 'Please contact our support team to resolve any issues and reactivate your account.'
        };
      default:
        return {
          title: 'Checking Activation Status',
          description: 'Please wait while we verify your pharmacy status.',
          details: 'This process may take a few moments.'
        };
    }
  };

  const statusInfo = getStatusMessage();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl bg-white/90 backdrop-blur-sm shadow-xl">
        <CardHeader className="text-center space-y-4">
          <div className="mx-auto p-3 bg-blue-100 rounded-full w-fit">
            {getStatusIcon()}
          </div>
          <div className="space-y-2">
            <CardTitle className="text-xl font-semibold text-gray-900">
              {statusInfo.title}
            </CardTitle>
            <div className="flex justify-center">
              {getStatusBadge()}
            </div>
            <p className="text-sm text-gray-600">
              {statusInfo.description}
            </p>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Shop Information */}
          <div className="bg-gray-50 rounded-lg p-4 border">
            <h3 className="font-medium text-gray-900 mb-3 flex items-center gap-2">
              <Building2 className="h-4 w-4" />
              Pharmacy Information
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Pharmacy Name:</span>
                <span className="font-medium">{userProfile.shop?.name || 'Loading...'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Owner:</span>
                <span className="font-medium">{userProfile.full_name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Email:</span>
                <span className="font-medium">{userProfile.email}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Registration Date:</span>
                <span className="font-medium">
                  {userProfile.created_at ? new Date(userProfile.created_at).toLocaleDateString() : 'N/A'}
                </span>
              </div>
            </div>
          </div>

          {/* Status Details */}
          <Alert className={`${
            shopStatus === 'pending' ? 'bg-yellow-50 border-yellow-200' :
            shopStatus === 'inactive' ? 'bg-red-50 border-red-200' :
            'bg-blue-50 border-blue-200'
          }`}>
            <Shield className={`h-4 w-4 ${
              shopStatus === 'pending' ? 'text-yellow-600' :
              shopStatus === 'inactive' ? 'text-red-600' :
              'text-blue-600'
            }`} />
            <AlertDescription className={`${
              shopStatus === 'pending' ? 'text-yellow-800' :
              shopStatus === 'inactive' ? 'text-red-800' :
              'text-blue-800'
            } text-sm`}>
              <strong>Current Status:</strong> {statusInfo.details}
            </AlertDescription>
          </Alert>

          {/* What happens next */}
          {shopStatus === 'pending' && (
            <div className="space-y-3">
              <h4 className="font-medium text-gray-900">What happens next?</h4>
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex items-start gap-2">
                  <span className="text-blue-600 font-medium">1.</span>
                  <span>Our team reviews your pharmacy registration details</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-blue-600 font-medium">2.</span>
                  <span>We verify your pharmacy license and credentials</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-blue-600 font-medium">3.</span>
                  <span>Once approved, your pharmacy will be activated automatically</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-blue-600 font-medium">4.</span>
                  <span>You'll gain full access to all pharmacy management features</span>
                </div>
              </div>
            </div>
          )}

          {/* Support Contact Information */}
          {shopStatus === 'inactive' && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <h4 className="font-medium text-red-900 mb-2">Need Help?</h4>
              <div className="space-y-2 text-sm text-red-800">
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  <span>Email: support@pharmacyms.com</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  <span>Phone: +1 (555) 123-4567</span>
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="space-y-3">
            <Button
              onClick={handleManualCheck}
              disabled={isChecking}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              {isChecking ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Checking Status...
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Check Activation Status
                </>
              )}
            </Button>

            <div className="text-center text-xs text-gray-500">
              Last checked: {lastChecked.toLocaleTimeString()}
              <br />
              Auto-checking every 30 seconds
            </div>
          </div>

          {/* Sign Out Option */}
          <div className="pt-4 border-t">
            <Button
              onClick={onSignOut}
              variant="ghost"
              className="w-full text-gray-600 hover:text-gray-800"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}