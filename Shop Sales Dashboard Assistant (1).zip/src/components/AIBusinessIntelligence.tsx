import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Brain, 
  TrendingUp, 
  AlertTriangle, 
  Package, 
  DollarSign,
  Calendar,
  BarChart3,
  Zap,
  RefreshCw,
  Download,
  Eye,
  Target,
  Users,
  ShoppingCart,
  Activity,
  Clock,
  FileText,
  Lightbulb,
  CheckCircle,
  XCircle,
  Loader2,
  Bug,
  Sparkles,
  ChevronDown,
  Menu
} from 'lucide-react';
import { Navigation } from './Navigation';
import { UserProfile as UserProfileType, FirebaseService, SalesService } from '../lib/firebase';
import { AIConnectionStatus } from '../hooks/useAIConnection';
import { View } from '../lib/app-constants';
import { formatTZS } from '../lib/currency-utils';
import { toast } from 'sonner@2.0.3';
import { APIDebugTester } from './APIDebugTester';
import { SimpleAPITester } from './SimpleAPITester';
import { APIRouteTester } from './APIRouteTester';
import { 
  AIBusinessIntelligenceService, 
  BusinessMetrics, 
  AIReport, 
  AIInsight,
  generateBusinessIntelligenceReport,
  validateBusinessData
} from '../lib/ai-business-intelligence';

interface AIBusinessIntelligenceProps {
  userProfile: UserProfileType | null;
  onBack: () => void;
  onSetCurrentView: (view: View) => void;
  onSignOut: () => void;
  aiSystemStatus?: AIConnectionStatus;
  hasPermissionErrors?: boolean;
  hasIndexErrors?: boolean;
}

export function AIBusinessIntelligence({
  userProfile,
  onBack,
  onSetCurrentView,
  onSignOut,
  aiSystemStatus,
  hasPermissionErrors,
  hasIndexErrors
}: AIBusinessIntelligenceProps) {
  const [metrics, setMetrics] = useState<BusinessMetrics | null>(null);
  const [aiReport, setAiReport] = useState<AIReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [selectedTab, setSelectedTab] = useState('overview');
  const [showDebugTester, setShowDebugTester] = useState(false);
  const [reportGenerated, setReportGenerated] = useState(false);
  const [showMobileActions, setShowMobileActions] = useState(false);

  // Load business metrics from Firebase
  const loadBusinessMetrics = useCallback(async () => {
    if (!userProfile?.shop_id) {
      console.log('⚠️ No shop ID available for metrics');
      setLoading(false);
      return;
    }

    try {
      console.log('📊 Loading business metrics for AI analysis...');
      setLoading(true);

      const shopId = userProfile.shop_id;
      const now = new Date();
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0);

      // More reasonable timeout - increased from 30 to 60 seconds
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('Data loading timeout after 60 seconds')), 60000);
      });

      // Load all data in parallel with timeout protection
      const dataPromise = Promise.all([
        SalesService.getSalesByShop(shopId, 200).catch((err) => {
          console.warn('⚠️ Failed to load all sales:', err);
          return [];
        }),
        SalesService.getSalesByShop(shopId, 100, {
          start: startOfMonth.toISOString(),
          end: now.toISOString()
        }).catch((err) => {
          console.warn('⚠️ Failed to load month sales:', err);
          return [];
        }),
        SalesService.getSalesByShop(shopId, 100, {
          start: lastMonth.toISOString(),
          end: endOfLastMonth.toISOString()
        }).catch((err) => {
          console.warn('⚠️ Failed to load last month sales:', err);
          return [];
        }),
        FirebaseService.getProducts(shopId).catch((err) => {
          console.warn('⚠️ Failed to load products:', err);
          return [];
        }),
        FirebaseService.getLowStockProducts(shopId).catch((err) => {
          console.warn('⚠️ Failed to load low stock products:', err);
          return [];
        }),
        FirebaseService.getExpiringProducts(shopId, 30).catch((err) => {
          console.warn('⚠️ Failed to load expiring products:', err);
          return [];
        })
      ]);

      const [
        allSales,
        monthSales,
        lastMonthSales,
        products,
        lowStockProducts,
        expiringProducts
      ] = await Promise.race([dataPromise, timeoutPromise]);

      // Calculate metrics
      const totalRevenue = allSales.reduce((sum, sale) => sum + (parseFloat(sale.total_price?.toString() || '0')), 0);
      const totalTransactions = allSales.length;
      const monthlyRevenue = monthSales.reduce((sum, sale) => sum + (parseFloat(sale.total_price?.toString() || '0')), 0);
      const lastMonthRevenue = lastMonthSales.reduce((sum, sale) => sum + (parseFloat(sale.total_price?.toString() || '0')), 0);
      const monthlyGrowth = lastMonthRevenue > 0 ? ((monthlyRevenue - lastMonthRevenue) / lastMonthRevenue) * 100 : 0;
      const averageTransactionValue = totalTransactions > 0 ? totalRevenue / totalTransactions : 0;
      
      const activeProducts = products.filter(p => p.status === 'active').length;
      const expiredProducts = products.filter(p => {
        if (!p.expiry_date) return false;
        const expiryDate = new Date(p.expiry_date);
        return expiryDate < now;
      }).length;

      // Calculate top selling products (improved implementation)
      const productSalesMap = new Map();
      allSales.forEach(sale => {
        if (sale.items) {
          sale.items.forEach(item => {
            const productName = item.product_name || item.name || 'Unknown Product';
            const quantity = parseInt(item.quantity?.toString() || '1');
            const revenue = parseFloat(item.total_price?.toString() || item.price?.toString() || '0');
            
            if (productSalesMap.has(productName)) {
              const existing = productSalesMap.get(productName);
              existing.sales += quantity;
              existing.revenue += revenue;
            } else {
              productSalesMap.set(productName, { name: productName, sales: quantity, revenue });
            }
          });
        }
      });

      const topSellingProducts = Array.from(productSalesMap.values())
        .sort((a, b) => b.revenue - a.revenue)
        .slice(0, 5);

      // Get recent sales
      const recentSales = allSales.slice(0, 10).map(sale => ({
        date: new Date(sale.timestamp || sale.created_at).toLocaleDateString(),
        amount: parseFloat(sale.total_price?.toString() || '0'),
        customer: sale.customer_name || 'Walk-in Customer'
      }));

      const businessMetrics: BusinessMetrics = validateBusinessData({
        totalRevenue,
        totalTransactions,
        totalProducts: products.length,
        activeProducts,
        lowStockItems: lowStockProducts.length,
        expiringItems: expiringProducts.length,
        expiredItems: expiredProducts,
        averageTransactionValue,
        monthlyGrowth,
        topSellingProducts,
        recentSales
      });

      setMetrics(businessMetrics);
      console.log('✅ Business metrics loaded successfully:', businessMetrics);

    } catch (error: any) {
      console.error('❌ Error loading business metrics:', error);
      
      // Create fallback metrics to prevent infinite loading
      const fallbackMetrics: BusinessMetrics = validateBusinessData({});
      setMetrics(fallbackMetrics);
      
      // Show appropriate error message
      if (error.message?.includes('timeout')) {
        toast.warning('Data Loading Timeout', {
          description: 'Some data took longer than expected to load. Using available information for analysis.',
          duration: 5000
        });
      } else if (error?.code === 'permission-denied') {
        toast.error('Permission Denied', {
          description: 'Unable to access pharmacy data. Please check Firebase permissions.',
          duration: 5000
        });
      } else {
        toast.warning('Limited Data Available', {
          description: 'Some pharmacy data could not be loaded. Analysis will use available information.',
          duration: 5000
        });
      }
    } finally {
      setLoading(false);
    }
  }, [userProfile?.shop_id]);

  // Generate AI report using client-side service
  const generateAIReport = useCallback(async () => {
    if (!metrics || !userProfile) {
      toast.error('No data available for analysis');
      return;
    }

    try {
      setGenerating(true);
      setReportGenerated(true);
      console.log('🤖 Generating AI business report (client-side)...');

      // Prepare user context
      const userContext = {
        role: userProfile.role,
        pharmacyType: 'community_pharmacy'
      };

      console.log('📊 Analysis data prepared:', { metrics, userContext });

      // Generate AI report using client-side service
      const report = await generateBusinessIntelligenceReport(metrics, userContext);

      setAiReport(report);
      
      // Show success message based on the source
      const source = report.source || 'unknown';
      if (source === 'intelligent-fallback') {
        toast.success('🧠 Intelligent Analysis Complete!', {
          description: 'Comprehensive business insights generated from your pharmacy data.',
          duration: 5000
        });
      } else if (source === 'basic-fallback') {
        toast.success('📊 Business Analysis Ready!', {
          description: 'Basic business analysis completed successfully.',
          duration: 5000
        });
      } else {
        toast.success('✅ AI Report Generated!', {
          description: 'Your business intelligence report is ready for review.',
          duration: 5000
        });
      }

      console.log('✅ AI business report generated successfully with source:', source);

    } catch (error: any) {
      console.error('❌ Error generating AI report:', error);
      
      // Generate basic fallback report if analysis fails
      const fallbackReport: AIReport = {
        summary: `Your pharmacy analysis is ready. Generated basic insights from ${metrics.totalTransactions} transactions and ${metrics.activeProducts} active products.`,
        insights: [
          {
            type: 'trend',
            title: 'Business Overview',
            description: `Your pharmacy has processed ${metrics.totalTransactions} transactions with a total revenue of ${formatTZS(metrics.totalRevenue)}.`,
            impact: 'medium',
            actionable: true,
            metrics: ['Revenue', 'Transactions']
          }
        ],
        recommendations: [
          'Continue monitoring your business performance regularly',
          'Review inventory levels to prevent stockouts',
          'Track customer satisfaction and feedback'
        ],
        predictions: [
          'Regular analysis will help identify growth opportunities',
          'Consistent monitoring can improve operational efficiency'
        ],
        generatedAt: new Date().toISOString(),
        source: 'error-fallback'
      };

      setAiReport(fallbackReport);
      
      toast.warning('Basic Analysis Generated', {
        description: 'Generated basic business insights. Try refreshing for enhanced analysis.',
        duration: 5000
      });
    } finally {
      setGenerating(false);
    }
  }, [metrics, userProfile]);

  // Load data on component mount with more reasonable timeout
  useEffect(() => {
    // Increased timeout from 45 to 90 seconds for component loading
    const timeoutId = setTimeout(() => {
      if (loading) {
        console.warn('⚠️ Component loading is taking longer than expected - but continuing...');
        // Don't force completion, just warn - let natural timeout handle it
        toast.info('Loading Taking Longer', {
          description: 'Data loading is taking longer than usual. Please be patient...',
          duration: 3000
        });
      }
    }, 90000); // 90 second warning (not forced completion)

    loadBusinessMetrics();

    return () => clearTimeout(timeoutId);
  }, [loadBusinessMetrics]);

  // Auto-generate report when metrics are loaded (prevent infinite loops)
  useEffect(() => {
    if (metrics && !aiReport && !generating && !reportGenerated && aiSystemStatus !== 'loading') {
      console.log('🤖 Auto-generating AI report with loaded metrics');
      setReportGenerated(true);
      generateAIReport();
    }
  }, [metrics, aiReport, generating, reportGenerated, aiSystemStatus]);

  // Render insight icon based on type
  const getInsightIcon = (type: string, impact: string) => {
    switch (type) {
      case 'opportunity':
        return <TrendingUp className={`h-4 w-4 ${impact === 'high' ? 'text-green-600' : 'text-green-500'}`} />;
      case 'risk':
        return <AlertTriangle className={`h-4 w-4 ${impact === 'high' ? 'text-red-600' : 'text-yellow-500'}`} />;
      case 'trend':
        return <BarChart3 className={`h-4 w-4 ${impact === 'high' ? 'text-blue-600' : 'text-blue-500'}`} />;
      case 'recommendation':
        return <Lightbulb className={`h-4 w-4 ${impact === 'high' ? 'text-purple-600' : 'text-purple-500'}`} />;
      default:
        return <Activity className="h-4 w-4 text-gray-500" />;
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <Navigation 
          userProfile={userProfile}
          currentView="ai-business-intelligence"
          onNavigate={onSetCurrentView}
          onSignOut={onSignOut}
          aiSystemStatus={aiSystemStatus}
          hasPermissionErrors={hasPermissionErrors}
          hasIndexErrors={hasIndexErrors}
        />

        <main className="min-h-screen">
          <div className="flex items-center justify-center min-h-[60vh]">
            <Card className="w-full max-w-md text-center p-8">
              <CardContent>
                <Brain className="h-16 w-16 text-indigo-600 mx-auto mb-4 animate-pulse" />
                <h3 className="text-lg font-semibold mb-2">Analyzing Your Business</h3>
                <p className="text-gray-600 mb-4">
                  AI is processing your pharmacy data to generate intelligent insights...
                </p>
                <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Loading business metrics</span>
                </div>
                <p className="text-xs text-gray-400 mt-3">
                  This may take a minute for large datasets
                </p>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Navigation 
        userProfile={userProfile}
        currentView="ai-business-intelligence"
        onNavigate={onSetCurrentView}
        onSignOut={onSignOut}
        aiSystemStatus={aiSystemStatus}
        hasPermissionErrors={hasPermissionErrors}
        hasIndexErrors={hasIndexErrors}
      />

      <main className="min-h-screen">
        {/* Mobile-First Header */}
        <div className="mb-4 sm:mb-6">
          {/* Mobile Header */}
          <div className="block lg:hidden">
            <div className="flex items-center justify-between mb-3">
              <div className="flex-1 min-w-0">
                <h1 className="text-xl font-bold text-gray-900 flex items-center gap-2 truncate">
                  <Brain className="h-6 w-6 text-indigo-600 flex-shrink-0" />
                  AI Business Intelligence
                </h1>
              </div>
              <Button
                onClick={() => setShowMobileActions(!showMobileActions)}
                variant="outline"
                size="sm"
                className="ml-3 flex-shrink-0"
              >
                <Menu className="h-4 w-4" />
              </Button>
            </div>
            
            <p className="text-sm text-gray-600 mb-3 px-1">
              AI-powered insights for strategic decisions
            </p>

            {/* Mobile AI Status Badge */}
            <div className="flex items-center justify-between mb-3">
              <Badge 
                variant="secondary" 
                className="bg-green-100 text-green-800 text-xs flex items-center gap-1"
              >
                <Sparkles className="h-3 w-3" />
                Client-Side AI
              </Badge>
            </div>

            {/* Mobile Actions Menu */}
            {showMobileActions && (
              <div className="bg-white border border-gray-200 rounded-lg p-3 mb-4 space-y-2 shadow-sm">
                <Button
                  onClick={() => {
                    setMetrics(null);
                    setAiReport(null);
                    setReportGenerated(false);
                    loadBusinessMetrics();
                    setShowMobileActions(false);
                  }}
                  disabled={loading}
                  size="sm"
                  variant="outline"
                  className="w-full border-blue-200 text-blue-600 hover:bg-blue-50"
                >
                  {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <RefreshCw className="h-4 w-4 mr-2" />}
                  {loading ? 'Refreshing...' : 'Refresh Data'}
                </Button>
                
                <Button
                  onClick={() => {
                    setAiReport(null);
                    setReportGenerated(false);
                    generateAIReport();
                    setShowMobileActions(false);
                  }}
                  disabled={generating || !metrics}
                  size="sm"
                  className="w-full bg-indigo-600 hover:bg-indigo-700"
                >
                  {generating ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <RefreshCw className="h-4 w-4 mr-2" />}
                  {generating ? 'Analyzing...' : 'Regenerate Report'}
                </Button>

                {/* Hide debug button on mobile */}
                {process.env.NODE_ENV === 'development' && (
                  <Button
                    onClick={() => {
                      setShowDebugTester(!showDebugTester);
                      setShowMobileActions(false);
                    }}
                    variant="outline"
                    size="sm"
                    className="w-full border-red-200 text-red-600 hover:bg-red-50"
                  >
                    <Bug className="h-4 w-4 mr-2" />
                    {showDebugTester ? 'Hide Debug' : 'Debug API'}
                  </Button>
                )}
              </div>
            )}
          </div>

          {/* Desktop Header */}
          <div className="hidden lg:flex items-center justify-between">
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <Brain className="h-8 w-8 text-indigo-600" />
                AI Business Intelligence
              </h1>
              <p className="text-gray-600 mt-1">
                AI-powered insights and analytics for strategic decision making
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Badge 
                variant="secondary" 
                className="bg-green-100 text-green-800 flex items-center gap-1"
              >
                <Sparkles className="h-3 w-3" />
                Client-Side AI
              </Badge>
              <Button
                onClick={() => {
                  setMetrics(null);
                  setAiReport(null);
                  setReportGenerated(false);
                  loadBusinessMetrics();
                }}
                disabled={loading}
                size="sm"
                variant="outline"
                className="border-blue-200 text-blue-600 hover:bg-blue-50"
              >
                {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <RefreshCw className="h-4 w-4 mr-2" />}
                {loading ? 'Refreshing...' : 'Refresh Data'}
              </Button>
              <Button
                onClick={() => {
                  setAiReport(null);
                  setReportGenerated(false);
                  generateAIReport();
                }}
                disabled={generating || !metrics}
                size="sm"
                className="bg-indigo-600 hover:bg-indigo-700"
              >
                {generating ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <RefreshCw className="h-4 w-4 mr-2" />}
                {generating ? 'Analyzing...' : 'Regenerate Report'}
              </Button>

              {/* Only show debug in development on desktop */}
              {process.env.NODE_ENV === 'development' && (
                <Button
                  onClick={() => setShowDebugTester(!showDebugTester)}
                  variant="outline"
                  size="sm"
                  className="border-red-200 text-red-600 hover:bg-red-50"
                >
                  <Bug className="h-4 w-4 mr-2" />
                  {showDebugTester ? 'Hide Debug' : 'Debug API'}
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Debug Tester - Only show in development */}
        {showDebugTester && process.env.NODE_ENV === 'development' && (
          <div className="space-y-4 mb-6">
            <Card className="border-red-200 bg-red-50/30">
              <CardHeader>
                <CardTitle className="text-red-800 flex items-center gap-2">
                  <Bug className="h-5 w-5" />
                  API Debug Panel (Development Only)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span className="font-medium text-green-800">AI Service Status: Active</span>
                  </div>
                  <p className="text-green-700 text-sm">
                    This application now uses client-side AI analysis, eliminating the need for server-side API routes. 
                    The AI Business Intelligence feature works entirely within your browser for enhanced privacy and reliability.
                  </p>
                </div>
                <APIRouteTester />
                <Separator />
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <SimpleAPITester />
                  <APIDebugTester onClose={() => setShowDebugTester(false)} />
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Main Content */}
        <div className="space-y-4 sm:space-y-6">
          {/* Quick Metrics Overview - Mobile Responsive Grid */}
          {metrics && (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
              <Card>
                <CardContent className="p-3 sm:p-4">
                  <div className="flex items-center justify-between">
                    <div className="min-w-0 flex-1">
                      <p className="text-xs sm:text-sm text-gray-600 truncate">Total Revenue</p>
                      <p className="text-lg sm:text-2xl font-bold text-green-600 truncate">
                        {formatTZS(metrics.totalRevenue)}
                      </p>
                    </div>
                    <DollarSign className="h-6 w-6 sm:h-8 sm:w-8 text-green-500 flex-shrink-0 ml-2" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-3 sm:p-4">
                  <div className="flex items-center justify-between">
                    <div className="min-w-0 flex-1">
                      <p className="text-xs sm:text-sm text-gray-600 truncate">Monthly Growth</p>
                      <p className={`text-lg sm:text-2xl font-bold truncate ${metrics.monthlyGrowth >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {metrics.monthlyGrowth > 0 ? '+' : ''}{metrics.monthlyGrowth.toFixed(1)}%
                      </p>
                    </div>
                    <TrendingUp className={`h-6 w-6 sm:h-8 sm:w-8 flex-shrink-0 ml-2 ${metrics.monthlyGrowth >= 0 ? 'text-green-500' : 'text-red-500'}`} />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-3 sm:p-4">
                  <div className="flex items-center justify-between">
                    <div className="min-w-0 flex-1">
                      <p className="text-xs sm:text-sm text-gray-600 truncate">Active Products</p>
                      <p className="text-lg sm:text-2xl font-bold text-blue-600 truncate">{metrics.activeProducts}</p>
                    </div>
                    <Package className="h-6 w-6 sm:h-8 sm:w-8 text-blue-500 flex-shrink-0 ml-2" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-3 sm:p-4">
                  <div className="flex items-center justify-between">
                    <div className="min-w-0 flex-1">
                      <p className="text-xs sm:text-sm text-gray-600 truncate">Alerts</p>
                      <p className="text-lg sm:text-2xl font-bold text-orange-600 truncate">
                        {metrics.lowStockItems + metrics.expiringItems}
                      </p>
                    </div>
                    <AlertTriangle className="h-6 w-6 sm:h-8 sm:w-8 text-orange-500 flex-shrink-0 ml-2" />
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* AI Report Tabs - Mobile Optimized */}
          {aiReport && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex flex-col sm:flex-row sm:items-center gap-2">
                  <div className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 sm:h-6 sm:w-6 text-indigo-600" />
                    <span className="text-base sm:text-lg">AI Business Intelligence Report</span>
                  </div>
                  <Badge variant="secondary" className="self-start sm:ml-auto text-xs">
                    {aiReport.source === 'intelligent-fallback' ? 'Smart Analysis' : 
                     aiReport.source === 'basic-fallback' ? 'Basic Analysis' : 'AI Generated'}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs value={selectedTab} onValueChange={setSelectedTab}>
                  {/* Mobile-Friendly Tab List */}
                  <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 h-auto">
                    <TabsTrigger value="overview" className="text-xs sm:text-sm py-2">Overview</TabsTrigger>
                    <TabsTrigger value="insights" className="text-xs sm:text-sm py-2">Insights</TabsTrigger>
                    <TabsTrigger value="recommendations" className="text-xs sm:text-sm py-2">Actions</TabsTrigger>
                    <TabsTrigger value="predictions" className="text-xs sm:text-sm py-2">Forecast</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="overview" className="space-y-4 mt-4">
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="flex items-center gap-2 text-base">
                          <FileText className="h-4 w-4 sm:h-5 sm:w-5" />
                          Executive Summary
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="text-sm sm:text-base text-gray-700 leading-relaxed">{aiReport.summary}</p>
                        <div className="mt-3 text-xs text-gray-500">
                          Generated: {new Date(aiReport.generatedAt).toLocaleString()}
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="insights" className="space-y-3 sm:space-y-4 mt-4">
                    {aiReport.insights.map((insight, index) => (
                      <Card key={index}>
                        <CardContent className="p-3 sm:p-4">
                          <div className="flex items-start gap-3">
                            <div className="flex-shrink-0 mt-1">
                              {getInsightIcon(insight.type, insight.impact)}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex flex-col sm:flex-row sm:items-center gap-2 mb-2">
                                <h4 className="font-semibold text-sm sm:text-base truncate">{insight.title}</h4>
                                <div className="flex gap-1 flex-wrap">
                                  <Badge variant="secondary" className={`text-xs ${getImpactColor(insight.impact)}`}>
                                    {insight.impact} impact
                                  </Badge>
                                  {insight.actionable && (
                                    <Badge variant="outline" className="text-xs">Actionable</Badge>
                                  )}
                                </div>
                              </div>
                              <p className="text-gray-600 text-xs sm:text-sm mb-2 break-words">{insight.description}</p>
                              {insight.metrics && insight.metrics.length > 0 && (
                                <div className="flex flex-wrap gap-1">
                                  {insight.metrics.map((metric, metricIndex) => (
                                    <Badge key={metricIndex} variant="outline" className="text-xs">
                                      {metric}
                                    </Badge>
                                  ))}
                                </div>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </TabsContent>

                  <TabsContent value="recommendations" className="space-y-3 mt-4">
                    {aiReport.recommendations.map((recommendation, index) => (
                      <Card key={index}>
                        <CardContent className="p-3 sm:p-4">
                          <div className="flex items-start gap-3">
                            <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 flex-shrink-0 mt-0.5" />
                            <p className="text-gray-700 text-xs sm:text-sm break-words">{recommendation}</p>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </TabsContent>

                  <TabsContent value="predictions" className="space-y-3 mt-4">
                    {aiReport.predictions.map((prediction, index) => (
                      <Card key={index}>
                        <CardContent className="p-3 sm:p-4">
                          <div className="flex items-start gap-3">
                            <Target className="h-4 w-4 sm:h-5 sm:w-5 text-blue-500 flex-shrink-0 mt-0.5" />
                            <p className="text-gray-700 text-xs sm:text-sm break-words">{prediction}</p>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          )}

          {/* Loading or No Report State */}
          {!aiReport && !generating && metrics && (
            <Card>
              <CardContent className="text-center p-6 sm:p-8">
                <Brain className="h-12 w-12 sm:h-16 sm:w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-base sm:text-lg font-semibold text-gray-600 mb-2">Ready to Generate AI Report</h3>
                <p className="text-sm text-gray-500 mb-4">
                  Click "Regenerate Report" to create fresh business insights
                </p>
                <Button
                  onClick={generateAIReport}
                  className="bg-indigo-600 hover:bg-indigo-700"
                >
                  <Brain className="h-4 w-4 mr-2" />
                  Generate AI Report
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Generating State */}
          {generating && (
            <Card>
              <CardContent className="text-center p-6 sm:p-8">
                <Brain className="h-12 w-12 sm:h-16 sm:w-16 text-indigo-600 mx-auto mb-4 animate-pulse" />
                <h3 className="text-base sm:text-lg font-semibold text-gray-600 mb-2">AI Analysis in Progress</h3>
                <p className="text-sm text-gray-500 mb-4">
                  Your business intelligence report is being generated...
                </p>
                <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Processing data and generating insights</span>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}