import React, { useState, useEffect, useRef } from 'react';
import { Package } from 'lucide-react';
import { Button } from './ui/button';
import { toast } from 'sonner';
import { ProductSearchPanel } from './pos/ProductSearchPanel';
import { CartPanel } from './pos/CartPanel';
import { PaymentDialog } from './pos/PaymentDialog';
import { Product, Sale, Customer, PaymentMethod, InsuranceProvider } from '../lib/firebase-types';
import { 
  CartItem, 
  parseNumericInput,
  calculateCartTotals,
  createCartItem,
  updateCartItemQuantity,
  findProductByCode,
  createSaleData
} from '../lib/pos-helpers';

interface POSSystemProps {
  userProfile: any;
  onSaleComplete?: (sale: Sale) => void;
  products?: Product[];
  customers?: Customer[];
  isLoading?: boolean;
  onBack?: () => void;
  onSetCurrentView?: (view: any) => void;
}

export function POSSystem({ 
  userProfile, 
  onSaleComplete, 
  products = [], 
  customers = [], 
  isLoading = false,
  onBack
}: POSSystemProps) {
  // Cart and transaction state
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [barcodeInput, setBarcodeInput] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentAmountInput, setPaymentAmountInput] = useState<string>('0');
  const [paymentReference, setPaymentReference] = useState('');
  const [discount, setDiscount] = useState<{ percentage: number; amount: number }>({ percentage: 0, amount: 0 });
  
  // Prescription state
  const [isPrescriptionSale, setIsPrescriptionSale] = useState(false);
  const [prescriptionNumber, setPrescriptionNumber] = useState('');
  const [doctorName, setDoctorName] = useState('');
  
  // Insurance state
  const [useInsurance, setUseInsurance] = useState(false);
  const [insuranceProvider, setInsuranceProvider] = useState<InsuranceProvider>('NHIF');
  const [insuranceNumber, setInsuranceNumber] = useState('');
  
  // UI state
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [showProductSearch, setShowProductSearch] = useState(false);
  const [showCustomerDialog, setShowCustomerDialog] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Refs
  const barcodeInputRef = useRef<HTMLInputElement>(null);

  // Auto-focus barcode input
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === 'F1' || (!e.ctrlKey && !e.altKey && e.key.length === 1)) {
        barcodeInputRef.current?.focus();
      }
    };

    document.addEventListener('keydown', handleKeyPress);
    return () => document.removeEventListener('keydown', handleKeyPress);
  }, []);

  // Helper function for payment amount handling
  const handlePaymentAmountChange = (value: string) => {
    setPaymentAmountInput(value);
    setPaymentAmount(parseNumericInput(value));
  };

  // Calculate totals
  const totals = calculateCartTotals(cart, discount);

  // Add product to cart
  const addToCart = (product: Product, quantity: number = 1) => {
    if (!product) {
      toast.error('Invalid product selected');
      return;
    }

    const existingItemIndex = cart.findIndex(item => item.product_id === product.id);
    
    if (existingItemIndex >= 0) {
      const existingItem = cart[existingItemIndex];
      const newQuantity = existingItem.quantity + quantity;
      
      if (newQuantity > product.stock_quantity) {
        toast.error(`Only ${product.stock_quantity} units available for ${product.name}`);
        return;
      }
      
      handleUpdateCartItemQuantity(product.id, newQuantity);
    } else {
      if (quantity > product.stock_quantity) {
        toast.error(`Only ${product.stock_quantity} units available for ${product.name}`);
        return;
      }
      
      const newItem = createCartItem(product, quantity, useInsurance);
      setCart([...cart, newItem]);
    }
    
    // Clear search and barcode inputs
    setSearchQuery('');
    setBarcodeInput('');
    setShowProductSearch(false);
    
    toast.success(`Added ${product.name} to cart`);
  };

  // Update cart item quantity
  const handleUpdateCartItemQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      handleRemoveFromCart(productId);
      return;
    }
    
    setCart(cart.map(item => {
      if (item.product_id === productId) {
        if (newQuantity > item.availableStock) {
          toast.error(`Only ${item.availableStock} units available`);
          return item;
        }
        
        return updateCartItemQuantity(item, newQuantity);
      }
      return item;
    }));
  };

  // Remove item from cart
  const handleRemoveFromCart = (productId: string) => {
    setCart(cart.filter(item => item.product_id !== productId));
    toast.success('Item removed from cart');
  };

  // Clear entire cart
  const clearCart = () => {
    setCart([]);
    setSelectedCustomer(null);
    setDiscount({ percentage: 0, amount: 0 });
    setPrescriptionNumber('');
    setDoctorName('');
    setInsuranceNumber('');
    setUseInsurance(false);
    setIsPrescriptionSale(false);
    toast.success('Cart cleared');
  };

  // Handle barcode scan
  const handleBarcodeScan = (barcode: string) => {
    const product = findProductByCode(products, barcode);
    
    if (product) {
      if (product.stock_quantity > 0) {
        addToCart(product);
        toast.success(`Scanned: ${product.name}`);
      } else {
        toast.error(`${product.name} is out of stock`);
      }
    } else {
      toast.error('Product not found');
    }
    
    setBarcodeInput('');
  };

  // Process payment and complete sale
  const processSale = async () => {
    if (cart.length === 0) {
      toast.error('Cart is empty');
      return;
    }
    
    const totalAmount = totals?.total || 0;
    const currentPaymentAmount = paymentAmount || 0;
    
    if (currentPaymentAmount < totalAmount) {
      toast.error('Insufficient payment amount');
      return;
    }
    
    if (!userProfile?.shop_id) {
      toast.error('Shop information not available');
      return;
    }
    
    setIsProcessing(true);
    
    try {
      const saleData = createSaleData(
        userProfile,
        cart,
        totals,
        paymentAmount,
        paymentMethod,
        paymentReference,
        selectedCustomer,
        isPrescriptionSale,
        prescriptionNumber,
        doctorName,
        useInsurance,
        insuranceProvider,
        insuranceNumber
      );
      
      if (onSaleComplete) {
        // The wrapper handles success/failure messages with more detail
        await onSaleComplete(saleData as Sale);
        
        // Only clear cart and UI state if the sale was successful
        // (if onSaleComplete throws an error, we don't want to clear the cart)
        clearCart();
        setPaymentAmount(0);
        setPaymentAmountInput('0');
        setPaymentReference('');
        setShowPaymentDialog(false);
      } else {
        // Fallback if no onSaleComplete handler is provided
        toast.error('Sale handler not available. Please refresh and try again.');
      }
      
    } catch (error) {
      console.error('Sale processing error:', error);
      // The wrapper already shows detailed error messages, so we don't need to show another one here
      // Just log the error for debugging
    } finally {
      setIsProcessing(false);
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="text-center">
          <Package className="h-16 w-16 animate-pulse text-gray-400 mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">Loading POS System</h2>
          <p className="text-gray-600">Setting up point of sale...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex bg-gray-50">
      {/* Header with Back Button */}
      <div className="fixed top-0 left-0 right-0 z-10 bg-white border-b shadow-sm">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            {onBack && (
              <Button variant="outline" onClick={onBack}>
                ← Back
              </Button>
            )}
            <h1 className="text-xl font-semibold">Point of Sale System</h1>
          </div>
          <div className="text-sm text-gray-500">
            {userProfile?.shop?.name || 'Pharmacy POS'}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-1 pt-20">
        {/* Left Panel - Product Selection */}
        <ProductSearchPanel
          products={products}
          searchQuery={searchQuery}
          barcodeInput={barcodeInput}
          showProductSearch={showProductSearch}
          onSearchQueryChange={setSearchQuery}
          onBarcodeInputChange={setBarcodeInput}
          onSetShowProductSearch={setShowProductSearch}
          onBarcodeScan={handleBarcodeScan}
          onAddToCart={addToCart}
        />

        {/* Right Panel - Cart and Checkout */}
        <CartPanel
          cart={cart}
          selectedCustomer={selectedCustomer}
          isPrescriptionSale={isPrescriptionSale}
          prescriptionNumber={prescriptionNumber}
          doctorName={doctorName}
          useInsurance={useInsurance}
          insuranceProvider={insuranceProvider}
          insuranceNumber={insuranceNumber}
          onUpdateQuantity={handleUpdateCartItemQuantity}
          onRemoveItem={handleRemoveFromCart}
          onClearCart={clearCart}
          onSelectCustomer={() => setShowCustomerDialog(true)}
          onTogglePrescription={setIsPrescriptionSale}
          onPrescriptionNumberChange={setPrescriptionNumber}
          onDoctorNameChange={setDoctorName}
          onToggleInsurance={setUseInsurance}
          onInsuranceProviderChange={setInsuranceProvider}
          onInsuranceNumberChange={setInsuranceNumber}
        />
      </div>

      {/* Payment Dialog */}
      {cart.length > 0 && (
        <div className="fixed bottom-0 right-96 w-96">
          <PaymentDialog
            open={showPaymentDialog}
            totals={totals}
            paymentMethod={paymentMethod}
            paymentAmountInput={paymentAmountInput}
            paymentAmount={paymentAmount}
            paymentReference={paymentReference}
            isProcessing={isProcessing}
            onOpenChange={setShowPaymentDialog}
            onPaymentMethodChange={setPaymentMethod}
            onPaymentAmountChange={handlePaymentAmountChange}
            onPaymentReferenceChange={setPaymentReference}
            onProcessSale={processSale}
            onTriggerClick={() => {
              const totalAmount = totals?.total || 0;
              setPaymentAmountInput(totalAmount.toFixed(2));
              setPaymentAmount(totalAmount);
            }}
          />
        </div>
      )}
    </div>
  );
}