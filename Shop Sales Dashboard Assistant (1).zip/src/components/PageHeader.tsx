import React from 'react';
import { ChevronRight, Home } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { View } from '../lib/app-constants';

interface BreadcrumbItem {
  label: string;
  view?: View;
  icon?: React.ReactNode;
}

interface PageHeaderProps {
  title: string;
  description?: string;
  breadcrumbs?: BreadcrumbItem[];
  badge?: {
    text: string;
    variant?: 'default' | 'secondary' | 'destructive' | 'outline';
  };
  action?: {
    label: string;
    onClick: () => void;
    variant?: 'default' | 'outline' | 'secondary';
  };
  onNavigate?: (view: View) => void;
}

export function PageHeader({ 
  title, 
  description, 
  breadcrumbs = [], 
  badge,
  action,
  onNavigate 
}: PageHeaderProps) {
  const defaultBreadcrumbs: BreadcrumbItem[] = breadcrumbs;

  return (
    <div className="mb-6 lg:mb-8">
      {/* Breadcrumbs */}
      {defaultBreadcrumbs.length > 0 && (
        <nav className="flex items-center space-x-1 text-sm text-gray-500 mb-4">
          {defaultBreadcrumbs.map((item, index) => (
            <React.Fragment key={index}>
              {index > 0 && <ChevronRight className="h-4 w-4 text-gray-400" />}
              {item.view && onNavigate ? (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onNavigate(item.view!)}
                  className="h-auto p-1 text-sm text-gray-500 hover:text-gray-700"
                >
                  <div className="flex items-center gap-1">
                    {item.icon}
                    {item.label}
                  </div>
                </Button>
              ) : (
                <span className={`flex items-center gap-1 ${index === defaultBreadcrumbs.length - 1 ? 'text-gray-900 font-medium' : ''}`}>
                  {item.icon}
                  {item.label}
                </span>
              )}
            </React.Fragment>
          ))}
        </nav>
      )}

      {/* Header Content */}
      <div className="flex flex-col space-y-4 lg:flex-row lg:items-center lg:justify-between lg:space-y-0">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">{title}</h1>
            {badge && (
              <Badge variant={badge.variant || 'default'} className="text-xs">
                {badge.text}
              </Badge>
            )}
          </div>
          {description && (
            <p className="text-gray-600 text-sm lg:text-base">{description}</p>
          )}
        </div>

        {/* Action Button */}
        {action && (
          <div className="flex-shrink-0">
            <Button 
              onClick={action.onClick}
              variant={action.variant || 'default'}
              className="w-full lg:w-auto"
            >
              {action.label}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}