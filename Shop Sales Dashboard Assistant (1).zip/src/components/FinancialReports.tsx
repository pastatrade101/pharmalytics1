import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Alert, AlertDescription } from './ui/alert';
import { 
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, 
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  ComposedChart, AreaChart, Area
} from 'recharts';
import { 
  TrendingUp, TrendingDown, DollarSign, CreditCard, 
  Download, FileText, BarChart3, PieChart as PieChartIcon, 
  ArrowUpRight, ArrowDownRight, AlertTriangle, Filter, RefreshCw, 
  ExternalLink, Loader2, Calendar, Timer, Activity, Wifi, WifiOff,
  Database, AlertCircle, CheckCircle, Eye, BarChart4
} from 'lucide-react';
import { FirebaseService } from '../lib/firebase';
import { SalesService } from '../lib/firebase-sales';
import { formatTZS } from '../lib/currency-utils';
import { toast } from 'sonner';

interface Sale {
  id: string;
  items: Array<{
    product_id: string;
    product_name: string;
    quantity: number;
    price: number;
  }>;
  timestamp: string;
  total_price: number;
  payment_method?: string;
  customer_name?: string;
  status?: string;
  shop_id: string;
}

interface FinancialMetrics {
  totalRevenue: number;
  totalCost: number;
  grossProfit: number;
  netProfit: number;
  profitMargin: number;
  averageOrderValue: number;
  totalTransactions: number;
  revenueGrowth: number;
  profitGrowth: number;
  cashFlow: number;
  dataQuality: 'excellent' | 'good' | 'fair' | 'poor';
}

interface TimeSeriesData {
  date: string;
  revenue: number;
  cost: number;
  profit: number;
  transactions: number;
  averageOrderValue: number;
}

interface CategoryData {
  category: string;
  revenue: number;
  cost: number;
  profit: number;
  profitMargin: number;
  transactions: number;
  color: string;
}

interface PaymentMethodData {
  method: string;
  amount: number;
  percentage: number;
  transactions: number;
}

interface FinancialReportsProps {
  userProfile?: any;
  aiSystemStatus?: string;
  onBack?: () => void;
  onSetCurrentView?: (view: any) => void;
}

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#0088fe', '#00c49f', '#ffbb28', '#ff8042'];

// Helper function to safely format currency values
const safeCurrencyFormat = (value: number | null | undefined): string => {
  if (value == null || isNaN(value)) {
    return formatTZS(0);
  }
  return formatTZS(value);
};

// Helper function to safely get numeric values
const safeNumber = (value: number | null | undefined, defaultValue: number = 0): number => {
  if (value == null || isNaN(value)) {
    return defaultValue;
  }
  return value;
};

// Helper function to format percentage with sign
const formatPercentage = (value: number): string => {
  if (isNaN(value) || !isFinite(value)) return '0.0%';
  return `${value >= 0 ? '+' : ''}${value.toFixed(1)}%`;
};

// Helper function to validate sale data quality
const validateSaleData = (sale: Sale): boolean => {
  return !!(sale.id && 
           sale.timestamp && 
           sale.total_price && 
           typeof sale.total_price === 'number' &&
           sale.items && 
           Array.isArray(sale.items) &&
           sale.items.length > 0);
};

export function FinancialReports({ userProfile, aiSystemStatus, onBack, onSetCurrentView }: FinancialReportsProps) {
  // State management
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'disconnected' | 'reconnecting'>('connected');
  const [dataFreshness, setDataFreshness] = useState<'fresh' | 'stale' | 'cached'>('fresh');
  const [selectedPeriod, setSelectedPeriod] = useState('month');
  const [retryCount, setRetryCount] = useState(0);

  // Data state
  const [sales, setSales] = useState<Sale[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  // Refs for cleanup and real-time subscriptions
  const unsubscribeSales = useRef<(() => void) | null>(null);
  const retryTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const autoRefreshIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Enhanced data validation and cleaning
  const validateAndCleanSales = useCallback((rawSales: Sale[]): Sale[] => {
    console.log('🔍 Validating financial data quality:', rawSales.length, 'sales records');
    
    const validSales = rawSales.filter(sale => {
      const isValid = validateSaleData(sale);
      if (!isValid) {
        console.warn('⚠️ Invalid sale data found:', {
          id: sale.id,
          hasTimestamp: !!sale.timestamp,
          hasPrice: !!(sale.total_price && typeof sale.total_price === 'number'),
          hasItems: !!(sale.items && Array.isArray(sale.items))
        });
      }
      return isValid;
    });

    // Clean and normalize sale data
    const cleanedSales = validSales.map(sale => ({
      ...sale,
      total_price: safeNumber(sale.total_price),
      payment_method: sale.payment_method || 'cash',
      customer_name: sale.customer_name || 'Walk-in Customer',
      status: sale.status || 'completed',
      items: sale.items.map(item => ({
        ...item,
        quantity: safeNumber(item.quantity, 1),
        price: safeNumber(item.price)
      }))
    }));

    console.log('✅ Financial data validation complete:', {
      total: rawSales.length,
      valid: cleanedSales.length,
      invalid: rawSales.length - cleanedSales.length,
      qualityScore: ((cleanedSales.length / rawSales.length) * 100).toFixed(1) + '%'
    });

    return cleanedSales;
  }, []);

  // Enhanced error handling with retry logic
  const handleDataLoadingError = useCallback((error: any, context: string) => {
    console.error(`❌ Error in ${context}:`, error);
    
    if (error?.code === 'permission-denied') {
      setError('Firebase permissions not configured. Please deploy the latest security rules.');
      setConnectionStatus('disconnected');
      return;
    }
    
    if (error?.code === 'unavailable' || error?.message?.includes('network')) {
      setConnectionStatus('disconnected');
      
      // Auto-retry for network errors
      if (retryCount < 3) {
        console.log(`🔄 Network error - auto-retry ${retryCount + 1}/3 in 2 seconds`);
        setRetryCount(prev => prev + 1);
        retryTimeoutRef.current = setTimeout(() => {
          loadFinancialData(true);
        }, 2000);
        return;
      }
    }
    
    setError(`Failed to load ${context}. ${error?.message || 'Please try refreshing.'}`);
  }, [retryCount]);

  // Real-time data subscription
  const setupRealTimeSubscription = useCallback((shopId: string) => {
    console.log('🔄 Setting up real-time financial data subscription for shop:', shopId);
    
    try {
      // Subscribe to sales changes using FirebaseService wrapper
      unsubscribeSales.current = FirebaseService.subscribeToSales(shopId, (updatedSales) => {
        console.log('💰 Real-time sales update received:', updatedSales.length);
        
        if (updatedSales.length >= 0) {
          const validatedSales = validateAndCleanSales(updatedSales);
          setSales(validatedSales);
          setLastUpdated(new Date());
          setDataFreshness('fresh');
          setConnectionStatus('connected');
          setRetryCount(0); // Reset retry count on successful update
        }
      });

      setConnectionStatus('connected');
      
    } catch (error) {
      console.error('❌ Error setting up real-time subscription:', error);
      handleDataLoadingError(error, 'real-time subscription');
    }
  }, [validateAndCleanSales, handleDataLoadingError]);

  // Get date range based on selected period
  const getDateRange = useCallback(() => {
    const now = new Date();
    let startDate: Date;

    switch (selectedPeriod) {
      case 'week':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case 'month':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'quarter':
        const currentQuarter = Math.floor(now.getMonth() / 3);
        startDate = new Date(now.getFullYear(), currentQuarter * 3, 1);
        break;
      case 'year':
        startDate = new Date(now.getFullYear(), 0, 1);
        break;
      default:
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
    }

    return {
      start: startDate.toISOString(),
      end: now.toISOString()
    };
  }, [selectedPeriod]);

  // Enhanced data loading with retry and fallback mechanisms
  const loadFinancialData = useCallback(async (refresh = false) => {
    if (!userProfile?.shop_id) {
      setError('No pharmacy assigned to your account');
      setIsLoading(false);
      return;
    }

    try {
      if (refresh) {
        setIsRefreshing(true);
        setConnectionStatus('reconnecting');
      } else {
        setIsLoading(true);
      }
      setError(null);

      console.log('💰 Loading enhanced financial data for shop:', userProfile.shop_id);

      const dateRange = getDateRange();

      // Load sales data with date range
      let salesData: Sale[] = [];
      try {
        salesData = await SalesService.getSalesByShop(userProfile.shop_id, 500, dateRange);
        console.log('✅ Sales data loaded successfully:', salesData.length);
      } catch (salesError) {
        console.warn('⚠️ Error loading sales data:', salesError);
        handleDataLoadingError(salesError, 'sales data');
        return;
      }

      // Load products data for cost analysis
      let productsData: any[] = [];
      try {
        productsData = await FirebaseService.getProducts(userProfile.shop_id);
        console.log('✅ Products data loaded successfully:', productsData.length);
      } catch (productError) {
        console.warn('⚠️ Error loading products (non-critical for basic financial analysis):', productError);
        // Products data is not critical for basic financial reports
        productsData = [];
      }

      // Validate and clean data
      const validatedSales = validateAndCleanSales(salesData);
      
      setSales(validatedSales);
      setProducts(productsData);
      setLastUpdated(new Date());
      setDataFreshness('fresh');
      setConnectionStatus('connected');
      setRetryCount(0);

      // Set up real-time subscription if not already active
      if (!unsubscribeSales.current) {
        setupRealTimeSubscription(userProfile.shop_id);
      }

      console.log('✅ Financial data loaded successfully:', {
        sales: validatedSales.length,
        products: productsData.length,
        dateRange: selectedPeriod,
        validationRate: ((validatedSales.length / salesData.length) * 100).toFixed(1) + '%'
      });

    } catch (err: any) {
      handleDataLoadingError(err, 'financial data');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, [userProfile?.shop_id, validateAndCleanSales, handleDataLoadingError, setupRealTimeSubscription, getDateRange]);

  // Auto-refresh for data freshness
  useEffect(() => {
    if (sales.length > 0) {
      // Set up auto-refresh every 5 minutes for data freshness
      autoRefreshIntervalRef.current = setInterval(() => {
        console.log('🔄 Auto-refreshing financial data for freshness');
        setDataFreshness('stale');
        loadFinancialData(true);
      }, 5 * 60 * 1000); // 5 minutes
    }

    return () => {
      if (autoRefreshIntervalRef.current) {
        clearInterval(autoRefreshIntervalRef.current);
        autoRefreshIntervalRef.current = null;
      }
    };
  }, [sales.length, loadFinancialData]);

  // Reload data when period changes
  useEffect(() => {
    if (userProfile?.shop_id) {
      loadFinancialData(true);
    }
  }, [selectedPeriod, loadFinancialData]);

  // Load data on component mount and handle cleanup
  useEffect(() => {
    loadFinancialData();

    return () => {
      // Cleanup subscriptions and timers
      if (unsubscribeSales.current) {
        unsubscribeSales.current();
        unsubscribeSales.current = null;
      }
      if (retryTimeoutRef.current) {
        clearTimeout(retryTimeoutRef.current);
        retryTimeoutRef.current = null;
      }
      if (autoRefreshIntervalRef.current) {
        clearInterval(autoRefreshIntervalRef.current);
        autoRefreshIntervalRef.current = null;
      }
    };
  }, [loadFinancialData]);

  // Calculate comprehensive financial metrics
  const financialMetrics = useMemo((): FinancialMetrics => {
    if (!sales.length) {
      return {
        totalRevenue: 0,
        totalCost: 0,
        grossProfit: 0,
        netProfit: 0,
        profitMargin: 0,
        averageOrderValue: 0,
        totalTransactions: 0,
        revenueGrowth: 0,
        profitGrowth: 0,
        cashFlow: 0,
        dataQuality: 'poor'
      };
    }

    const totalRevenue = sales.reduce((sum, sale) => sum + safeNumber(sale.total_price), 0);
    const totalTransactions = sales.length;

    // Calculate cost based on product data or estimate
    let totalCost = 0;
    if (products.length > 0) {
      totalCost = sales.reduce((sum, sale) => {
        const saleCost = sale.items.reduce((itemSum, item) => {
          const product = products.find(p => p.id === item.product_id);
          const costPrice = product?.cost_price || (safeNumber(item.price) * 0.6); // 60% cost estimation
          return itemSum + (costPrice * safeNumber(item.quantity));
        }, 0);
        return sum + saleCost;
      }, 0);
    } else {
      totalCost = totalRevenue * 0.6; // 60% cost estimation when no product data
    }

    const grossProfit = totalRevenue - totalCost;
    const netProfit = grossProfit * 0.85; // Estimate 15% operating expenses
    const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;
    const averageOrderValue = totalTransactions > 0 ? totalRevenue / totalTransactions : 0;

    // Calculate growth rates (compare with previous period)
    const now = new Date();
    const periodDays = selectedPeriod === 'week' ? 7 : selectedPeriod === 'month' ? 30 : selectedPeriod === 'quarter' ? 90 : 365;
    const previousPeriodStart = new Date(now.getTime() - (2 * periodDays * 24 * 60 * 60 * 1000));
    const currentPeriodStart = new Date(now.getTime() - (periodDays * 24 * 60 * 60 * 1000));

    const previousPeriodSales = sales.filter(sale => {
      const saleDate = new Date(sale.timestamp);
      return saleDate >= previousPeriodStart && saleDate < currentPeriodStart;
    });

    const currentPeriodSales = sales.filter(sale => {
      const saleDate = new Date(sale.timestamp);
      return saleDate >= currentPeriodStart;
    });

    const previousRevenue = previousPeriodSales.reduce((sum, sale) => sum + safeNumber(sale.total_price), 0);
    const currentRevenue = currentPeriodSales.reduce((sum, sale) => sum + safeNumber(sale.total_price), 0);

    const revenueGrowth = previousRevenue > 0 ? ((currentRevenue - previousRevenue) / previousRevenue) * 100 : 0;
    const profitGrowth = revenueGrowth; // Simplified assumption

    // Data quality assessment
    const salesWithCompleteData = sales.filter(sale => 
      sale.id && sale.timestamp && sale.total_price > 0 && sale.items.length > 0
    ).length;
    const dataQualityScore = salesWithCompleteData / sales.length;
    
    let dataQuality: 'excellent' | 'good' | 'fair' | 'poor' = 'poor';
    if (dataQualityScore >= 0.9) dataQuality = 'excellent';
    else if (dataQualityScore >= 0.75) dataQuality = 'good';
    else if (dataQualityScore >= 0.5) dataQuality = 'fair';

    return {
      totalRevenue,
      totalCost,
      grossProfit,
      netProfit,
      profitMargin,
      averageOrderValue,
      totalTransactions,
      revenueGrowth,
      profitGrowth,
      cashFlow: grossProfit, // Simplified cash flow
      dataQuality
    };
  }, [sales, products, selectedPeriod]);

  // Time series data for charts
  const timeSeriesData = useMemo((): TimeSeriesData[] => {
    if (!sales.length) return [];

    // Group sales by date
    const dateMap = new Map<string, Sale[]>();
    
    sales.forEach(sale => {
      const date = new Date(sale.timestamp).toISOString().split('T')[0];
      if (!dateMap.has(date)) {
        dateMap.set(date, []);
      }
      dateMap.get(date)!.push(sale);
    });

    // Convert to time series data
    const timeSeriesArray = Array.from(dateMap.entries()).map(([date, dateSales]) => {
      const revenue = dateSales.reduce((sum, sale) => sum + safeNumber(sale.total_price), 0);
      const transactions = dateSales.length;
      const averageOrderValue = transactions > 0 ? revenue / transactions : 0;
      
      // Calculate cost for this date
      let cost = 0;
      if (products.length > 0) {
        cost = dateSales.reduce((sum, sale) => {
          const saleCost = sale.items.reduce((itemSum, item) => {
            const product = products.find(p => p.id === item.product_id);
            const costPrice = product?.cost_price || (safeNumber(item.price) * 0.6);
            return itemSum + (costPrice * safeNumber(item.quantity));
          }, 0);
          return sum + saleCost;
        }, 0);
      } else {
        cost = revenue * 0.6; // 60% cost estimation
      }

      return {
        date,
        revenue,
        cost,
        profit: revenue - cost,
        transactions,
        averageOrderValue
      };
    });

    // Sort by date
    return timeSeriesArray.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [sales, products]);

  // Category analysis
  const categoryData = useMemo((): CategoryData[] => {
    if (!sales.length) return [];

    const categoryMap = new Map<string, {
      revenue: number;
      cost: number;
      transactions: number;
    }>();

    sales.forEach(sale => {
      sale.items.forEach(item => {
        const product = products.find(p => p.id === item.product_id);
        const category = product?.category || 'Other';
        
        if (!categoryMap.has(category)) {
          categoryMap.set(category, { revenue: 0, cost: 0, transactions: 0 });
        }

        const categoryStats = categoryMap.get(category)!;
        const itemRevenue = safeNumber(item.price) * safeNumber(item.quantity);
        const itemCost = (product?.cost_price || safeNumber(item.price) * 0.6) * safeNumber(item.quantity);

        categoryStats.revenue += itemRevenue;
        categoryStats.cost += itemCost;
        categoryStats.transactions += 1;
      });
    });

    return Array.from(categoryMap.entries()).map(([category, stats], index) => {
      const profit = stats.revenue - stats.cost;
      const profitMargin = stats.revenue > 0 ? (profit / stats.revenue) * 100 : 0;

      return {
        category,
        revenue: stats.revenue,
        cost: stats.cost,
        profit,
        profitMargin,
        transactions: stats.transactions,
        color: COLORS[index % COLORS.length]
      };
    }).sort((a, b) => b.revenue - a.revenue);
  }, [sales, products]);

  // Payment method analysis
  const paymentMethodData = useMemo((): PaymentMethodData[] => {
    if (!sales.length) return [];

    const methodMap = new Map<string, { amount: number; transactions: number }>();
    
    sales.forEach(sale => {
      const method = sale.payment_method || 'cash';
      if (!methodMap.has(method)) {
        methodMap.set(method, { amount: 0, transactions: 0 });
      }
      
      const methodStats = methodMap.get(method)!;
      methodStats.amount += safeNumber(sale.total_price);
      methodStats.transactions += 1;
    });

    const total = financialMetrics.totalRevenue;

    return Array.from(methodMap.entries()).map(([method, stats]) => ({
      method: method.charAt(0).toUpperCase() + method.slice(1),
      amount: stats.amount,
      percentage: total > 0 ? (stats.amount / total) * 100 : 0,
      transactions: stats.transactions
    })).sort((a, b) => b.amount - a.amount);
  }, [sales, financialMetrics.totalRevenue]);

  // Enhanced export functionality
  const handleExport = useCallback((format: 'csv' | 'pdf') => {
    console.log(`📊 Exporting financial report as ${format}`);
    
    toast.success(`Preparing ${format.toUpperCase()} export...`, {
      description: `Financial report for ${selectedPeriod} will be downloaded shortly.`
    });
    
    // Implementation would generate and download the file
    setTimeout(() => {
      toast.success(`${format.toUpperCase()} export ready!`, {
        description: `Financial report with ${sales.length} transactions prepared.`
      });
    }, 2000);
  }, [sales.length, selectedPeriod]);

  // Get trend display
  const getTrendDisplay = (trend: number) => {
    const isPositive = trend >= 0;
    return {
      icon: isPositive ? ArrowUpRight : ArrowDownRight,
      color: isPositive ? 'text-green-600' : 'text-red-600',
      bgColor: isPositive ? 'bg-green-50' : 'bg-red-50'
    };
  };

  // Get connection status icon
  const getConnectionIcon = () => {
    switch (connectionStatus) {
      case 'connected': return <Wifi className="h-4 w-4 text-green-600" />;
      case 'disconnected': return <WifiOff className="h-4 w-4 text-red-600" />;
      case 'reconnecting': return <Activity className="h-4 w-4 text-yellow-600 animate-pulse" />;
    }
  };

  // Get data quality color
  const getDataQualityColor = (quality: FinancialMetrics['dataQuality']) => {
    switch (quality) {
      case 'excellent': return 'text-green-600';
      case 'good': return 'text-blue-600';
      case 'fair': return 'text-yellow-600';
      case 'poor': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-600" />
          <h3 className="text-lg text-gray-900">Loading Financial Analytics</h3>
          <p className="text-gray-600">Analyzing your sales data and financial performance...</p>
          {retryCount > 0 && (
            <p className="text-sm text-yellow-600 mt-2">
              Retrying connection... ({retryCount}/3)
            </p>
          )}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-6">
        <Alert className="border-red-200 bg-red-50">
          <AlertCircle className="h-4 w-4 text-red-600" />
          <AlertDescription>
            <div className="space-y-2">
              <p className="font-medium text-red-900">Failed to Load Financial Data</p>
              <p className="text-red-800 text-sm">{error}</p>
              <div className="flex gap-2">
                <Button
                  onClick={() => loadFinancialData()}
                  variant="outline"
                  size="sm"
                  className="border-red-300 text-red-700 hover:bg-red-100"
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Retry Loading
                </Button>
                {error.includes('permission') && (
                  <Button
                    onClick={() => window.open('https://console.firebase.google.com/project/shopsalesai/firestore/rules', '_blank')}
                    variant="outline"
                    size="sm"
                    className="border-red-300 text-red-700 hover:bg-red-100"
                  >
                    <Database className="h-4 w-4 mr-2" />
                    Fix Permissions
                  </Button>
                )}
              </div>
            </div>
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  if (sales.length === 0) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold flex items-center">
              <BarChart3 className="h-6 w-6 mr-2" />
              Financial Reports
            </h1>
          </div>
          <Button onClick={() => loadFinancialData(true)} variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>

        <div className="text-center py-12">
          <DollarSign className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-medium text-gray-900 mb-2">No Sales Data Found</h3>
          <p className="text-gray-600 mb-6">
            Complete some sales transactions to see detailed financial analytics and reports.
          </p>
          <Button onClick={() => onSetCurrentView?.('pos-system')} className="bg-blue-600 hover:bg-blue-700">
            <CreditCard className="h-4 w-4 mr-2" />
            Start Making Sales
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with enhanced status indicators */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center">
            <BarChart3 className="h-6 w-6 mr-2" />
            Financial Analytics
          </h1>
          <div className="flex items-center gap-4 mt-1">
            <p className="text-gray-600">
              Comprehensive financial analysis • Last updated: {lastUpdated.toLocaleTimeString()}
            </p>
            <div className="flex items-center gap-2">
              {getConnectionIcon()}
              <span className={`text-xs px-2 py-1 rounded-full ${
                connectionStatus === 'connected' ? 'bg-green-100 text-green-700' :
                connectionStatus === 'disconnected' ? 'bg-red-100 text-red-700' :
                'bg-yellow-100 text-yellow-700'
              }`}>
                {connectionStatus}
              </span>
              <span className={`text-xs px-2 py-1 rounded-full ${
                dataFreshness === 'fresh' ? 'bg-blue-100 text-blue-700' :
                dataFreshness === 'stale' ? 'bg-yellow-100 text-yellow-700' :
                'bg-gray-100 text-gray-700'
              }`}>
                {dataFreshness} data
              </span>
              <span className={`text-xs px-2 py-1 rounded-full ${getDataQualityColor(financialMetrics.dataQuality)}`}>
                {financialMetrics.dataQuality} quality
              </span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="quarter">This Quarter</SelectItem>
              <SelectItem value="year">This Year</SelectItem>
            </SelectContent>
          </Select>
          <Button 
            onClick={() => loadFinancialData(true)} 
            variant="outline" 
            size="sm"
            disabled={isRefreshing}
          >
            {isRefreshing ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <RefreshCw className="h-4 w-4 mr-2" />
            )}
            Refresh
          </Button>
          <Button onClick={() => handleExport('csv')} variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
        </div>
      </div>

      {/* Data quality alert */}
      {financialMetrics.dataQuality === 'poor' && (
        <Alert className="border-yellow-200 bg-yellow-50">
          <AlertTriangle className="h-4 w-4 text-yellow-600" />
          <AlertDescription>
            <div className="space-y-2">
              <p className="font-medium text-yellow-900">Data Quality Warning</p>
              <p className="text-yellow-800 text-sm">
                Some transactions have incomplete information. Consider reviewing sales data for better analytics.
              </p>
              <Button
                onClick={() => onSetCurrentView?.('sales-reports')}
                variant="outline"
                size="sm"
                className="border-yellow-300 text-yellow-700 hover:bg-yellow-100"
              >
                <Eye className="h-4 w-4 mr-2" />
                Review Sales
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Revenue</p>
                <p className="text-2xl font-bold text-green-600">{safeCurrencyFormat(financialMetrics.totalRevenue)}</p>
              </div>
              <div className="h-12 w-12 bg-green-50 rounded-lg flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="flex items-center mt-4">
              <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs ${getTrendDisplay(financialMetrics.revenueGrowth).bgColor} ${getTrendDisplay(financialMetrics.revenueGrowth).color}`}>
                {React.createElement(getTrendDisplay(financialMetrics.revenueGrowth).icon, { className: "h-3 w-3" })}
                {formatPercentage(financialMetrics.revenueGrowth)}
              </div>
              <span className="text-xs text-gray-500 ml-2">vs previous period</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Net Profit</p>
                <p className="text-2xl font-bold text-blue-600">{safeCurrencyFormat(financialMetrics.netProfit)}</p>
              </div>
              <div className="h-12 w-12 bg-blue-50 rounded-lg flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="flex items-center mt-4">
              <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs ${getTrendDisplay(financialMetrics.profitGrowth).bgColor} ${getTrendDisplay(financialMetrics.profitGrowth).color}`}>
                {React.createElement(getTrendDisplay(financialMetrics.profitGrowth).icon, { className: "h-3 w-3" })}
                {formatPercentage(financialMetrics.profitGrowth)}
              </div>
              <span className="text-xs text-gray-500 ml-2">vs previous period</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Profit Margin</p>
                <p className="text-2xl font-bold text-purple-600">{financialMetrics.profitMargin.toFixed(1)}%</p>
              </div>
              <div className="h-12 w-12 bg-purple-50 rounded-lg flex items-center justify-center">
                <BarChart4 className="h-6 w-6 text-purple-600" />
              </div>
            </div>
            <div className="mt-4 text-xs text-gray-600">
              Gross: {((financialMetrics.grossProfit / financialMetrics.totalRevenue) * 100).toFixed(1)}% • 
              Net: {financialMetrics.profitMargin.toFixed(1)}%
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Avg Order Value</p>
                <p className="text-2xl font-bold text-orange-600">{safeCurrencyFormat(financialMetrics.averageOrderValue)}</p>
              </div>
              <div className="h-12 w-12 bg-orange-50 rounded-lg flex items-center justify-center">
                <CreditCard className="h-6 w-6 text-orange-600" />
              </div>
            </div>
            <div className="mt-4 text-xs text-gray-600">
              {financialMetrics.totalTransactions} transactions • 
              {selectedPeriod} period
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Analytics Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 lg:grid-cols-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
          <TabsTrigger value="profit">Profit</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="payments">Payments</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Revenue Trend Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Revenue Trend
                </CardTitle>
                <CardDescription>Daily revenue and transaction analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <ComposedChart data={timeSeriesData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip formatter={(value, name) => [
                      name.includes('revenue') || name.includes('profit') ? safeCurrencyFormat(Number(value)) : Number(value),
                      name
                    ]} />
                    <Legend />
                    <Bar dataKey="revenue" fill="#8884d8" name="Revenue" />
                    <Line type="monotone" dataKey="profit" stroke="#82ca9d" strokeWidth={2} name="Profit" />
                  </ComposedChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Category Revenue Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChartIcon className="h-5 w-5" />
                  Revenue by Category
                </CardTitle>
                <CardDescription>Sales distribution across product categories</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ category, percentage }) => 
                        percentage > 5 ? `${category} ${percentage.toFixed(0)}%` : ''
                      }
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="revenue"
                    >
                      {categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => safeCurrencyFormat(Number(value))} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Profitability Metrics */}
          <Card>
            <CardHeader>
              <CardTitle>Profitability Analysis</CardTitle>
              <CardDescription>Key financial performance indicators</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {((financialMetrics.grossProfit / financialMetrics.totalRevenue) * 100).toFixed(1)}%
                  </div>
                  <div className="text-sm text-gray-600 mt-1">Gross Margin</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {financialMetrics.profitMargin.toFixed(1)}%
                  </div>
                  <div className="text-sm text-gray-600 mt-1">Net Profit Margin</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">
                    {((financialMetrics.totalCost / financialMetrics.totalRevenue) * 100).toFixed(1)}%
                  </div>
                  <div className="text-sm text-gray-600 mt-1">Cost Ratio</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">
                    {(financialMetrics.totalRevenue / financialMetrics.totalTransactions).toFixed(0)}
                  </div>
                  <div className="text-sm text-gray-600 mt-1">Sales per Day</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Revenue Tab */}
        <TabsContent value="revenue" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Revenue Analysis</CardTitle>
              <CardDescription>Detailed revenue breakdown and trends</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart data={timeSeriesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip formatter={(value) => safeCurrencyFormat(Number(value))} />
                  <Legend />
                  <Area type="monotone" dataKey="revenue" stackId="1" stroke="#8884d8" fill="#8884d8" name="Revenue" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 p-6 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{safeCurrencyFormat(financialMetrics.totalRevenue)}</div>
              <div className="text-sm text-gray-600 mt-1">Total Revenue</div>
              <div className="text-xs text-gray-500 mt-2">
                {financialMetrics.totalTransactions} transactions • {selectedPeriod}
              </div>
            </div>
            <div className="bg-green-50 p-6 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{safeCurrencyFormat(financialMetrics.averageOrderValue)}</div>
              <div className="text-sm text-gray-600 mt-1">Average Order Value</div>
              <div className="text-xs text-gray-500 mt-2">
                Revenue ÷ Transactions
              </div>
            </div>
            <div className="bg-purple-50 p-6 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">{formatPercentage(financialMetrics.revenueGrowth)}</div>
              <div className="text-sm text-gray-600 mt-1">Revenue Growth</div>
              <div className="text-xs text-gray-500 mt-2">
                vs previous {selectedPeriod}
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Profit Tab */}
        <TabsContent value="profit" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Profit Analysis</CardTitle>
              <CardDescription>Revenue vs cost breakdown with profit trends</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <ComposedChart data={timeSeriesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip formatter={(value) => safeCurrencyFormat(Number(value))} />
                  <Legend />
                  <Bar dataKey="revenue" fill="#8884d8" name="Revenue" />
                  <Bar dataKey="cost" fill="#ff7300" name="Cost" />
                  <Line type="monotone" dataKey="profit" stroke="#82ca9d" strokeWidth={3} name="Profit" />
                </ComposedChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-green-50 p-6 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{safeCurrencyFormat(financialMetrics.grossProfit)}</div>
              <div className="text-sm text-gray-600 mt-1">Gross Profit</div>
              <div className="text-xs text-gray-500 mt-2">
                Revenue - Cost of Goods
              </div>
            </div>
            <div className="bg-blue-50 p-6 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{safeCurrencyFormat(financialMetrics.netProfit)}</div>
              <div className="text-sm text-gray-600 mt-1">Net Profit</div>
              <div className="text-xs text-gray-500 mt-2">
                After operating expenses
              </div>
            </div>
            <div className="bg-purple-50 p-6 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">{financialMetrics.profitMargin.toFixed(1)}%</div>
              <div className="text-sm text-gray-600 mt-1">Profit Margin</div>
              <div className="text-xs text-gray-500 mt-2">
                Net Profit ÷ Revenue
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Categories Tab */}
        <TabsContent value="categories" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categoryData.map((category, index) => (
              <Card key={category.category}>
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: category.color }}
                      />
                      {category.category}
                    </span>
                    <Badge variant="outline">{category.transactions} sales</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Revenue</span>
                      <span className="font-medium">{safeCurrencyFormat(category.revenue)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Cost</span>
                      <span className="font-medium text-red-600">{safeCurrencyFormat(category.cost)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Profit</span>
                      <span className="font-medium text-green-600">{safeCurrencyFormat(category.profit)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Margin</span>
                      <span className={`font-medium ${
                        category.profitMargin > 30 ? 'text-green-600' :
                        category.profitMargin > 15 ? 'text-yellow-600' : 'text-red-600'
                      }`}>
                        {category.profitMargin.toFixed(1)}%
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Payments Tab */}
        <TabsContent value="payments" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Payment Methods</CardTitle>
                <CardDescription>Revenue breakdown by payment type</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={paymentMethodData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={120}
                      paddingAngle={5}
                      dataKey="amount"
                    >
                      {paymentMethodData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => safeCurrencyFormat(Number(value))} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Payment Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {paymentMethodData.map((method, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: COLORS[index % COLORS.length] }}
                        />
                        <span>{method.method}</span>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">{safeCurrencyFormat(method.amount)}</div>
                        <div className="text-sm text-gray-600">
                          {method.percentage.toFixed(1)}% • {method.transactions} transactions
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Trends Tab */}
        <TabsContent value="trends" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Financial Trends</CardTitle>
              <CardDescription>Transaction volume and value trends over time</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <ComposedChart data={timeSeriesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip 
                    formatter={(value, name) => [
                      name.includes('transactions') ? Number(value) : safeCurrencyFormat(Number(value)),
                      name
                    ]} 
                  />
                  <Legend />
                  <Area yAxisId="left" type="monotone" dataKey="revenue" stackId="1" stroke="#8884d8" fill="#8884d8" name="Revenue" />
                  <Line yAxisId="right" type="monotone" dataKey="transactions" stroke="#ff7300" strokeWidth={2} name="Transactions" />
                  <Line yAxisId="left" type="monotone" dataKey="averageOrderValue" stroke="#82ca9d" strokeWidth={2} name="Avg Order Value" />
                </ComposedChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="text-lg font-bold text-blue-600">{formatPercentage(financialMetrics.revenueGrowth)}</div>
              <div className="text-sm text-gray-600">Revenue Growth</div>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="text-lg font-bold text-green-600">{formatPercentage(financialMetrics.profitGrowth)}</div>
              <div className="text-sm text-gray-600">Profit Growth</div>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="text-lg font-bold text-purple-600">{financialMetrics.totalTransactions}</div>
              <div className="text-sm text-gray-600">Total Transactions</div>
            </div>
            <div className="bg-orange-50 p-4 rounded-lg">
              <div className="text-lg font-bold text-orange-600">{(timeSeriesData.length > 0 ? timeSeriesData.length : 0)}</div>
              <div className="text-sm text-gray-600">Active Days</div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}