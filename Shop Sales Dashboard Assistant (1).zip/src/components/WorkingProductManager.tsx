import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Plus, Pill, ArrowLeft, Upload, RefreshCw } from 'lucide-react';
import { UserProfile, Product, FirebaseService } from '../lib/firebase';
import { ComprehensiveProductForm } from './ComprehensiveProductForm';
import { FileImportDialog } from './FileImportDialog';
import { useError } from '../contexts/ErrorContext';
import { toast } from 'sonner';

interface WorkingProductManagerProps {
  onBack: () => void;
  userProfile: UserProfile | null;
}

export function WorkingProductManager({ onBack, userProfile }: WorkingProductManagerProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddProductDialog, setShowAddProductDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);

  const { addError, addSuccess, clearErrorsByContext } = useError();

  useEffect(() => {
    loadProducts();
  }, [userProfile]);

  const loadProducts = async () => {
    setLoading(true);
    clearErrorsByContext('Product Loading');
    
    try {
      if (!userProfile?.shop_id) {
        setLoading(false);
        return;
      }

      console.log('🔄 Loading products for shop:', userProfile.shop_id);
      const loadedProducts = await FirebaseService.getProducts(userProfile.shop_id);
      
      const activeProducts = loadedProducts.filter(p => p.status !== 'deleted');
      setProducts(activeProducts);
      addSuccess(`Successfully loaded ${loadedProducts.length} products`, 'Product Loading');
      
    } catch (error) {
      console.error('❌ Error loading products:', error);
      addError(
        error, 
        'Product Loading',
        'Failed to load products from database.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleImportComplete = () => {
    setShowImportDialog(false);
    loadProducts();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="mx-auto h-12 w-12 text-blue-600 animate-spin mb-4" />
          <h2 className="text-xl font-semibold text-gray-900">Loading Products...</h2>
          <p className="text-gray-600">Please wait while we fetch your pharmacy inventory.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Button onClick={onBack} variant="outline" size="sm" className="mr-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
            <div>
              <div className="flex items-center">
                <Pill className="h-8 w-8 text-indigo-600 mr-2" />
                <h1 className="text-3xl font-bold text-gray-900">Product Management</h1>
              </div>
              {userProfile && (
                <p className="text-gray-600 mt-1">
                  {userProfile.shop?.name || 'Your Pharmacy'} • {products.length} products • TZS Currency
                </p>
              )}
            </div>
          </div>
          
          <div className="flex gap-2">
            {/* Add Product Button */}
            <Button 
              onClick={() => {
                setEditingProduct(null);
                setShowAddProductDialog(true);
              }}
              className="bg-indigo-600 hover:bg-indigo-700"
              disabled={!userProfile?.shop_id}
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Product
            </Button>
            
            {/* Import CSV Button */}
            <Button 
              onClick={() => {
                const allowedRoles = ['product_manager', 'owner', 'admin', 'super_admin'];
                const hasPermission = userProfile && allowedRoles.includes(userProfile.role);
                
                if (!hasPermission) {
                  toast.error('Permission Denied', {
                    description: `Your role (${userProfile?.role || 'unknown'}) doesn't have permission to import products. Required roles: ${allowedRoles.join(', ')}`,
                    duration: 8000
                  });
                  return;
                }
                setShowImportDialog(true);
              }}
              className="bg-purple-600 hover:bg-purple-700"
              disabled={!userProfile || !['product_manager', 'owner', 'admin', 'super_admin'].includes(userProfile.role)}
            >
              <Upload className="mr-2 h-4 w-4" />
              Import CSV
            </Button>
          </div>
        </div>

        {/* Product Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <h3 className="text-lg font-semibold text-gray-900">{products.length}</h3>
                <p className="text-sm text-gray-600">Total Products</p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <h3 className="text-lg font-semibold text-orange-600">
                  {products.filter(p => p.stock_quantity <= p.min_stock_level).length}
                </h3>
                <p className="text-sm text-gray-600">Low Stock</p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <h3 className="text-lg font-semibold text-red-600">
                  {products.filter(p => p.stock_quantity === 0).length}
                </h3>
                <p className="text-sm text-gray-600">Out of Stock</p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <h3 className="text-lg font-semibold text-green-600">
                  TZS {products.reduce((sum, p) => sum + (p.stock_quantity * p.cost_price), 0).toLocaleString()}
                </h3>
                <p className="text-sm text-gray-600">Total Value</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Product List */}
        <Card>
          <CardHeader>
            <CardTitle>Product Inventory</CardTitle>
          </CardHeader>
          <CardContent>
            {products.length === 0 ? (
              <div className="text-center py-12">
                <Pill className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No Products Yet</h3>
                <p className="text-gray-600 mb-4">Start by adding your first product or importing from a CSV file.</p>
                <div className="flex gap-2 justify-center">
                  <Button 
                    onClick={() => setShowAddProductDialog(true)}
                    className="bg-indigo-600 hover:bg-indigo-700"
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Add First Product
                  </Button>
                  <Button 
                    onClick={() => setShowImportDialog(true)}
                    variant="outline"
                  >
                    <Upload className="mr-2 h-4 w-4" />
                    Import CSV
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {products.slice(0, 10).map((product) => (
                  <div key={product.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h4 className="font-semibold">{product.name}</h4>
                      <p className="text-sm text-gray-600">SKU: {product.sku} • Stock: {product.stock_quantity}</p>
                      <p className="text-sm text-gray-500">
                        TZS {product.retail_price.toLocaleString()} • {product.category}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => {
                          setEditingProduct(product);
                          setShowAddProductDialog(true);
                        }}
                      >
                        Edit
                      </Button>
                    </div>
                  </div>
                ))}
                {products.length > 10 && (
                  <p className="text-center text-gray-500 py-4">
                    Showing 10 of {products.length} products
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Comprehensive Product Form Dialog */}
        <ComprehensiveProductForm
          open={showAddProductDialog}
          onOpenChange={setShowAddProductDialog}
          userProfile={userProfile}
          onProductAdded={loadProducts}
          editingProduct={editingProduct}
        />

        {/* File Import Dialog */}
        <FileImportDialog
          open={showImportDialog}
          onOpenChange={setShowImportDialog}
          userProfile={userProfile}
          onImportComplete={handleImportComplete}
        />
      </div>
    </div>
  );
}