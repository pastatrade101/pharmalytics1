import React, { useState } from 'react';
import { Alert, AlertDescription } from './ui/alert';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { 
  AlertTriangle, 
  ExternalLink, 
  Copy, 
  CheckCircle2,
  Clock,
  Database,
  Zap
} from 'lucide-react';
import { useError } from '../contexts/ErrorContext';

interface FirestoreIndexAlertProps {
  className?: string;
}

export function FirestoreIndexAlert({ className = '' }: FirestoreIndexAlertProps) {
  const { getIndexErrors, clearErrorsByType } = useError();
  const [copiedInstructions, setCopiedInstructions] = useState(false);
  
  const indexErrors = getIndexErrors();
  
  if (indexErrors.length === 0) {
    return null;
  }

  const extractIndexUrl = (errorMessage: string): string | null => {
    // More robust URL extraction to handle various formats
    const urlMatch = errorMessage.match(/https:\/\/console\.firebase\.google\.com[^\s\)"']*/);
    let indexUrl = urlMatch ? urlMatch[0] : null;
    
    // Clean up any trailing characters that might not be part of the URL
    if (indexUrl) {
      indexUrl = indexUrl.replace(/[,.]$/, ''); // Remove trailing comma or period
      console.log('🔧 Extracted index URL:', indexUrl);
    }
    
    return indexUrl;
  };

  const copyIndexInstructions = () => {
    const instructions = `
🔧 FIRESTORE INDEX SETUP INSTRUCTIONS

Your Shop Sales Dashboard needs database indexes to load analytics and reports efficiently.

QUICK FIXES:

${indexErrors.map((error, index) => {
  const indexUrl = extractIndexUrl(error.message);
  return `
${index + 1}. ${error.context} Index Error:
   Problem: ${error.userFriendlyMessage}
   ${indexUrl ? `Quick Fix: ${indexUrl}` : 'Fix: Create composite index in Firebase Console'}
   
   Manual Steps:
   - Go to Firebase Console → Firestore → Indexes
   - Click "Create Index"
   - Configure fields based on query requirements
   - Wait 2-3 minutes for deployment
`;
}).join('\n')}

After creating indexes:
- Refresh your Shop Sales Dashboard
- Analytics and reports will load instantly
- No more "failed-precondition" errors

Timestamp: ${new Date().toISOString()}
    `.trim();
    
    navigator.clipboard.writeText(instructions).then(() => {
      setCopiedInstructions(true);
      setTimeout(() => setCopiedInstructions(false), 3000);
    });
  };

  const openFirebaseConsole = () => {
    window.open('https://console.firebase.google.com/project/shopsalesai/firestore/indexes', '_blank');
  };

  const dismissIndexErrors = () => {
    clearErrorsByType('index');
  };

  // Get the most recent index error for primary display
  const primaryError = indexErrors[indexErrors.length - 1];
  const indexUrl = extractIndexUrl(primaryError.message);

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Primary Index Error Alert */}
      <Alert className="bg-yellow-50 border-yellow-300">
        <Database className="h-4 w-4 text-yellow-600" />
        <AlertDescription>
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <strong className="text-yellow-900">🔧 Database Index Required</strong>
              <div className="mt-1 text-sm text-yellow-800">
                Analytics and reports need Firestore indexes to load efficiently. 
                <strong> Click the quick fix link below to create the required index.</strong>
              </div>
              <div className="mt-2 text-xs text-yellow-700">
                Context: {primaryError.context} • {indexErrors.length} index error{indexErrors.length > 1 ? 's' : ''}
              </div>
            </div>
            <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
              {indexErrors.length} INDEX{indexErrors.length > 1 ? 'ES' : ''} NEEDED
            </Badge>
          </div>
        </AlertDescription>
      </Alert>

      {/* Detailed Index Fix Card */}
      <Card className="border-yellow-300 bg-yellow-50">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Database className="h-5 w-5 text-yellow-600" />
              <CardTitle className="text-yellow-900">Firestore Index Setup Required</CardTitle>
            </div>
            <Button onClick={dismissIndexErrors} variant="outline" size="sm" className="text-xs">
              Dismiss
            </Button>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Quick Fix Section */}
          {indexUrl && (
            <div className="bg-green-100 border border-green-300 rounded-lg p-4">
              <h4 className="font-semibold text-green-900 mb-2 flex items-center">
                <Zap className="h-4 w-4 mr-2" />
                ⚡ Quick Fix Available (1 minute)
              </h4>
              <p className="text-green-800 text-sm mb-3">
                Firebase generated a direct link to create the required index. This is the fastest way to fix the issue.
              </p>
              <div className="flex gap-2">
                <Button 
                  onClick={() => window.open(indexUrl, '_blank')}
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  <ExternalLink className="mr-2 h-4 w-4" />
                  🔧 Create Index (Auto-Generated Link)
                </Button>
              </div>
            </div>
          )}

          {/* Manual Instructions */}
          <div className="bg-blue-50 border border-blue-300 rounded-lg p-4">
            <h4 className="font-semibold text-blue-900 mb-2 flex items-center">
              <Clock className="h-4 w-4 mr-2" />
              Manual Setup (2-3 minutes)
            </h4>
            <div className="text-blue-800 text-sm space-y-2">
              <p><strong>If the auto-generated link doesn't work:</strong></p>
              <ol className="list-decimal list-inside ml-4 space-y-1">
                <li>Open Firebase Console → Firestore → Indexes</li>
                <li>Click "Create Index"</li>
                <li>Configure the composite index fields</li>
                <li>Click "Create" and wait 2-3 minutes</li>
                <li>Refresh your Shop Sales Dashboard</li>
              </ol>
            </div>
            <div className="flex gap-2 mt-3">
              <Button 
                onClick={openFirebaseConsole}
                variant="outline" 
                className="border-blue-300 text-blue-700"
              >
                <ExternalLink className="mr-2 h-4 w-4" />
                Open Firebase Console
              </Button>
              <Button 
                onClick={copyIndexInstructions}
                variant="outline" 
                className="border-blue-300 text-blue-700"
              >
                <Copy className="mr-2 h-4 w-4" />
                {copiedInstructions ? '✅ Copied!' : 'Copy Instructions'}
              </Button>
            </div>
          </div>

          {/* All Index Errors List */}
          {indexErrors.length > 1 && (
            <div className="bg-yellow-100 border border-yellow-300 rounded-lg p-4">
              <h4 className="font-semibold text-yellow-900 mb-2">All Index Errors ({indexErrors.length})</h4>
              <div className="space-y-2 text-xs">
                {indexErrors.map((error, index) => (
                  <div key={error.id} className="text-yellow-800 border-l-2 border-yellow-400 pl-2">
                    <div><strong>{index + 1}. {error.context}</strong></div>
                    <div className="text-yellow-700">{error.userFriendlyMessage}</div>
                    <div className="text-yellow-600">{new Date(error.timestamp).toLocaleTimeString()}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Expected Results */}
          <div className="bg-gray-50 border border-gray-300 rounded-lg p-4">
            <h4 className="font-semibold text-gray-900 mb-2">✅ After Index Creation:</h4>
            <div className="grid grid-cols-2 gap-2 text-sm text-gray-700">
              <div>✅ Analytics load instantly</div>
              <div>✅ Reports display properly</div>
              <div>✅ Owner dashboard functional</div>
              <div>✅ No more index errors</div>
              <div>✅ Fast database queries</div>
              <div>✅ Efficient data filtering</div>
            </div>
          </div>

          {/* Important Note */}
          <Alert className="bg-amber-50 border-amber-300">
            <AlertTriangle className="h-4 w-4 text-amber-600" />
            <AlertDescription className="text-amber-800 text-sm">
              <strong>Important:</strong> Index creation can take 2-3 minutes. Wait for "Ready" status 
              in Firebase Console before refreshing your app. Large datasets may take longer to index.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    </div>
  );
}