import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription } from './ui/alert';
import { Textarea } from './ui/textarea';
import { Checkbox } from './ui/checkbox';
import { Loader2, Stethoscope, Crown, AlertTriangle, Users, Building, Globe, Settings, RefreshCw, Mail, HelpCircle, Eye, EyeOff, Lock, User, ArrowRight, Store } from 'lucide-react';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, FirebaseService, auth } from '../lib/firebase';
import { updateProfile, sendEmailVerification } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase-config';
import { toast } from 'sonner';

interface AuthFormProps {
  onAuthSuccess: () => void;
}

interface AuthError {
  message: string;
  suggestions: string[];
  showRetry?: boolean;
  showPasswordReset?: boolean;
  showHelp?: boolean;
}

export function AuthForm({ onAuthSuccess }: AuthFormProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<AuthError | null>(null);
  const [activeTab, setActiveTab] = useState<'signin' | 'signup'>('signin');
  const [retryCount, setRetryCount] = useState(0);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Sign In Form
  const [signInData, setSignInData] = useState({
    email: '',
    password: ''
  });

  // Enhanced User Registration Form - Only for Pharmacy Owners
  const [signUpData, setSignUpData] = useState({
    // User Information
    email: '',
    password: '',
    confirmPassword: '',
    fullName: '',
    
    // Account Type - Fixed as 'owner' since only pharmacy owners can register
    accountType: 'owner' as const,
    
    // Pharmacy Information (required for all registrations)
    pharmacyName: '',
    pharmacyDescription: '',
    pharmacyAddress: '',
    pharmacyPhone: '',
    
    // Business Settings
    currency: 'TZS',
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    reportTime: '20:00',
    
    // Acknowledgment
    agreeToTerms: false
  });

  // Pharmacy system - category is fixed as 'pharmacy'
  const pharmacyCategory = 'pharmacy' as const;

  const currencies = [
    { code: 'TZS', name: 'Tanzanian Shilling (TSh)', symbol: 'TSh' },
    { code: 'USD', name: 'US Dollar ($)', symbol: '$' },
    { code: 'EUR', name: 'Euro (€)', symbol: '€' },
    { code: 'GBP', name: 'British Pound (£)', symbol: '£' },
    { code: 'CAD', name: 'Canadian Dollar (C$)', symbol: 'C$' },
    { code: 'AUD', name: 'Australian Dollar (A$)', symbol: 'A$' },
    { code: 'JPY', name: 'Japanese Yen (¥)', symbol: '¥' },
    { code: 'INR', name: 'Indian Rupee (₹)', symbol: '₹' },
    { code: 'BRL', name: 'Brazilian Real (R$)', symbol: 'R$' }
  ];

  const isConfigurationError = (error: Error) => {
    return error.message.includes('configuration') || 
           error.message.includes('environment variables') ||
           error.message.includes('NEXT_PUBLIC_FIREBASE');
  };

  const getAuthErrorDetails = (err: any): AuthError => {
    let errorMessage = 'Failed to sign in. Please try again.';
    let suggestions: string[] = [];
    let showRetry = true;
    let showPasswordReset = false;
    let showHelp = false;

    // Check if it's a configuration error
    if (isConfigurationError(err)) {
      return {
        message: 'Firebase is not properly configured. Please check your .env.local file and ensure all required environment variables are set.',
        suggestions: [
          'Verify NEXT_PUBLIC_FIREBASE_API_KEY is set',
          'Verify NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN is set', 
          'Verify NEXT_PUBLIC_FIREBASE_PROJECT_ID is set',
          'Check that all environment variables are spelled correctly'
        ],
        showRetry: false,
        showHelp: true
      };
    }

    // Handle specific Firebase errors with detailed suggestions
    switch (err.code) {
      case 'auth/user-not-found':
        errorMessage = 'No account found with this email address.';
        suggestions = [
          'Double-check your email address for typos',
          'Try creating a new account if you haven\'t registered yet',
          'Contact your pharmacy administrator if you should have an account'
        ];
        showPasswordReset = false;
        break;

      case 'auth/wrong-password':
        errorMessage = 'The password you entered is incorrect.';
        suggestions = [
          'Check that Caps Lock is not enabled',
          'Try typing your password again carefully',
          'Reset your password if you\'ve forgotten it'
        ];
        showPasswordReset = true;
        break;

      case 'auth/invalid-credential':
        errorMessage = 'The email or password you entered is incorrect.';
        suggestions = [
          'Double-check both your email and password',
          'Ensure you\'re using the correct email address',
          'Make sure your password is correct (check Caps Lock)',
          'Reset your password if you\'ve forgotten it'
        ];
        showPasswordReset = true;
        break;

      case 'auth/invalid-email':
        errorMessage = 'The email address format is not valid.';
        suggestions = [
          'Make sure your email contains @ and a domain (e.g., user@example.com)',
          'Remove any extra spaces before or after your email',
          'Use a valid email format'
        ];
        showPasswordReset = false;
        break;

      case 'auth/too-many-requests':
        errorMessage = 'Too many failed sign-in attempts. Your account has been temporarily locked.';
        suggestions = [
          'Wait 15-30 minutes before trying again',
          'Reset your password to unlock your account immediately',
          'Contact support if the issue persists'
        ];
        showPasswordReset = true;
        showRetry = false;
        break;

      case 'auth/network-request-failed':
        errorMessage = 'Network connection failed. Please check your internet connection.';
        suggestions = [
          'Check your internet connection',
          'Try refreshing the page',
          'Ensure you\'re not behind a firewall blocking Firebase',
          'Try again in a few moments'
        ];
        break;

      case 'auth/user-disabled':
        errorMessage = 'This account has been disabled by an administrator.';
        suggestions = [
          'Contact your pharmacy administrator',
          'Contact support for assistance',
          'This may be a temporary suspension'
        ];
        showRetry = false;
        showPasswordReset = false;
        break;

      default:
        errorMessage = 'Sign in failed. Please try again.';
        suggestions = [
          'Check your email and password',
          'Ensure you have a stable internet connection',
          'Try refreshing the page and signing in again',
          'Contact support if the problem persists'
        ];
        showHelp = true;
        break;
    }

    return {
      message: errorMessage,
      suggestions,
      showRetry,
      showPasswordReset,
      showHelp
    };
  };

  const handleRetry = () => {
    setError(null);
    setRetryCount(prev => prev + 1);
    // Automatically retry the sign in with the same credentials
    if (signInData.email && signInData.password) {
      handleSignIn(new Event('submit') as any);
    }
  };

  const handlePasswordReset = () => {
    if (signInData.email) {
      toast.info('Password Reset', {
        description: `If an account exists for ${signInData.email}, you will receive a password reset email shortly.`,
        duration: 8000,
        action: {
          label: 'Check Email',
          onClick: () => {
            // Open default email client
            window.location.href = 'mailto:';
          }
        }
      });
      
      // In a real implementation, you would call Firebase's password reset function
      console.log('Password reset requested for:', signInData.email);
      
      // Show success message
      setTimeout(() => {
        toast.success('Password reset email sent (if account exists)');
      }, 1000);
    } else {
      toast.error('Please enter your email address first');
    }
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      await signInWithEmailAndPassword(auth, signInData.email, signInData.password);
      setRetryCount(0); // Reset retry count on success
      toast.success('Welcome back! Successfully signed in.');
      onAuthSuccess();
    } catch (err: any) {
      console.error('Sign in error:', err);
      
      const errorDetails = getAuthErrorDetails(err);
      setError(errorDetails);
      
      // Show a toast for immediate feedback
      toast.error('Sign In Failed', {
        description: errorDetails.message,
        duration: 6000
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Helper function to wait for user document to be created
  const waitForUserDocument = async (userId: string, maxRetries = 10, delay = 1000): Promise<boolean> => {
    for (let i = 0; i < maxRetries; i++) {
      try {
        const userDoc = await getDoc(doc(db, 'users', userId));
        if (userDoc.exists()) {
          console.log(`✅ User document found on attempt ${i + 1}`);
          return true;
        }
        console.log(`⏳ User document not found, retrying in ${delay}ms... (attempt ${i + 1}/${maxRetries})`);
        await new Promise(resolve => setTimeout(resolve, delay));
      } catch (error) {
        console.warn(`⚠️ Error checking user document on attempt ${i + 1}:`, error);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
    return false;
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    // Enhanced Validation
    if (signUpData.password !== signUpData.confirmPassword) {
      setError({
        message: 'Passwords do not match',
        suggestions: ['Make sure both password fields contain the same password'],
        showRetry: false
      });
      setIsLoading(false);
      return;
    }

    if (signUpData.password.length < 6) {
      setError({
        message: 'Password must be at least 6 characters',
        suggestions: [
          'Choose a password with at least 6 characters',
          'Consider using a mix of letters, numbers, and symbols',
          'Make sure your password is secure but memorable'
        ],
        showRetry: false
      });
      setIsLoading(false);
      return;
    }

    if (!signUpData.fullName.trim()) {
      setError({
        message: 'Full name is required',
        suggestions: ['Please enter your full name as it should appear in the system'],
        showRetry: false
      });
      setIsLoading(false);
      return;
    }

    // Pharmacy name is always required since we only allow pharmacy owners
    if (!signUpData.pharmacyName.trim()) {
      setError({
        message: 'Pharmacy name is required',
        suggestions: ['Please enter your pharmacy name as it should appear in the system'],
        showRetry: false
      });
      setIsLoading(false);
      return;
    }

    if (!signUpData.agreeToTerms) {
      setError({
        message: 'You must agree to the terms and conditions',
        suggestions: ['Please read and accept the terms and conditions to continue'],
        showRetry: false
      });
      setIsLoading(false);
      return;
    }

    try {
      console.log('🔄 Starting pharmacy owner signup process...');
      
      // Step 1: Create Firebase Auth user
      const userCredential = await createUserWithEmailAndPassword(
        auth,
        signUpData.email,
        signUpData.password
      );
      
      const user = userCredential.user;
      console.log('✅ Firebase Auth user created:', user.uid);

      if (user) {
        // Step 2: Update display name
        await updateProfile(user, {
          displayName: signUpData.fullName
        });
        console.log('✅ User display name updated');

        // Step 3: Create user profile as pharmacy owner
        console.log('🔄 Creating pharmacy owner profile in Firestore...');
        const userProfile = await FirebaseService.createUserProfile({
          uid: user.uid,
          email: signUpData.email,
          full_name: signUpData.fullName,
          role: 'owner'
        });
        console.log('✅ Pharmacy owner profile created in Firestore');

        // Step 4: Wait for user document to be available
        console.log('⏳ Waiting for user document to be available...');
        const userDocExists = await waitForUserDocument(user.uid);
        if (!userDocExists) {
          console.warn('⚠️ User document not found after retries, but continuing...');
        }

        // Step 5: Create pharmacy for the owner
        console.log('🔄 Creating pharmacy for owner...');
        const pharmacy = await FirebaseService.createShop({
          name: signUpData.pharmacyName,
          owner_id: user.uid,
          description: signUpData.pharmacyDescription || `${signUpData.pharmacyName} - Pharmacy Management System`,
          category: pharmacyCategory,
          address: signUpData.pharmacyAddress,
          phone: signUpData.pharmacyPhone,
          settings: {
            timezone: signUpData.timezone,
            currency: signUpData.currency,
            report_time: signUpData.reportTime
          }
        });
        console.log('✅ Pharmacy created successfully:', pharmacy.id);

        // Step 6: Update user profile with shop assignment
        console.log('🔄 Assigning owner to pharmacy...');
        try {
          await FirebaseService.updateUserProfileWithShop(user.uid, pharmacy.id);
          console.log('✅ Owner assigned to pharmacy:', pharmacy.id);
        } catch (assignError: any) {
          console.error('❌ Error assigning owner to pharmacy:', assignError);
          // Continue anyway - the shop was created successfully
          // Fallback: try the old method
          try {
            await FirebaseService.assignUserToShop(user.uid, pharmacy.id);
            console.log('✅ Owner assigned via fallback method');
          } catch (fallbackError) {
            console.error('❌ Fallback assignment also failed:', fallbackError);
          }
        }

        // Step 7: Send email verification (with enhanced error handling)
        try {
          await sendEmailVerification(user);
          console.log('📧 Email verification sent to:', signUpData.email);
          
          toast.success('📧 Verification email sent!', {
            description: 'Please check your email to verify your account before proceeding.'
          });
        } catch (verificationError: any) {
          console.error('Error sending verification email:', verificationError);
          
          if (verificationError.code === 'auth/too-many-requests') {
            toast.warning('⚠️ Email verification delayed', {
              description: 'Account created successfully, but verification email was rate limited. You can request it again from the verification screen.'
            });
          } else {
            toast.warning('⚠️ Verification email issue', {
              description: 'Account created, but there was an issue sending the verification email. You can request it again from the verification screen.'
            });
          }
        }

        // Success message
        toast.success(`Pharmacy "${signUpData.pharmacyName}" created successfully!`, {
          description: 'Please verify your email to complete the setup.'
        });
        
        console.log('✅ Pharmacy owner signup process completed successfully');
        onAuthSuccess();
      }
    } catch (err: any) {
      console.error('Sign up error:', err);
      
      // Check if it's a specific Firestore validation error
      if (err.code === 'invalid-argument' && err.message.includes('Unsupported field value: undefined')) {
        setError({
          message: 'Account creation failed due to data validation error.',
          suggestions: [
            'Please try again with all required fields filled',
            'Make sure your internet connection is stable',
            'Contact support if the problem persists'
          ],
          showRetry: true
        });
      } else {
        const errorDetails = getAuthErrorDetails(err);
        
        // Override with sign-up specific messages
        if (err.code === 'auth/email-already-in-use') {
          errorDetails.message = 'An account with this email already exists.';
          errorDetails.suggestions = [
            'Try signing in instead of creating a new account',
            'Use a different email address',
            'Reset your password if you\'ve forgotten it'
          ];
          errorDetails.showPasswordReset = true;
        } else if (err.code === 'auth/weak-password') {
          errorDetails.message = 'Password is too weak. Please choose a stronger password.';
          errorDetails.suggestions = [
            'Use at least 8 characters',
            'Include uppercase and lowercase letters',
            'Add numbers and special characters',
            'Avoid common words or patterns'
          ];
          errorDetails.showRetry = false;
        }
        
        setError(errorDetails);
      }
      
      // Show a toast for immediate feedback
      toast.error('Account Creation Failed', {
        description: error?.message || 'Please try again.',
        duration: 6000
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto space-y-6">
      {/* Auth Mode Toggle */}
      <div className="flex rounded-xl bg-slate-100 p-1">
        <button
          onClick={() => setActiveTab('signin')}
          className={`flex-1 rounded-lg px-4 py-2.5 text-sm font-medium transition-all duration-200 ${
            activeTab === 'signin'
              ? 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Lock className="h-4 w-4 inline mr-2" />
          Sign In
        </button>
        <button
          onClick={() => setActiveTab('signup')}
          className={`flex-1 rounded-lg px-4 py-2.5 text-sm font-medium transition-all duration-200 ${
            activeTab === 'signup'
              ? 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <User className="h-4 w-4 inline mr-2" />
          Create Pharmacy
        </button>
      </div>

      {/* Error Display */}
      {error && (
        <Alert className="border-red-200 bg-red-50">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            <div className="space-y-3">
              <p className="font-medium">{error.message}</p>
              
              {error.suggestions.length > 0 && (
                <div>
                  <p className="text-sm font-medium mb-2">What to try:</p>
                  <ul className="text-sm space-y-1">
                    {error.suggestions.map((suggestion, index) => (
                      <li key={index} className="flex items-start">
                        <span className="mr-2">•</span>
                        <span>{suggestion}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              
              <div className="flex flex-wrap gap-2 pt-2">
                {error.showRetry && (
                  <Button
                    onClick={handleRetry}
                    size="sm"
                    variant="outline"
                    className="text-xs border-red-300 text-red-700 hover:bg-red-100"
                    disabled={isLoading}
                  >
                    <RefreshCw className="h-3 w-3 mr-1" />
                    Try Again {retryCount > 0 && `(${retryCount})`}
                  </Button>
                )}
                
                {error.showPasswordReset && (
                  <Button
                    onClick={handlePasswordReset}
                    size="sm"
                    variant="outline"
                    className="text-xs border-red-300 text-red-700 hover:bg-red-100"
                  >
                    <Mail className="h-3 w-3 mr-1" />
                    Reset Password
                  </Button>
                )}
                
                {error.showHelp && (
                  <Button
                    onClick={() => {
                      toast.info('Help & Support', {
                        description: 'For technical assistance, please contact your system administrator or check the setup documentation.',
                        duration: 8000
                      });
                    }}
                    size="sm"
                    variant="outline"
                    className="text-xs border-red-300 text-red-700 hover:bg-red-100"
                  >
                    <HelpCircle className="h-3 w-3 mr-1" />
                    Get Help
                  </Button>
                )}
              </div>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Sign In Form */}
      {activeTab === 'signin' && (
        <form onSubmit={handleSignIn} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="signin-email" className="text-sm font-medium text-slate-700">
              Email Address
            </Label>
            <div className="relative">
              <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
              <Input
                id="signin-email"
                type="email"
                placeholder="Enter your email"
                value={signInData.email}
                onChange={(e) => setSignInData({ ...signInData, email: e.target.value })}
                required
                className={`pl-10 h-12 bg-white border-slate-200 focus:border-blue-500 focus:ring-blue-500 ${
                  error?.message.includes('email') ? 'border-red-300 focus:border-red-500' : ''
                }`}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="signin-password" className="text-sm font-medium text-slate-700">
              Password
            </Label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
              <Input
                id="signin-password"
                type={showPassword ? 'text' : 'password'}
                placeholder="Enter your password"
                value={signInData.password}
                onChange={(e) => setSignInData({ ...signInData, password: e.target.value })}
                required
                className={`pl-10 pr-10 h-12 bg-white border-slate-200 focus:border-blue-500 focus:ring-blue-500 ${
                  error?.message.includes('password') ? 'border-red-300 focus:border-red-500' : ''
                }`}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3 h-4 w-4 text-slate-400 hover:text-slate-600"
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <Button 
            type="submit" 
            className="w-full h-12 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-medium shadow-lg hover:shadow-xl transition-all duration-200" 
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Signing you in...
              </>
            ) : (
              <>
                Sign In
                <ArrowRight className="ml-2 h-4 w-4" />
              </>
            )}
          </Button>

          <div className="text-center">
            <button
              type="button"
              onClick={handlePasswordReset}
              className="text-sm text-blue-600 hover:text-blue-700 hover:underline font-medium"
              disabled={!signInData.email}
            >
              Forgot your password?
            </button>
          </div>
        </form>
      )}

      {/* Sign Up Form - Pharmacy Owner Only */}
      {activeTab === 'signup' && (
        <div className="space-y-6">
          {/* Pharmacy Owner Info */}
          <Alert className="bg-blue-50 border-blue-200">
            <Store className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-800">
              <strong>Create your pharmacy business:</strong> Register as a pharmacy owner to create and manage your own pharmacy with full administrative capabilities.
            </AlertDescription>
          </Alert>

          <form onSubmit={handleSignUp} className="space-y-6">
            {/* Personal Information */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b border-slate-200">
                <User className="h-5 w-5 text-blue-600" />
                <h3 className="font-medium text-slate-900">Personal Information</h3>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="signup-fullname" className="text-sm font-medium text-slate-700">
                    Full Name
                  </Label>
                  <Input
                    id="signup-fullname"
                    placeholder="Enter your full name"
                    value={signUpData.fullName}
                    onChange={(e) => setSignUpData({ ...signUpData, fullName: e.target.value })}
                    required
                    className="h-12 bg-white border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="signup-email" className="text-sm font-medium text-slate-700">
                    Email Address
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                    <Input
                      id="signup-email"
                      type="email"
                      placeholder="Enter your email"
                      value={signUpData.email}
                      onChange={(e) => setSignUpData({ ...signUpData, email: e.target.value })}
                      required
                      className="pl-10 h-12 bg-white border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="signup-password" className="text-sm font-medium text-slate-700">
                      Password
                    </Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                      <Input
                        id="signup-password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Choose a password"
                        value={signUpData.password}
                        onChange={(e) => setSignUpData({ ...signUpData, password: e.target.value })}
                        required
                        className="pl-10 pr-10 h-12 bg-white border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-3 h-4 w-4 text-slate-400 hover:text-slate-600"
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="signup-confirm-password" className="text-sm font-medium text-slate-700">
                      Confirm Password
                    </Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                      <Input
                        id="signup-confirm-password"
                        type={showConfirmPassword ? 'text' : 'password'}
                        placeholder="Confirm your password"
                        value={signUpData.confirmPassword}
                        onChange={(e) => setSignUpData({ ...signUpData, confirmPassword: e.target.value })}
                        required
                        className="pl-10 pr-10 h-12 bg-white border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute right-3 top-3 h-4 w-4 text-slate-400 hover:text-slate-600"
                      >
                        {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Pharmacy Information */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b border-slate-200">
                <Building className="h-5 w-5 text-blue-600" />
                <h3 className="font-medium text-slate-900">Pharmacy Information</h3>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="pharmacy-name" className="text-sm font-medium text-slate-700">
                    Pharmacy Name *
                  </Label>
                  <Input
                    id="pharmacy-name"
                    placeholder="Enter your pharmacy name"
                    value={signUpData.pharmacyName}
                    onChange={(e) => setSignUpData({ ...signUpData, pharmacyName: e.target.value })}
                    required
                    className="h-12 bg-white border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="pharmacy-description" className="text-sm font-medium text-slate-700">
                    Description (Optional)
                  </Label>
                  <Textarea
                    id="pharmacy-description"
                    placeholder="Brief description of your pharmacy"
                    value={signUpData.pharmacyDescription}
                    onChange={(e) => setSignUpData({ ...signUpData, pharmacyDescription: e.target.value })}
                    className="resize-none bg-white border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="pharmacy-address" className="text-sm font-medium text-slate-700">
                    Address
                  </Label>
                  <Input
                    id="pharmacy-address"
                    placeholder="Enter pharmacy address"
                    value={signUpData.pharmacyAddress}
                    onChange={(e) => setSignUpData({ ...signUpData, pharmacyAddress: e.target.value })}
                    className="h-12 bg-white border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="pharmacy-phone" className="text-sm font-medium text-slate-700">
                    Phone Number
                  </Label>
                  <Input
                    id="pharmacy-phone"
                    placeholder="Enter pharmacy phone number"
                    value={signUpData.pharmacyPhone}
                    onChange={(e) => setSignUpData({ ...signUpData, pharmacyPhone: e.target.value })}
                    className="h-12 bg-white border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Business Settings */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b border-slate-200">
                <Settings className="h-5 w-5 text-blue-600" />
                <h3 className="font-medium text-slate-900">Business Settings</h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="currency" className="text-sm font-medium text-slate-700">
                    Currency
                  </Label>
                  <Select
                    value={signUpData.currency}
                    onValueChange={(value) => setSignUpData({ ...signUpData, currency: value })}
                  >
                    <SelectTrigger className="h-12 bg-white border-slate-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {currencies.map((currency) => (
                        <SelectItem key={currency.code} value={currency.code}>
                          {currency.symbol} - {currency.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="report-time" className="text-sm font-medium text-slate-700">
                    Daily Report Time
                  </Label>
                  <Input
                    id="report-time"
                    type="time"
                    value={signUpData.reportTime}
                    onChange={(e) => setSignUpData({ ...signUpData, reportTime: e.target.value })}
                    className="h-12 bg-white border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Terms and Conditions */}
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <Checkbox
                  id="agree-terms"
                  checked={signUpData.agreeToTerms}
                  onCheckedChange={(checked) => setSignUpData({ ...signUpData, agreeToTerms: checked as boolean })}
                  className="mt-1"
                />
                <div className="space-y-1">
                  <Label htmlFor="agree-terms" className="text-sm font-medium text-slate-700 cursor-pointer">
                    I agree to the Terms of Service and Privacy Policy
                  </Label>
                  <p className="text-xs text-slate-500">
                    By creating an account, you accept our terms and conditions.
                  </p>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <Button 
              type="submit" 
              className="w-full h-12 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-medium shadow-lg hover:shadow-xl transition-all duration-200" 
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating your pharmacy...
                </>
              ) : (
                <>
                  <Store className="mr-2 h-4 w-4" />
                  Create Pharmacy & Owner Account
                  <ArrowRight className="ml-2 h-4 w-4" />
                </>
              )}
            </Button>
          </form>
        </div>
      )}
    </div>
  );
}