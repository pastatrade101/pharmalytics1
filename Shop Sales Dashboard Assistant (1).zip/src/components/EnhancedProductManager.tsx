import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { 
  Plus, 
  Package, 
  Edit, 
  Trash2, 
  Search, 
  ArrowLeft, 
  Save, 
  X, 
  AlertTriangle,
  ImagePlus,
  Zap,
  TrendingUp,
  BarChart3,
  Calculator,
  CheckCircle,
  ChevronRight,
  ShoppingCart,
  DollarSign,
  Package2,
  AlertCircle,
  Upload,
  Download,
  FileSpreadsheet,
  FileText,
  CheckSquare,
  XCircle,
  RefreshCw,
  Info,
  Wrench
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { UserProfile, Product, FirebaseService } from '../lib/firebase';
import { useError } from '../contexts/ErrorContext';
import { ErrorDisplay } from './ErrorDisplay';
import { ProductDataMigration } from './ProductDataMigration';

interface EnhancedProductManagerProps {
  onBack: () => void;
  userProfile: UserProfile | null;
}

// Pharmacy-specific categories with medical descriptions
const PRODUCT_CATEGORIES = [
  { id: 'prescription', name: 'Prescription Medicines', description: 'Prescription-only medicines (POM)', icon: '💊' },
  { id: 'otc', name: 'Over-the-Counter', description: 'Non-prescription medicines', icon: '🏥' },
  { id: 'painkillers', name: 'Pain Relief', description: 'Analgesics, NSAIDs, pain management', icon: '🎯' },
  { id: 'antibiotics', name: 'Antibiotics', description: 'Antimicrobial medicines', icon: '🦠' },
  { id: 'vitamins', name: 'Vitamins & Supplements', description: 'Nutritional supplements, multivitamins', icon: '🌟' },
  { id: 'cold_flu', name: 'Cold & Flu', description: 'Cough syrups, decongestants, throat lozenges', icon: '🤧' },
  { id: 'digestive', name: 'Digestive Health', description: 'Antacids, laxatives, probiotics', icon: '🫁' },
  { id: 'skincare', name: 'Dermatological', description: 'Topical creams, ointments, skin treatments', icon: '🧴' },
  { id: 'baby_care', name: 'Baby & Child Care', description: 'Pediatric medicines, baby care products', icon: '🍼' },
  { id: 'medical_devices', name: 'Medical Devices', description: 'Thermometers, blood pressure monitors, glucose meters', icon: '🩺' },
  { id: 'first_aid', name: 'First Aid', description: 'Bandages, antiseptics, wound care', icon: '🩹' },
  { id: 'personal_care', name: 'Personal Care', description: 'Hygiene products, contraceptives', icon: '🧼' }
];

// Pharmacy-specific pricing templates with realistic margins
const PRICING_TEMPLATES = [
  { name: 'Generic Medicine', markup: 25, description: '25% markup - Standard for generic drugs' },
  { name: 'Branded Medicine', markup: 40, description: '40% markup - Branded pharmaceuticals' },
  { name: 'OTC Products', markup: 35, description: '35% markup - Over-the-counter items' },
  { name: 'Supplements', markup: 50, description: '50% markup - Vitamins and supplements' },
  { name: 'Medical Devices', markup: 30, description: '30% markup - Thermometers, monitors' },
  { name: 'Personal Care', markup: 45, description: '45% markup - Hygiene and care products' }
];

// Form steps for multi-step creation
const FORM_STEPS = [
  { id: 'basic', title: 'Basic Information', icon: Package },
  { id: 'pricing', title: 'Pricing & Costs', icon: DollarSign },
  { id: 'inventory', title: 'Inventory Details', icon: Package2 },
  { id: 'review', title: 'Review & Save', icon: CheckCircle }
];

export function EnhancedProductManager({ onBack, userProfile }: EnhancedProductManagerProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [loading, setLoading] = useState(true);
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [quickAddMode, setQuickAddMode] = useState(false);

  // Import-related states
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importPreviewData, setImportPreviewData] = useState<any[]>([]);
  const [importProgress, setImportProgress] = useState(0);
  const [importing, setImporting] = useState(false);
  const [importResults, setImportResults] = useState<{
    successful: number;
    failed: number;
    errors: string[];
  }>({ successful: 0, failed: 0, errors: [] });
  const [importStep, setImportStep] = useState<'select' | 'preview' | 'importing' | 'results'>('select');

  const { 
    addError, 
    addSuccess, 
    addWarning, 
    clearErrorsByContext, 
    hasErrorsInContext,
    getErrorsByContext 
  } = useError();

  // Enhanced form state with better organization
  const [productForm, setProductForm] = useState({
    // Basic Information
    name: '',
    description: '',
    category: 'otc',
    sku: '',
    status: 'active' as const,
    
    // Pricing & Costs (in TZS)
    cost: '',
    price: '',
    useTemplate: false,
    selectedTemplate: '',
    
    // Inventory
    stock_quantity: '',
    min_stock_level: '',
    max_stock_level: '',
    reorder_point: '',
    
    // Additional fields
    barcode: '',
    supplier: '',
    notes: ''
  });

  useEffect(() => {
    loadProducts();
  }, [userProfile]);

  const loadProducts = async () => {
    setLoading(true);
    clearErrorsByContext('Product Loading');
    
    try {
      console.log('🔄 Loading products for current user...');
      
      // Use the new helper function that handles shop ID automatically
      const loadedProducts = await FirebaseService.getProductsForCurrentUser();
      
      // Filter out deleted products
      const activeProducts = loadedProducts.filter(p => p.status !== 'deleted');
      setProducts(activeProducts);
      addSuccess(`Successfully loaded ${loadedProducts.length} products`, 'Product Loading');
      console.log('✅ Products loaded successfully:', loadedProducts.length);
      
    } catch (error: any) {
      console.error('❌ Error loading products:', error);
      
      if (error.message?.includes('No pharmacy associated')) {
        addWarning('No pharmacy associated with your account', 'Product Loading');
      } else {
        addError(
          error, 
          'Product Loading',
          'Failed to load products from database. Please check your connection and Firebase rules.'
        );
      }
    } finally {
      setLoading(false);
    }
  };

  // Enhanced product creation with validation
  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitting(true);
    clearErrorsByContext('Product Creation');
    
    try {
      // The createProduct function will now handle shop_id automatically

      // Validate form before proceeding
      const validationErrors = validateProductForm();
      if (validationErrors.length > 0) {
        console.log('❌ Validation errors:', validationErrors);
        validationErrors.forEach(error => {
          addError(new Error(error), 'Product Creation', error);
        });
        setFormSubmitting(false);
        return;
      }

      // Ensure we have all required data before submitting
      const trimmedName = productForm.name.trim();
      const trimmedSku = productForm.sku.trim();
      const trimmedDescription = productForm.description.trim();

      if (!trimmedName || !trimmedSku) {
        addError(new Error('Missing required fields'), 'Product Creation', 'Product name and SKU are required');
        setFormSubmitting(false);
        return;
      }

      console.log('🔄 Creating new product:', {
        name: trimmedName,
        sku: trimmedSku,
        price: parseFloat(productForm.price),
        cost: parseFloat(productForm.cost)
      });

      const newProduct = await FirebaseService.createProduct({
        name: trimmedName,
        description: trimmedDescription,
        price: parseFloat(productForm.price),
        cost: parseFloat(productForm.cost),
        category: productForm.category,
        stock_quantity: parseInt(productForm.stock_quantity),
        min_stock_level: parseInt(productForm.min_stock_level),
        sku: trimmedSku,
        status: productForm.status
        // shop_id will be added automatically by FirebaseService.createProduct
      });

      console.log('✅ Product created successfully:', newProduct);

      setProducts(prev => [newProduct, ...prev]);
      resetProductForm();
      setIsAddingProduct(false);
      setCurrentStep(0);
      
      addSuccess(`Product "${newProduct.name}" added successfully`, 'Product Creation');
      
    } catch (error) {
      console.error('❌ Error adding product:', error);
      addError(
        error, 
        'Product Creation',
        `Failed to add product "${productForm.name || 'Unknown'}". Please check your data and try again.`
      );
    } finally {
      setFormSubmitting(false);
    }
  };

  // Handle editing existing product
  const handleEditProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;
    
    setFormSubmitting(true);
    clearErrorsByContext('Product Edit');
    
    try {
      if (!userProfile?.shop_id) {
        addError(new Error('No shop ID'), 'Product Edit', 'No shop associated with your account');
        setFormSubmitting(false);
        return;
      }

      // Validate form before proceeding
      const validationErrors = validateProductForm();
      if (validationErrors.length > 0) {
        console.log('❌ Edit validation errors:', validationErrors);
        validationErrors.forEach(error => {
          addError(new Error(error), 'Product Edit', error);
        });
        setFormSubmitting(false);
        return;
      }

      // Ensure we have all required data before submitting
      const trimmedName = productForm.name.trim();
      const trimmedSku = productForm.sku.trim();
      const trimmedDescription = productForm.description.trim();

      if (!trimmedName || !trimmedSku) {
        addError(new Error('Missing required fields'), 'Product Edit', 'Product name and SKU are required');
        setFormSubmitting(false);
        return;
      }

      console.log('🔄 Updating product:', editingProduct.id, {
        name: trimmedName,
        sku: trimmedSku,
        price: parseFloat(productForm.price),
        cost: parseFloat(productForm.cost)
      });

      const updatedProduct = await FirebaseService.updateProduct(editingProduct.id, {
        name: trimmedName,
        description: trimmedDescription,
        price: parseFloat(productForm.price),
        cost: parseFloat(productForm.cost),
        category: productForm.category,
        stock_quantity: parseInt(productForm.stock_quantity),
        min_stock_level: parseInt(productForm.min_stock_level),
        sku: trimmedSku,
        status: productForm.status
      });

      console.log('✅ Product updated successfully:', updatedProduct);

      // Update the products list
      setProducts(prev => prev.map(p => p.id === editingProduct.id ? updatedProduct : p));
      
      // Reset form and close edit mode
      resetProductForm();
      setEditingProduct(null);
      
      addSuccess(`Product "${updatedProduct.name}" updated successfully`, 'Product Edit');
      
    } catch (error) {
      console.error('❌ Error updating product:', error);
      addError(
        error, 
        'Product Edit',
        `Failed to update product "${productForm.name || 'Unknown'}". Please check your data and try again.`
      );
    } finally {
      setFormSubmitting(false);
    }
  };

  // Start editing a product
  const startEditingProduct = (product: Product) => {
    console.log('🔄 Starting to edit product:', product.id, product.name);
    
    setEditingProduct(product);
    setProductForm({
      name: product.name,
      description: product.description || '',
      category: product.category,
      sku: product.sku,
      status: product.status,
      cost: product.cost?.toString() || '',
      price: product.price.toString(),
      useTemplate: false,
      selectedTemplate: '',
      stock_quantity: product.stock_quantity?.toString() || '0',
      min_stock_level: product.min_stock_level?.toString() || '0',
      max_stock_level: '',
      reorder_point: '',
      barcode: '',
      supplier: '',
      notes: ''
    });
    
    clearErrorsByContext('Product Edit');
    setCurrentStep(0);
    setQuickAddMode(true); // Use quick mode for editing
    
    toast.success(`Editing product: ${product.name}`);
  };

  // Cancel editing
  const cancelEdit = () => {
    console.log('❌ Cancelling product edit');
    setEditingProduct(null);
    resetProductForm();
    clearErrorsByContext('Product Edit');
    toast.info('Edit cancelled');
  };

  // Delete product
  const handleDeleteProduct = async (product: Product) => {
    if (!confirm(`Are you sure you want to delete "${product.name}"? This action cannot be undone.`)) {
      return;
    }

    try {
      console.log('🗑️ Deleting product:', product.id, product.name);
      await FirebaseService.hardDeleteProduct(product.id);
      
      setProducts(prev => prev.filter(p => p.id !== product.id));
      addSuccess(`Product "${product.name}" deleted successfully`, 'Product Management');
      
      console.log('✅ Product deleted successfully');
    } catch (error) {
      console.error('❌ Error deleting product:', error);
      addError(
        error,
        'Product Management',
        `Failed to delete product "${product.name}". Please try again.`
      );
    }
  };

  const validateProductForm = (): string[] => {
    const errors: string[] = [];
    
    // Basic validation with trimming
    const trimmedName = productForm.name?.trim() || '';
    const trimmedSku = productForm.sku?.trim() || '';
    const priceValue = productForm.price ? parseFloat(productForm.price) : 0;
    const costValue = productForm.cost ? parseFloat(productForm.cost) : 0;
    const stockValue = productForm.stock_quantity ? parseInt(productForm.stock_quantity) : 0;
    const minStockValue = productForm.min_stock_level ? parseInt(productForm.min_stock_level) : 0;
    
    if (!trimmedName) {
      errors.push('Product name is required');
    }
    
    if (!trimmedSku) {
      errors.push('SKU is required');
    }
    
    if (!productForm.price || isNaN(priceValue) || priceValue <= 0) {
      errors.push('Valid selling price is required');
    }
    
    if (!productForm.cost || isNaN(costValue) || costValue < 0) {
      errors.push('Valid cost price is required');
    }
    
    if (!productForm.stock_quantity || isNaN(stockValue) || stockValue < 0) {
      errors.push('Valid stock quantity is required');
    }
    
    if (!productForm.min_stock_level || isNaN(minStockValue) || minStockValue < 0) {
      errors.push('Valid minimum stock level is required');
    }
    
    // Only validate price vs cost if both are valid numbers
    if (!isNaN(priceValue) && !isNaN(costValue) && priceValue <= costValue) {
      errors.push('Selling price must be higher than cost price');
    }

    // Check for duplicate SKU only if SKU is not empty
    if (trimmedSku) {
      const existingSKU = products.find(p => 
        p.sku.toLowerCase() === trimmedSku.toLowerCase() && 
        p.id !== editingProduct?.id
      );
      if (existingSKU) {
        errors.push(`SKU "${trimmedSku}" already exists`);
      }
    }
    
    return errors;
  };

  const resetProductForm = () => {
    setProductForm({
      name: '',
      description: '',
      category: 'otc',
      sku: '',
      status: 'active',
      cost: '',
      price: '',
      useTemplate: false,
      selectedTemplate: '',
      stock_quantity: '',
      min_stock_level: '',
      max_stock_level: '',
      reorder_point: '',
      barcode: '',
      supplier: '',
      notes: ''
    });
    // Clear any validation errors when resetting
    clearErrorsByContext('Product Creation');
    clearErrorsByContext('Product Edit');
  };

  // Apply pricing template
  const applyPricingTemplate = (template: any) => {
    if (productForm.cost) {
      const costValue = parseFloat(productForm.cost);
      const newPrice = costValue + (costValue * template.markup / 100);
      setProductForm(prev => ({
        ...prev,
        price: newPrice.toFixed(0), // Round to nearest TZS
        selectedTemplate: template.name
      }));
      toast.success(`Applied ${template.name} pricing template`);
    }
  };

  // Generate SKU automatically
  const generateSKU = () => {
    const category = PRODUCT_CATEGORIES.find(c => c.id === productForm.category);
    const categoryCode = category?.name.substring(0, 3).toUpperCase() || 'PRD';
    const timestamp = Date.now().toString().slice(-4);
    const randomNum = Math.floor(Math.random() * 100).toString().padStart(2, '0');
    
    const newSKU = `${categoryCode}-${timestamp}${randomNum}`;
    setProductForm(prev => ({ ...prev, sku: newSKU }));
    toast.success('SKU generated automatically');
  };

  // Calculate profit metrics
  const getProfitMetrics = () => {
    const cost = parseFloat(productForm.cost) || 0;
    const price = parseFloat(productForm.price) || 0;
    
    const profit = price - cost;
    const margin = price > 0 ? (profit / price) * 100 : 0;
    const markup = cost > 0 ? (profit / cost) * 100 : 0;
    
    return { profit, margin, markup };
  };

  // Filter products
  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.sku.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Get categories with counts
  const categoriesWithCounts = PRODUCT_CATEGORIES.map(category => ({
    ...category,
    count: products.filter(p => p.category === category.id).length
  }));

  const hasLoadingErrors = hasErrorsInContext('Product Loading');
  const hasCreationErrors = hasErrorsInContext('Product Creation');
  const hasEditErrors = hasErrorsInContext('Product Edit');

  // Format TZS currency
  const formatTZS = (amount: number) => {
    return new Intl.NumberFormat('sw-TZ', {
      style: 'currency',
      currency: 'TZS',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  // File import handlers
  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    console.log('🔄 File selection started');
    const file = event.target.files?.[0];
    if (!file) {
      console.log('��� No file selected');
      return;
    }

    console.log('📁 File selected:', {
      name: file.name,
      type: file.type,
      size: file.size
    });

    const allowedTypes = [
      'text/csv',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/json'
    ];

    if (!allowedTypes.includes(file.type)) {
      console.log('❌ Invalid file type:', file.type);
      addError(
        new Error('Invalid file type'),
        'File Import',
        'Please select a CSV, Excel, or JSON file'
      );
      return;
    }

    setImportFile(file);
    
    try {
      console.log('🔄 Starting file parsing...');
      const previewData = await parseImportFile(file);
      console.log('✅ File parsed successfully. Products found:', previewData.length);
      setImportPreviewData(previewData);
      setImportStep('preview');
    } catch (error) {
      console.error('❌ Error parsing file:', error);
      addError(error, 'File Import', 'Failed to parse the selected file');
    }
  };

  const parseImportFile = async (file: File): Promise<any[]> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const content = e.target?.result as string;
          let data: any[] = [];

          if (file.type === 'application/json') {
            const jsonData = JSON.parse(content);
            data = Array.isArray(jsonData) ? jsonData : [jsonData];
          } else if (file.type === 'text/csv' || file.name.endsWith('.csv')) {
            data = parseCSV(content);
          } else {
            reject(new Error('Excel files require a specialized parser. Please convert to CSV format.'));
            return;
          }

          const normalizedData = data.map((item, index) => {
            return normalizeImportData(item, index);
          });

          resolve(normalizedData.filter(item => item !== null));
        } catch (error) {
          reject(error);
        }
      };

      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsText(file);
    });
  };

  const parseCSV = (content: string): any[] => {
    const lines = content.trim().split('\n');
    if (lines.length < 2) return [];

    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    const data: any[] = [];

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
      if (values.length !== headers.length) continue;

      const row: any = {};
      headers.forEach((header, index) => {
        row[header.toLowerCase().replace(/\s+/g, '_')] = values[index];
      });
      data.push(row);
    }

    return data;
  };

  const normalizeImportData = (item: any, index: number): any | null => {
    try {
      const fieldMappings: { [key: string]: string[] } = {
        'name': ['name', 'product_name', 'medicine_name', 'title'],
        'description': ['description', 'desc', 'details'],
        'category': ['category', 'type', 'group'],
        'sku': ['sku', 'code', 'product_code', 'item_code'],
        'price': ['price', 'selling_price', 'retail_price'],
        'cost': ['cost', 'cost_price', 'wholesale_price', 'purchase_price'],
        'stock_quantity': ['stock_quantity', 'stock', 'quantity', 'qty'],
        'min_stock_level': ['min_stock_level', 'min_stock', 'reorder_level']
      };

      const normalized: any = {};

      Object.keys(fieldMappings).forEach(targetField => {
        const possibleFields = fieldMappings[targetField];
        for (const field of possibleFields) {
          if (item[field] !== undefined && item[field] !== '') {
            normalized[targetField] = item[field];
            break;
          }
        }
      });

      if (!normalized.name || !normalized.sku) {
        console.warn(`Row ${index + 1}: Missing required fields (name or sku)`);
        return null;
      }

      ['price', 'cost', 'stock_quantity', 'min_stock_level'].forEach(field => {
        if (normalized[field]) {
          const num = parseFloat(normalized[field].toString().replace(/[^\d.-]/g, ''));
          if (!isNaN(num)) {
            normalized[field] = num;
          }
        }
      });

      if (!normalized.category) {
        normalized.category = 'otc';
      }

      normalized.status = 'active';
      normalized.price = normalized.price || 0;
      normalized.cost = normalized.cost || 0;
      normalized.stock_quantity = normalized.stock_quantity || 0;
      normalized.min_stock_level = normalized.min_stock_level || 1;

      return normalized;
    } catch (error) {
      console.error(`Error normalizing row ${index + 1}:`, error);
      return null;
    }
  };

  const validateImportData = (data: any[]): { valid: any[], invalid: any[], errors: string[] } => {
    const valid: any[] = [];
    const invalid: any[] = [];
    const errors: string[] = [];

    data.forEach((item, index) => {
      const itemErrors: string[] = [];

      if (!item.name?.trim()) itemErrors.push('Missing name');
      if (!item.sku?.trim()) itemErrors.push('Missing SKU');
      if (!item.price || item.price <= 0) itemErrors.push('Invalid price');
      if (!item.cost || item.cost < 0) itemErrors.push('Invalid cost');
      if (!item.stock_quantity || item.stock_quantity < 0) itemErrors.push('Invalid stock quantity');

      const duplicateIndex = data.findIndex((otherItem, otherIndex) => 
        otherIndex !== index && otherItem.sku === item.sku
      );
      if (duplicateIndex !== -1) {
        itemErrors.push(`Duplicate SKU in row ${duplicateIndex + 1}`);
      }

      const existingSKU = products.find(p => p.sku === item.sku);
      if (existingSKU) {
        itemErrors.push(`SKU already exists in inventory`);
      }

      if (itemErrors.length > 0) {
        invalid.push({ ...item, _errors: itemErrors, _rowIndex: index + 1 });
        errors.push(`Row ${index + 1}: ${itemErrors.join(', ')}`);
      } else {
        valid.push(item);
      }
    });

    return { valid, invalid, errors };
  };

  const handleImport = async () => {
    // Enhanced import will handle shop ID automatically

    // Enhanced debugging for permission issues
    console.log('🔍 Import Debug - User Profile:', {
      uid: userProfile?.uid,
      role: userProfile?.role,
      shop_id: userProfile?.shop_id,
      email: userProfile?.email,
      full_name: userProfile?.full_name
    });

    // Check if user has permission to create products
    const allowedRoles = ['manager', 'owner', 'admin'];
    if (!allowedRoles.includes(userProfile.role)) {
      addError(
        new Error('Insufficient permissions'), 
        'Import', 
        `Your role (${userProfile.role}) doesn't have permission to import products. Required roles: ${allowedRoles.join(', ')}`
      );
      return;
    }

    setImporting(true);
    setImportStep('importing');
    setImportProgress(0);
    
    const { valid } = validateImportData(importPreviewData);
    let successful = 0;
    let failed = 0;
    const importErrors: string[] = [];

    try {
      for (let i = 0; i < valid.length; i++) {
        const item = valid[i];
        
        try {
          const productData = {
            ...item,
            description: item.description || '',
            name: item.name.trim(),
            sku: item.sku.trim()
            // shop_id will be added automatically by FirebaseService.createProduct
          };

          console.log(`🔄 Importing product ${i + 1}/${valid.length}: ${productData.name}`);
          await FirebaseService.createProduct(productData);
          successful++;
          
          setImportProgress(((i + 1) / valid.length) * 100);
          
        } catch (error) {
          console.error(`❌ Failed to import product ${item.name}:`, error);
          failed++;
          
          // Enhanced error reporting
          let errorMessage = 'Unknown error';
          if (error instanceof Error) {
            if (error.message.includes('permission-denied') || error.message.includes('CRITICAL: Firebase permission')) {
              errorMessage = 'Permission denied - Firebase rules not deployed';
            } else if (error.message.includes('already exists')) {
              errorMessage = 'Product with this SKU already exists';
            } else {
              errorMessage = error.message;
            }
          }
          
          importErrors.push(`${item.name} (${item.sku}): ${errorMessage}`);
        }
        
        // Add small delay to prevent overwhelming Firestore
        if (i < valid.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      }

      // Only reload products if we had some success
      if (successful > 0) {
        await loadProducts();
      }
      
      setImportResults({ successful, failed, errors: importErrors });
      setImportStep('results');
      
      if (successful > 0) {
        addSuccess(`Successfully imported ${successful} products`, 'Import');
      }
      if (failed > 0) {
        addWarning(`Failed to import ${failed} products`, 'Import');
        
        // Show specific guidance for permission errors
        const hasPermissionErrors = importErrors.some(error => 
          error.includes('Permission denied') || error.includes('Firebase permission')
        );
        
        if (hasPermissionErrors) {
          addError(
            new Error('Firebase permission error'),
            'Import',
            '🚨 CRITICAL: Firebase security rules are not deployed. Run "firebase deploy --only firestore:rules" to fix this issue.'
          );
        }
      }
      
    } catch (error) {
      console.error('❌ Import process failed:', error);
      addError(error, 'Import', 'Failed to complete the import process');
    } finally {
      setImporting(false);
    }
  };

  const resetImport = () => {
    setImportFile(null);
    setImportPreviewData([]);
    setImportProgress(0);
    setImportResults({ successful: 0, failed: 0, errors: [] });
    setImportStep('select');
    setShowImportDialog(false);
  };

  const downloadSampleCSV = () => {
    const sampleData = [
      'name,sku,category,price,cost,stock_quantity,min_stock_level,description',
      'Paracetamol 500mg,PAR-001,painkillers,2000,1500,100,10,Pain relief and fever reducer',
      'Amoxicillin 250mg,AMX-002,antibiotics,3500,2800,50,5,Broad spectrum antibiotic',
      'Vitamin C Tablets,VIT-003,vitamins,1500,1000,200,20,Immune system support'
    ].join('\n');

    const blob = new Blob([sampleData], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'pharmacy_products_sample.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    toast.success('Sample CSV file downloaded');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Button onClick={onBack} variant="outline" size="sm" className="mr-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
            <div>
              <div className="flex items-center">
                <Package className="h-8 w-8 text-indigo-600 mr-2" />
                <h1 className="text-3xl font-bold text-gray-900">Enhanced Pharmacy Management</h1>
              </div>
              {userProfile && (
                <p className="text-gray-600 mt-1">
                  {userProfile.shop?.name || 'Your Pharmacy'} • {products.length} medicines & products • TZS Currency
                </p>
              )}
            </div>
          </div>
          
          <div className="flex gap-2">
            {/* Import Dialog */}
            <Dialog open={showImportDialog} onOpenChange={(open) => {
              if (!open) {
                resetImport();
              }
            }}>
              <DialogTrigger asChild>
                <Button 
                  variant="outline"
                  onClick={() => setShowImportDialog(true)}
                  disabled={!userProfile?.shop_id}
                >
                  <Upload className="mr-2 h-4 w-4" />
                  Import Catalog
                </Button>
              </DialogTrigger>
              
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="flex items-center">
                    <Upload className="mr-2 h-5 w-5" />
                    Import Product Catalog
                  </DialogTitle>
                  <DialogDescription>
                    Import products from CSV, Excel, or JSON files. Download a sample template to get started.
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-6">
                  {importStep === 'select' && (
                    <div className="space-y-4">
                      {/* File Selection */}
                      <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                        <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                        <div className="space-y-2">
                          <h3 className="text-lg font-semibold">Select File to Import</h3>
                          <p className="text-gray-600">Choose a CSV, Excel, or JSON file containing your product data</p>
                          <input
                            type="file"
                            accept=".csv,.xlsx,.xls,.json"
                            onChange={handleFileSelect}
                            className="hidden"
                            id="import-file"
                          />
                          <div className="flex gap-2 justify-center">
                            <Button 
                              variant="outline" 
                              onClick={() => {
                                console.log('🔄 File input button clicked');
                                document.getElementById('import-file')?.click();
                              }}
                              className="cursor-pointer"
                            >
                              <FileSpreadsheet className="mr-2 h-4 w-4" />
                              Choose File
                            </Button>
                            <Button variant="outline" onClick={downloadSampleCSV}>
                              <Download className="mr-2 h-4 w-4" />
                              Download Sample CSV
                            </Button>
                          </div>
                        </div>
                      </div>
                      
                      {/* Import Instructions */}
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-blue-900 mb-2 flex items-center">
                          <Info className="mr-2 h-4 w-4" />
                          Import Requirements
                        </h4>
                        <ul className="text-sm text-blue-800 space-y-1 list-disc list-inside">
                          <li><strong>Required fields:</strong> name, sku, price, cost, stock_quantity</li>
                          <li><strong>Supported formats:</strong> CSV, Excel (.xlsx, .xls), JSON</li>
                          <li><strong>Field mappings:</strong> The system auto-maps common field variations</li>
                          <li><strong>Categories:</strong> Use pharmacy categories (prescription, otc, painkillers, etc.)</li>
                        </ul>
                      </div>
                    </div>
                  )}
                  
                  {importStep === 'preview' && importPreviewData.length > 0 && (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="text-lg font-semibold">Preview Import Data</h3>
                        <p className="text-sm text-gray-600">{importPreviewData.length} products found</p>
                      </div>
                      
                      {(() => {
                        const { valid, invalid } = validateImportData(importPreviewData);
                        return (
                          <div className="space-y-4">
                            {/* Validation Summary */}
                            <div className="grid grid-cols-2 gap-4">
                              <div className="bg-green-50 p-3 rounded-lg">
                                <div className="flex items-center">
                                  <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                                  <span className="font-semibold text-green-900">{valid.length} Valid Products</span>
                                </div>
                              </div>
                              <div className="bg-red-50 p-3 rounded-lg">
                                <div className="flex items-center">
                                  <XCircle className="h-5 w-5 text-red-600 mr-2" />
                                  <span className="font-semibold text-red-900">{invalid.length} Invalid Products</span>
                                </div>
                              </div>
                            </div>
                            
                            {/* Preview Table */}
                            <div className="max-h-60 overflow-y-auto border rounded-lg">
                              <table className="w-full text-sm">
                                <thead className="bg-gray-50 sticky top-0">
                                  <tr>
                                    <th className="px-3 py-2 text-left">Status</th>
                                    <th className="px-3 py-2 text-left">Name</th>
                                    <th className="px-3 py-2 text-left">SKU</th>
                                    <th className="px-3 py-2 text-left">Category</th>
                                    <th className="px-3 py-2 text-left">Price (TZS)</th>
                                    <th className="px-3 py-2 text-left">Stock</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {importPreviewData.slice(0, 10).map((item, index) => {
                                    const isValid = valid.includes(item);
                                    
                                    return (
                                      <tr key={index} className={isValid ? 'bg-green-50' : 'bg-red-50'}>
                                        <td className="px-3 py-2">
                                          {isValid ? (
                                            <CheckSquare className="h-4 w-4 text-green-600" />
                                          ) : (
                                            <XCircle className="h-4 w-4 text-red-600" />
                                          )}
                                        </td>
                                        <td className="px-3 py-2">{item.name || 'Missing'}</td>
                                        <td className="px-3 py-2">{item.sku || 'Missing'}</td>
                                        <td className="px-3 py-2">{item.category || 'otc'}</td>
                                        <td className="px-3 py-2">{item.price ? formatTZS(item.price) : 'Missing'}</td>
                                        <td className="px-3 py-2">{item.stock_quantity || 0}</td>
                                      </tr>
                                    );
                                  })}
                                </tbody>
                              </table>
                            </div>
                            
                            {importPreviewData.length > 10 && (
                              <p className="text-sm text-gray-600 text-center">
                                Showing first 10 of {importPreviewData.length} products
                              </p>
                            )}
                            
                            {/* Validation Errors */}
                            {invalid.length > 0 && (
                              <div className="bg-red-50 p-4 rounded-lg max-h-40 overflow-y-auto">
                                <h4 className="font-semibold text-red-900 mb-2">Validation Errors:</h4>
                                <ul className="text-sm text-red-800 space-y-1">
                                  {invalid.slice(0, 5).map((item, index) => (
                                    <li key={index}>
                                      <strong>Row {item._rowIndex}:</strong> {item._errors.join(', ')}
                                    </li>
                                  ))}
                                  {invalid.length > 5 && (
                                    <li className="text-red-600">... and {invalid.length - 5} more errors</li>
                                  )}
                                </ul>
                              </div>
                            )}
                            
                            {/* Action Buttons */}
                            <div className="flex justify-between">
                              <Button variant="outline" onClick={() => setImportStep('select')}>
                                <ArrowLeft className="mr-2 h-4 w-4" />
                                Back to File Selection
                              </Button>
                              <Button 
                                onClick={handleImport}
                                disabled={valid.length === 0}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                Import {valid.length} Valid Products
                                <ChevronRight className="ml-2 h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        );
                      })()}
                    </div>
                  )}
                  
                  {importStep === 'importing' && (
                    <div className="space-y-6 text-center py-8">
                      <RefreshCw className="mx-auto h-12 w-12 text-blue-600 animate-spin" />
                      <div className="space-y-2">
                        <h3 className="text-lg font-semibold">Importing Products...</h3>
                        <p className="text-gray-600">Please wait while we add products to your pharmacy inventory</p>
                      </div>
                      <div className="space-y-2">
                        <Progress value={importProgress} className="w-full max-w-md mx-auto" />
                        <p className="text-sm text-gray-500">{Math.round(importProgress)}% complete</p>
                      </div>
                    </div>
                  )}
                  
                  {importStep === 'results' && (
                    <div className="space-y-4">
                      <div className="text-center space-y-2">
                        <CheckCircle className="mx-auto h-12 w-12 text-green-600" />
                        <h3 className="text-lg font-semibold">Import Complete</h3>
                      </div>
                      
                      {/* Results Summary */}
                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-green-50 p-4 rounded-lg text-center">
                          <div className="text-2xl font-bold text-green-900">{importResults.successful}</div>
                          <div className="text-green-700">Successfully Imported</div>
                        </div>
                        <div className="bg-red-50 p-4 rounded-lg text-center">
                          <div className="text-2xl font-bold text-red-900">{importResults.failed}</div>
                          <div className="text-red-700">Failed to Import</div>
                        </div>
                      </div>
                      
                      {/* Error Details */}
                      {importResults.errors.length > 0 && (
                        <div className="bg-red-50 p-4 rounded-lg max-h-40 overflow-y-auto">
                          <h4 className="font-semibold text-red-900 mb-2">Import Errors:</h4>
                          <ul className="text-sm text-red-800 space-y-1">
                            {importResults.errors.map((error, index) => (
                              <li key={index}>{error}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                      
                      {/* Action Buttons */}
                      <div className="flex justify-center gap-2">
                        <Button variant="outline" onClick={resetImport}>
                          Import More Products
                        </Button>
                        <Button onClick={() => setShowImportDialog(false)}>
                          Close
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </DialogContent>
            </Dialog>

            <Dialog open={isAddingProduct || !!editingProduct} onOpenChange={(open) => {
              if (!open) {
                setIsAddingProduct(false);
                if (editingProduct) {
                  cancelEdit();
                }
              }
            }}>
              <DialogTrigger asChild>
                <Button 
                  onClick={() => {
                    setIsAddingProduct(true);
                    setQuickAddMode(false);
                    setCurrentStep(0);
                    resetProductForm();
                  }}
                  className="bg-indigo-600 hover:bg-indigo-700"
                  disabled={!userProfile?.shop_id}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Product
                </Button>
              </DialogTrigger>
              
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="flex items-center">
                    {editingProduct ? <Edit className="mr-2 h-5 w-5" /> : <Package className="mr-2 h-5 w-5" />}
                    {editingProduct ? `Edit Product: ${editingProduct.name}` : 'Add New Product'}
                  </DialogTitle>
                  <DialogDescription>
                    {editingProduct 
                      ? 'Update the product information, pricing, and inventory details.'
                      : 'Create a new product for your inventory with comprehensive details and pricing information.'
                    }
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-6">
                  {/* Form Content */}
                  <form onSubmit={editingProduct ? handleEditProduct : handleAddProduct} className="space-y-6">
                    {/* Quick Form for editing or adding */}
                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Basic Info */}
                      <div className="space-y-4">
                        <h3 className="font-semibold text-lg flex items-center">
                          <Package className="mr-2 h-5 w-5" />
                          Basic Information
                        </h3>
                        
                        <div>
                          <Label htmlFor="name">Product Name *</Label>
                          <Input
                            id="name"
                            value={productForm.name}
                            onChange={(e) => setProductForm(prev => ({ ...prev, name: e.target.value }))}
                            placeholder="Enter product name"
                            required
                          />
                        </div>

                        <div>
                          <Label htmlFor="category">Category *</Label>
                          <Select value={productForm.category} onValueChange={(value) => setProductForm(prev => ({ ...prev, category: value }))}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {PRODUCT_CATEGORIES.map((category) => (
                                <SelectItem key={category.id} value={category.id}>
                                  <div className="flex items-center">
                                    <span className="mr-2">{category.icon}</span>
                                    {category.name}
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="flex gap-2">
                          <div className="flex-1">
                            <Label htmlFor="sku">SKU *</Label>
                            <Input
                              id="sku"
                              value={productForm.sku}
                              onChange={(e) => setProductForm(prev => ({ ...prev, sku: e.target.value }))}
                              placeholder="e.g., BEV-001"
                              required
                            />
                          </div>
                          <Button type="button" variant="outline" size="sm" onClick={generateSKU} className="mt-6">
                            <Zap className="h-4 w-4" />
                          </Button>
                        </div>

                        <div>
                          <Label htmlFor="description">Description</Label>
                          <Textarea
                            id="description"
                            value={productForm.description}
                            onChange={(e) => setProductForm(prev => ({ ...prev, description: e.target.value }))}
                            placeholder="Product description"
                            rows={3}
                          />
                        </div>
                      </div>

                      {/* Pricing & Inventory */}
                      <div className="space-y-4">
                        <h3 className="font-semibold text-lg flex items-center">
                          <DollarSign className="mr-2 h-5 w-5" />
                          Pricing & Inventory
                        </h3>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="cost">Cost Price (TZS) *</Label>
                            <Input
                              id="cost"
                              type="number"
                              value={productForm.cost}
                              onChange={(e) => setProductForm(prev => ({ ...prev, cost: e.target.value }))}
                              placeholder="0"
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="price">Selling Price (TZS) *</Label>
                            <Input
                              id="price"
                              type="number"
                              value={productForm.price}
                              onChange={(e) => setProductForm(prev => ({ ...prev, price: e.target.value }))}
                              placeholder="0"
                              required
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="stock_quantity">Current Stock *</Label>
                            <Input
                              id="stock_quantity"
                              type="number"
                              value={productForm.stock_quantity}
                              onChange={(e) => setProductForm(prev => ({ ...prev, stock_quantity: e.target.value }))}
                              placeholder="0"
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="min_stock_level">Minimum Stock *</Label>
                            <Input
                              id="min_stock_level"
                              type="number"
                              value={productForm.min_stock_level}
                              onChange={(e) => setProductForm(prev => ({ ...prev, min_stock_level: e.target.value }))}
                              placeholder="0"
                              required
                            />
                          </div>
                        </div>

                        {/* Profit Display */}
                        {productForm.price && productForm.cost && (
                          <div className="p-4 bg-green-50 rounded-lg">
                            <h4 className="font-medium text-green-800 mb-2">Profit Analysis</h4>
                            <div className="grid grid-cols-3 gap-4 text-sm">
                              <div>
                                <p className="text-gray-600">Profit per Unit</p>
                                <p className="font-semibold text-green-700">
                                  {formatTZS(getProfitMetrics().profit)}
                                </p>
                              </div>
                              <div>
                                <p className="text-gray-600">Margin</p>
                                <p className="font-semibold text-green-700">
                                  {getProfitMetrics().margin.toFixed(1)}%
                                </p>
                              </div>
                              <div>
                                <p className="text-gray-600">Markup</p>
                                <p className="font-semibold text-green-700">
                                  {getProfitMetrics().markup.toFixed(1)}%
                                </p>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Error Display */}
                    {(hasCreationErrors || hasEditErrors) && (
                      <div className="space-y-2">
                        <ErrorDisplay 
                          errors={getErrorsByContext('Product Creation')}
                          title="Product Creation Errors"
                        />
                        <ErrorDisplay 
                          errors={getErrorsByContext('Product Edit')}
                          title="Product Edit Errors"
                        />
                      </div>
                    )}

                    {/* Form Actions */}
                    <div className="flex justify-end space-x-4 pt-4 border-t">
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => {
                          if (editingProduct) {
                            cancelEdit();
                          } else {
                            setIsAddingProduct(false);
                            resetProductForm();
                          }
                        }}
                        disabled={formSubmitting}
                      >
                        <X className="mr-2 h-4 w-4" />
                        Cancel
                      </Button>
                      <Button 
                        type="submit" 
                        disabled={formSubmitting}
                        className="bg-indigo-600 hover:bg-indigo-700"
                      >
                        <Save className="mr-2 h-4 w-4" />
                        {formSubmitting 
                          ? (editingProduct ? 'Updating...' : 'Adding...') 
                          : (editingProduct ? 'Update Product' : 'Add Product')
                        }
                      </Button>
                    </div>
                  </form>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Error Display for Loading */}
        {hasLoadingErrors && (
          <div className="mb-6">
            <ErrorDisplay 
              errors={getErrorsByContext('Product Loading')}
              title="Product Loading Issues"
            />
          </div>
        )}

        {/* Search and Filter */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search products by name or SKU..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="md:w-48">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories ({products.length})</SelectItem>
                  {categoriesWithCounts.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      <div className="flex items-center justify-between w-full">
                        <span className="flex items-center">
                          <span className="mr-2">{category.icon}</span>
                          {category.name}
                        </span>
                        <span className="ml-2 text-gray-500">({category.count})</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
              <p className="text-gray-600">Loading products...</p>
            </div>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-12">
            <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {searchTerm || selectedCategory !== 'all' ? 'No products found' : 'No products yet'}
            </h3>
            <p className="text-gray-500 mb-4">
              {searchTerm || selectedCategory !== 'all' 
                ? 'Try adjusting your search or filter criteria'
                : 'Get started by adding your first product to the inventory'
              }
            </p>
            {(!searchTerm && selectedCategory === 'all') && (
              <Button 
                onClick={() => {
                  setIsAddingProduct(true);
                  resetProductForm();
                }}
                disabled={!userProfile?.shop_id}
              >
                <Plus className="mr-2 h-4 w-4" />
                Add Your First Product
              </Button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map((product) => {
              const category = PRODUCT_CATEGORIES.find(c => c.id === product.category);
              const isLowStock = product.stock_quantity <= (product.min_stock_level || 0);
              
              return (
                <Card key={product.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center">
                        <span className="text-2xl mr-2">{category?.icon || '📦'}</span>
                        <div>
                          <CardTitle className="text-lg">{product.name}</CardTitle>
                          <p className="text-sm text-gray-500">{product.sku}</p>
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => startEditingProduct(product)}
                          className="h-8 w-8 p-0"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDeleteProduct(product)}
                          className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {product.description && (
                      <p className="text-sm text-gray-600 line-clamp-2">
                        {product.description}
                      </p>
                    )}
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-500">Price</p>
                        <p className="font-semibold text-lg">{formatTZS(product.price)}</p>
                      </div>
                      {product.cost && (
                        <div className="text-right">
                          <p className="text-sm text-gray-500">Cost</p>
                          <p className="text-sm">{formatTZS(product.cost)}</p>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-500">Stock</p>
                        <div className="flex items-center">
                          <span className={`font-medium ${isLowStock ? 'text-red-600' : 'text-green-600'}`}>
                            {product.stock_quantity || 0}
                          </span>
                          {isLowStock && (
                            <AlertTriangle className="h-4 w-4 text-red-500 ml-1" />
                          )}
                        </div>
                      </div>
                      <Badge variant={product.status === 'active' ? 'default' : 'secondary'}>
                        {product.status}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <span>{category?.name || 'Other'}</span>
                      {product.cost && (
                        <span>
                          {((product.price - product.cost) / product.cost * 100).toFixed(0)}% markup
                        </span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}