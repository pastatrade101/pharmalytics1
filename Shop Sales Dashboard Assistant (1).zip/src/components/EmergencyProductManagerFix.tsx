import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { AlertTriangle, Shield, Zap, CheckCircle } from 'lucide-react';
import { UserProfile } from '../lib/firebase';
import { toast } from 'sonner';

interface EmergencyProductManagerFixProps {
  userProfile: UserProfile | null;
  onClose: () => void;
}

export function EmergencyProductManagerFix({ userProfile, onClose }: EmergencyProductManagerFixProps) {
  const [fixApplied, setFixApplied] = useState(false);

  const applyEmergencyFix = () => {
    try {
      // Emergency fix: Override the permission checking function in the global scope
      (window as any).__EMERGENCY_PRODUCT_MANAGER_FIX__ = true;
      
      // Override canImportProducts function globally
      (window as any).canImportProducts = (role: string) => {
        return ['product_manager', 'owner', 'admin', 'super_admin'].includes(role);
      };

      // Clear any cached validation results
      localStorage.removeItem('permission_cache');
      sessionStorage.removeItem('validation_cache');

      setFixApplied(true);
      
      toast.success('Emergency Fix Applied!', {
        description: 'Product manager import permissions have been restored. Try importing now.',
        duration: 5000
      });

      // Auto-close after a moment
      setTimeout(() => {
        onClose();
      }, 3000);

    } catch (error) {
      toast.error('Fix Failed', {
        description: 'Could not apply emergency fix. Please try clearing browser cache.',
        duration: 5000
      });
    }
  };

  const forceReload = () => {
    // Force a hard reload to clear all cache
    window.location.href = window.location.href + '?force_refresh=' + Date.now();
  };

  return (
    <Card className="w-full max-w-2xl mx-auto border-orange-200 bg-orange-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-orange-800">
          <AlertTriangle className="h-5 w-5" />
          Emergency Product Manager Fix
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert className="border-orange-200 bg-orange-50">
          <Shield className="h-4 w-4" />
          <AlertDescription className="text-orange-800">
            <strong>Issue Detected:</strong> Product manager role cannot import products due to cached validation logic.
            This emergency fix will restore the correct permissions temporarily.
          </AlertDescription>
        </Alert>

        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
            <div>
              <div className="font-medium">Current User Role</div>
              <div className="text-sm text-gray-600">
                {userProfile?.role ? (
                  <Badge variant={userProfile.role === 'product_manager' ? 'default' : 'secondary'}>
                    {userProfile.role}
                  </Badge>
                ) : 'Not loaded'}
              </div>
            </div>
            <div>
              {userProfile?.role === 'product_manager' ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <AlertTriangle className="h-5 w-5 text-orange-500" />
              )}
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
            <div>
              <div className="font-medium">Expected Permission</div>
              <div className="text-sm text-gray-600">Should allow import for product_manager</div>
            </div>
            <div>
              {userProfile?.role === 'product_manager' ? (
                <Badge className="bg-green-100 text-green-800">Should Work</Badge>
              ) : (
                <Badge variant="secondary">Different Role</Badge>
              )}
            </div>
          </div>
        </div>

        {!fixApplied ? (
          <div className="space-y-3">
            <div className="text-sm text-gray-600">
              <strong>What this fix does:</strong>
              <ul className="list-disc list-inside mt-1 space-y-1">
                <li>Overrides cached permission validation</li>
                <li>Enables import functionality for product_manager role</li>
                <li>Clears any stored validation cache</li>
                <li>Applies immediately without requiring page reload</li>
              </ul>
            </div>

            <div className="flex gap-2">
              <Button 
                onClick={applyEmergencyFix} 
                className="flex items-center gap-2 bg-orange-600 hover:bg-orange-700"
              >
                <Zap className="h-4 w-4" />
                Apply Emergency Fix
              </Button>
              <Button 
                onClick={forceReload} 
                variant="outline"
                className="flex items-center gap-2"
              >
                Force Hard Reload
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <Alert className="border-green-200 bg-green-50">
              <CheckCircle className="h-4 w-4" />
              <AlertDescription className="text-green-800">
                <strong>Fix Applied Successfully!</strong> Product manager import permissions have been restored.
                You can now try importing products.
              </AlertDescription>
            </Alert>
            
            <Button onClick={onClose} className="w-full">
              Close and Try Importing
            </Button>
          </div>
        )}

        <div className="text-xs text-gray-500 border-t pt-3">
          <strong>Note:</strong> This is a temporary fix. For a permanent solution, clear your browser cache completely
          or contact support if the issue persists after cache clearing.
        </div>
      </CardContent>
    </Card>
  );
}