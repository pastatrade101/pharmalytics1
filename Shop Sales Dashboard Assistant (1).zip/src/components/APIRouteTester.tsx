import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { CheckCircle, XCircle, Loader2, RefreshCw, Network } from 'lucide-react';

interface APITestResult {
  endpoint: string;
  method: string;
  status: number;
  success: boolean;
  data: any;
  error?: string;
  responseTime: number;
  timestamp: string;
}

export function APIRouteTester() {
  const [results, setResults] = useState<APITestResult[]>([]);
  const [testing, setTesting] = useState(false);
  const [currentTest, setCurrentTest] = useState<string | null>(null);

  const testEndpoints = [
    { url: '/api/health', method: 'GET' },
    { url: '/api/health', method: 'POST' },
    { url: '/api/generate-report', method: 'GET' },
    { url: '/api/generate-report', method: 'POST' },
    { url: '/api/sales', method: 'GET' },
    { url: '/api/sales', method: 'POST' },
  ];

  const testAPI = async (endpoint: string, method: 'GET' | 'POST') => {
    const testKey = `${method} ${endpoint}`;
    setCurrentTest(testKey);
    const startTime = Date.now();
    
    try {
      const options: RequestInit = {
        method,
        headers: {
          'Content-Type': 'application/json',
        }
      };

      // Add appropriate body for POST requests
      if (method === 'POST') {
        if (endpoint.includes('health')) {
          options.body = JSON.stringify({ test: 'health check data' });
        } else if (endpoint.includes('generate-report')) {
          options.body = JSON.stringify({
            type: 'business_intelligence',
            data: {
              pharmacyName: 'Test Pharmacy',
              timeframe: 'Test Period',
              metrics: {
                revenue: 100000,
                transactions: 50,
                products: 10,
                activeProducts: 8,
                lowStock: 2,
                expiring: 1,
                expired: 0,
                avgTransactionValue: 2000,
                monthlyGrowth: 5.5
              },
              topProducts: [{ name: 'Test Product', sales: 10, revenue: 20000 }],
              recentActivity: 5
            },
            userProfile: {
              role: 'owner',
              pharmacyType: 'community_pharmacy'
            }
          });
        } else if (endpoint.includes('sales')) {
          options.body = JSON.stringify({
            test: 'sales data',
            amount: 1000,
            products: ['Product A', 'Product B']
          });
        }
      }

      console.log(`🧪 Testing ${method} ${endpoint}...`);
      const response = await fetch(endpoint, options);
      const responseTime = Date.now() - startTime;
      
      let data;
      const responseClone = response.clone();
      try {
        data = await response.json();
      } catch (parseError) {
        console.log('JSON parse failed, trying text:', parseError);
        data = await responseClone.text();
      }
      
      const result: APITestResult = {
        endpoint,
        method,
        status: response.status,
        success: response.ok,
        data,
        responseTime,
        timestamp: new Date().toISOString(),
        error: response.ok ? undefined : `HTTP ${response.status} ${response.statusText}`
      };

      setResults(prev => [result, ...prev]);
      
      console.log(`✅ ${method} ${endpoint} completed:`, result);
      
    } catch (error: any) {
      const responseTime = Date.now() - startTime;
      const result: APITestResult = {
        endpoint,
        method,
        status: 0,
        success: false,
        data: null,
        responseTime,
        timestamp: new Date().toISOString(),
        error: error.message || 'Network error'
      };
      
      setResults(prev => [result, ...prev]);
      console.error(`❌ ${method} ${endpoint} failed:`, result);
    }
    
    setCurrentTest(null);
  };

  const testAllEndpoints = async () => {
    setTesting(true);
    setResults([]);
    
    for (const endpoint of testEndpoints) {
      await testAPI(endpoint.url, endpoint.method as 'GET' | 'POST');
      // Small delay between requests
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    setTesting(false);
  };

  const clearResults = () => {
    setResults([]);
  };

  const getStatusColor = (status: number) => {
    if (status >= 200 && status < 300) return 'bg-green-100 text-green-800';
    if (status >= 400 && status < 500) return 'bg-red-100 text-red-800';
    if (status >= 500) return 'bg-red-100 text-red-800';
    return 'bg-gray-100 text-gray-800';
  };

  return (
    <Card className="w-full max-w-4xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Network className="h-5 w-5 text-blue-600" />
          API Route Tester
          <Badge variant="outline" className="ml-auto">
            App Router
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        
        {/* Control buttons */}
        <div className="flex gap-2 flex-wrap">
          <Button 
            onClick={testAllEndpoints} 
            disabled={testing || currentTest !== null}
            size="sm"
            className="bg-blue-600 hover:bg-blue-700"
          >
            {testing ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Testing All...
              </>
            ) : (
              <>
                <RefreshCw className="h-4 w-4 mr-2" />
                Test All Endpoints
              </>
            )}
          </Button>
          
          {testEndpoints.map((endpoint, index) => (
            <Button 
              key={index}
              onClick={() => testAPI(endpoint.url, endpoint.method as 'GET' | 'POST')} 
              disabled={testing || currentTest !== null}
              size="sm"
              variant="outline"
              className={currentTest === `${endpoint.method} ${endpoint.url}` ? 'bg-yellow-50' : ''}
            >
              {currentTest === `${endpoint.method} ${endpoint.url}` && (
                <Loader2 className="h-3 w-3 mr-1 animate-spin" />
              )}
              {endpoint.method} {endpoint.url.replace('/api/', '')}
            </Button>
          ))}
          
          <Button 
            onClick={clearResults} 
            disabled={testing || results.length === 0}
            size="sm"
            variant="ghost"
          >
            Clear Results
          </Button>
        </div>

        <Separator />

        {/* Results */}
        <div className="space-y-2">
          <h3 className="font-medium text-gray-900">Test Results ({results.length})</h3>
          
          {results.length === 0 && (
            <div className="text-center text-gray-500 py-8">
              <Network className="h-12 w-12 mx-auto mb-2 text-gray-300" />
              <p>No tests run yet. Click "Test All Endpoints" to start.</p>
            </div>
          )}
          
          {results.map((result, index) => (
            <Card key={index} className={`border-l-4 ${
              result.success ? 'border-l-green-500 bg-green-50/30' : 'border-l-red-500 bg-red-50/30'
            }`}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {result.success ? (
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    ) : (
                      <XCircle className="h-4 w-4 text-red-600" />
                    )}
                    <span className="font-medium">{result.method} {result.endpoint}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={getStatusColor(result.status)}>
                      {result.status || 'ERR'}
                    </Badge>
                    <span className="text-xs text-gray-500">
                      {result.responseTime}ms
                    </span>
                    <span className="text-xs text-gray-500">
                      {new Date(result.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                </div>
                
                {result.error && (
                  <div className="text-sm text-red-600 mb-2 p-2 bg-red-50 rounded">
                    <strong>Error:</strong> {result.error}
                  </div>
                )}
                
                {result.success && result.data?.source && (
                  <div className="text-sm text-green-600 mb-2">
                    <strong>Source:</strong> {result.data.source}
                  </div>
                )}
                
                <details className="text-xs">
                  <summary className="cursor-pointer text-gray-600 hover:text-gray-800 select-none">
                    View Response Data
                  </summary>
                  <pre className="mt-2 p-2 bg-gray-50 rounded overflow-auto text-xs">
                    {typeof result.data === 'string' 
                      ? result.data 
                      : JSON.stringify(result.data, null, 2)
                    }
                  </pre>
                </details>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Summary */}
        {results.length > 0 && (
          <Card className="bg-blue-50/30 border-blue-200">
            <CardContent className="p-4">
              <h4 className="font-medium text-blue-900 mb-2">Test Summary</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <div className="text-green-600 font-medium">
                    {results.filter(r => r.success).length} Successful
                  </div>
                </div>
                <div>
                  <div className="text-red-600 font-medium">
                    {results.filter(r => !r.success).length} Failed
                  </div>
                </div>
                <div>
                  <div className="text-blue-600 font-medium">
                    {Math.round(results.reduce((sum, r) => sum + r.responseTime, 0) / results.length)}ms Avg
                  </div>
                </div>
                <div>
                  <div className="text-gray-600 font-medium">
                    {results.length} Total Tests
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </CardContent>
    </Card>
  );
}