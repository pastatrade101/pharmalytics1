import React, { useRef } from 'react';
import { Search, Scan, X, Plus, Package } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { ScrollArea } from '../ui/scroll-area';
import { Product } from '../../lib/firebase-types';
import { formatTZS } from '../../lib/currency-utils';
import { filterProducts, getAvailableProducts } from '../../lib/pos-helpers';

interface ProductSearchPanelProps {
  products: Product[];
  searchQuery: string;
  barcodeInput: string;
  showProductSearch: boolean;
  onSearchQueryChange: (query: string) => void;
  onBarcodeInputChange: (barcode: string) => void;
  onSetShowProductSearch: (show: boolean) => void;
  onBarcodeScan: (barcode: string) => void;
  onAddToCart: (product: Product) => void;
}

export function ProductSearchPanel({
  products,
  searchQuery,
  barcodeInput,
  showProductSearch,
  onSearchQueryChange,
  onBarcodeInputChange,
  onSetShowProductSearch,
  onBarcodeScan,
  onAddToCart
}: ProductSearchPanelProps) {
  const barcodeInputRef = useRef<HTMLInputElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const filteredProducts = React.useMemo(() => 
    filterProducts(products, searchQuery), 
    [products, searchQuery]
  );

  const availableProducts = React.useMemo(() => 
    getAvailableProducts(products), 
    [products]
  );

  return (
    <div className="flex-1 flex flex-col">
      {/* Search and Barcode Scanner */}
      <Card className="m-4 mb-2">
        <CardContent className="p-4">
          <div className="flex gap-3">
            {/* Barcode Input */}
            <div className="flex-1">
              <Label htmlFor="barcode" className="text-sm font-medium">
                Barcode Scanner (F1 to focus)
              </Label>
              <div className="flex gap-2 mt-1">
                <Input
                  ref={barcodeInputRef}
                  id="barcode"
                  placeholder="Scan or enter barcode/SKU..."
                  value={barcodeInput}
                  onChange={(e) => onBarcodeInputChange(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && barcodeInput.trim()) {
                      onBarcodeScan(barcodeInput.trim());
                    }
                  }}
                  className="font-mono"
                />
                <Button 
                  variant="outline" 
                  size="icon"
                  onClick={() => barcodeInput.trim() && onBarcodeScan(barcodeInput.trim())}
                  disabled={!barcodeInput.trim()}
                >
                  <Scan className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            {/* Product Search */}
            <div className="flex-1">
              <Label htmlFor="search" className="text-sm font-medium">
                Product Search
              </Label>
              <div className="flex gap-2 mt-1">
                <Input
                  ref={searchInputRef}
                  id="search"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => onSearchQueryChange(e.target.value)}
                  onFocus={() => onSetShowProductSearch(true)}
                />
                <Button 
                  variant="outline" 
                  size="icon"
                  onClick={() => onSetShowProductSearch(!showProductSearch)}
                >
                  <Search className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Product Search Results */}
      {showProductSearch && (
        <Card className="mx-4 mb-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center justify-between">
              Search Results ({filteredProducts.length})
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => onSetShowProductSearch(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-64">
              <div className="p-4 pt-0">
                {filteredProducts.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                    {filteredProducts.slice(0, 20).map((product) => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        onClick={() => onAddToCart(product)}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    No products found matching your search
                  </div>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Available Products */}
      <Card className="flex-1 mx-4 mb-4">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Package className="h-5 w-5" />
            Available Products ({availableProducts.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {availableProducts.length > 0 ? (
            <ScrollArea className="h-96">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {availableProducts.slice(0, 50).map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onClick={() => onAddToCart(product)}
                    showPrescriptionBadge
                  />
                ))}
              </div>
            </ScrollArea>
          ) : (
            <div className="text-center py-12">
              <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-600 mb-2">No Products Available</h3>
              <p className="text-gray-500">
                No products are currently available for sale. Please add products to your inventory.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

interface ProductCardProps {
  product: Product;
  onClick: () => void;
  showPrescriptionBadge?: boolean;
}

function ProductCard({ product, onClick, showPrescriptionBadge }: ProductCardProps) {
  // Debug logging for price issues
  React.useEffect(() => {
    if (product.retail_price === null || product.retail_price === undefined || isNaN(Number(product.retail_price))) {
      console.warn('Product with invalid price detected:', {
        id: product.id,
        name: product.name,
        retail_price: product.retail_price,
        typeof_price: typeof product.retail_price
      });
    }
  }, [product]);

  return (
    <Card 
      className="cursor-pointer hover:bg-gray-50 transition-colors"
      onClick={onClick}
    >
      <CardContent className="p-3">
        <div className="flex justify-between items-start mb-2">
          <h4 className="font-medium text-sm line-clamp-2">{product.name || 'Unknown Product'}</h4>
          <Badge variant={(product.stock_quantity || 0) <= (product.min_stock_level || 0) ? "destructive" : "secondary"}>
            {product.stock_quantity || 0}
          </Badge>
        </div>
        
        {showPrescriptionBadge && product.requires_prescription && (
          <Badge variant="outline" className="text-xs mb-2">
            <Package className="h-3 w-3 mr-1" />
            Prescription Required
          </Badge>
        )}
        
        <div className="text-xs text-gray-500 mb-2">
          {product.generic_name && <div>Generic: {product.generic_name}</div>}
          <div>SKU: {product.sku || 'N/A'}</div>
          <div>Category: {product.category || 'Uncategorized'}</div>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="font-semibold text-green-600">
            {formatTZS(product.retail_price)}
          </span>
          <Button size="sm" variant="outline">
            <Plus className="h-3 w-3 mr-1" />
            Add
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}