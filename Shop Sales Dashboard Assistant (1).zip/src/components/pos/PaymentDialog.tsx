import React from 'react';
import { CreditCard, Check, Package, Smartphone, Banknote, X, ShieldCheck, Building, Receipt } from 'lucide-react';
import { Button } from '../ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Separator } from '../ui/separator';
import { Badge } from '../ui/badge';
import { PaymentMethod } from '../../lib/firebase-types';
import { CartTotals } from '../../lib/pos-helpers';
import { PAYMENT_METHODS, PaymentMethodValue } from '../../lib/app-constants';
import { formatTZS } from '../../lib/currency-utils';

interface PaymentDialogProps {
  open: boolean;
  totals: CartTotals;
  paymentMethod: PaymentMethod;
  paymentAmountInput: string;
  paymentAmount: number;
  paymentReference: string;
  isProcessing: boolean;
  onOpenChange: (open: boolean) => void;
  onPaymentMethodChange: (method: PaymentMethod) => void;
  onPaymentAmountChange: (amount: string) => void;
  onPaymentReferenceChange: (reference: string) => void;
  onProcessSale: () => void;
  onTriggerClick: () => void;
}

export function PaymentDialog({
  open,
  totals,
  paymentMethod,
  paymentAmountInput,
  paymentAmount,
  paymentReference,
  isProcessing,
  onOpenChange,
  onPaymentMethodChange,
  onPaymentAmountChange,
  onPaymentReferenceChange,
  onProcessSale,
  onTriggerClick
}: PaymentDialogProps) {
  // Map PaymentMethod (firebase-types) to PaymentMethodValue (app-constants)
  const mapPaymentMethod = (method: PaymentMethod): PaymentMethodValue => {
    switch (method) {
      case 'cash': return 'cash';
      case 'card': return 'card';
      case 'mobile_money': return 'mpesa'; // Default to M-PESA for mobile money
      case 'bank_transfer': return 'bank-transfer';
      case 'insurance': return 'insurance';
      default: return 'cash';
    }
  };

  const getMethodIcon = (method: PaymentMethod) => {
    switch (method) {
      case 'cash':
        return <Banknote className="h-5 w-5" />;
      case 'mobile_money':
        return <Smartphone className="h-5 w-5" />;
      case 'card':
        return <CreditCard className="h-5 w-5" />;
      case 'insurance':
        return <ShieldCheck className="h-5 w-5" />;
      case 'bank_transfer':
        return <Building className="h-5 w-5" />;
      default:
        return <CreditCard className="h-5 w-5" />;
    }
  };

  const selectedMethod = PAYMENT_METHODS.find(m => m.value === mapPaymentMethod(paymentMethod));

  return (
    <div className="p-6 border-t bg-gradient-to-b from-gray-50 to-white space-y-6">
      {/* Order Summary */}
      <div className="bg-white rounded-xl p-4 border shadow-sm space-y-3">
        <div className="flex items-center gap-2 mb-3">
          <Receipt className="h-4 w-4 text-gray-600" />
          <h3 className="font-medium text-gray-900">Order Summary</h3>
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between text-sm text-gray-600">
            <span>Subtotal:</span>
            <span className="font-medium">{formatTZS(totals.subtotal)}</span>
          </div>
          {totals.discountAmount > 0 && (
            <div className="flex justify-between text-sm">
              <span className="text-red-600">Discount:</span>
              <span className="font-medium text-red-600">-{formatTZS(totals.discountAmount)}</span>
            </div>
          )}
          <div className="flex justify-between text-sm text-gray-600">
            <span>Tax (18%):</span>
            <span className="font-medium">{formatTZS(totals.taxAmount)}</span>
          </div>
          <Separator className="my-2" />
          <div className="flex justify-between text-lg font-semibold">
            <span className="text-gray-900">Total:</span>
            <span className="text-green-600">{formatTZS(totals.total)}</span>
          </div>
        </div>
      </div>

      {/* Checkout Button */}
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogTrigger asChild>
          <Button 
            className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-[1.02]" 
            size="lg"
            onClick={onTriggerClick}
          >
            {getMethodIcon(paymentMethod)}
            <span className="ml-2 font-medium">Process Payment - {formatTZS(totals.total)}</span>
          </Button>  
        </DialogTrigger>
        
        <DialogContent className="max-w-lg mx-auto">
          <DialogHeader className="space-y-4 pb-6">
            <div className="flex items-center justify-between">
              <DialogTitle className="text-xl font-semibold text-gray-900 flex items-center gap-3">
                <div className="p-2 bg-green-100 rounded-lg">
                  <CreditCard className="h-5 w-5 text-green-600" />
                </div>
                Process Payment
              </DialogTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onOpenChange(false)}
                className="h-8 w-8 p-0 hover:bg-gray-100 rounded-full"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            <DialogDescription className="sr-only">
              Complete the payment process for this sale by selecting a payment method and entering the payment amount.
            </DialogDescription>
            <div className="bg-gray-50 rounded-lg p-4 border">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Amount to collect:</span>
                <span className="text-2xl font-bold text-green-600">{formatTZS(totals.total)}</span>
              </div>
            </div>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Payment Method Selection - Clean Payment Method Grid */}
            <div className="space-y-4">
              <Label className="text-base font-medium text-gray-900">Select Payment Method</Label>
              
              {/* Payment Method Grid */}
              <div className="grid grid-cols-2 gap-3">
                {/* Cash Payment */}
                <button
                  type="button"
                  onClick={() => onPaymentMethodChange('cash')}
                  className={`p-4 rounded-xl border-2 transition-all duration-200 text-left hover:shadow-md ${
                    paymentMethod === 'cash'
                      ? 'border-green-500 bg-green-50 shadow-md'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-3 rounded-lg ${
                      paymentMethod === 'cash' ? 'bg-green-100' : 'bg-gray-100'
                    }`}>
                      <Banknote className={`h-5 w-5 ${
                        paymentMethod === 'cash' ? 'text-green-600' : 'text-gray-600'
                      }`} />
                    </div>
                    <div>
                      <div className={`font-medium ${
                        paymentMethod === 'cash' ? 'text-green-900' : 'text-gray-900'
                      }`}>
                        Cash
                      </div>
                      <div className="text-xs text-gray-500">Physical payment</div>
                    </div>
                  </div>
                </button>

                {/* Mobile Money */}
                <button
                  type="button"
                  onClick={() => onPaymentMethodChange('mobile_money')}
                  className={`p-4 rounded-xl border-2 transition-all duration-200 text-left hover:shadow-md ${
                    paymentMethod === 'mobile_money'
                      ? 'border-blue-500 bg-blue-50 shadow-md'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-3 rounded-lg ${
                      paymentMethod === 'mobile_money' ? 'bg-blue-100' : 'bg-gray-100'
                    }`}>
                      <Smartphone className={`h-5 w-5 ${
                        paymentMethod === 'mobile_money' ? 'text-blue-600' : 'text-gray-600'
                      }`} />
                    </div>
                    <div>
                      <div className={`font-medium ${
                        paymentMethod === 'mobile_money' ? 'text-blue-900' : 'text-gray-900'
                      }`}>
                        Mobile Money
                      </div>
                      <div className="text-xs text-gray-500">M-PESA, Tigo Pesa</div>
                    </div>
                  </div>
                </button>

                {/* Card Payment */}
                <button
                  type="button"
                  onClick={() => onPaymentMethodChange('card')}
                  className={`p-4 rounded-xl border-2 transition-all duration-200 text-left hover:shadow-md ${
                    paymentMethod === 'card'
                      ? 'border-purple-500 bg-purple-50 shadow-md'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-3 rounded-lg ${
                      paymentMethod === 'card' ? 'bg-purple-100' : 'bg-gray-100'
                    }`}>
                      <CreditCard className={`h-5 w-5 ${
                        paymentMethod === 'card' ? 'text-purple-600' : 'text-gray-600'
                      }`} />
                    </div>
                    <div>
                      <div className={`font-medium ${
                        paymentMethod === 'card' ? 'text-purple-900' : 'text-gray-900'
                      }`}>
                        Card Payment
                      </div>
                      <div className="text-xs text-gray-500">Debit or Credit</div>
                    </div>
                  </div>
                </button>

                {/* Insurance */}
                <button
                  type="button"
                  onClick={() => onPaymentMethodChange('insurance')}
                  className={`p-4 rounded-xl border-2 transition-all duration-200 text-left hover:shadow-md ${
                    paymentMethod === 'insurance'
                      ? 'border-orange-500 bg-orange-50 shadow-md'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-3 rounded-lg ${
                      paymentMethod === 'insurance' ? 'bg-orange-100' : 'bg-gray-100'
                    }`}>
                      <ShieldCheck className={`h-5 w-5 ${
                        paymentMethod === 'insurance' ? 'text-orange-600' : 'text-gray-600'
                      }`} />
                    </div>
                    <div>
                      <div className={`font-medium ${
                        paymentMethod === 'insurance' ? 'text-orange-900' : 'text-gray-900'
                      }`}>
                        Insurance
                      </div>
                      <div className="text-xs text-gray-500">Health coverage</div>
                    </div>
                  </div>
                </button>
              </div>
              
              {/* Selected Method Display */}
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-white rounded-lg border">
                    {getMethodIcon(paymentMethod)}
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-gray-900">
                      {paymentMethod === 'cash' && 'Cash Payment'}
                      {paymentMethod === 'mobile_money' && 'Mobile Money'}
                      {paymentMethod === 'card' && 'Card Payment'}
                      {paymentMethod === 'insurance' && 'Health Insurance'}
                      {paymentMethod === 'bank_transfer' && 'Bank Transfer'}
                    </div>
                    {paymentMethod === 'mobile_money' && (
                      <div className="text-xs text-gray-600 mt-1">
                        Requires confirmation code after payment
                      </div>
                    )}
                    {paymentMethod === 'card' && (
                      <div className="text-xs text-gray-600 mt-1">
                        Processing fee: 2.5%
                      </div>
                    )}
                    {paymentMethod === 'cash' && (
                      <div className="text-xs text-gray-600 mt-1">
                        Change will be calculated automatically
                      </div>
                    )}
                  </div>
                  <Badge variant="secondary" className="bg-green-100 text-green-700">
                    Selected
                  </Badge>
                </div>
              </div>
            </div>

            {/* Payment Amount */}
            <div className="space-y-3">
              <Label className="text-base font-medium text-gray-900">Payment Amount</Label>
              <div className="relative">
                <Input
                  type="number"
                  value={paymentAmountInput}
                  onChange={(e) => onPaymentAmountChange(e.target.value)}
                  step="0.01"
                  min={0}
                  className="text-xl font-semibold h-14 pl-12 pr-4 border-2 focus:border-green-500"
                  placeholder="0.00"
                />
                <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-lg font-semibold text-gray-500">
                  TZS
                </div>
              </div>
              
              {/* Payment Amount Status */}
              <div className="space-y-2">
                {(() => {
                  const currentPaymentAmount = paymentAmount || 0;
                  const totalAmount = totals?.total || 0;
                  
                  if (currentPaymentAmount < totalAmount && paymentAmountInput) {
                    return (
                      <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                        <div className="flex items-center gap-2 text-red-700">
                          <X className="h-4 w-4" />
                          <span className="font-medium">Insufficient amount</span>
                        </div>
                        <div className="text-sm text-red-600 mt-1">
                          Required: {formatTZS(totalAmount)} | Short by: {formatTZS(totalAmount - currentPaymentAmount)}
                        </div>
                      </div>
                    );
                  }
                  
                  if (currentPaymentAmount > totalAmount && currentPaymentAmount > 0) {
                    return (
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                        <div className="flex items-center gap-2 text-blue-700">
                          <Check className="h-4 w-4" />
                          <span className="font-medium">Change due</span>
                        </div>
                        <div className="text-sm text-blue-600 mt-1">
                          Change to return: {formatTZS(currentPaymentAmount - totalAmount)}
                        </div>
                      </div>
                    );
                  }
                  
                  if (currentPaymentAmount === totalAmount && currentPaymentAmount > 0) {
                    return (
                      <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                        <div className="flex items-center gap-2 text-green-700">
                          <Check className="h-4 w-4" />
                          <span className="font-medium">Exact amount - Ready to process</span>
                        </div>
                      </div>
                    );
                  }
                  
                  return null;
                })()}
              </div>

              {/* Quick Amount Buttons */}
              <div className="grid grid-cols-3 gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const totalAmount = totals?.total || 0;
                    onPaymentAmountChange(totalAmount.toString());
                  }}
                  className="text-sm h-10"
                >
                  Exact Amount
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const totalAmount = totals?.total || 0;
                    const roundedAmount = Math.ceil(totalAmount / 1000) * 1000;
                    onPaymentAmountChange(roundedAmount.toString());
                  }}
                  className="text-sm h-10"
                >
                  Round Up
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onPaymentAmountChange('')}
                  className="text-sm h-10"
                >
                  Clear
                </Button>
              </div>
            </div>

            {/* Payment Reference */}
            {(paymentMethod === 'mobile_money' || paymentMethod === 'card' || paymentMethod === 'insurance' || paymentMethod === 'bank_transfer') && (
              <div className="space-y-3">
                <Label className="text-base font-medium text-gray-900 flex items-center gap-2">
                  {(() => {
                    switch (paymentMethod) {
                      case 'mpesa':
                      case 'tigo-pesa':
                      case 'halopesa':
                      case 'airtel-money':
                        return (
                          <>
                            <Smartphone className="h-4 w-4" />
                            Mobile Money Reference
                          </>
                        );
                      case 'card':
                        return (
                          <>
                            <CreditCard className="h-4 w-4" />
                            Transaction Reference
                          </>
                        );
                      case 'insurance':
                        return (
                          <>
                            <ShieldCheck className="h-4 w-4" />
                            Claim Reference
                          </>
                        );
                      case 'bank-transfer':
                        return (
                          <>
                            <Building className="h-4 w-4" />
                            Transfer Reference
                          </>
                        );
                      default:
                        return 'Reference Number';
                    }
                  })()}
                </Label>
                <Input
                  value={paymentReference}
                  onChange={(e) => onPaymentReferenceChange(e.target.value)}
                  placeholder={(() => {
                    switch (paymentMethod) {
                      case 'mpesa':
                        return 'Enter M-PESA confirmation code';
                      case 'tigo-pesa':
                        return 'Enter Tigo Pesa confirmation code';
                      case 'halopesa':
                        return 'Enter HaloPesa transaction ID';
                      case 'airtel-money':
                        return 'Enter Airtel Money reference';
                      case 'card':
                        return 'Enter card transaction reference';
                      case 'insurance':
                        return 'Enter insurance claim number';
                      case 'bank-transfer':
                        return 'Enter bank transfer reference';
                      default:
                        return 'Enter reference number';
                    }
                  })()}
                  className="font-mono h-12 border-2 focus:border-green-500"
                />
                {paymentMethod === 'mobile_money' && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                    <div className="text-sm text-blue-700">
                      💡 Enter the confirmation code you received from your mobile money provider after completing the payment.
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3 pt-6 border-t">
              <Button 
                variant="outline" 
                onClick={() => onOpenChange(false)}
                className="flex-1 h-12 border-2"
              >
                Cancel
              </Button>
              <Button 
                onClick={onProcessSale}
                disabled={
                  isProcessing || 
                  (paymentAmount || 0) < (totals?.total || 0) || 
                  ((paymentMethod === 'mobile_money' || paymentMethod === 'card' || paymentMethod === 'insurance' || paymentMethod === 'bank_transfer') && !paymentReference)
                }
                className="flex-1 h-12 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl transition-all duration-200"
              >
                {isProcessing ? (
                  <>
                    <Package className="h-5 w-5 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Check className="h-5 w-5 mr-2" />
                    Complete Sale
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}