import React from 'react';
import { ShoppingCart, User, Trash2, X, Plus, Minus, AlertCircle, Stethoscope, Shield } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { ScrollArea } from '../ui/scroll-area';
import { Switch } from '../ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { CartItem } from '../../lib/pos-helpers';
import { Customer, InsuranceProvider } from '../../lib/firebase-types';
import { INSURANCE_PROVIDERS } from '../../lib/app-constants';
import { formatTZS } from '../../lib/currency-utils';

interface CartPanelProps {
  cart: CartItem[];
  selectedCustomer: Customer | null;
  isPrescriptionSale: boolean;
  prescriptionNumber: string;
  doctorName: string;
  useInsurance: boolean;
  insuranceProvider: InsuranceProvider;
  insuranceNumber: string;
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  onSelectCustomer: () => void;
  onTogglePrescription: (enabled: boolean) => void;
  onPrescriptionNumberChange: (value: string) => void;
  onDoctorNameChange: (value: string) => void;
  onToggleInsurance: (enabled: boolean) => void;
  onInsuranceProviderChange: (provider: InsuranceProvider) => void;
  onInsuranceNumberChange: (value: string) => void;
}

export function CartPanel({
  cart,
  selectedCustomer,
  isPrescriptionSale,
  prescriptionNumber,
  doctorName,
  useInsurance,
  insuranceProvider,
  insuranceNumber,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onSelectCustomer,
  onTogglePrescription,
  onPrescriptionNumberChange,
  onDoctorNameChange,
  onToggleInsurance,
  onInsuranceProviderChange,
  onInsuranceNumberChange
}: CartPanelProps) {
  return (
    <div className="w-96 bg-white border-l shadow-lg flex flex-col">
      {/* Cart Header */}
      <div className="p-4 border-b">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <ShoppingCart className="h-5 w-5" />
            Cart ({cart.length})
          </h2>
          {cart.length > 0 && (
            <Button variant="outline" size="sm" onClick={onClearCart}>
              <Trash2 className="h-4 w-4 mr-1" />
              Clear
            </Button>
          )}
        </div>
        
        {/* Customer Selection */}
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={onSelectCustomer}
            className="flex-1"
          >
            <User className="h-4 w-4 mr-1" />
            {selectedCustomer ? selectedCustomer.name : 'Select Customer'}
          </Button>
        </div>
      </div>

      {/* Cart Items */}
      <ScrollArea className="flex-1 p-4">
        {cart.length > 0 ? (
          <div className="space-y-3">
            {cart.map((item) => (
              <CartItemCard
                key={item.product_id}
                item={item}
                onUpdateQuantity={onUpdateQuantity}
                onRemoveItem={onRemoveItem}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-gray-500">
            <ShoppingCart className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>Cart is empty</p>
            <p className="text-sm">Scan or search for products to add</p>
          </div>
        )}
      </ScrollArea>

      {/* Special Features */}
      {cart.length > 0 && (
        <div className="p-4 border-t space-y-3">
          {/* Prescription Toggle */}
          <div className="flex items-center justify-between">
            <Label htmlFor="prescription" className="text-sm font-medium flex items-center gap-2">
              <Stethoscope className="h-4 w-4" />
              Prescription Sale
            </Label>
            <Switch
              id="prescription"
              checked={isPrescriptionSale}
              onCheckedChange={onTogglePrescription}
            />
          </div>
          
          {isPrescriptionSale && (
            <div className="space-y-2">
              <Input
                placeholder="Prescription Number"
                value={prescriptionNumber}
                onChange={(e) => onPrescriptionNumberChange(e.target.value)}
                className="text-sm"
              />
              <Input
                placeholder="Doctor Name"
                value={doctorName}
                onChange={(e) => onDoctorNameChange(e.target.value)}
                className="text-sm"
              />
            </div>
          )}

          {/* Insurance Toggle */}
          <div className="flex items-center justify-between">
            <Label htmlFor="insurance" className="text-sm font-medium flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Insurance Claim
            </Label>
            <Switch
              id="insurance"
              checked={useInsurance}
              onCheckedChange={onToggleInsurance}
            />
          </div>
          
          {useInsurance && (
            <div className="space-y-2">
              <Select 
                value={insuranceProvider} 
                onValueChange={onInsuranceProviderChange}
              >
                <SelectTrigger className="text-sm">
                  <SelectValue placeholder="Select insurance provider" />
                </SelectTrigger>
                <SelectContent>
                  {INSURANCE_PROVIDERS.map((provider) => (
                    <SelectItem key={provider} value={provider}>
                      {provider}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                placeholder="Insurance Number"
                value={insuranceNumber}
                onChange={(e) => onInsuranceNumberChange(e.target.value)}
                className="text-sm"
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
}

interface CartItemCardProps {
  item: CartItem;
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
}

function CartItemCard({ item, onUpdateQuantity, onRemoveItem }: CartItemCardProps) {
  return (
    <Card className="p-3">
      <div className="flex justify-between items-start mb-2">
        <h4 className="font-medium text-sm line-clamp-2 flex-1 mr-2">
          {item.product_name}
        </h4>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => onRemoveItem(item.product_id)}
          className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
        >
          <X className="h-3 w-3" />
        </Button>
      </div>
      
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onUpdateQuantity(item.product_id, item.quantity - 1)}
            className="h-7 w-7 p-0"
          >
            <Minus className="h-3 w-3" />
          </Button>
          <span className="w-8 text-center font-medium">{item.quantity}</span>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onUpdateQuantity(item.product_id, item.quantity + 1)}
            className="h-7 w-7 p-0"
            disabled={item.quantity >= item.availableStock}
          >
            <Plus className="h-3 w-3" />
          </Button>
        </div>
        <div className="text-right">
          <div className="text-sm text-gray-500">
            {formatTZS(item.unit_price)} × {item.quantity}
          </div>
          <div className="font-semibold">
            {formatTZS(item.total)}
          </div>
        </div>
      </div>
      
      {item.availableStock <= item.product.min_stock_level && (
        <div className="flex items-center gap-1 text-xs text-orange-600">
          <AlertCircle className="h-3 w-3" />
          Low stock: {item.availableStock} remaining
        </div>
      )}
    </Card>
  );
}