import React from 'react';
import { DollarSign, ExternalLink, Clock, TrendingUp, AlertCircle, CheckCircle } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { AISystemStatus } from '../lib/app-constants';

interface QuotaManagementPanelProps {
  aiSystemStatus: AISystemStatus;
  quotaInfo?: {
    exceeded: boolean;
    resetTime?: string;
    upgradeUrl?: string;
    currentTier?: string;
    dailyLimit?: string;
  };
  className?: string;
}

export function QuotaManagementPanel({ aiSystemStatus, quotaInfo, className = '' }: QuotaManagementPanelProps) {
  if (aiSystemStatus !== 'quota-exceeded' && aiSystemStatus !== 'auth-error') {
    return null;
  }

  const isQuotaExceeded = aiSystemStatus === 'quota-exceeded';
  const isAuthError = aiSystemStatus === 'auth-error';

  return (
    <Card className={`p-4 border-l-4 ${isQuotaExceeded ? 'border-l-orange-500 bg-orange-50' : 'border-l-red-500 bg-red-50'} ${className}`}>
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-start gap-3">
          {isQuotaExceeded ? (
            <DollarSign className="h-5 w-5 text-orange-600 mt-0.5" />
          ) : (
            <AlertCircle className="h-5 w-5 text-red-600 mt-0.5" />
          )}
          <div className="flex-1">
            <h3 className={`font-semibold ${isQuotaExceeded ? 'text-orange-800' : 'text-red-800'}`}>
              {isQuotaExceeded ? 'Gemini API Quota Exceeded' : 'Gemini API Authentication Error'}
            </h3>
            <p className={`text-sm ${isQuotaExceeded ? 'text-orange-700' : 'text-red-700'} mt-1`}>
              {isQuotaExceeded 
                ? 'Your free tier quota has been reached. The system is using intelligent fallback analysis.'
                : 'API key authentication failed. Please check your Gemini API key configuration.'
              }
            </p>
          </div>
          <Badge variant={isQuotaExceeded ? 'secondary' : 'destructive'} className="text-xs">
            {isQuotaExceeded ? 'Quota Issue' : 'Auth Issue'}
          </Badge>
        </div>

        {/* Current Status */}
        <div className="bg-white/50 rounded-lg p-3 space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Current Status:</span>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span className="text-green-700 font-medium">Fallback Analysis Active</span>
            </div>
          </div>
          
          {isQuotaExceeded && quotaInfo && (
            <>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Current Tier:</span>
                <span className="font-medium">{quotaInfo.currentTier || 'Free Tier'}</span>
              </div>
              
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Daily Limit:</span>
                <span className="font-medium">{quotaInfo.dailyLimit || '50 requests'}</span>
              </div>
              
              {quotaInfo.resetTime && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Estimated Reset:</span>
                  <div className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    <span className="font-medium">
                      {new Date(quotaInfo.resetTime).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Solutions */}
        <div className="space-y-3">
          <h4 className="font-medium text-gray-800">Solutions:</h4>
          
          {isQuotaExceeded ? (
            <div className="space-y-2">
              <div className="flex items-start gap-2 text-sm">
                <TrendingUp className="h-4 w-4 text-blue-600 mt-0.5" />
                <div>
                  <span className="font-medium">Upgrade your Google Cloud Plan</span>
                  <p className="text-gray-600">Get higher quotas and remove daily limits</p>
                </div>
              </div>
              
              <div className="flex items-start gap-2 text-sm">
                <Clock className="h-4 w-4 text-green-600 mt-0.5" />
                <div>
                  <span className="font-medium">Wait for quota reset</span>
                  <p className="text-gray-600">Free tier quota resets daily (typically midnight UTC)</p>
                </div>
              </div>
              
              <div className="flex items-start gap-2 text-sm">
                <CheckCircle className="h-4 w-4 text-purple-600 mt-0.5" />
                <div>
                  <span className="font-medium">Continue with fallback analysis</span>
                  <p className="text-gray-600">Full functionality available with intelligent local analysis</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="flex items-start gap-2 text-sm">
                <AlertCircle className="h-4 w-4 text-red-600 mt-0.5" />
                <div>
                  <span className="font-medium">Check your API key</span>
                  <p className="text-gray-600">Verify your Gemini API key in .env.local is correct</p>
                </div>
              </div>
              
              <div className="flex items-start gap-2 text-sm">
                <ExternalLink className="h-4 w-4 text-blue-600 mt-0.5" />
                <div>
                  <span className="font-medium">Enable Gemini API</span>
                  <p className="text-gray-600">Ensure the Generative Language API is enabled in Google Cloud</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 pt-2">
          {isQuotaExceeded ? (
            <Button 
              size="sm" 
              onClick={() => window.open('https://console.cloud.google.com/billing', '_blank')}
              className="flex items-center gap-2"
            >
              <ExternalLink className="h-3 w-3" />
              Upgrade Plan
            </Button>
          ) : (
            <Button 
              size="sm" 
              onClick={() => window.open('https://console.cloud.google.com/apis/library/generativelanguage.googleapis.com', '_blank')}
              className="flex items-center gap-2"
            >
              <ExternalLink className="h-3 w-3" />
              Manage API
            </Button>
          )}
          
          <Button 
            size="sm" 
            variant="outline"
            onClick={() => window.location.reload()}
          >
            Retry Connection
          </Button>
        </div>

        {/* Fallback Assurance */}
        <div className="bg-green-50 border border-green-200 rounded-lg p-3">
          <div className="flex items-start gap-2">
            <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
            <div className="text-sm">
              <span className="font-medium text-green-800">System fully operational</span>
              <p className="text-green-700 mt-1">
                Your shop dashboard continues to work normally with intelligent fallback analysis. 
                All features remain available including sales recording, analytics, and reporting.
              </p>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}