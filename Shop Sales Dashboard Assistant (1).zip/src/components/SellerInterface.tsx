import React, { useState, useEffect } from 'react';
import { SalesForm } from './SalesForm';
import { PageHeader } from './PageHeader';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { TrendingUp, DollarSign, ShoppingCart, Clock, AlertTriangle, Shield } from 'lucide-react';
import { Sale, UserProfile } from '../lib/firebase-types';
import { FirebaseService } from '../lib/firebase';
import { useError } from '../contexts/ErrorContext';
import { formatTZS } from '../lib/currency-utils';
import { toast } from 'sonner@2.0.3';

interface SellerInterfaceProps {
  onBack: () => void;
  userProfile: UserProfile | null;
}

export function SellerInterface({ onBack, userProfile }: SellerInterfaceProps) {
  const [todaysSales, setTodaysSales] = useState<Sale[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [salesCount, setSalesCount] = useState(0);
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [realtimeUnsubscribe, setRealtimeUnsubscribe] = useState<(() => void) | null>(null);

  // Use error context for better error handling
  const { addError, addSuccess, addWarning, getPermissionErrors, hasErrorsOfType } = useError();

  useEffect(() => {
    if (userProfile?.shop_id) {
      loadTodaysSales();
      setupRealTimeUpdates();
    }

    // Cleanup function
    return () => {
      if (realtimeUnsubscribe) {
        console.log('🧹 Cleaning up real-time subscription');
        realtimeUnsubscribe();
      }
    };
  }, [userProfile]);

  // Check for permission errors that would block sales
  const permissionErrors = getPermissionErrors();
  const hasPermissionErrors = permissionErrors.length > 0;
  const hasRecentSaleErrors = hasErrorsOfType('permission') && 
    permissionErrors.some(error => 
      error.context.toLowerCase().includes('sale') ||
      error.context.toLowerCase().includes('creating sale')
    );

  const loadTodaysSales = async () => {
    if (!userProfile?.shop_id) return;

    try {
      setIsLoading(true);
      const sales = await FirebaseService.getTodaysSales(userProfile.shop_id);
      
      // Ensure unique sales and sort by timestamp
      const uniqueSales = sales ? deduplicateSales(sales) : [];
      setTodaysSales(uniqueSales);
      
      // Calculate totals
      const count = uniqueSales.length;
      const revenue = uniqueSales.reduce((sum, sale) => sum + parseFloat(sale.total_price.toString()), 0);
      
      setSalesCount(count);
      setTotalRevenue(revenue);
      
      console.log(`✅ Loaded ${count} unique today's sales`);
    } catch (error) {
      console.error('Error loading today\'s sales:', error);
      addError(error, 'Loading Sales', 'Failed to load today\'s sales data');
    } finally {
      setIsLoading(false);
    }
  };

  const setupRealTimeUpdates = () => {
    if (!userProfile?.shop_id) return;

    try {
      console.log('📡 Setting up real-time sales updates for shop:', userProfile.shop_id);
      
      const unsubscribe = FirebaseService.subscribeToSales(
        userProfile.shop_id,
        (sales) => {
          console.log('📡 Real-time sales update received:', sales.length, 'sales');
          
          try {
            // Filter for today's sales
            const today = new Date().toDateString();
            const todaysData = sales.filter(sale => {
              const saleDate = new Date(sale.timestamp).toDateString();
              return saleDate === today;
            });
            
            // Ensure unique sales to prevent duplicate key warnings
            const uniqueTodaysSales = deduplicateSales(todaysData);
            
            setTodaysSales(uniqueTodaysSales);
            setSalesCount(uniqueTodaysSales.length);
            setTotalRevenue(uniqueTodaysSales.reduce((sum, sale) => sum + parseFloat(sale.total_price.toString()), 0));
            
            console.log(`✅ Real-time update processed: ${uniqueTodaysSales.length} unique today's sales`);
          } catch (processingError) {
            console.error('Error processing real-time update:', processingError);
            addError(processingError, 'Real-time Update Processing', 'Failed to process real-time sales update');
          }
        }
      );

      setRealtimeUnsubscribe(() => unsubscribe);
      console.log('✅ Real-time subscription established');

    } catch (error) {
      console.error('Error setting up real-time updates:', error);
      
      // Check if this is a permission error
      const errorMessage = error?.message || String(error);
      if (errorMessage.includes('permission-denied') || errorMessage.includes('Missing or insufficient permissions')) {
        addError(error, 'Real-time Updates', '🚨 Real-time updates blocked by Firebase security rules. Deploy rules to enable live updates.');
      } else {
        addError(error, 'Real-time Updates', 'Failed to set up live sales updates');
      }
    }
  };

  // Helper function to remove duplicate sales and ensure unique keys
  const deduplicateSales = (sales: Sale[]): Sale[] => {
    const seen = new Set<string>();
    const unique: Sale[] = [];
    
    // Sort by timestamp (newest first) before deduplication
    const sorted = [...sales].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    for (const sale of sorted) {
      const key = `${sale.id}-${sale.timestamp}`;
      if (!seen.has(key)) {
        seen.add(key);
        unique.push(sale);
      } else {
        console.warn('🚨 Duplicate sale detected and removed:', sale.id, sale.timestamp);
      }
    }
    
    console.log(`🧹 Deduplicated ${sales.length} sales to ${unique.length} unique sales`);
    return unique;
  };

  // Generate truly unique key for each sale
  const getSaleKey = (sale: Sale, index: number): string => {
    return `sale-${sale.id}-${sale.timestamp}-${index}`;
  };

  const handleSaleAdded = async (saleData: {
    item: string;
    quantity: number;
    unitPrice: number;
    totalPrice: number;
    productId?: string;
  }) => {
    if (!userProfile?.shop_id || !userProfile.id) {
      addError(new Error('User information missing'), 'Sale Creation', 'User information is missing. Please refresh the page and try again.');
      return;
    }

    try {
      console.log('🛒 Attempting to create sale:', saleData);
      
      const sale = await FirebaseService.createSale({
        item: saleData.item,
        quantity: saleData.quantity,
        unit_price: saleData.unitPrice,
        total_price: saleData.totalPrice,
        timestamp: new Date().toISOString(),
        seller_id: userProfile.id,
        shop_id: userProfile.shop_id,
        product_id: saleData.productId // Include product ID if available
      });

      console.log('✅ Sale created successfully:', sale.id);
      addSuccess(`Sale recorded: ${sale.item} - ${formatTZS(parseFloat(sale.total_price.toString()))}`, 'Sale Creation');
      
      // Update local state immediately for responsive UI
      // Real-time updates will also update, but this provides immediate feedback
      setTodaysSales(prev => {
        const newSales = [sale, ...prev];
        return deduplicateSales(newSales);
      });
      setSalesCount(prev => prev + 1);
      setTotalRevenue(prev => prev + parseFloat(sale.total_price.toString()));
      
    } catch (error) {
      console.error('❌ Error creating sale:', error);
      
      // Use enhanced error handling
      addError(error, 'Creating Sale', 'Failed to record sale. This may be a Firebase security rules issue.');
      
      // Check if this is a permission error and show specific guidance
      const errorMessage = error?.message || String(error);
      if (errorMessage.includes('permission-denied') || errorMessage.includes('Missing or insufficient permissions')) {
        console.log('🚨 PERMISSION ERROR in sale creation - this should trigger rules modal');
        
        // Additional toast for immediate user feedback
        toast.error('🚨 Sale Blocked by Firebase Rules', {
          description: 'Deploy security rules to enable sales recording',
          duration: 8000,
        });
      }
    }
  };

  const formatCurrency = (amount: number) => {
    return formatTZS(amount);
  };

  const averageTransaction = salesCount > 0 ? totalRevenue / salesCount : 0;

  return (
    <div className="max-w-6xl mx-auto">
      {/* Page Header with Navigation */}
      <PageHeader
        title="Sales Recording"
        description={`Record sales transactions • ${userProfile?.full_name} • ${userProfile?.shop?.name}`}
        breadcrumbs={[{ label: 'Sales Recording', icon: <ShoppingCart className="h-4 w-4" /> }]}
        badge={
          hasPermissionErrors 
            ? { text: 'Rules Issue', variant: 'destructive' }
            : { text: 'Live Updates', variant: 'secondary' }
        }
      />

        {/* Permission Error Alert */}
        {hasRecentSaleErrors && (
          <Alert variant="destructive" className="mb-6 bg-red-50 border-red-300">
            <Shield className="h-4 w-4 text-red-600" />
            <AlertDescription>
              <div className="text-red-800">
                <strong className="text-red-900">🚨 CRITICAL: Sales Recording Blocked</strong>
                <div className="mt-1 text-sm">
                  Firebase security rules are preventing sale creation. Use the Critical Rules Modal to deploy working rules immediately.
                </div>
                <div className="mt-2 text-xs">
                  <strong>Recent Error:</strong> {permissionErrors[permissionErrors.length - 1]?.userFriendlyMessage}
                </div>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Daily Stats */}
        <div className="grid md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Today's Sales</p>
                  <p className="text-2xl font-bold text-gray-900">{salesCount}</p>
                </div>
                <ShoppingCart className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Revenue</p>
                  <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalRevenue)}</p>
                </div>
                <DollarSign className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Avg Transaction</p>
                  <p className="text-2xl font-bold text-gray-900">{formatCurrency(averageTransaction)}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Sales Form */}
          <div className="lg:col-span-1">
            <SalesForm 
              onSaleAdded={handleSaleAdded} 
              shopId={userProfile?.shop_id || ''} 
            />
            
            {/* Permission Error Notice on Sales Form */}
            {hasPermissionErrors && (
              <Alert variant="destructive" className="mt-4 bg-red-50 border-red-300">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800 text-sm">
                  <strong>Sales Form Disabled:</strong> Firebase rules prevent sale recording. 
                  Deploy rules using the modal to enable this feature.
                </AlertDescription>
              </Alert>
            )}
          </div>

          {/* Recent Sales */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Today's Sales Activity</CardTitle>
                <p className="text-sm text-gray-600">
                  Real-time sales recorded today • {salesCount} transactions
                </p>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-3">
                    {[1, 2, 3].map((i) => (
                      <div key={`loading-${i}`} className="animate-pulse">
                        <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                      </div>
                    ))}
                  </div>
                ) : todaysSales.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <ShoppingCart className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No sales recorded today yet.</p>
                    <p className="text-sm">
                      {hasPermissionErrors 
                        ? 'Deploy Firebase rules first, then use the form to record sales!'
                        : 'Use the form to record your first sale!'
                      }
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {todaysSales.map((sale, index) => (
                      <div
                        key={getSaleKey(sale, index)}
                        className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                      >
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium text-gray-900">{sale.item}</h4>
                            <span className="font-semibold text-green-600">
                              {formatCurrency(parseFloat(sale.total_price.toString()))}
                            </span>
                          </div>
                          <div className="flex items-center text-sm text-gray-600 mt-1">
                            <span>Qty: {sale.quantity}</span>
                            <span className="mx-2">•</span>
                            <span>{formatCurrency(parseFloat(sale.unit_price.toString()))} each</span>
                            <span className="mx-2">•</span>
                            <span>{new Date(sale.timestamp).toLocaleTimeString()}</span>
                          </div>
                          {sale.seller && (
                            <p className="text-xs text-gray-500 mt-1">
                              Sold by: {sale.seller.full_name}
                            </p>
                          )}
                          {/* Add unique identifier for debugging */}
                          <p className="text-xs text-gray-400 mt-1">
                            ID: {sale.id}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Debug Information for Permission Errors */}
        {hasPermissionErrors && (
          <div className="mt-8">
            <Card className="bg-red-50 border-red-300">
              <CardHeader>
                <CardTitle className="text-red-900">🚨 Permission Error Debug Info</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-red-800 text-sm space-y-2">
                  <div><strong>Total Permission Errors:</strong> {permissionErrors.length}</div>
                  <div><strong>Sale-Related Errors:</strong> {permissionErrors.filter(e => 
                    e.context.toLowerCase().includes('sale')).length}</div>
                  <div><strong>Latest Error:</strong> {permissionErrors[permissionErrors.length - 1]?.message}</div>
                  <div><strong>Error Context:</strong> {permissionErrors[permissionErrors.length - 1]?.context}</div>
                  <div><strong>Error Time:</strong> {permissionErrors[permissionErrors.length - 1]?.timestamp}</div>
                  <div><strong>Today's Sales Count:</strong> {todaysSales.length}</div>
                  <div><strong>Realtime Active:</strong> {realtimeUnsubscribe ? 'Yes' : 'No'}</div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
    </div>
  );
}