import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { AlertTriangle, CheckCircle, XCircle, RefreshCw, Zap, Terminal, Copy, ExternalLink } from 'lucide-react';
import { FirebaseService, UserProfile, auth, db } from '../lib/firebase';
import { toast } from 'sonner@2.0.3';
import { doc, getDoc, setDoc, collection, addDoc } from 'firebase/firestore';

interface EnhancedFirebasePermissionTesterProps {
  userProfile: UserProfile | null;
}

interface TestResult {
  status: 'pending' | 'success' | 'error' | 'warning';
  details: string[];
  recommendations: string[];
}

export function EnhancedFirebasePermissionTester({ userProfile }: EnhancedFirebasePermissionTesterProps) {
  const [testing, setTesting] = useState(false);
  const [currentStep, setCurrentStep] = useState<string>('');
  const [testResults, setTestResults] = useState<{
    authentication: TestResult;
    profileAccess: TestResult;
    rulesDeployment: TestResult;
    shopAccess: TestResult;
    productPermissions: TestResult;
    productCreation: TestResult;
  }>({
    authentication: { status: 'pending', details: [], recommendations: [] },
    profileAccess: { status: 'pending', details: [], recommendations: [] },
    rulesDeployment: { status: 'pending', details: [], recommendations: [] },
    shopAccess: { status: 'pending', details: [], recommendations: [] },
    productPermissions: { status: 'pending', details: [], recommendations: [] },
    productCreation: { status: 'pending', details: [], recommendations: [] }
  });

  // Test authentication state
  const testAuthentication = async (): Promise<TestResult> => {
    const details: string[] = [];
    const recommendations: string[] = [];
    
    try {
      const currentUser = auth.currentUser;
      
      if (!currentUser) {
        details.push('❌ No authenticated user found');
        recommendations.push('Sign in to your account first');
        return { status: 'error', details, recommendations };
      }
      
      details.push(`✅ User authenticated: ${currentUser.email}`);
      details.push(`📧 Email verified: ${currentUser.emailVerified ? '✅ Yes' : '⚠️ No'}`);
      details.push(`🔑 UID: ${currentUser.uid}`);
      
      // Check token validity
      try {
        await currentUser.getIdToken(true); // Force refresh
        details.push('✅ Auth token is valid and refreshed');
      } catch (tokenError) {
        details.push('❌ Auth token refresh failed');
        recommendations.push('Sign out and sign in again');
        return { status: 'error', details, recommendations };
      }
      
      return { status: 'success', details, recommendations };
    } catch (error: any) {
      details.push(`❌ Authentication error: ${error.message}`);
      recommendations.push('Check your internet connection and try again');
      return { status: 'error', details, recommendations };
    }
  };

  // Test profile access
  const testProfileAccess = async (): Promise<TestResult> => {
    const details: string[] = [];
    const recommendations: string[] = [];
    
    try {
      if (!auth.currentUser) {
        details.push('❌ Cannot test - user not authenticated');
        return { status: 'error', details, recommendations };
      }
      
      // Direct Firestore access test
      const profileRef = doc(db, 'profiles', auth.currentUser.uid);
      const profileDoc = await getDoc(profileRef);
      
      if (!profileDoc.exists()) {
        details.push('❌ Profile document does not exist in Firestore');
        recommendations.push('Create user profile document in Firestore');
        recommendations.push('Contact admin to set up your account');
        return { status: 'error', details, recommendations };
      }
      
      const profileData = profileDoc.data();
      details.push('✅ Profile document found in Firestore');
      details.push(`👤 Name: ${profileData.full_name || 'Not set'}`);
      details.push(`🔑 Role: ${profileData.role || 'Not set'}`);
      details.push(`🏪 Shop ID: ${profileData.shop_id || 'Not assigned'}`);
      details.push(`📧 Email: ${profileData.email || 'Not set'}`);
      details.push(`🕐 Created: ${profileData.created_at || 'Unknown'}`);
      
      // Validate profile data
      if (!profileData.role) {
        details.push('⚠️ No role assigned to user');
        recommendations.push('Contact admin to assign a role');
        return { status: 'warning', details, recommendations };
      }
      
      const validRoles = ['admin', 'owner', 'manager', 'seller', 'cashier', 'pharmacist', 'pharmacy_assistant', 'inventory_clerk'];
      if (!validRoles.includes(profileData.role)) {
        details.push(`❌ Invalid role: ${profileData.role}`);
        recommendations.push(`Valid roles: ${validRoles.join(', ')}`);
        return { status: 'error', details, recommendations };
      }
      
      // Check if role can create products
      const productCreatorRoles = ['admin', 'owner', 'manager'];
      if (!productCreatorRoles.includes(profileData.role)) {
        details.push(`⚠️ Role '${profileData.role}' cannot create products`);
        details.push(`✅ But profile access is working`);
        recommendations.push(`For product creation, you need one of these roles: ${productCreatorRoles.join(', ')}`);
        return { status: 'warning', details, recommendations };
      }
      
      if (!profileData.shop_id) {
        details.push('❌ No shop assignment found');
        recommendations.push('Contact admin to assign you to a shop');
        return { status: 'error', details, recommendations };
      }
      
      details.push('✅ Profile data is valid for product creation');
      return { status: 'success', details, recommendations };
    } catch (error: any) {
      if (error.code === 'permission-denied') {
        details.push('❌ Permission denied accessing profile');
        details.push('🚨 This indicates Firestore rules are not deployed');
        recommendations.push('Deploy Firestore security rules immediately');
        recommendations.push('Run: firebase deploy --only firestore:rules');
      } else {
        details.push(`❌ Profile access error: ${error.message}`);
        recommendations.push('Check your internet connection');
      }
      return { status: 'error', details, recommendations };
    }
  };

  // Test rules deployment
  const testRulesDeployment = async (): Promise<TestResult> => {
    const details: string[] = [];
    const recommendations: string[] = [];
    
    try {
      // Test basic read operation that should work with proper rules
      const testDoc = doc(db, 'system_settings', 'test');
      
      try {
        await getDoc(testDoc);
        details.push('✅ Basic Firestore read operation successful');
      } catch (readError: any) {
        if (readError.code === 'permission-denied') {
          details.push('❌ Basic read operation failed - Permission denied');
          details.push('🚨 CRITICAL: Firestore security rules are NOT deployed');
          recommendations.push('IMMEDIATE ACTION REQUIRED:');
          recommendations.push('1. Open terminal in project directory');
          recommendations.push('2. Run: firebase deploy --only firestore:rules');
          recommendations.push('3. Wait for deployment to complete');
          recommendations.push('4. Refresh this page and test again');
          return { status: 'error', details, recommendations };
        }
      }
      
      // Test if we can access collections that require authentication
      if (auth.currentUser && userProfile?.shop_id) {
        try {
          const productsCollection = collection(db, 'products');
          // This should work if rules are properly deployed
          details.push('✅ Products collection accessible');
          details.push('✅ Firestore security rules appear to be deployed');
        } catch (collectionError: any) {
          if (collectionError.code === 'permission-denied') {
            details.push('❌ Products collection access denied');
            details.push('⚠️ Rules may be deployed but user lacks permissions');
            recommendations.push('Check user role and shop assignment');
            return { status: 'warning', details, recommendations };
          }
        }
      }
      
      return { status: 'success', details, recommendations };
    } catch (error: any) {
      details.push(`❌ Rules deployment test failed: ${error.message}`);
      recommendations.push('Contact Firebase admin for assistance');
      return { status: 'error', details, recommendations };
    }
  };

  // Test shop access
  const testShopAccess = async (): Promise<TestResult> => {
    const details: string[] = [];
    const recommendations: string[] = [];
    
    try {
      if (!userProfile?.shop_id) {
        details.push('❌ No shop ID in user profile');
        recommendations.push('Contact admin to assign you to a shop');
        return { status: 'error', details, recommendations };
      }
      
      // Try to access shop document
      const shopRef = doc(db, 'shops', userProfile.shop_id);
      
      try {
        const shopDoc = await getDoc(shopRef);
        
        if (!shopDoc.exists()) {
          details.push(`❌ Shop document '${userProfile.shop_id}' does not exist`);
          recommendations.push('Contact admin to create the shop document');
          return { status: 'error', details, recommendations };
        }
        
        const shopData = shopDoc.data();
        details.push('✅ Shop document found and accessible');
        details.push(`🏪 Shop Name: ${shopData.name || 'Unnamed'}`);
        details.push(`👤 Owner: ${shopData.owner_id || 'Not set'}`);
        details.push(`🏢 Category: ${shopData.category || 'Not set'}`);
        
        return { status: 'success', details, recommendations };
      } catch (shopError: any) {
        if (shopError.code === 'permission-denied') {
          details.push('❌ Permission denied accessing shop document');
          details.push('🚨 User does not have access to assigned shop');
          recommendations.push('Check if user is properly assigned to shop');
          recommendations.push('Contact admin to verify shop permissions');
        } else {
          details.push(`❌ Shop access error: ${shopError.message}`);
        }
        return { status: 'error', details, recommendations };
      }
    } catch (error: any) {
      details.push(`❌ Shop access test failed: ${error.message}`);
      return { status: 'error', details, recommendations };
    }
  };

  // Test product permissions
  const testProductPermissions = async (): Promise<TestResult> => {
    const details: string[] = [];
    const recommendations: string[] = [];
    
    try {
      if (!userProfile?.shop_id) {
        details.push('❌ Cannot test - no shop assignment');
        return { status: 'error', details, recommendations };
      }
      
      // Test reading products collection
      try {
        const products = await FirebaseService.getProducts(userProfile.shop_id);
        details.push('✅ Can read products collection');
        details.push(`📦 Found ${products.length} products in shop`);
      } catch (readError: any) {
        if (readError.message.includes('permission-denied') || readError.message.includes('CRITICAL: Firebase permission')) {
          details.push('❌ Cannot read products - Permission denied');
          details.push('🚨 This confirms rules deployment issue');
          recommendations.push('Deploy Firestore rules immediately');
          return { status: 'error', details, recommendations };
        } else {
          details.push(`⚠️ Product read warning: ${readError.message}`);
        }
      }
      
      // Check user role for product creation
      const productCreatorRoles = ['admin', 'owner', 'manager'];
      if (!productCreatorRoles.includes(userProfile.role)) {
        details.push(`❌ Role '${userProfile.role}' cannot create products`);
        details.push(`✅ Required roles: ${productCreatorRoles.join(', ')}`);
        recommendations.push('Contact admin to change your role for product management');
        return { status: 'warning', details, recommendations };
      }
      
      details.push(`✅ Role '${userProfile.role}' has product creation permissions`);
      return { status: 'success', details, recommendations };
    } catch (error: any) {
      details.push(`❌ Product permissions test failed: ${error.message}`);
      return { status: 'error', details, recommendations };
    }
  };

  // Test actual product creation
  const testProductCreation = async (): Promise<TestResult> => {
    const details: string[] = [];
    const recommendations: string[] = [];
    
    try {
      if (!userProfile?.shop_id) {
        details.push('❌ Cannot test - no shop assignment');
        return { status: 'error', details, recommendations };
      }
      
      const testProduct = {
        name: `PERMISSION_TEST_${Date.now()}`,
        sku: `TEST-${Date.now()}`,
        category: 'otc' as const,
        price: 1000,
        cost: 800,
        stock_quantity: 1,
        min_stock_level: 1,
        status: 'active' as const,
        shop_id: userProfile.shop_id,
        description: 'Automated permission test product - safe to delete',
        created_by: auth.currentUser?.uid || 'test-user',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      details.push('🔄 Attempting to create test product...');
      
      try {
        const createdProduct = await FirebaseService.createProduct(testProduct);
        details.push('✅ Test product created successfully!');
        details.push(`📦 Product ID: ${createdProduct.id}`);
        details.push('✅ Firebase write permissions are working');
        
        // Clean up test product
        try {
          await FirebaseService.deleteProduct(createdProduct.id);
          details.push('✅ Test product cleaned up successfully');
        } catch (cleanupError) {
          details.push('⚠️ Could not clean up test product (manual cleanup may be needed)');
        }
        
        details.push('🎉 ALL TESTS PASSED - Product import should work now!');
        return { status: 'success', details, recommendations };
      } catch (createError: any) {
        if (createError.message.includes('permission-denied') || createError.message.includes('CRITICAL: Firebase permission')) {
          details.push('❌ Product creation failed - Permission denied');
          details.push('🚨 FINAL CONFIRMATION: Rules are not deployed');
          recommendations.push('URGENT: Deploy Firebase security rules');
          recommendations.push('Command: firebase deploy --only firestore:rules');
          return { status: 'error', details, recommendations };
        } else if (createError.message.includes('already exists')) {
          details.push('⚠️ Product creation failed - Duplicate detected');
          details.push('✅ But this means permissions are working!');
          return { status: 'success', details, recommendations };
        } else {
          details.push(`❌ Product creation failed: ${createError.message}`);
          recommendations.push('Check error details and contact support if needed');
          return { status: 'error', details, recommendations };
        }
      }
    } catch (error: any) {
      details.push(`❌ Product creation test failed: ${error.message}`);
      return { status: 'error', details, recommendations };
    }
  };

  // Run all tests
  const runTests = async () => {
    setTesting(true);
    
    try {
      // Reset all test results
      setTestResults({
        authentication: { status: 'pending', details: [], recommendations: [] },
        profileAccess: { status: 'pending', details: [], recommendations: [] },
        rulesDeployment: { status: 'pending', details: [], recommendations: [] },
        shopAccess: { status: 'pending', details: [], recommendations: [] },
        productPermissions: { status: 'pending', details: [], recommendations: [] },
        productCreation: { status: 'pending', details: [], recommendations: [] }
      });
      
      // Test 1: Authentication
      setCurrentStep('Testing authentication...');
      const authResult = await testAuthentication();
      setTestResults(prev => ({ ...prev, authentication: authResult }));
      
      if (authResult.status === 'error') {
        setTesting(false);
        return;
      }
      
      // Test 2: Profile Access
      setCurrentStep('Testing profile access...');
      const profileResult = await testProfileAccess();
      setTestResults(prev => ({ ...prev, profileAccess: profileResult }));
      
      // Test 3: Rules Deployment
      setCurrentStep('Testing rules deployment...');
      const rulesResult = await testRulesDeployment();
      setTestResults(prev => ({ ...prev, rulesDeployment: rulesResult }));
      
      if (rulesResult.status === 'error') {
        setTesting(false);
        return;
      }
      
      // Test 4: Shop Access
      setCurrentStep('Testing shop access...');
      const shopResult = await testShopAccess();
      setTestResults(prev => ({ ...prev, shopAccess: shopResult }));
      
      // Test 5: Product Permissions
      setCurrentStep('Testing product permissions...');
      const permissionsResult = await testProductPermissions();
      setTestResults(prev => ({ ...prev, productPermissions: permissionsResult }));
      
      if (permissionsResult.status === 'success') {
        // Test 6: Product Creation
        setCurrentStep('Testing product creation...');
        const creationResult = await testProductCreation();
        setTestResults(prev => ({ ...prev, productCreation: creationResult }));
        
        if (creationResult.status === 'success') {
          toast.success('🎉 All tests passed! Product import should work now.');
        }
      }
      
    } catch (error: any) {
      console.error('Test execution error:', error);
      toast.error('Test execution failed. Check console for details.');
    } finally {
      setTesting(false);
      setCurrentStep('');
    }
  };

  const copyCommand = (command: string) => {
    navigator.clipboard.writeText(command);
    toast.success('Command copied to clipboard!');
  };

  const getStatusIcon = (status: 'pending' | 'success' | 'error' | 'warning') => {
    switch (status) {
      case 'success': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'error': return <XCircle className="h-4 w-4 text-red-600" />;
      case 'warning': return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      default: return <RefreshCw className="h-4 w-4 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: 'pending' | 'success' | 'error' | 'warning') => {
    switch (status) {
      case 'success': return <Badge variant="default" className="bg-green-100 text-green-800">Passed</Badge>;
      case 'error': return <Badge variant="destructive">Failed</Badge>;
      case 'warning': return <Badge variant="outline" className="border-yellow-400 text-yellow-700">Warning</Badge>;
      default: return <Badge variant="outline">Pending</Badge>;
    }
  };

  const allTests = [
    { key: 'authentication', name: 'Authentication Check', result: testResults.authentication },
    { key: 'profileAccess', name: 'Profile Access', result: testResults.profileAccess },
    { key: 'rulesDeployment', name: 'Rules Deployment', result: testResults.rulesDeployment },
    { key: 'shopAccess', name: 'Shop Access', result: testResults.shopAccess },
    { key: 'productPermissions', name: 'Product Permissions', result: testResults.productPermissions },
    { key: 'productCreation', name: 'Product Creation', result: testResults.productCreation }
  ];

  const hasErrors = allTests.some(test => test.result.status === 'error');
  const allPassed = allTests.every(test => test.result.status === 'success' || test.result.status === 'pending');

  return (
    <Card className={`border-2 ${hasErrors ? 'border-red-200 bg-red-50' : 'border-yellow-200 bg-yellow-50'}`}>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Terminal className="h-5 w-5 text-blue-600 mr-2" />
          Enhanced Firebase Permission Diagnostic
        </CardTitle>
        <p className="text-sm text-gray-600">
          Comprehensive testing to identify and resolve Firebase permission issues affecting product imports.
        </p>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Current Status */}
        {testing && (
          <div className="flex items-center space-x-2 p-3 bg-blue-50 border border-blue-200 rounded">
            <RefreshCw className="h-4 w-4 animate-spin text-blue-600" />
            <span className="text-sm text-blue-800">{currentStep}</span>
          </div>
        )}

        {/* Test Results Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {allTests.map((test) => (
            <div key={test.key} className="flex items-center justify-between p-3 border rounded">
              <div className="flex items-center space-x-2">
                {getStatusIcon(test.result.status)}
                <span className="text-sm font-medium">{test.name}</span>
              </div>
              {getStatusBadge(test.result.status)}
            </div>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2">
          <Button 
            onClick={runTests} 
            disabled={testing}
            className="flex-1"
            variant={hasErrors ? "destructive" : "default"}
          >
            {testing ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Running Tests...
              </>
            ) : (
              <>
                <Zap className="mr-2 h-4 w-4" />
                Run Diagnostic
              </>
            )}
          </Button>
        </div>

        {/* Critical Error Alert */}
        {testResults.rulesDeployment.status === 'error' && (
          <div className="bg-red-50 border-2 border-red-200 rounded-lg p-4">
            <div className="flex items-center mb-3">
              <AlertTriangle className="h-5 w-5 text-red-600 mr-2" />
              <h3 className="font-bold text-red-900">CRITICAL: Firebase Rules Not Deployed</h3>
            </div>
            <div className="space-y-3">
              <p className="text-sm text-red-800">
                Your Firestore security rules are not deployed. This is blocking all product operations.
              </p>
              <div className="bg-red-100 p-3 rounded">
                <p className="text-xs font-semibold text-red-900 mb-2">IMMEDIATE FIX:</p>
                <div className="flex items-center space-x-2">
                  <code className="flex-1 bg-red-200 px-2 py-1 rounded text-xs text-red-900">
                    firebase deploy --only firestore:rules
                  </code>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => copyCommand('firebase deploy --only firestore:rules')}
                  >
                    <Copy className="h-3 w-3" />
                  </Button>
                </div>
              </div>
              <div className="text-xs text-red-700 space-y-1">
                <p>1. Open terminal in your project directory</p>
                <p>2. Run the command above</p>
                <p>3. Wait for "Deploy complete!"</p>
                <p>4. Refresh this page and test again</p>
              </div>
            </div>
          </div>
        )}

        {/* Success Message */}
        {testResults.productCreation.status === 'success' && (
          <div className="bg-green-50 border-2 border-green-200 rounded-lg p-4">
            <div className="flex items-center mb-2">
              <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
              <h3 className="font-bold text-green-900">All Tests Passed!</h3>
            </div>
            <p className="text-sm text-green-800">
              Your Firebase permissions are working correctly. Product import should now function normally.
            </p>
          </div>
        )}

        {/* Detailed Results */}
        {allTests.some(test => test.result.details.length > 0) && (
          <div className="space-y-3">
            <h4 className="font-semibold text-sm">Detailed Test Results:</h4>
            <div className="bg-gray-900 text-green-400 p-4 rounded text-xs font-mono max-h-96 overflow-y-auto">
              {allTests.map((test) => 
                test.result.details.length > 0 && (
                  <div key={test.key} className="mb-4">
                    <div className="text-yellow-400 font-bold border-b border-gray-700 pb-1 mb-2">
                      === {test.name.toUpperCase()} ===
                    </div>
                    {test.result.details.map((detail, index) => (
                      <div key={index} className="mb-1">{detail}</div>
                    ))}
                    {test.result.recommendations.length > 0 && (
                      <>
                        <div className="text-cyan-400 font-bold mt-2 mb-1">RECOMMENDATIONS:</div>
                        {test.result.recommendations.map((rec, index) => (
                          <div key={index} className="text-cyan-300 mb-1">→ {rec}</div>
                        ))}
                      </>
                    )}
                  </div>
                )
              )}
            </div>
          </div>
        )}

        {/* Help Links */}
        <div className="flex gap-2 text-xs">
          <Button variant="outline" size="sm" onClick={() => window.open('/FIREBASE_RULES_DEPLOYMENT_GUIDE.md', '_blank')}>
            <ExternalLink className="h-3 w-3 mr-1" />
            Deployment Guide
          </Button>
          <Button variant="outline" size="sm" onClick={() => window.open('/FIREBASE_PERMISSION_DEBUGGING.md', '_blank')}>
            <ExternalLink className="h-3 w-3 mr-1" />
            Debug Guide
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}