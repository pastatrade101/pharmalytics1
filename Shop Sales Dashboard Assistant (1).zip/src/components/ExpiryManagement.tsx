import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Checkbox } from './ui/checkbox';
import { 
  ArrowLeft, 
  Calendar as CalendarIcon,
  AlertTriangle, 
  AlertCircle, 
  Clock, 
  Trash2, 
  Download, 
  Settings, 
  Search,
  Package,
  Loader2,
  Eye,
  DollarSign,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { UserProfile, Product, ProductBatch, ExpiryAlert, DisposalRecord, ExpirySettings, FirebaseService } from '../lib/firebase';
import { useError } from '../contexts/ErrorContext';
import { ErrorDisplay } from './ErrorDisplay';
import { formatTZS } from '../lib/currency-utils';
import { format, isAfter, isBefore, addDays, differenceInDays, isValid } from 'date-fns';
import { cn } from './ui/utils';

interface ExpiryManagementProps {
  onBack: () => void;
  userProfile: UserProfile | null;
}

const DISPOSAL_METHODS = [
  'incineration',
  'return_to_supplier', 
  'pharmaceutical_waste',
  'other'
] as const;

// Fixed Calendar Date Picker Component
function CalendarDatePicker({ 
  date, 
  onDateChange, 
  placeholder = "Pick a date",
  disabled = false 
}: {
  date?: Date;
  onDateChange: (date: Date | undefined) => void;
  placeholder?: string;
  disabled?: boolean;
}) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="calendar-form-field">
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            className={cn(
              "w-full justify-start text-left font-normal",
              !date && "text-muted-foreground"
            )}
            disabled={disabled}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {date ? format(date, "PPP") : <span>{placeholder}</span>}
          </Button>
        </PopoverTrigger>
        <PopoverContent 
          className="w-auto p-0 calendar-popover" 
          align="start"
          side="bottom"
          style={{ zIndex: 999999 }}
          sideOffset={4}
        >
          <Calendar
            mode="single"
            selected={date}
            onSelect={onDateChange}
            initialFocus
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}

export function ExpiryManagement({ onBack, userProfile }: ExpiryManagementProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [products, setProducts] = useState<Product[]>([]);
  const [expiryAlerts, setExpiryAlerts] = useState<ExpiryAlert[]>([]);
  const [disposalRecords, setDisposalRecords] = useState<DisposalRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showDisposalDialog, setShowDisposalDialog] = useState(false);
  const [showBatchDialog, setShowBatchDialog] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);
  const [statusFilter, setStatusFilter] = useState('all');

  const { 
    addError, 
    addSuccess, 
    clearErrorsByContext, 
    hasErrorsInContext
  } = useError();

  const [disposalForm, setDisposalForm] = useState({
    disposal_method: 'pharmaceutical_waste' as const,
    disposal_location: '',
    cost_of_disposal: '',
    disposal_certificate: '',
    responsible_person: userProfile?.full_name || '',
    notes: '',
    regulatory_compliance: true
  });

  const [batchForm, setBatchForm] = useState({
    batch_number: '',
    expiry_date: new Date(),
    quantity: '',
    cost_price: '',
    supplier_info: '',
    received_date: new Date()
  });

  useEffect(() => {
    loadAllData();
  }, [userProfile]);

  const loadAllData = async () => {
    setLoading(true);
    clearErrorsByContext('Expiry Management');
    
    try {
      const loadedProducts = await FirebaseService.getProductsForCurrentUser();
      setProducts(loadedProducts);
    } catch (error: any) {
      addError(error, 'Expiry Management', 'Failed to load expiry management data.');
    } finally {
      setLoading(false);
    }
  };

  // Safe date formatting helper
  const formatExpiryDate = (dateValue: any) => {
    try {
      if (!dateValue) return 'No expiry date';
      const date = new Date(dateValue);
      if (isValid(date)) {
        return format(date, 'MMM dd, yyyy');
      }
      return 'Invalid date';
    } catch (error) {
      console.warn('Error formatting date:', dateValue, error);
      return 'Invalid date';
    }
  };

  // Safe date comparison helper
  const safeDateSort = (a: any, b: any) => {
    if (!a && !b) return 0;
    if (!a) return 1;
    if (!b) return -1;
    
    try {
      const dateA = new Date(a);
      const dateB = new Date(b);
      
      if (!isValid(dateA) && !isValid(dateB)) return 0;
      if (!isValid(dateA)) return 1;
      if (!isValid(dateB)) return -1;
      
      return dateA.getTime() - dateB.getTime();
    } catch (error) {
      console.warn('Error comparing dates:', a, b, error);
      return 0;
    }
  };

  // Get expiry status for a product
  const getExpiryStatus = (product: Product) => {
    if (!product.expiry_date) return { status: 'no_expiry', color: 'text-gray-500', days: null };
    
    try {
      const today = new Date();
      const expiryDate = new Date(product.expiry_date);
      
      if (!isValid(expiryDate)) {
        return { status: 'no_expiry', color: 'text-gray-500', days: null };
      }
      
      const daysUntilExpiry = differenceInDays(expiryDate, today);

      if (daysUntilExpiry < 0) {
        return { status: 'expired', color: 'text-red-600', days: Math.abs(daysUntilExpiry) };
      } else if (daysUntilExpiry <= 7) {
        return { status: 'critical', color: 'text-red-600', days: daysUntilExpiry };
      } else if (daysUntilExpiry <= 30) {
        return { status: 'warning', color: 'text-orange-600', days: daysUntilExpiry };
      } else {
        return { status: 'good', color: 'text-green-600', days: daysUntilExpiry };
      }
    } catch (error) {
      console.warn('Invalid expiry date for product:', product.name, product.expiry_date);
      return { status: 'no_expiry', color: 'text-gray-500', days: null };
    }
  };

  // Calculate expiry statistics with safe date handling
  const expiryStats = useMemo(() => {
    const today = new Date();
    
    const expiringSoon = products.filter(p => {
      if (!p.expiry_date) return false;
      try {
        const expiryDate = new Date(p.expiry_date);
        if (!isValid(expiryDate)) return false;
        const daysUntilExpiry = differenceInDays(expiryDate, today);
        return daysUntilExpiry <= 30 && daysUntilExpiry > 0;
      } catch (error) {
        console.warn('Invalid expiry date in stats calculation:', p.expiry_date);
        return false;
      }
    });

    const expired = products.filter(p => {
      if (!p.expiry_date) return false;
      try {
        const expiryDate = new Date(p.expiry_date);
        if (!isValid(expiryDate)) return false;
        return isBefore(expiryDate, today);
      } catch (error) {
        console.warn('Invalid expiry date in expired calculation:', p.expiry_date);
        return false;
      }
    });

    const criticallyExpiring = products.filter(p => {
      if (!p.expiry_date) return false;
      try {
        const expiryDate = new Date(p.expiry_date);
        if (!isValid(expiryDate)) return false;
        const daysUntilExpiry = differenceInDays(expiryDate, today);
        return daysUntilExpiry <= 7 && daysUntilExpiry > 0;
      } catch (error) {
        console.warn('Invalid expiry date in critical calculation:', p.expiry_date);
        return false;
      }
    });

    const totalValueAtRisk = [...expiringSoon, ...expired].reduce((sum, p) => 
      sum + (p.stock_quantity * (p.cost_price || 0)), 0
    );

    return {
      expiringSoon: expiringSoon.length,
      expired: expired.length,
      criticallyExpiring: criticallyExpiring.length,
      totalValueAtRisk,
      needsDisposal: expired.filter(p => p.stock_quantity > 0).length,
      productsWithExpiry: products.filter(p => {
        if (!p.expiry_date) return false;
        try {
          return isValid(new Date(p.expiry_date));
        } catch (error) {
          return false;
        }
      }).length,
      totalProducts: products.length
    };
  }, [products]);

  // Filtered and paginated products for overview table
  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      // Search filter
      const matchesSearch = searchTerm === '' || 
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (p.manufacturer && p.manufacturer.toLowerCase().includes(searchTerm.toLowerCase()));
      
      // Status filter
      if (statusFilter === 'all') return matchesSearch;
      
      const expiryStatus = getExpiryStatus(p);
      const matchesStatus = statusFilter === expiryStatus.status;
      
      return matchesSearch && matchesStatus;
    }).sort((a, b) => safeDateSort(a.expiry_date, b.expiry_date));
  }, [products, searchTerm, statusFilter]);

  const paginatedProducts = useMemo(() => {
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    return filteredProducts.slice(startIndex, endIndex);
  }, [filteredProducts, currentPage, pageSize]);

  const totalPages = Math.ceil(filteredProducts.length / pageSize);

  // Reset pagination when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, statusFilter]);

  const handleDisposeProduct = async (product: Product) => {
    setSelectedProduct(product);
    setDisposalForm({
      ...disposalForm,
      responsible_person: userProfile?.full_name || ''
    });
    setShowDisposalDialog(true);
  };

  const submitDisposal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct) return;

    setFormSubmitting(true);
    clearErrorsByContext('Product Disposal');

    try {
      await FirebaseService.updateProduct(selectedProduct.id, {
        stock_quantity: 0,
        status: 'inactive' as const,
        updated_by: userProfile?.id
      });

      setProducts(prev => prev.map(p => 
        p.id === selectedProduct.id 
          ? { ...p, stock_quantity: 0, status: 'inactive' as const }
          : p
      ));

      addSuccess(`Product "${selectedProduct.name}" disposed successfully`, 'Product Disposal');
      setShowDisposalDialog(false);
      resetDisposalForm();

    } catch (error) {
      addError(error, 'Product Disposal', 'Failed to record product disposal.');
    } finally {
      setFormSubmitting(false);
    }
  };

  const resetDisposalForm = () => {
    setDisposalForm({
      disposal_method: 'pharmaceutical_waste',
      disposal_location: '',
      cost_of_disposal: '',
      disposal_certificate: '',
      responsible_person: userProfile?.full_name || '',
      notes: '',
      regulatory_compliance: true
    });
    setSelectedProduct(null);
  };

  const exportExpiryReport = () => {
    try {
      const reportData = {
        generated_at: new Date().toISOString(),
        pharmacy: userProfile?.shop?.name || 'Unknown Pharmacy',
        statistics: expiryStats,
        expiring_products: products.filter(p => {
          if (!p.expiry_date) return false;
          try {
            const expiryDate = new Date(p.expiry_date);
            if (!isValid(expiryDate)) return false;
            const daysUntilExpiry = differenceInDays(expiryDate, new Date());
            return daysUntilExpiry <= 30;
          } catch (error) {
            return false;
          }
        }),
        disposal_records: disposalRecords
      };

      const dataStr = JSON.stringify(reportData, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `expiry-report-${format(new Date(), 'yyyy-MM-dd')}.json`;
      link.click();
      URL.revokeObjectURL(url);

      addSuccess('Expiry report exported successfully', 'Expiry Management');
    } catch (error) {
      addError(error, 'Expiry Management', 'Failed to export expiry report.');
    }
  };

  const hasErrors = hasErrorsInContext('Expiry Management') || 
                   hasErrorsInContext('Product Disposal');

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-indigo-600 mr-2" />
            <span>Loading expiry management data...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4 expiry-management-container">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="flex items-center">
              <CalendarIcon className="h-8 w-8 text-indigo-600 mr-2" />
              <h1 className="text-3xl font-bold text-gray-900">Expiry Management</h1>
            </div>
            <p className="text-gray-600 mt-1">
              Monitor and manage product expiry dates
            </p>
          </div>
          <div className="flex gap-2">
            <Button 
              onClick={exportExpiryReport}
              variant="outline" 
              size="sm"
            >
              <Download className="mr-2 h-4 w-4" />
              Export Report
            </Button>
            <Button 
              variant="outline" 
              size="sm"
            >
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </Button>
          </div>
        </div>

        {/* Error Display */}
        {hasErrors && (
          <div className="space-y-4 mb-6">
            <ErrorDisplay compact hideSystemErrors />
          </div>
        )}

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Expiring Soon</p>
                  <p className="text-2xl font-bold text-orange-600">{expiryStats.expiringSoon}</p>
                  <p className="text-xs text-gray-500 mt-1">Within 30 days</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-orange-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Expired</p>
                  <p className="text-2xl font-bold text-red-600">{expiryStats.expired}</p>
                  <p className="text-xs text-gray-500 mt-1">Need disposal</p>
                </div>
                <AlertCircle className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Critical</p>
                  <p className="text-2xl font-bold text-red-600">{expiryStats.criticallyExpiring}</p>
                  <p className="text-xs text-gray-500 mt-1">Within 7 days</p>
                </div>
                <Clock className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Value at Risk</p>
                  <p className="text-2xl font-bold text-red-600">{formatTZS(expiryStats.totalValueAtRisk)}</p>
                  <p className="text-xs text-gray-500 mt-1">Total cost value</p>
                </div>
                <DollarSign className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Alert Banner */}
        {(expiryStats.expired > 0 || expiryStats.criticallyExpiring > 0) && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
                <span className="text-red-800">
                  <strong>Urgent Attention Required:</strong> {expiryStats.expired} expired products and {expiryStats.criticallyExpiring} products expiring within 7 days.
                </span>
              </div>
              <Button variant="outline" size="sm" className="text-red-700 border-red-300">
                View Details
              </Button>
            </div>
          </div>
        )}

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="alerts">
              Alerts
              {expiryAlerts.filter(a => !a.is_acknowledged).length > 0 && (
                <Badge variant="destructive" className="ml-2 h-5 w-5 p-0 text-xs">
                  {expiryAlerts.filter(a => !a.is_acknowledged).length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="disposal">Disposal</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Product Expiry Overview</CardTitle>
                  <div className="flex gap-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        type="text"
                        placeholder="Search products..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-64"
                      />
                    </div>
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Filter by status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="expired">Expired</SelectItem>
                        <SelectItem value="critical">Critical ≤7 days</SelectItem>
                        <SelectItem value="warning">Warning ≤30 days</SelectItem>
                        <SelectItem value="good">Good &gt;30 days</SelectItem>
                        <SelectItem value="no_expiry">No Expiry Date</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {/* Summary info */}
                <div className="flex items-center justify-between mb-4 text-sm text-gray-600">
                  <span>
                    Showing {((currentPage - 1) * pageSize) + 1} to {Math.min(currentPage * pageSize, filteredProducts.length)} of {filteredProducts.length} products
                  </span>
                  <div className="flex items-center gap-2">
                    <span>Show:</span>
                    <Select value={pageSize.toString()} onValueChange={(value) => setPageSize(parseInt(value))}>
                      <SelectTrigger className="w-20">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="10">10</SelectItem>
                        <SelectItem value="15">15</SelectItem>
                        <SelectItem value="25">25</SelectItem>
                        <SelectItem value="50">50</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="rounded-md border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Product</TableHead>
                        <TableHead>SKU</TableHead>
                        <TableHead>Stock</TableHead>
                        <TableHead>Expiry Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Value</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {paginatedProducts.length > 0 ? (
                        paginatedProducts.map((product) => {
                          const expiryStatus = getExpiryStatus(product);
                          return (
                            <TableRow key={product.id}>
                              <TableCell>
                                <div>
                                  <div className="font-medium">{product.name}</div>
                                  <div className="text-sm text-gray-500">{product.manufacturer || 'N/A'}</div>
                                </div>
                              </TableCell>
                              <TableCell>
                                <code className="text-sm bg-gray-100 px-2 py-1 rounded">
                                  {product.sku}
                                </code>
                              </TableCell>
                              <TableCell>
                                <div className={`font-medium ${
                                  product.stock_quantity === 0 ? 'text-gray-500' : 'text-gray-900'
                                }`}>
                                  {product.stock_quantity} units
                                </div>
                              </TableCell>
                              <TableCell>
                                {product.expiry_date ? (
                                  <div>
                                    <div className="font-medium">
                                      {formatExpiryDate(product.expiry_date)}
                                    </div>
                                    <div className={`text-sm ${expiryStatus.color}`}>
                                      {expiryStatus.status === 'expired' 
                                        ? `Expired ${expiryStatus.days} days ago`
                                        : expiryStatus.status === 'no_expiry'
                                        ? 'No expiry date'
                                        : `${expiryStatus.days} days remaining`
                                      }
                                    </div>
                                  </div>
                                ) : (
                                  <span className="text-gray-400">No expiry date</span>
                                )}
                              </TableCell>
                              <TableCell>
                                <Badge className={
                                  expiryStatus.status === 'expired' ? 'bg-red-100 text-red-800' :
                                  expiryStatus.status === 'critical' ? 'bg-red-100 text-red-800' :
                                  expiryStatus.status === 'warning' ? 'bg-orange-100 text-orange-800' :
                                  'bg-green-100 text-green-800'
                                }>
                                  {expiryStatus.status === 'expired' ? 'Expired' :
                                   expiryStatus.status === 'critical' ? 'Critical' :
                                   expiryStatus.status === 'warning' ? 'Warning' :
                                   expiryStatus.status === 'good' ? 'Good' : 'No Expiry'}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <div className="font-medium">
                                  {formatTZS(product.stock_quantity * (product.cost_price || 0))}
                                </div>
                              </TableCell>
                              <TableCell className="text-right">
                                <div className="flex gap-2 justify-end">
                                  {expiryStatus.status === 'expired' && product.stock_quantity > 0 && (
                                    <Button
                                      onClick={() => handleDisposeProduct(product)}
                                      size="sm"
                                      variant="outline"
                                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  )}
                                  <Button
                                    size="sm"
                                    variant="outline"
                                  >
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          );
                        })
                      ) : (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center py-12">
                            <div className="space-y-4">
                              <Package className="h-16 w-16 text-gray-400 mx-auto" />
                              <div>
                                <h3 className="font-medium text-gray-900 mb-2">No products found</h3>
                                <p className="text-gray-600 mb-4">
                                  {searchTerm || statusFilter !== 'all' 
                                    ? 'Try adjusting your search or filters'
                                    : 'No products with expiry dates found'
                                  }
                                </p>
                                {(searchTerm || statusFilter !== 'all') && (
                                  <Button
                                    variant="outline"
                                    onClick={() => {
                                      setSearchTerm('');
                                      setStatusFilter('all');
                                    }}
                                  >
                                    Clear Filters
                                  </Button>
                                )}
                              </div>
                            </div>
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-between mt-6">
                    <div className="text-sm text-gray-600">
                      Page {currentPage} of {totalPages}
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                        disabled={currentPage === 1}
                      >
                        <ChevronLeft className="h-4 w-4" />
                        Previous
                      </Button>
                      
                      <div className="flex gap-1">
                        {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                          let pageNumber;
                          if (totalPages <= 5) {
                            pageNumber = i + 1;
                          } else if (currentPage <= 3) {
                            pageNumber = i + 1;
                          } else if (currentPage >= totalPages - 2) {
                            pageNumber = totalPages - 4 + i;
                          } else {
                            pageNumber = currentPage - 2 + i;
                          }
                          
                          return (
                            <Button
                              key={pageNumber}
                              variant={pageNumber === currentPage ? "default" : "outline"}
                              size="sm"
                              onClick={() => setCurrentPage(pageNumber)}
                              className="w-10"
                            >
                              {pageNumber}
                            </Button>
                          );
                        })}
                      </div>
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                        disabled={currentPage === totalPages}
                      >
                        Next
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Other tabs content */}
          <TabsContent value="alerts" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Expiry Alerts</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Alert management functionality will be implemented here.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="disposal" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Product Disposal Records</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Disposal records and management functionality will be implemented here.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Expiry Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Comprehensive expiry reporting functionality will be implemented here.</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Disposal Dialog */}
      <Dialog open={showDisposalDialog} onOpenChange={setShowDisposalDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Dispose Expired Product</DialogTitle>
          </DialogHeader>
          <form onSubmit={submitDisposal} className="space-y-4">
            {selectedProduct && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium">Product: {selectedProduct.name}</h4>
                <p className="text-sm text-gray-600">SKU: {selectedProduct.sku}</p>
                <p className="text-sm text-gray-600">
                  Expiry Date: {formatExpiryDate(selectedProduct.expiry_date)}
                </p>
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="disposal_method">Disposal Method *</Label>
                <Select 
                  value={disposalForm.disposal_method} 
                  onValueChange={(value: typeof disposalForm.disposal_method) => 
                    setDisposalForm({ ...disposalForm, disposal_method: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pharmaceutical_waste">Pharmaceutical Waste</SelectItem>
                    <SelectItem value="incineration">Incineration</SelectItem>
                    <SelectItem value="return_to_supplier">Return to Supplier</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="disposal_location">Disposal Location</Label>
                <Input
                  id="disposal_location"
                  value={disposalForm.disposal_location}
                  onChange={(e) => setDisposalForm({ ...disposalForm, disposal_location: e.target.value })}
                  placeholder="Location where disposed"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="cost_of_disposal">Cost of Disposal</Label>
                <Input
                  id="cost_of_disposal"
                  type="number"
                  step="0.01"
                  value={disposalForm.cost_of_disposal}
                  onChange={(e) => setDisposalForm({ ...disposalForm, cost_of_disposal: e.target.value })}
                  placeholder="0.00"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="responsible_person">Responsible Person *</Label>
                <Input
                  id="responsible_person"
                  value={disposalForm.responsible_person}
                  onChange={(e) => setDisposalForm({ ...disposalForm, responsible_person: e.target.value })}
                  placeholder="Name of responsible person"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="disposal_certificate">Disposal Certificate</Label>
              <Input
                id="disposal_certificate"
                value={disposalForm.disposal_certificate}
                onChange={(e) => setDisposalForm({ ...disposalForm, disposal_certificate: e.target.value })}
                placeholder="Certificate number or reference"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={disposalForm.notes}
                onChange={(e) => setDisposalForm({ ...disposalForm, notes: e.target.value })}
                placeholder="Additional notes about disposal"
                rows={3}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="regulatory_compliance"
                checked={disposalForm.regulatory_compliance}
                onCheckedChange={(checked) => 
                  setDisposalForm({ ...disposalForm, regulatory_compliance: !!checked })
                }
              />
              <Label htmlFor="regulatory_compliance">
                Disposal complies with regulatory requirements
              </Label>
            </div>

            <div className="flex justify-end gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowDisposalDialog(false)}
                disabled={formSubmitting}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={formSubmitting}>
                {formSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Recording...
                  </>
                ) : (
                  'Record Disposal'
                )}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Batch Dialog */}
      <Dialog open={showBatchDialog} onOpenChange={setShowBatchDialog}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>Add Product Batch</DialogTitle>
          </DialogHeader>
          <form className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="batch_number">Batch Number *</Label>
              <Input
                id="batch_number"
                value={batchForm.batch_number}
                onChange={(e) => setBatchForm({ ...batchForm, batch_number: e.target.value })}
                placeholder="Enter batch number"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Expiry Date *</Label>
                <CalendarDatePicker
                  date={batchForm.expiry_date}
                  onDateChange={(date) => setBatchForm({ ...batchForm, expiry_date: date || new Date() })}
                  placeholder="Select expiry date"
                />
              </div>

              <div className="space-y-2">
                <Label>Received Date *</Label>
                <CalendarDatePicker
                  date={batchForm.received_date}
                  onDateChange={(date) => setBatchForm({ ...batchForm, received_date: date || new Date() })}
                  placeholder="Select received date"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="quantity">Quantity *</Label>
                <Input
                  id="quantity"
                  type="number"
                  value={batchForm.quantity}
                  onChange={(e) => setBatchForm({ ...batchForm, quantity: e.target.value })}
                  placeholder="0"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cost_price">Cost Price *</Label>
                <Input
                  id="cost_price"
                  type="number"
                  step="0.01"
                  value={batchForm.cost_price}
                  onChange={(e) => setBatchForm({ ...batchForm, cost_price: e.target.value })}
                  placeholder="0.00"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="supplier_info">Supplier Information</Label>
              <Input
                id="supplier_info"
                value={batchForm.supplier_info}
                onChange={(e) => setBatchForm({ ...batchForm, supplier_info: e.target.value })}
                placeholder="Supplier name and details"
              />
            </div>

            <div className="flex justify-end gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowBatchDialog(false)}
              >
                Cancel
              </Button>
              <Button type="submit">
                Add Batch
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}