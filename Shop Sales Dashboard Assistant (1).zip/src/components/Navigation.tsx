import React, { useState, useEffect, useMemo } from 'react';
import { 
  Home, 
  ShoppingCart, 
  BarChart3, 
  Package, 
  Users, 
  Settings, 
  User, 
  Menu, 
  X,
  Store,
  LogOut,
  ChevronDown,
  Zap,
  DollarSign,
  Sparkles,
  Shield,
  MoreHorizontal,
  ChevronRight,
  ChevronLeft,
  // New icons for pharmacy features
  Pill,
  Calendar,
  TruckIcon,
  AlertTriangle,
  Repeat,
  CreditCard,
  FileText,
  Receipt,
  UserCheck,
  Activity,
  Bell,
  Smartphone,
  RefreshCw,
  Building,
  ClipboardList,
  Stethoscope,
  Archive,
  PieChart,
  TrendingUp,
  Brain
} from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar';
import { Separator } from './ui/separator';
import { Sheet, SheetContent, SheetTrigger, SheetTitle, SheetDescription, SheetHeader } from './ui/sheet';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { View, UserRole, SUPER_ADMIN_VIEWS, canAccessView } from '../lib/app-constants';
import { UserProfile as UserProfileType } from '../lib/firebase';
import { getRoleDisplayName, getAIStatusDisplay } from '../lib/app-helpers';

interface NavigationProps {
  currentView: View;
  userProfile: UserProfileType | null;
  onNavigate: (view: View) => void;
  onSignOut: () => void;
  aiSystemStatus?: string;
  hasPermissionErrors?: boolean;
  hasIndexErrors?: boolean;
  onSidebarStateChange?: (collapsed: boolean) => void;
}

interface NavItem {
  id: View;
  label: string;
  icon: React.ReactNode;
  description: string;
  badge?: string;
  isPrimary?: boolean;
}

interface NavSection {
  title: string;
  items: NavItem[];
  icon: React.ReactNode;
  collapsible?: boolean;
}

// Define navigation sections with simplified pharmacy roles
const getNavigationSections = (userRole: UserRole): NavSection[] => {
  const sections: NavSection[] = [];

  // Super Admin Dashboard (Only for super_admin users)
  if (userRole === 'super_admin') {
    sections.push({
      title: 'Super Admin',
      icon: <Shield className="h-4 w-4" />,
      items: [
        {
          id: 'super-admin-dashboard',
          label: 'Super Admin Dashboard',
          icon: <Shield className="h-5 w-5" />,
          description: 'System overview and pharmacy management',
          isPrimary: true,
          badge: 'Admin'
        },
        {
          id: 'all-pharmacies',
          label: 'All Pharmacies',
          icon: <Building className="h-5 w-5" />,
          description: 'View and manage all pharmacy accounts'
        },
        {
          id: 'system-overview',
          label: 'System Overview',
          icon: <Activity className="h-5 w-5" />,
          description: 'Platform-wide analytics and monitoring'
        },
        {
          id: 'software-settings',
          label: 'Software Settings',
          icon: <Settings className="h-5 w-5" />,
          description: 'Global system configuration'
        }
      ]
    });
    
    // Add separator and profile for super admin
    sections.push({
      title: 'Profile',
      icon: <User className="h-4 w-4" />,
      items: [
        {
          id: 'profile',
          label: 'Admin Profile',
          icon: <User className="h-5 w-5" />,
          description: 'Manage your admin account'
        }
      ]
    });
    
    return sections; // Return early for super admin - they don't need regular pharmacy features
  }

  // Main Dashboard (Always visible for regular users)
  sections.push({
    title: 'Dashboard',
    icon: <Home className="h-4 w-4" />,
    items: [
      {
        id: 'home',
        label: 'Dashboard',
        icon: <Home className="h-5 w-5" />,
        description: 'Overview and quick access',
        isPrimary: true
      }
    ]
  });

  // Inventory & Product Management - Only for product_manager and admin
  if (['admin', 'product_manager'].includes(userRole)) {
    sections.push({
      title: 'Inventory Management',
      icon: <Package className="h-4 w-4" />,
      collapsible: true,
      items: [
        {
          id: 'product-management',
          label: 'Product Management',
          icon: <Pill className="h-5 w-5" />,
          description: 'Add, edit, and manage products'
        },
        {
          id: 'batch-tracking',
          label: 'Batch Tracking',
          icon: <Archive className="h-5 w-5" />,
          description: 'Track product batches and lots'
        },
        {
          id: 'expiry-management',
          label: 'Expiry Management',
          icon: <Calendar className="h-5 w-5" />,
          description: 'Monitor expiring products',
          badge: 'Alert'
        },
        {
          id: 'stock-transfers',
          label: 'Stock Transfers',
          icon: <TruckIcon className="h-5 w-5" />,
          description: 'Inter-branch stock movement'
        },
        {
          id: 'reorder-management',
          label: 'Reorder Management',
          icon: <Repeat className="h-5 w-5" />,
          description: 'Low stock alerts and reordering'
        }
      ]
    });
  }

  // Sales & POS - For salesman, product_manager, and admin
  if (['admin', 'salesman', 'product_manager'].includes(userRole)) {
    sections.push({
      title: 'Sales & POS',
      icon: <ShoppingCart className="h-4 w-4" />,
      collapsible: true,
      items: [
        {
          id: 'pos-system',
          label: 'Point of Sale',
          icon: <CreditCard className="h-5 w-5" />,
          description: 'Process sales and transactions',
          isPrimary: userRole === 'salesman'
        },
        {
          id: 'sales-history',
          label: 'Sales History',
          icon: <Receipt className="h-5 w-5" />,
          description: 'View past transactions'
        },
        {
          id: 'returns-refunds',
          label: 'Returns & Refunds',
          icon: <RefreshCw className="h-5 w-5" />,
          description: 'Process returns and refunds'
        },
        {
          id: 'prescriptions',
          label: 'Prescriptions',
          icon: <Stethoscope className="h-5 w-5" />,
          description: 'Manage prescription orders'
        },
        {
          id: 'customer-accounts',
          label: 'Customer Accounts',
          icon: <UserCheck className="h-5 w-5" />,
          description: 'Customer management and credit'
        }
      ]
    });
  }

  // Reports & Analytics - For owner, product_manager, and admin
  if (['admin', 'owner', 'product_manager'].includes(userRole)) {
    sections.push({
      title: 'Reports & Analytics',
      icon: <BarChart3 className="h-4 w-4" />,
      collapsible: true,
      items: [
        {
          id: 'sales-reports',
          label: 'Sales Reports',
          icon: <TrendingUp className="h-5 w-5" />,
          description: 'Sales analytics and trends'
        },
        {
          id: 'inventory-reports',
          label: 'Inventory Reports',
          icon: <ClipboardList className="h-5 w-5" />,
          description: 'Stock and movement reports'
        },
        {
          id: 'financial-reports',
          label: 'Financial Reports',
          icon: <PieChart className="h-5 w-5" />,
          description: 'Profit, loss, and financial analysis'
        },
        {
          id: 'customer-reports',
          label: 'Customer Analytics',
          icon: <Users className="h-5 w-5" />,
          description: 'Customer behavior and loyalty'
        },
        {
          id: 'supplier-reports',
          label: 'Supplier Reports',
          icon: <Building className="h-5 w-5" />,
          description: 'Supplier performance and analysis'
        }
      ]
    });
  }

  // User Management & Security - For admin and owner only
  if (['admin', 'owner'].includes(userRole)) {
    sections.push({
      title: 'Administration',
      icon: <Shield className="h-4 w-4" />,
      collapsible: true,
      items: [
        {
          id: 'user-management',
          label: 'User Management',
          icon: <Users className="h-5 w-5" />,
          description: 'Manage staff and permissions'
        },
        {
          id: 'branch-management',
          label: 'Branch Management',
          icon: <Building className="h-5 w-5" />,
          description: 'Multi-branch operations'
        },
        {
          id: 'audit-logs',
          label: 'Audit Logs',
          icon: <Activity className="h-5 w-5" />,
          description: 'System activity and security logs'
        }
      ]
    });
  }

  // Smart Features - For admin, owner, and product_manager
  if (['admin', 'owner', 'product_manager'].includes(userRole)) {
    sections.push({
      title: 'Smart Features',
      icon: <Zap className="h-4 w-4" />,
      collapsible: true,
      items: [
        {
          id: 'ai-business-intelligence',
          label: 'AI Business Intelligence',
          icon: <Brain className="h-5 w-5" />,
          description: 'AI-powered business insights and analytics',
          badge: 'AI'
        },
        {
          id: 'notifications',
          label: 'Notifications',
          icon: <Bell className="h-5 w-5" />,
          description: 'System alerts and notifications'
        },
        {
          id: 'mobile-manager',
          label: 'Mobile Manager',
          icon: <Smartphone className="h-5 w-5" />,
          description: 'Mobile app management'
        }
      ]
    });
  }

  // Settings & Profile (Always visible)
  sections.push({
    title: 'Settings & Profile',
    icon: <Settings className="h-4 w-4" />,
    items: [
      {
        id: 'profile',
        label: 'User Profile',
        icon: <User className="h-5 w-5" />,
        description: 'Manage your account'
      },
      ...((['admin', 'owner', 'product_manager'].includes(userRole)) ? [{
        id: 'settings' as View,
        label: 'System Settings',
        icon: <Settings className="h-5 w-5" />,
        description: 'Business configuration'
      }] : [])
    ]
  });

  return sections;
};

export function Navigation({ 
  currentView, 
  userProfile, 
  onNavigate,
  onSignOut,
  aiSystemStatus = 'fallback',
  hasPermissionErrors = false,
  hasIndexErrors = false,
  onSidebarStateChange 
}: NavigationProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(true);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [expandedSections, setExpandedSections] = useState<string[]>(['Dashboard', 'Super Admin']);

  // Calculate userRole and navigationSections FIRST, before any effects
  const userRole = (userProfile?.role as UserRole) || 'salesman';
  const navigationSections = useMemo(() => getNavigationSections(userRole), [userRole]);
  const aiStatus = getAIStatusDisplay(aiSystemStatus);

  // Check if we're on mobile device
  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth < 1024;
      setIsMobile(mobile);
      if (!mobile) {
        setMobileMenuOpen(false);
      }
    };
    
    const handleOrientationChange = () => {
      setMobileMenuOpen(false);
      setTimeout(checkMobile, 100);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    window.addEventListener('orientationchange', handleOrientationChange);
    
    return () => {
      window.removeEventListener('resize', checkMobile);
      window.removeEventListener('orientationchange', handleOrientationChange);
    };
  }, []);

  // Initialize sidebar state and communicate to parent
  useEffect(() => {
    console.log('🔄 Navigation: Sidebar state changed to:', sidebarCollapsed);
    if (onSidebarStateChange) {
      onSidebarStateChange(sidebarCollapsed);
    }
  }, [sidebarCollapsed, onSidebarStateChange]);

  // Fix: Ensure initial state is communicated immediately on mount
  useEffect(() => {
    if (onSidebarStateChange) {
      console.log('🔄 Navigation: Communicating initial sidebar state:', sidebarCollapsed);
      onSidebarStateChange(sidebarCollapsed);
    }
  }, [onSidebarStateChange]); // Only run once on mount

  // Special fix for dashboard (home) view initialization
  useEffect(() => {
    if (currentView === 'home' && onSidebarStateChange) {
      console.log('🏠 Navigation: Special initialization for dashboard view');
      // Force a state update for dashboard view to ensure proper layout
      setTimeout(() => {
        onSidebarStateChange(sidebarCollapsed);
      }, 50);
    }
  }, [currentView, onSidebarStateChange, sidebarCollapsed]);

  // Fix: Ensure the section containing the current view is always expanded
  useEffect(() => {
    const findSectionForView = (viewId: View) => {
      for (const section of navigationSections) {
        if (section.items.some(item => item.id === viewId)) {
          return section.title;
        }
      }
      return null;
    };

    const currentSection = findSectionForView(currentView);
    if (currentSection && !expandedSections.includes(currentSection)) {
      console.log('🔄 Navigation: Auto-expanding section for current view:', currentSection);
      setExpandedSections(prev => [...prev, currentSection]);
    }
  }, [currentView, navigationSections, expandedSections]);
  
  // Get user initials for avatar
  const getUserInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  // Handle navigation click with role-based access control
  const handleNavClick = (viewId: View) => {
    console.log(`🔄 Navigation clicked: ${viewId}`);
    
    // Enhanced security check: Prevent navigation to restricted views
    if (!canAccessView(userRole, viewId)) {
      console.warn(`🚫 Access denied: User with role '${userRole}' attempted to navigate to '${viewId}'`);
      
      // Show graceful error notification
      const message = SUPER_ADMIN_VIEWS.includes(viewId) 
        ? 'This area is restricted to system administrators only.'
        : 'You don\'t have permission to access that area.';
      
      // Try to use toast if available, otherwise log to console
      try {
        if (typeof window !== 'undefined' && (window as any).toast) {
          (window as any).toast.error('Access Denied', {
            description: message,
            duration: 4000,
            action: {
              label: 'Learn More',
              onClick: () => {
                console.log('📋 Access Control Information:');
                console.log(`Current Role: ${userRole}`);
                console.log(`Attempted Access: ${viewId}`);
                console.log('Contact your system administrator for access requests.');
              }
            }
          });
        } else {
          console.warn(`Access denied: ${message}`);
        }
      } catch (error) {
        console.warn(`Access denied: ${message}`);
      }
      
      return; // Prevent navigation
    }
    onNavigate(viewId);
    setMobileMenuOpen(false);
  };

  // Toggle section expansion
  const toggleSection = (sectionTitle: string) => {
    setExpandedSections(prev => 
      prev.includes(sectionTitle) 
        ? prev.filter(s => s !== sectionTitle)
        : [...prev, sectionTitle]
    );
  };

  // Handle sidebar toggle - FIXED: Removed requestAnimationFrame for synchronous updates
  const handleSidebarToggle = () => {
    const newState = !sidebarCollapsed;
    console.log('🔄 Navigation: Toggling sidebar from', sidebarCollapsed, 'to', newState);
    
    // Update both states synchronously to prevent glitch
    setSidebarCollapsed(newState);
    if (onSidebarStateChange) {
      onSidebarStateChange(newState);
    }
  };

  // Render system status badge
  const renderSystemStatus = () => {
    if (hasPermissionErrors) {
      return (
        <Badge variant="destructive" className="text-xs animate-pulse">
          <Shield className="h-3 w-3 mr-1" />
          Rules Required
        </Badge>
      );
    }
    
    if (hasIndexErrors) {
      return (
        <Badge variant="secondary" className="text-xs bg-yellow-100 text-yellow-800">
          <Settings className="h-3 w-3 mr-1" />
          Indexes Needed
        </Badge>
      );
    }
    
    if (aiSystemStatus === 'ready') {
      return (
        <Badge variant="secondary" className="text-xs bg-green-100 text-green-800">
          <Zap className="h-3 w-3 mr-1" />
          AI Active
        </Badge>
      );
    }
    
    if (aiSystemStatus === 'quota-exceeded') {
      return (
        <Badge variant="secondary" className="text-xs bg-orange-100 text-orange-800">
          <DollarSign className="h-3 w-3 mr-1" />
          Quota Exceeded
        </Badge>
      );
    }
    
    if (aiSystemStatus === 'fallback') {
      return (
        <Badge variant="secondary" className="text-xs bg-yellow-100 text-yellow-800">
          <Sparkles className="h-3 w-3 mr-1" />
          Smart Fallback
        </Badge>
      );
    }
    
    return null;
  };

  // Unified Sidebar Content
  const SidebarContent = ({ isSheet = false }) => (
    <div className="flex flex-col h-full bg-white">
      {/* Header */}
      <div className={`p-6 border-b ${sidebarCollapsed && !isSheet ? 'p-4' : ''}`}>
        <div className={`flex items-center ${sidebarCollapsed && !isSheet ? 'justify-center' : ''}`}>
          <Store className={`h-8 w-8 text-indigo-600 ${sidebarCollapsed && !isSheet ? '' : 'mr-3'}`} />
          {(!sidebarCollapsed || isSheet) && (
            <div className="flex-1">
              <h1 className="font-semibold text-gray-900">Pharmacy Management</h1>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-xs text-gray-500">TZS Currency</span>
                {renderSystemStatus()}
              </div>
            </div>
          )}
          {!isSheet && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleSidebarToggle}
              className={`h-8 w-8 p-0 hover:bg-gray-100 transition-all duration-200 ${sidebarCollapsed ? 'ml-0' : 'ml-2'}`}
              aria-label={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            >
              <ChevronLeft className={`h-4 w-4 transition-transform duration-300 ${sidebarCollapsed ? 'rotate-180' : 'rotate-0'}`} />
            </Button>
          )}
        </div>
      </div>

      {/* User Profile Section */}
      <div className={`p-4 border-b ${sidebarCollapsed && !isSheet ? 'p-2' : ''}`}>
        {(!sidebarCollapsed || isSheet) ? (
          <div className="flex items-center">
            <Avatar className="h-10 w-10">
              <AvatarImage src="/placeholder-avatar.png" />
              <AvatarFallback className="bg-indigo-100 text-indigo-600">
                {userProfile?.full_name ? getUserInitials(userProfile.full_name) : 'U'}
              </AvatarFallback>
            </Avatar>
            <div className="ml-3 flex-1">
              <p className="text-sm font-medium text-gray-900">{userProfile?.full_name}</p>
              <p className="text-xs text-gray-500">{getRoleDisplayName(userRole)}</p>
            </div>
          </div>
        ) : (
          <div className="flex justify-center">
            <Avatar className="h-8 w-8">
              <AvatarImage src="/placeholder-avatar.png" />
              <AvatarFallback className="bg-indigo-100 text-indigo-600 text-xs">
                {userProfile?.full_name ? getUserInitials(userProfile.full_name) : 'U'}
              </AvatarFallback>
            </Avatar>
          </div>
        )}
        
        {userProfile?.shop && (!sidebarCollapsed || isSheet) && (
          <div className="mt-2 text-xs text-gray-500 bg-gray-50 rounded px-2 py-1">
            {userProfile.shop.name}
          </div>
        )}
      </div>

      {/* Navigation Sections */}
      <nav className={`flex-1 p-4 space-y-2 overflow-y-auto ${sidebarCollapsed && !isSheet ? 'p-2' : ''}`}>
        {navigationSections.map((section) => {
          const isExpanded = expandedSections.includes(section.title);
          const hasCollapsibleItems = section.collapsible && section.items.length > 1;
          
          return (
            <div key={section.title} className="space-y-1">
              {/* Section Header */}
              {(!sidebarCollapsed || isSheet) && (
                <div className="flex items-center justify-between">
                  <div className="text-xs font-medium text-gray-400 uppercase tracking-wider flex items-center gap-2">
                    {section.icon}
                    <span>{section.title}</span>
                  </div>
                  {hasCollapsibleItems && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleSection(section.title)}
                      className="h-6 w-6 p-0"
                    >
                      <ChevronDown className={`h-3 w-3 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                    </Button>
                  )}
                </div>
              )}
              
              {/* Section Items */}
              <div className={hasCollapsibleItems && !isExpanded && !isSheet && !sidebarCollapsed ? 'hidden' : 'space-y-1'}>
                {section.items.map((item) => {
                  const isActive = currentView === item.id;
                  const isDisabled = hasPermissionErrors && item.id !== 'home';
                  
                  return (
                    <Button
                      key={item.id}
                      variant={isActive ? "default" : "ghost"}
                      className={`w-full sidebar-nav-item transition-all duration-200 ${
                        sidebarCollapsed && !isSheet 
                          ? 'justify-center p-2 min-w-12 max-w-12 h-12 overflow-hidden' 
                          : 'justify-start p-3 h-auto'
                      } ${
                        isActive 
                          ? 'bg-indigo-600 text-white shadow-sm' 
                          : 'text-gray-700 hover:text-gray-900 hover:bg-gray-100'
                      } ${isDisabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                      onClick={() => !isDisabled && handleNavClick(item.id)}
                      disabled={isDisabled}
                      title={sidebarCollapsed && !isSheet ? item.label : undefined}
                    >
                      {sidebarCollapsed && !isSheet ? (
                        <div className={`${isActive ? 'text-white' : 'text-gray-400'} transition-colors duration-200 flex items-center justify-center w-full h-full`}>
                          {item.icon}
                        </div>
                      ) : (
                        <div className="flex items-center w-full">
                          <div className={`mr-3 transition-colors duration-200 ${isActive ? 'text-white' : 'text-gray-400'} flex-shrink-0`}>
                            {item.icon}
                          </div>
                          <div className="flex-1 text-left min-w-0">
                            <div className={`text-sm font-medium transition-colors duration-200 ${isActive ? 'text-white' : 'text-gray-900'} truncate`}>
                              {item.label}
                            </div>
                            <div className={`text-xs transition-colors duration-200 ${isActive ? 'text-indigo-100' : 'text-gray-500'} truncate`}>
                              {item.description}
                            </div>
                          </div>
                          <div className="flex items-center gap-1 flex-shrink-0">
                            {item.badge && (
                              <Badge variant="secondary" className="text-xs">
                                {item.badge}
                              </Badge>
                            )}
                            {item.isPrimary && (
                              <Badge variant="outline" className="text-xs">
                                Primary
                              </Badge>
                            )}
                          </div>
                        </div>
                      )}
                    </Button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </nav>

      {/* Sign Out Button */}
      <div className={`p-4 border-t ${sidebarCollapsed && !isSheet ? 'p-2' : ''}`}>
        <Button 
          onClick={onSignOut}
          variant="outline" 
          className={`w-full transition-all duration-200 ${
            sidebarCollapsed && !isSheet 
              ? 'justify-center p-2 min-w-12 max-w-12 h-12 overflow-hidden' 
              : 'justify-start'
          } text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700`}
          title={sidebarCollapsed && !isSheet ? 'Sign Out' : undefined}
        >
          <LogOut className={`h-4 w-4 ${sidebarCollapsed && !isSheet ? '' : 'mr-2'}`} />
          {(!sidebarCollapsed || isSheet) && 'Sign Out'}
        </Button>
      </div>
    </div>
  );

  // Desktop Sidebar
  const DesktopSidebar = () => (
    <div className={`desktop-sidebar hidden lg:flex lg:flex-shrink-0 sidebar-transition ${sidebarCollapsed ? 'w-16' : 'w-80'} h-screen overflow-hidden z-30 ${sidebarCollapsed ? 'sidebar-collapsed' : ''}`}>
      <Card className="h-full bg-white/95 backdrop-blur-sm border-r shadow-sm rounded-none flex flex-col w-full">
        <SidebarContent />
      </Card>
    </div>
  );

  // Mobile Header
  const MobileHeader = () => (
    <div className="lg:hidden fixed top-0 left-0 right-0 z-40 mobile-header bg-white/95 backdrop-blur-sm border-b">
      <div className="px-4 py-3">
        <div className="flex items-center justify-between">
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-10 w-10 p-0 rounded-full hover:bg-gray-100 transition-all duration-200 btn-press"
                aria-label="Open navigation menu"
              >
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent 
              side="left" 
              className="w-full max-w-sm p-0 bg-white animate-slide-in-right z-50"
            >
              <SheetHeader className="sr-only">
                <SheetTitle>Navigation Menu</SheetTitle>
                <SheetDescription>
                  Access pharmacy management features including inventory, sales, and reports.
                </SheetDescription>
              </SheetHeader>
              <SidebarContent isSheet={true} />
            </SheetContent>
          </Sheet>
            
          <div className="flex items-center flex-1 justify-center">
            <Store className="h-7 w-7 text-indigo-600 mr-3 flex-shrink-0" />
            <div className="text-center">
              <h1 className="font-semibold text-gray-900 text-base">Pharmacy MS</h1>
              <div className="flex items-center justify-center gap-2 mt-0.5">
                <span className="text-xs text-gray-500">TZS</span>
                {renderSystemStatus()}
              </div>
            </div>
          </div>

          <div className="flex items-center flex-shrink-0">
            <Avatar className="h-9 w-9">
              <AvatarImage src="/placeholder-avatar.png" />
              <AvatarFallback className="bg-indigo-100 text-indigo-600 text-sm font-medium">
                {userProfile?.full_name ? getUserInitials(userProfile.full_name) : 'U'}
              </AvatarFallback>
            </Avatar>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {!isMobile && <DesktopSidebar />}
      {isMobile && <MobileHeader />}
    </>
  );
}