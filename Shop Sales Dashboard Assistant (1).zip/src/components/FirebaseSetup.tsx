import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { 
  Database, 
  Key, 
  Globe, 
  CheckCircle, 
  Copy, 
  ExternalLink, 
  AlertTriangle,
  FileText,
  Settings,
  Users,
  Shield
} from 'lucide-react';

export function FirebaseSetup() {
  const [copiedStep, setCopiedStep] = useState<string | null>(null);

  const handleCopy = (text: string, stepId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedStep(stepId);
    setTimeout(() => setCopiedStep(null), 2000);
  };

  const envTemplate = `# Firebase Configuration - Vite Environment Variables
# Copy this file to .env.local and fill in your Firebase project details

# Get these values from your Firebase project settings
VITE_FIREBASE_API_KEY=your_api_key_here
VITE_FIREBASE_AUTH_DOMAIN=your_project_id.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your_project_id
VITE_FIREBASE_STORAGE_BUCKET=your_project_id.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
VITE_FIREBASE_APP_ID=your_app_id

# Optional: OpenAI API Key for AI features
VITE_OPENAI_API_KEY=your_openai_api_key_here`;

  const firestoreRules = `rules_version = '2';

service cloud.firestore {
  match /databases/{database}/documents {
    // Users can read/write their own profile
    match /profiles/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Shop owners can read/write their shop and all related data
    match /shops/{shopId} {
      allow read, write: if request.auth != null && 
        exists(/databases/$(database)/documents/profiles/$(request.auth.uid)) &&
        get(/databases/$(database)/documents/profiles/$(request.auth.uid)).data.shop_id == shopId;
    }
    
    // Sales data - accessible by shop members
    match /sales/{saleId} {
      allow read, write: if request.auth != null && 
        exists(/databases/$(database)/documents/profiles/$(request.auth.uid)) &&
        get(/databases/$(database)/documents/profiles/$(request.auth.uid)).data.shop_id == resource.data.shop_id;
    }
    
    // Products data - accessible by shop members
    match /products/{productId} {
      allow read, write: if request.auth != null && 
        exists(/databases/$(database)/documents/profiles/$(request.auth.uid)) &&
        get(/databases/$(database)/documents/profiles/$(request.auth.uid)).data.shop_id == resource.data.shop_id;
    }
  }
}`;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Database className="h-12 w-12 text-indigo-600 mr-3" />
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Firebase Setup Required</h1>
              <p className="text-gray-600 mt-2">Configure Firebase to enable the Shop Sales Dashboard</p>
            </div>
          </div>
          
          <Alert className="max-w-2xl mx-auto">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Important:</strong> Firebase configuration is required for authentication, data storage, and all dashboard features. This is a one-time setup process.
            </AlertDescription>
          </Alert>
        </div>

        {/* Setup Steps */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="project">Project</TabsTrigger>
            <TabsTrigger value="services">Services</TabsTrigger>
            <TabsTrigger value="config">Config</TabsTrigger>
            <TabsTrigger value="rules">Security</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
                  Setup Overview
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600">
                  Follow these steps to set up Firebase for your Shop Sales Dashboard. The entire process takes about 10-15 minutes.
                </p>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <h4 className="font-medium flex items-center">
                      <Globe className="h-4 w-4 mr-2 text-blue-600" />
                      What You'll Create:
                    </h4>
                    <ul className="text-sm text-gray-600 space-y-1 ml-6">
                      <li>• Firebase project for your shop</li>
                      <li>• Authentication system for users</li>
                      <li>• Firestore database for data</li>
                      <li>• Security rules for data protection</li>
                      <li>• Environment configuration</li>
                    </ul>
                  </div>
                  
                  <div className="space-y-3">
                    <h4 className="font-medium flex items-center">
                      <Users className="h-4 w-4 mr-2 text-purple-600" />
                      What You'll Get:
                    </h4>
                    <ul className="text-sm text-gray-600 space-y-1 ml-6">
                      <li>• Secure user authentication</li>
                      <li>• Real-time data synchronization</li>
                      <li>• Role-based access control</li>
                      <li>• Scalable cloud infrastructure</li>
                      <li>• Production-ready setup</li>
                    </ul>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h4 className="font-medium text-blue-900 mb-2">Prerequisites:</h4>
                  <ul className="text-sm text-blue-800 space-y-1">
                    <li>• Google account (free)</li>
                    <li>• 10-15 minutes of setup time</li>
                    <li>• Basic familiarity with environment variables</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Project Setup Tab */}
          <TabsContent value="project" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Database className="h-5 w-5 mr-2 text-indigo-600" />
                  Step 1: Create Firebase Project
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <Badge variant="outline" className="mt-1">1</Badge>
                    <div className="flex-1">
                      <p className="font-medium">Go to Firebase Console</p>
                      <p className="text-sm text-gray-600 mt-1">
                        Visit the Firebase Console to create your project
                      </p>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="mt-2"
                        onClick={() => window.open('https://console.firebase.google.com/', '_blank')}
                      >
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Open Firebase Console
                      </Button>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Badge variant="outline" className="mt-1">2</Badge>
                    <div className="flex-1">
                      <p className="font-medium">Create New Project</p>
                      <p className="text-sm text-gray-600 mt-1">
                        Click "Add project" or "Create a project"
                      </p>
                      <ul className="text-sm text-gray-600 mt-2 ml-4 space-y-1">
                        <li>• Enter project name (e.g., "my-shop-dashboard")</li>
                        <li>• Choose whether to enable Google Analytics (optional)</li>
                        <li>• Click "Create project"</li>
                      </ul>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Badge variant="outline" className="mt-1">3</Badge>
                    <div className="flex-1">
                      <p className="font-medium">Add Web App</p>
                      <p className="text-sm text-gray-600 mt-1">
                        In your project dashboard, add a web application
                      </p>
                      <ul className="text-sm text-gray-600 mt-2 ml-4 space-y-1">
                        <li>• Click the web icon (&lt;/&gt;) to add a web app</li>
                        <li>• Enter app nickname (e.g., "Shop Dashboard")</li>
                        <li>• Don't check "Firebase Hosting" for now</li>
                        <li>• Click "Register app"</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <Alert className="bg-green-50 border-green-200">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800">
                    <strong>Success!</strong> Your Firebase project is now created. Next, you'll enable the required services.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Services Tab */}
          <TabsContent value="services" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Settings className="h-5 w-5 mr-2 text-purple-600" />
                  Step 2: Enable Required Services
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Authentication Setup */}
                <div className="border rounded-lg p-4">
                  <h4 className="font-medium flex items-center mb-3">
                    <Key className="h-4 w-4 mr-2 text-blue-600" />
                    Enable Authentication
                  </h4>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <Badge variant="outline" className="mt-1">1</Badge>
                      <div>
                        <p className="font-medium">Go to Authentication</p>
                        <p className="text-sm text-gray-600">In the sidebar, click "Authentication"</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Badge variant="outline" className="mt-1">2</Badge>
                      <div>
                        <p className="font-medium">Get Started</p>
                        <p className="text-sm text-gray-600">Click "Get started" if it's your first time</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Badge variant="outline" className="mt-1">3</Badge>
                      <div>
                        <p className="font-medium">Sign-in Method</p>
                        <p className="text-sm text-gray-600">Go to "Sign-in method" tab</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Badge variant="outline" className="mt-1">4</Badge>
                      <div>
                        <p className="font-medium">Enable Email/Password</p>
                        <p className="text-sm text-gray-600">Click on "Email/Password" and enable it</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Firestore Setup */}
                <div className="border rounded-lg p-4">
                  <h4 className="font-medium flex items-center mb-3">
                    <Database className="h-4 w-4 mr-2 text-green-600" />
                    Enable Firestore Database
                  </h4>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <Badge variant="outline" className="mt-1">1</Badge>
                      <div>
                        <p className="font-medium">Go to Firestore Database</p>
                        <p className="text-sm text-gray-600">In the sidebar, click "Firestore Database"</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Badge variant="outline" className="mt-1">2</Badge>
                      <div>
                        <p className="font-medium">Create Database</p>
                        <p className="text-sm text-gray-600">Click "Create database"</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Badge variant="outline" className="mt-1">3</Badge>
                      <div>
                        <p className="font-medium">Choose Security Rules</p>
                        <p className="text-sm text-gray-600">Start in "Test mode" (we'll add proper rules later)</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Badge variant="outline" className="mt-1">4</Badge>
                      <div>
                        <p className="font-medium">Select Location</p>
                        <p className="text-sm text-gray-600">Choose a location close to your users</p>
                      </div>
                    </div>
                  </div>
                </div>

                <Alert className="bg-blue-50 border-blue-200">
                  <Database className="h-4 w-4 text-blue-600" />
                  <AlertDescription className="text-blue-800">
                    <strong>Note:</strong> Test mode allows read/write access for 30 days. We'll add proper security rules in the next step.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Configuration Tab */}
          <TabsContent value="config" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileText className="h-5 w-5 mr-2 text-orange-600" />
                  Step 3: Configure Environment Variables
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <Badge variant="outline" className="mt-1">1</Badge>
                    <div className="flex-1">
                      <p className="font-medium">Get Firebase Configuration</p>
                      <ul className="text-sm text-gray-600 mt-2 ml-4 space-y-1">
                        <li>• Go to Project Settings (gear icon)</li>
                        <li>• Scroll to "Your apps" section</li>
                        <li>• Find your web app and click "Config"</li>
                        <li>• Copy the configuration object</li>
                      </ul>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Badge variant="outline" className="mt-1">2</Badge>
                    <div className="flex-1">
                      <p className="font-medium">Create Environment File</p>
                      <p className="text-sm text-gray-600 mt-1">
                        Create a <code className="bg-gray-100 px-2 py-1 rounded">.env.local</code> file in your project root
                      </p>
                      
                      <div className="mt-3 relative">
                        <div className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
                          <pre>{envTemplate}</pre>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          className="absolute top-2 right-2"
                          onClick={() => handleCopy(envTemplate, 'env')}
                        >
                          {copiedStep === 'env' ? (
                            <CheckCircle className="h-4 w-4" />
                          ) : (
                            <Copy className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Badge variant="outline" className="mt-1">3</Badge>
                    <div className="flex-1">
                      <p className="font-medium">Fill in Your Values</p>
                      <p className="text-sm text-gray-600 mt-1">
                        Replace the placeholder values with your actual Firebase configuration
                      </p>
                      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mt-2">
                        <p className="text-sm text-yellow-800">
                          <strong>Important:</strong> Make sure to use the <code>VITE_</code> prefix for all variables. This is required for Vite to expose them to the browser.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <Alert className="bg-green-50 border-green-200">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800">
                    <strong>Security:</strong> The <code>.env.local</code> file is automatically ignored by Git, so your API keys won't be committed to your repository.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Security Rules Tab */}
          <TabsContent value="rules" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="h-5 w-5 mr-2 text-red-600" />
                  Step 4: Set Up Security Rules
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <Badge variant="outline" className="mt-1">1</Badge>
                    <div className="flex-1">
                      <p className="font-medium">Go to Firestore Rules</p>
                      <p className="text-sm text-gray-600 mt-1">
                        In Firestore Database, click on the "Rules" tab
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Badge variant="outline" className="mt-1">2</Badge>
                    <div className="flex-1">
                      <p className="font-medium">Replace Default Rules</p>
                      <p className="text-sm text-gray-600 mt-1">
                        Copy and paste these security rules for proper access control
                      </p>
                      
                      <div className="mt-3 relative">
                        <div className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto max-h-80">
                          <pre>{firestoreRules}</pre>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          className="absolute top-2 right-2"
                          onClick={() => handleCopy(firestoreRules, 'rules')}
                        >
                          {copiedStep === 'rules' ? (
                            <CheckCircle className="h-4 w-4" />
                          ) : (
                            <Copy className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Badge variant="outline" className="mt-1">3</Badge>
                    <div className="flex-1">
                      <p className="font-medium">Publish Rules</p>
                      <p className="text-sm text-gray-600 mt-1">
                        Click "Publish" to activate the new security rules
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <h4 className="font-medium text-red-900 mb-2">Security Rules Explanation:</h4>
                  <ul className="text-sm text-red-800 space-y-1">
                    <li>• Users can only access their own profile data</li>
                    <li>• Shop owners can access all data for their shop</li>
                    <li>• Team members can access sales and products for their assigned shop</li>
                    <li>• No public access - authentication required for all operations</li>
                  </ul>
                </div>

                <Alert className="bg-green-50 border-green-200">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800">
                    <strong>Complete!</strong> Your Firebase setup is now complete. Restart your development server to see the changes.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Final Action */}
        <Card className="bg-gradient-to-r from-indigo-50 to-blue-50 border-indigo-200">
          <CardContent className="p-6 text-center">
            <h3 className="text-xl font-semibold mb-2">Ready to Get Started?</h3>
            <p className="text-gray-600 mb-4">
              Once you've completed all steps, restart your development server to see your Shop Sales Dashboard
            </p>
            <div className="flex justify-center gap-3">
              <Button 
                variant="outline" 
                onClick={() => window.open('https://console.firebase.google.com/', '_blank')}
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                Open Firebase Console
              </Button>
              <Button onClick={() => window.location.reload()}>
                <CheckCircle className="h-4 w-4 mr-2" />
                Check Configuration
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}