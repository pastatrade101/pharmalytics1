import React, { useState, useEffect } from 'react';
import { Search, Filter, Calendar, Eye, Download, RefreshCw, Receipt, CreditCard, Smartphone, Banknote, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Separator } from './ui/separator';
import { Alert, AlertDescription } from './ui/alert';
import { formatTZS } from '../lib/currency-utils';
import { SalesService } from '../lib/firebase-sales';
import { Sale } from '../lib/firebase-types';
import { UserProfile } from '../lib/firebase-types';

interface SalesHistoryProps {
  userProfile: UserProfile;
  onBack: () => void;
  onSetCurrentView: (view: any) => void;
}

export function SalesHistory({ userProfile, onBack, onSetCurrentView }: SalesHistoryProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterPayment, setFilterPayment] = useState('all');
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null);
  const [salesTransactions, setSalesTransactions] = useState<Sale[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load sales data from Firebase on component mount
  useEffect(() => {
    let unsubscribe: (() => void) | null = null;

    const loadSalesData = async () => {
      if (!userProfile?.shop_id) {
        setError('No pharmacy assigned to your account');
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError(null);

        // Subscribe to real-time sales updates
        unsubscribe = SalesService.subscribeToSales(
          userProfile.shop_id,
          (sales: Sale[]) => {
            console.log('📊 Real-time sales update received:', sales.length, 'transactions');
            setSalesTransactions(sales);
            setLoading(false);
          }
        );

      } catch (err: any) {
        console.error('❌ Error loading sales data:', err);
        setError(err.message || 'Failed to load sales data');
        setLoading(false);
      }
    };

    loadSalesData();

    // Cleanup subscription on unmount
    return () => {
      if (unsubscribe) {
        console.log('🧹 Cleaning up sales subscription');
        unsubscribe();
      }
    };
  }, [userProfile?.shop_id]);

  const getPaymentIcon = (method: string) => {
    switch (method) {
      case 'cash':
        return <Banknote className="h-4 w-4" />;
      case 'card':
        return <CreditCard className="h-4 w-4" />;
      case 'mobile_money':
      case 'mobile-money':
        return <Smartphone className="h-4 w-4" />;
      case 'insurance':
        return <Receipt className="h-4 w-4" />;
      default:
        return <CreditCard className="h-4 w-4" />;
    }
  };

  const getPaymentMethodName = (method: string) => {
    if (!method) return 'Unknown';
    
    switch (method) {
      case 'cash': return 'Cash';
      case 'card': return 'Card';
      case 'mobile_money':
      case 'mobile-money': return 'Mobile Money';
      case 'insurance': return 'Insurance';
      default: return method.charAt(0).toUpperCase() + method.slice(1);
    }
  };

  const filteredSales = salesTransactions.filter(sale => {
    const matchesSearch = sale.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         sale.sale_number?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         sale.customer_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         sale.customer_phone?.includes(searchQuery) ||
                         sale.prescription_number?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = filterStatus === 'all' || sale.status === filterStatus;
    const matchesPayment = filterPayment === 'all' || sale.payment_method === filterPayment;
    
    return matchesSearch && matchesStatus && matchesPayment;
  });

  const totalSales = salesTransactions.reduce((sum, sale) => sum + Number(sale.total_price), 0);
  const totalTransactions = salesTransactions.length;
  const averageTransaction = totalTransactions > 0 ? totalSales / totalTransactions : 0;

  // Manual refresh function
  const handleRefresh = async () => {
    if (!userProfile?.shop_id) return;
    
    setLoading(true);
    try {
      const sales = await SalesService.getSales(userProfile.shop_id);
      setSalesTransactions(sales);
    } catch (err: any) {
      console.error('❌ Error refreshing sales:', err);
      setError(err.message || 'Failed to refresh sales data');
    } finally {
      setLoading(false);
    }
  };

  const SaleDetailModal = ({ sale, onClose }: { sale: Sale; onClose: () => void }) => (
    <div className="space-y-6 max-h-[80vh] overflow-y-auto">
      {/* Sale Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">{sale.sale_number || sale.id}</h3>
          <p className="text-sm text-gray-500">{new Date(sale.timestamp).toLocaleString()}</p>
        </div>
        <Badge variant={sale.status === 'completed' ? 'default' : 'secondary'}>
          {sale.status}
        </Badge>
      </div>

      {/* Customer Information */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <h4 className="font-medium mb-2">Customer Information</h4>
          <div className="space-y-1 text-sm">
            <div><strong>Name:</strong> {sale.customer_name || 'Walk-in Customer'}</div>
            {sale.customer_phone && <div><strong>Phone:</strong> {sale.customer_phone}</div>}
            {sale.customer_address && <div><strong>Address:</strong> {sale.customer_address}</div>}
          </div>
        </div>

        <div>
          <h4 className="font-medium mb-2">Transaction Details</h4>
          <div className="space-y-1 text-sm">
            <div><strong>Sale Number:</strong> {sale.sale_number}</div>
            <div className="flex items-center gap-2">
              <strong>Payment:</strong>
              {getPaymentIcon(sale.payment_method)}
              {getPaymentMethodName(sale.payment_method)}
            </div>
            {sale.payment_reference && (
              <div><strong>Payment Ref:</strong> {sale.payment_reference}</div>
            )}
          </div>
        </div>
      </div>

      {/* Prescription Information */}
      {sale.prescription_number && (
        <div>
          <h4 className="font-medium mb-2">Prescription Information</h4>
          <div className="bg-blue-50 p-3 rounded text-sm">
            <div><strong>Prescription #:</strong> {sale.prescription_number}</div>
            {sale.doctor_name && <div><strong>Doctor:</strong> {sale.doctor_name}</div>}
          </div>
        </div>
      )}

      {/* Insurance Information */}
      {sale.insurance_provider && (
        <div>
          <h4 className="font-medium mb-2">Insurance Information</h4>
          <div className="bg-green-50 p-3 rounded text-sm">
            <div><strong>Provider:</strong> {sale.insurance_provider}</div>
            {sale.insurance_number && <div><strong>Member #:</strong> {sale.insurance_number}</div>}
          </div>
        </div>
      )}

      {/* Items */}
      <div>
        <h4 className="font-medium mb-2">Items Sold</h4>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Product</TableHead>
              <TableHead className="text-right">Qty</TableHead>
              <TableHead className="text-right">Unit Price</TableHead>
              <TableHead className="text-right">Total</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sale.items.map((item, index) => (
              <TableRow key={index}>
                <TableCell>{item.product_name}</TableCell>
                <TableCell className="text-right">{item.quantity}</TableCell>
                <TableCell className="text-right">{formatTZS(item.unit_price)}</TableCell>
                <TableCell className="text-right">{formatTZS(item.total)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Payment Summary */}
      <div className="bg-gray-50 p-4 rounded">
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span>Subtotal:</span>
            <span>{formatTZS(sale.subtotal)}</span>
          </div>
          {sale.discount_amount > 0 && (
            <div className="flex justify-between text-red-600">
              <span>Discount:</span>
              <span>-{formatTZS(sale.discount_amount)}</span>
            </div>
          )}
          <div className="flex justify-between">
            <span>Tax:</span>
            <span>{formatTZS(sale.tax_amount)}</span>
          </div>
          <Separator />
          <div className="flex justify-between font-medium text-lg">
            <span>Total:</span>
            <span className="text-green-600">{formatTZS(sale.total_price)}</span>
          </div>
          <div className="flex justify-between">
            <span>Amount Paid:</span>
            <span>{formatTZS(sale.amount_paid)}</span>
          </div>
          {sale.change_amount > 0 && (
            <div className="flex justify-between text-blue-600">
              <span>Change:</span>
              <span>{formatTZS(sale.change_amount)}</span>
            </div>
          )}
        </div>
      </div>

      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={onClose}>
          Close
        </Button>
        <Button variant="outline">
          <Receipt className="h-4 w-4 mr-2" />
          Print Receipt
        </Button>
        <Button variant="outline" onClick={() => onSetCurrentView('returns-refunds')}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Process Return
        </Button>
      </div>
    </div>
  );

  // Show loading state
  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-center space-y-4">
            <RefreshCw className="h-8 w-8 animate-spin mx-auto text-blue-600" />
            <p className="text-muted-foreground">Loading sales history...</p>
          </div>
        </div>
      </div>
    );
  }

  // Show error state
  if (error) {
    return (
      <div className="space-y-6">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            {error}
          </AlertDescription>
        </Alert>
        <div className="flex justify-center">
          <Button onClick={() => window.location.reload()}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* No Sales Message */}
      {salesTransactions.length === 0 && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            No sales transactions found. Sales will appear here once you start recording transactions in the POS system.
          </AlertDescription>
        </Alert>
      )}

      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Receipt className="h-8 w-8 text-blue-600" />
              <div>
                <div className="text-2xl font-bold">{totalTransactions}</div>
                <p className="text-sm text-muted-foreground">Total Transactions</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <CreditCard className="h-8 w-8 text-green-600" />
              <div>
                <div className="text-2xl font-bold text-green-600">{formatTZS(totalSales)}</div>
                <p className="text-sm text-muted-foreground">Total Sales Value</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Smartphone className="h-8 w-8 text-purple-600" />
              <div>
                <div className="text-2xl font-bold">{formatTZS(Math.round(averageTransaction))}</div>
                <p className="text-sm text-muted-foreground">Average Transaction</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex items-center gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search by sale ID, customer name, phone, or prescription..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="voided">Voided</SelectItem>
            <SelectItem value="returned">Returned</SelectItem>
          </SelectContent>
        </Select>

        <Select value={filterPayment} onValueChange={setFilterPayment}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Payment" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Methods</SelectItem>
            <SelectItem value="cash">Cash</SelectItem>
            <SelectItem value="card">Card</SelectItem>
            <SelectItem value="mobile_money">Mobile Money</SelectItem>
            <SelectItem value="insurance">Insurance</SelectItem>
          </SelectContent>
        </Select>

        <Button variant="outline" size="sm" onClick={handleRefresh} disabled={loading}>
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
        
        <Button variant="outline" size="sm">
          <Download className="h-4 w-4 mr-2" />
          Export
        </Button>
      </div>

      {/* Sales Table */}
      <Card>
        <CardHeader>
          <CardTitle>Sales Transactions ({filteredSales.length} records)</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Sale ID</TableHead>
                <TableHead>Date & Time</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Items</TableHead>
                <TableHead>Payment</TableHead>
                <TableHead className="text-right">Total</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredSales.map((sale) => (
                <TableRow key={sale.id}>
                  <TableCell className="font-mono text-sm">{sale.sale_number || sale.id}</TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div>{new Date(sale.timestamp).toLocaleDateString()}</div>
                      <div className="text-gray-500">{new Date(sale.timestamp).toLocaleTimeString()}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">{sale.customer_name || 'Walk-in'}</div>
                      {sale.customer_phone && (
                        <div className="text-sm text-gray-500">{sale.customer_phone}</div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div>{sale.items.length} item(s)</div>
                      {sale.prescription_number && (
                        <Badge variant="outline" className="text-xs mt-1">
                          Prescription
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getPaymentIcon(sale.payment_method)}
                      <span className="text-sm">{getPaymentMethodName(sale.payment_method)}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right font-medium">
                    {formatTZS(sale.total_price)}
                  </TableCell>
                  <TableCell>
                    <Badge variant={sale.status === 'completed' ? 'default' : 'secondary'}>
                      {sale.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setSelectedSale(sale)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Sale Detail Modal */}
      {selectedSale && (
        <Dialog open={!!selectedSale} onOpenChange={() => setSelectedSale(null)}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Sale Details - {selectedSale.sale_number || selectedSale.id}</DialogTitle>
            </DialogHeader>
            <SaleDetailModal sale={selectedSale} onClose={() => setSelectedSale(null)} />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}