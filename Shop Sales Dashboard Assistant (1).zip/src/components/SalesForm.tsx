import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Plus, Calculator, Search, Package } from 'lucide-react';
import { FirebaseService, Product } from '../lib/firebase';
import { formatTZS, formatTZSWithSymbol } from '../lib/currency-utils';
import { toast } from 'sonner';

interface SalesFormProps {
  onSaleAdded: (saleData: {
    item: string;
    quantity: number;
    unitPrice: number;
    totalPrice: number;
    productId?: string; // Optional product ID for stock updates
  }) => Promise<void>;
  shopId: string;
}

export function SalesForm({ onSaleAdded, shopId }: SalesFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [formData, setFormData] = useState({
    selectedProductId: '',
    customItem: '',
    quantity: 1,
    unitPrice: '',
    useCustomItem: false
  });

  useEffect(() => {
    loadProducts();
  }, [shopId]);

  useEffect(() => {
    // Filter products based on search term
    if (searchTerm) {
      const filtered = products.filter(product => 
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.sku.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredProducts(filtered);
    } else {
      setFilteredProducts(products);
    }
  }, [searchTerm, products]);

  const loadProducts = async () => {
    try {
      setLoadingProducts(true);
      const activeProducts = await FirebaseService.getActiveProducts(shopId);
      setProducts(activeProducts);
      setFilteredProducts(activeProducts);
    } catch (error) {
      console.error('Error loading products:', error);
      toast.error('Failed to load products');
    } finally {
      setLoadingProducts(false);
    }
  };

  const selectedProduct = products.find(p => p.id === formData.selectedProductId);
  const totalPrice = formData.quantity * (parseFloat(formData.unitPrice) || 0);

  const handleProductSelect = (productId: string) => {
    const product = products.find(p => p.id === productId);
    if (product) {
      setFormData(prev => ({
        ...prev,
        selectedProductId: productId,
        unitPrice: product.price.toString(),
        useCustomItem: false,
        customItem: ''
      }));
    }
  };

  const handleCustomItemToggle = () => {
    setFormData(prev => ({
      ...prev,
      useCustomItem: !prev.useCustomItem,
      selectedProductId: '',
      customItem: '',
      unitPrice: ''
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const itemName = formData.useCustomItem 
      ? formData.customItem.trim() 
      : selectedProduct?.name || '';
    
    if (!itemName || !formData.unitPrice || formData.quantity <= 0) {
      return;
    }

    setIsSubmitting(true);
    
    try {
      await onSaleAdded({
        item: itemName,
        quantity: formData.quantity,
        unitPrice: parseFloat(formData.unitPrice),
        totalPrice: totalPrice,
        productId: formData.useCustomItem ? undefined : formData.selectedProductId || undefined,
      });

      // Reset form
      setFormData({
        selectedProductId: '',
        customItem: '',
        quantity: 1,
        unitPrice: '',
        useCustomItem: false
      });
      setSearchTerm('');
    } catch (error) {
      console.error('Error submitting sale:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleQuantityChange = (delta: number) => {
    setFormData(prev => ({
      ...prev,
      quantity: Math.max(1, prev.quantity + delta)
    }));
  };

  const formatCurrency = (amount: number) => {
    return formatTZS(amount);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Plus className="h-5 w-5 mr-2" />
          Record New Sale
        </CardTitle>
        <p className="text-sm text-gray-600">
          Select a product from inventory or add a custom item • Prices in TZS
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Product Selection Mode Toggle */}
          <div className="flex gap-2">
            <Button
              type="button"
              variant={!formData.useCustomItem ? "default" : "outline"}
              size="sm"
              onClick={handleCustomItemToggle}
              disabled={isSubmitting}
            >
              <Package className="h-4 w-4 mr-2" />
              From Catalog
            </Button>
            <Button
              type="button"
              variant={formData.useCustomItem ? "default" : "outline"}
              size="sm"
              onClick={handleCustomItemToggle}
              disabled={isSubmitting}
            >
              Custom Item
            </Button>
          </div>

          {/* Product Selection from Catalog */}
          {!formData.useCustomItem && (
            <div className="space-y-3">
              {/* Product Search */}
              <div className="space-y-2">
                <Label htmlFor="search">Search Products</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="search"
                    type="text"
                    placeholder="Search by name, category, or SKU..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                    disabled={isSubmitting}
                  />
                </div>
              </div>

              {/* Product Selection */}
              <div className="space-y-2">
                <Label>Select Product</Label>
                {loadingProducts ? (
                  <div className="text-center py-4">
                    <div className="animate-spin h-6 w-6 border-2 border-indigo-600 border-t-transparent rounded-full mx-auto"></div>
                    <p className="text-sm text-gray-600 mt-2">Loading products...</p>
                  </div>
                ) : filteredProducts.length === 0 ? (
                  <div className="text-center py-4 text-gray-500">
                    {searchTerm ? 'No products match your search' : 'No products available'}
                  </div>
                ) : (
                  <div className="grid gap-2 max-h-48 overflow-y-auto">
                    {filteredProducts.map((product) => (
                      <div
                        key={product.id}
                        onClick={() => handleProductSelect(product.id)}
                        className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                          formData.selectedProductId === product.id
                            ? 'border-indigo-500 bg-indigo-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="font-medium">{product.name}</h4>
                              <Badge variant="secondary">{product.category}</Badge>
                              {product.stock_quantity <= product.min_stock_level && (
                                <Badge variant="destructive">Low Stock</Badge>
                              )}
                            </div>
                            <p className="text-sm text-gray-600">{product.description}</p>
                            <div className="flex items-center gap-4 mt-1 text-xs text-gray-500">
                              <span>SKU: {product.sku}</span>
                              <span>Stock: {product.stock_quantity}</span>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-semibold">{formatCurrency(product.price)}</div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Custom Item Input */}
          {formData.useCustomItem && (
            <div className="space-y-2">
              <Label htmlFor="customItem">Custom Item Name</Label>
              <Input
                id="customItem"
                type="text"
                placeholder="Enter custom item name..."
                value={formData.customItem}
                onChange={(e) => setFormData({ ...formData, customItem: e.target.value })}
                disabled={isSubmitting}
                required
              />
            </div>
          )}

          {/* Unit Price - Pre-filled for catalog items, editable for custom items */}
          <div className="space-y-2">
            <Label htmlFor="unitPrice">Unit Price (TZS)</Label>
            <Input
              id="unitPrice"
              type="number"
              step="100"
              min="0"
              placeholder="0"
              value={formData.unitPrice}
              onChange={(e) => setFormData({ ...formData, unitPrice: e.target.value })}
              disabled={isSubmitting}
              required
              readOnly={!formData.useCustomItem && formData.selectedProductId !== ''}
            />
            {!formData.useCustomItem && selectedProduct && (
              <p className="text-xs text-gray-500">
                Price automatically set from product catalog
              </p>
            )}
          </div>

          {/* Quantity */}
          <div className="space-y-2">
            <Label htmlFor="quantity">Quantity</Label>
            <div className="flex items-center space-x-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => handleQuantityChange(-1)}
                disabled={formData.quantity <= 1 || isSubmitting}
              >
                -
              </Button>
              <Input
                id="quantity"
                type="number"
                min="1"
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) || 1 })}
                disabled={isSubmitting}
                className="text-center"
                required
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => handleQuantityChange(1)}
                disabled={isSubmitting}
              >
                +
              </Button>
            </div>
            {selectedProduct && selectedProduct.stock_quantity < formData.quantity && (
              <p className="text-xs text-red-600">
                Warning: Quantity exceeds available stock ({selectedProduct.stock_quantity} available)
              </p>
            )}
          </div>

          {/* Total Price Display */}
          {formData.unitPrice && (
            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Calculator className="h-5 w-5 text-green-600 mr-2" />
                  <span className="font-medium text-green-800">Total Price</span>
                </div>
                <span className="text-2xl font-bold text-green-800">
                  {formatCurrency(totalPrice)}
                </span>
              </div>
              <div className="text-sm text-green-700 mt-1">
                {formData.quantity} × {formatCurrency(parseFloat(formData.unitPrice) || 0)}
              </div>
              {selectedProduct && (
                <div className="text-xs text-green-600 mt-1">
                  Profit: {formatCurrency((parseFloat(formData.unitPrice) - selectedProduct.cost) * formData.quantity)}
                </div>
              )}
            </div>
          )}

          <Button 
            type="submit" 
            className="w-full" 
            disabled={
              isSubmitting || 
              (!formData.useCustomItem && !formData.selectedProductId) ||
              (formData.useCustomItem && !formData.customItem.trim()) ||
              !formData.unitPrice || 
              totalPrice <= 0
            }
          >
            {isSubmitting ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Recording Sale...
              </>
            ) : (
              <>
                <Plus className="h-4 w-4 mr-2" />
                Record Sale - {formatCurrency(totalPrice)}
              </>
            )}
          </Button>
        </form>

        {/* Quick Sale Buttons - Top Selling Products */}
        {!loadingProducts && products.length > 0 && (
          <div className="mt-6 pt-4 border-t">
            <h4 className="font-medium text-gray-900 mb-3">Quick Add Popular Items</h4>
            <div className="grid grid-cols-2 gap-2">
              {products.slice(0, 4).map((product) => (
                <Button
                  key={product.id}
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    handleProductSelect(product.id);
                    setFormData(prev => ({ ...prev, quantity: 1 }));
                  }}
                  disabled={isSubmitting}
                  className="text-xs p-2 h-auto"
                >
                  <div className="text-center">
                    <div className="font-medium">{product.name}</div>
                    <div className="text-gray-500">{formatCurrency(product.price)}</div>
                  </div>
                </Button>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}