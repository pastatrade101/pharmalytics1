import React from 'react';
import { Loader2 } from 'lucide-react';
import { ErrorDisplay } from './ErrorDisplay';
import { getAIStatusDisplay } from '../lib/app-helpers';
import { AISystemStatus } from '../lib/app-constants';

interface LoadingScreenProps {
  aiSystemStatus: AISystemStatus;
  errors: any[];
  hasPermissionErrors?: boolean;
  permissionErrorsCount?: number;
}

export function LoadingScreen({ aiSystemStatus, errors, hasPermissionErrors, permissionErrorsCount }: LoadingScreenProps) {
  const aiStatus = getAIStatusDisplay(aiSystemStatus);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
      <div className="text-center space-y-4">
        <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-indigo-600" />
        <p className="text-gray-600">Loading...</p>
        
        {/* Show loading info */}
        <div className="text-xs text-gray-500 space-y-1">
          <div>URL: {window.location.href}</div>
          <div>Loading since: {new Date().toLocaleTimeString()}</div>
          <div className="flex items-center justify-center gap-2">
            {aiStatus.icon}
            <span className={aiStatus.color}>{aiStatus.text}</span>
          </div>
          {aiSystemStatus === 'quota-exceeded' && (
            <div className="text-orange-600 text-center">
              <p>Free AI quota exceeded</p>
              <p>Using intelligent fallback</p>
            </div>
          )}
          {hasPermissionErrors && (
            <div className="text-red-600 text-center">
              <p>{permissionErrorsCount} permission error(s)</p>
              <p>Deploy Firebase rules required</p>
            </div>
          )}
        </div>

        {/* Show any loading errors */}
        {errors.length > 0 && (
          <div className="max-w-md">
            <ErrorDisplay showAll compact />
          </div>
        )}
      </div>
    </div>
  );
}