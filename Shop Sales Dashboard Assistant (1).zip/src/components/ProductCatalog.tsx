import React, { useState } from 'react';
import { Plus, Search, Filter, Edit, Trash2, Package, Pill, Scan, Download, Upload, Eye } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Switch } from './ui/switch';
import { Separator } from './ui/separator';
import { formatTZS } from '../lib/currency-utils';

interface ProductCatalogProps {
  userProfile: any;
  onBack: () => void;
  onSetCurrentView: (view: any) => void;
}

export function ProductCatalog({ userProfile, onBack, onSetCurrentView }: ProductCatalogProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);

  // Mock product data
  const products = [
    {
      id: '1',
      name: 'Paracetamol 500mg Tablets',
      genericName: 'Paracetamol',
      brandName: 'Panadol',
      sku: 'PAR500',
      barcode: '1234567890123',
      category: 'Pain Relief',
      dosageForm: 'Tablet',
      strength: '500mg',
      manufacturer: 'GlaxoSmithKline',
      retailPrice: 5000,
      wholesalePrice: 4000,
      insurancePrice: 4500,
      costPrice: 3500,
      stockQuantity: 150,
      minStockLevel: 20,
      requiresPrescription: false,
      status: 'active'
    },
    {
      id: '2',
      name: 'Amoxicillin 250mg Capsules',
      genericName: 'Amoxicillin',
      brandName: 'Amoxil',
      sku: 'AMX250',
      barcode: '2345678901234',
      category: 'Antibiotics',
      dosageForm: 'Capsule',
      strength: '250mg',
      manufacturer: 'Pfizer',
      retailPrice: 12000,
      wholesalePrice: 10000,
      insurancePrice: 11000,
      costPrice: 8500,
      stockQuantity: 75,
      minStockLevel: 15,
      requiresPrescription: true,
      status: 'active'
    },
    {
      id: '3',
      name: 'Vitamin C 1000mg Tablets',
      genericName: 'Ascorbic Acid',
      brandName: 'Redoxon',
      sku: 'VTC1000',
      barcode: '3456789012345',
      category: 'Vitamins & Supplements',
      dosageForm: 'Tablet',
      strength: '1000mg',
      manufacturer: 'Bayer',
      retailPrice: 8000,
      wholesalePrice: 6500,
      insurancePrice: 7000,
      costPrice: 5500,
      stockQuantity: 200,
      minStockLevel: 25,
      requiresPrescription: false,
      status: 'active'
    }
  ];

  const categories = [
    'Prescription Medicines',
    'Over-the-Counter (OTC)',
    'Antibiotics',
    'Pain Relief',
    'Vitamins & Supplements',
    'First Aid',
    'Baby Care',
    'Personal Care',
    'Medical Devices',
    'Herbal Medicines'
  ];

  const dosageForms = [
    'Tablet',
    'Capsule',
    'Syrup',
    'Injection',
    'Drops',
    'Cream/Ointment',
    'Inhaler',
    'Suppository',
    'Powder',
    'Solution'
  ];

  const getStockStatus = (current: number, min: number) => {
    if (current === 0) return { variant: 'destructive', text: 'Out of Stock' };
    if (current <= min) return { variant: 'secondary', text: 'Low Stock' };
    return { variant: 'default', text: 'In Stock' };
  };

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.genericName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.barcode?.includes(searchQuery);
    
    const matchesCategory = filterCategory === 'all' || product.category === filterCategory;
    const matchesStatus = filterStatus === 'all' || product.status === filterStatus;
    
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const ProductForm = ({ product, onClose }: any) => {
    const [formData, setFormData] = useState({
      name: product?.name || '',
      genericName: product?.genericName || '',
      brandName: product?.brandName || '',
      sku: product?.sku || '',
      barcode: product?.barcode || '',
      category: product?.category || '',
      dosageForm: product?.dosageForm || '',
      strength: product?.strength || '',
      manufacturer: product?.manufacturer || '',
      retailPrice: product?.retailPrice || 0,
      wholesalePrice: product?.wholesalePrice || 0,
      insurancePrice: product?.insurancePrice || 0,
      costPrice: product?.costPrice || 0,
      minStockLevel: product?.minStockLevel || 0,
      requiresPrescription: product?.requiresPrescription || false,
      description: product?.description || ''
    });

    return (
      <div className="space-y-6 max-h-[80vh] overflow-y-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="font-medium">Basic Information</h3>
            
            <div>
              <Label htmlFor="name">Product Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="Enter product name"
              />
            </div>

            <div>
              <Label htmlFor="genericName">Generic Name</Label>
              <Input
                id="genericName"
                value={formData.genericName}
                onChange={(e) => setFormData({...formData, genericName: e.target.value})}
                placeholder="Enter generic name"
              />
            </div>

            <div>
              <Label htmlFor="brandName">Brand Name</Label>
              <Input
                id="brandName"
                value={formData.brandName}
                onChange={(e) => setFormData({...formData, brandName: e.target.value})}
                placeholder="Enter brand name"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="sku">SKU *</Label>
                <Input
                  id="sku"
                  value={formData.sku}
                  onChange={(e) => setFormData({...formData, sku: e.target.value})}
                  placeholder="Product SKU"
                />
              </div>
              <div>
                <Label htmlFor="barcode">Barcode</Label>
                <Input
                  id="barcode"
                  value={formData.barcode}
                  onChange={(e) => setFormData({...formData, barcode: e.target.value})}
                  placeholder="Barcode number"
                />
              </div>
            </div>
          </div>

          {/* Product Details */}
          <div className="space-y-4">
            <h3 className="font-medium">Product Details</h3>
            
            <div>
              <Label htmlFor="category">Category *</Label>
              <Select value={formData.category} onValueChange={(value) => setFormData({...formData, category: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(category => (
                    <SelectItem key={category} value={category}>{category}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="dosageForm">Dosage Form</Label>
                <Select value={formData.dosageForm} onValueChange={(value) => setFormData({...formData, dosageForm: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select form" />
                  </SelectTrigger>
                  <SelectContent>
                    {dosageForms.map(form => (
                      <SelectItem key={form} value={form}>{form}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="strength">Strength</Label>
                <Input
                  id="strength"
                  value={formData.strength}
                  onChange={(e) => setFormData({...formData, strength: e.target.value})}
                  placeholder="e.g., 500mg"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="manufacturer">Manufacturer</Label>
              <Input
                id="manufacturer"
                value={formData.manufacturer}
                onChange={(e) => setFormData({...formData, manufacturer: e.target.value})}
                placeholder="Manufacturer name"
              />
            </div>

            <div>
              <Label htmlFor="minStockLevel">Minimum Stock Level</Label>
              <Input
                id="minStockLevel"
                type="number"
                value={formData.minStockLevel}
                onChange={(e) => setFormData({...formData, minStockLevel: Number(e.target.value)})}
                placeholder="Minimum stock level"
              />
            </div>
          </div>
        </div>

        {/* Pricing */}
        <div className="space-y-4">
          <h3 className="font-medium">Pricing (TZS)</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="costPrice">Cost Price *</Label>
              <Input
                id="costPrice"
                type="number"
                value={formData.costPrice}
                onChange={(e) => setFormData({...formData, costPrice: Number(e.target.value)})}
                placeholder="Cost price"
              />
            </div>
            <div>
              <Label htmlFor="retailPrice">Retail Price *</Label>
              <Input
                id="retailPrice"
                type="number"
                value={formData.retailPrice}
                onChange={(e) => setFormData({...formData, retailPrice: Number(e.target.value)})}
                placeholder="Retail price"
              />
            </div>
            <div>
              <Label htmlFor="wholesalePrice">Wholesale Price</Label>
              <Input
                id="wholesalePrice"
                type="number"
                value={formData.wholesalePrice}
                onChange={(e) => setFormData({...formData, wholesalePrice: Number(e.target.value)})}
                placeholder="Wholesale price"
              />
            </div>
            <div>
              <Label htmlFor="insurancePrice">Insurance Price</Label>
              <Input
                id="insurancePrice"
                type="number"
                value={formData.insurancePrice}
                onChange={(e) => setFormData({...formData, insurancePrice: Number(e.target.value)})}
                placeholder="Insurance price"
              />
            </div>
          </div>
        </div>

        {/* Additional Settings */}
        <div className="space-y-4">
          <h3 className="font-medium">Additional Settings</h3>
          
          <div className="flex items-center space-x-2">
            <Switch
              id="requiresPrescription"
              checked={formData.requiresPrescription}
              onCheckedChange={(checked) => setFormData({...formData, requiresPrescription: checked})}
            />
            <Label htmlFor="requiresPrescription">Requires Prescription</Label>
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              placeholder="Product description and usage instructions"
              rows={3}
            />
          </div>
        </div>

        <Separator />
        
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={() => {
            // Handle save
            console.log('Saving product:', formData);
            onClose();
          }}>
            {product ? 'Update Product' : 'Add Product'}
          </Button>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header Actions */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search products by name, SKU, or barcode..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 w-96"
            />
          </div>
          
          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map(category => (
                <SelectItem key={category} value={category}>{category}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-32">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Upload className="h-4 w-4 mr-2" />
            Import
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Dialog open={showAddProduct} onOpenChange={setShowAddProduct}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Product
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl">
              <DialogHeader>
                <DialogTitle>Add New Product</DialogTitle>
              </DialogHeader>
              <ProductForm onClose={() => setShowAddProduct(false)} />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Package className="h-8 w-8 text-blue-600" />
              <div>
                <div className="text-2xl font-bold">{products.length}</div>
                <p className="text-sm text-muted-foreground">Total Products</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Pill className="h-8 w-8 text-green-600" />
              <div>
                <div className="text-2xl font-bold">{products.filter(p => p.status === 'active').length}</div>
                <p className="text-sm text-muted-foreground">Active Products</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Scan className="h-8 w-8 text-purple-600" />
              <div>
                <div className="text-2xl font-bold">{products.filter(p => p.requiresPrescription).length}</div>
                <p className="text-sm text-muted-foreground">Prescription Required</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Filter className="h-8 w-8 text-orange-600" />
              <div>
                <div className="text-2xl font-bold">{categories.length}</div>
                <p className="text-sm text-muted-foreground">Categories</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Products Table */}
      <Card>
        <CardHeader>
          <CardTitle>Product Catalog ({filteredProducts.length} products)</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Product</TableHead>
                <TableHead>SKU</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Pricing</TableHead>
                <TableHead>Stock</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredProducts.map((product) => {
                const stockStatus = getStockStatus(product.stockQuantity, product.minStockLevel);
                return (
                  <TableRow key={product.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{product.name}</div>
                        <div className="text-sm text-gray-500">
                          {product.genericName && `Generic: ${product.genericName}`}
                          {product.strength && ` • ${product.strength}`}
                        </div>
                        {product.requiresPrescription && (
                          <Badge variant="secondary" className="mt-1 text-xs">
                            Prescription Required
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-mono text-sm">{product.sku}</div>
                        {product.barcode && (
                          <div className="text-xs text-gray-500">{product.barcode}</div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div>{product.category}</div>
                        <div className="text-sm text-gray-500">{product.dosageForm}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{formatTZS(product.retailPrice)}</div>
                        <div className="text-sm text-gray-500">
                          Cost: {formatTZS(product.costPrice)}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{product.stockQuantity}</div>
                        <Badge variant={stockStatus.variant as any} className="text-xs">
                          {stockStatus.text}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={product.status === 'active' ? 'default' : 'secondary'}>
                        {product.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button size="sm" variant="ghost" onClick={() => setSelectedProduct(product)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="ghost">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="ghost" className="text-red-600 hover:text-red-700">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Product Details Modal */}
      {selectedProduct && (
        <Dialog open={!!selectedProduct} onOpenChange={() => setSelectedProduct(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{selectedProduct.name}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Generic Name</Label>
                  <p>{selectedProduct.genericName || 'N/A'}</p>
                </div>
                <div>
                  <Label>Brand Name</Label>
                  <p>{selectedProduct.brandName || 'N/A'}</p>
                </div>
                <div>
                  <Label>SKU</Label>
                  <p className="font-mono">{selectedProduct.sku}</p>
                </div>
                <div>
                  <Label>Category</Label>
                  <p>{selectedProduct.category}</p>
                </div>
                <div>
                  <Label>Dosage Form</Label>
                  <p>{selectedProduct.dosageForm}</p>
                </div>
                <div>
                  <Label>Strength</Label>
                  <p>{selectedProduct.strength}</p>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <Label>Pricing</Label>
                <div className="grid grid-cols-2 gap-4 mt-2">
                  <div>Retail: {formatTZS(selectedProduct.retailPrice)}</div>
                  <div>Wholesale: {formatTZS(selectedProduct.wholesalePrice)}</div>
                  <div>Insurance: {formatTZS(selectedProduct.insurancePrice)}</div>
                  <div>Cost: {formatTZS(selectedProduct.costPrice)}</div>
                </div>
              </div>
              
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setSelectedProduct(null)}>
                  Close
                </Button>
                <Button>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Product
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}