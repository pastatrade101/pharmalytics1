import React, { useState, useCallback, useEffect } from 'react';
import { Navigation } from './Navigation';
import { View, UserProfile as UserProfileType } from '../lib/firebase';
import { AIConnectionStatus } from '../hooks/useAIConnection';

interface DashboardLayoutProps {
  currentView: View;
  userProfile: UserProfileType | null;
  aiSystemStatus: AIConnectionStatus;
  hasPermissionErrors: boolean;
  hasIndexErrors: boolean;
  onNavigate: (view: View) => void;
  onSignOut: () => void;
  children: React.ReactNode;
}

export function DashboardLayout({
  currentView,
  userProfile,
  aiSystemStatus,
  hasPermissionErrors,
  hasIndexErrors,
  onNavigate,
  onSignOut,
  children
}: DashboardLayoutProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);

  const handleSidebarStateChange = useCallback((collapsed: boolean) => {
    console.log('🔄 DashboardLayout: Sidebar state changing to:', collapsed);
    setSidebarCollapsed(collapsed);
    if (!isInitialized) {
      setIsInitialized(true);
    }
  }, [isInitialized]);

  // Debug: Track sidebar state changes
  useEffect(() => {
    console.log('🔄 DashboardLayout: Sidebar state updated to:', sidebarCollapsed);
    const classes = getMainContentClasses();
    console.log('🔄 DashboardLayout: Main content classes will be:', classes);
  }, [sidebarCollapsed, isInitialized]);

  // Fix: Ensure proper initialization timeout for dashboard view
  useEffect(() => {
    if (currentView === 'home' && !isInitialized) {
      console.log('🏠 DashboardLayout: Initializing for dashboard view');
      const timer = setTimeout(() => {
        if (!isInitialized) {
          console.log('🔄 DashboardLayout: Force initialization after timeout');
          setIsInitialized(true);
        }
      }, 100); // Small timeout to ensure Navigation component has mounted
      
      return () => clearTimeout(timer);
    }
  }, [currentView, isInitialized]);

  // Additional fix: Force re-render when switching to/from home view
  useEffect(() => {
    if (currentView === 'home') {
      console.log('🏠 DashboardLayout: Dashboard view detected, ensuring layout refresh');
      // Small delay to ensure proper state synchronization
      const refreshTimer = setTimeout(() => {
        console.log('🔄 DashboardLayout: Layout refresh for dashboard complete');
      }, 50);
      
      return () => clearTimeout(refreshTimer);
    }
  }, [currentView]);

  // Calculate main content margin based on sidebar state - with initialization check
  const getMainContentClasses = () => {
    // Always start with default expanded state until initialized
    const marginClass = isInitialized 
      ? (sidebarCollapsed ? 'lg:ml-16' : 'lg:ml-80')
      : 'lg:ml-80'; // Default to expanded state
      
    return `min-h-screen main-content-transition ${marginClass} p-6`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Navigation Sidebar */}
      <Navigation 
        userProfile={userProfile}
        currentView={currentView}
        onNavigate={onNavigate}
        onSignOut={onSignOut}
        aiSystemStatus={aiSystemStatus}
        hasPermissionErrors={hasPermissionErrors}
        hasIndexErrors={hasIndexErrors}
        onSidebarStateChange={handleSidebarStateChange}
      />

      {/* Main content area with proper desktop sidebar spacing */}
      <main className={getMainContentClasses()}>
        {children}
      </main>
    </div>
  );
}