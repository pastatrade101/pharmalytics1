import React from 'react';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { AlertTriangle, X, Bug, Shield, Database, Wifi, AlertCircle } from 'lucide-react';
import { useError } from '../contexts/ErrorContext';
import { isDevelopment } from '../lib/app-constants';

interface ErrorDisplayProps {
  errorType?: 'network' | 'validation' | 'permission' | 'system';
  compact?: boolean;
  showAll?: boolean;
  errors?: any[];
  hideSystemErrors?: boolean;
}

export function ErrorDisplay({ 
  errorType, 
  compact = false, 
  showAll = false, 
  errors: propErrors,
  hideSystemErrors = false
}: ErrorDisplayProps) {
  const { errors: contextErrors, clearErrorsByType, clearErrorsByContext } = useError();
  
  // Use prop errors if provided, otherwise use context errors
  const allErrors = propErrors || contextErrors;
  
  // Filter errors based on type and user-actionability
  const getFilteredErrors = () => {
    let filtered = allErrors;
    
    if (errorType) {
      filtered = allErrors.filter(error => error.type === errorType);
    }
    
    if (hideSystemErrors) {
      // Filter out system-level errors that users can't act on
      const systemErrorPatterns = [
        'Real AI analytics',
        'Gemini API connection',
        'AI system',
        'Connection established',
        'Analytics available',
        'WebChannelConnection',
        'Listen stream',
        'Firebase connection',
        'Real-time subscription',
        'Connection manager',
        'Listener setup',
        'Auth state',
        'Loaded',
        'products for expiry monitoring',
        'products from database',
        'Welcome back',
        'Successfully loaded',
        'Authentication successful',
        'Successfully signed out',
        'Welcome to Shop Sales Dashboard',
        'system using fallback',
        'fallback analysis',
        'quota exceeded',
        'intelligent fallback'
      ];
      
      filtered = filtered.filter(error => {
        const errorMessage = error.message || error.description || '';
        const isSystemError = systemErrorPatterns.some(pattern => 
          errorMessage.toLowerCase().includes(pattern.toLowerCase())
        );
        
        // Keep permission errors and validation errors, filter out system errors
        return error.isPermissionError || 
               error.type === 'validation' ||
               !isSystemError;
      });
    }
    
    // In production, only show user-actionable errors
    if (!isDevelopment && !showAll) {
      filtered = filtered.filter(error => 
        error.isPermissionError || 
        error.type === 'validation' ||
        error.type === 'permission' ||
        error.context === 'User Action Required'
      );
    }
    
    return filtered;
  };
  
  const filteredErrors = getFilteredErrors();
  
  if (filteredErrors.length === 0) {
    return null;
  }

  const getErrorIcon = (error: any) => {
    if (error.isPermissionError || error.type === 'permission') {
      return <Shield className="h-4 w-4" />;
    }
    if (error.type === 'network') {
      return <Wifi className="h-4 w-4" />;
    }
    if (error.type === 'validation') {
      return <AlertCircle className="h-4 w-4" />;
    }
    if (error.type === 'system') {
      return <Database className="h-4 w-4" />;
    }
    return <AlertTriangle className="h-4 w-4" />;
  };

  const getErrorVariant = (error: any) => {
    if (error.isPermissionError || error.type === 'permission') {
      return 'destructive';
    }
    return 'default';
  };

  const getErrorTitle = (errorType?: string) => {
    switch (errorType) {
      case 'network':
        return 'Connection Issues';
      case 'validation':
        return 'Input Validation';
      case 'permission':
        return 'Access Denied';
      case 'system':
        return isDevelopment ? 'System Information' : 'System Status';
      default:
        return filteredErrors.some(e => e.isPermissionError) ? 'Critical Issues' : 'Notifications';
    }
  };

  const handleClearErrors = () => {
    if (errorType) {
      clearErrorsByType(errorType);
    } else {
      clearErrorsByContext('All');
    }
  };

  // Don't show system errors to end users
  if (errorType === 'system' && !isDevelopment) {
    return null;
  }

  return (
    <Alert variant={getErrorVariant(filteredErrors[0])} className="mb-4">
      {getErrorIcon(filteredErrors[0])}
      <div className="flex justify-between items-start w-full">
        <div className="flex-1">
          <AlertTitle className="flex items-center gap-2">
            {getErrorTitle(errorType)}
            <Badge variant="secondary" className="text-xs">
              {filteredErrors.length}
            </Badge>
            {!isDevelopment && hideSystemErrors && (
              <Badge variant="outline" className="text-xs">
                User View
              </Badge>
            )}
          </AlertTitle>
          <AlertDescription className="mt-2">
            {compact ? (
              <div className="space-y-1">
                {filteredErrors.slice(0, 3).map((error, index) => (
                  <div key={index} className="text-sm">
                    {error.userMessage || error.message || 'An error occurred'}
                  </div>
                ))}
                {filteredErrors.length > 3 && (
                  <div className="text-xs text-muted-foreground">
                    +{filteredErrors.length - 3} more errors
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                {filteredErrors.map((error, index) => (
                  <div key={index} className="border-l-2 border-muted pl-4">
                    <div className="font-medium">
                      {error.userMessage || error.message || 'An error occurred'}
                    </div>
                    {error.context && (
                      <div className="text-sm text-muted-foreground mt-1">
                        Context: {error.context}
                      </div>
                    )}
                    {isDevelopment && error.stack && (
                      <details className="mt-2">
                        <summary className="text-xs cursor-pointer text-muted-foreground">
                          Technical Details
                        </summary>
                        <pre className="text-xs mt-1 p-2 bg-muted rounded overflow-x-auto">
                          {error.stack}
                        </pre>
                      </details>
                    )}
                  </div>
                ))}
              </div>
            )}
          </AlertDescription>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleClearErrors}
          className="ml-2 h-6 w-6 p-0"
        >
          <X className="h-3 w-3" />
          <span className="sr-only">Clear errors</span>
        </Button>
      </div>
    </Alert>
  );
}