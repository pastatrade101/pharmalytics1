import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { 
  Shield, 
  Mail, 
  AlertTriangle,
  ArrowLeft,
  User,
  Building,
  Phone
} from 'lucide-react';
import { isDevelopment, getSuperAdminEmailDenialReason } from '../lib/app-constants';

interface SuperAdminAccessDeniedProps {
  email?: string;
  onBackToRegular: () => void;
  onTryAgain: () => void;
}

export function SuperAdminAccessDenied({ 
  email, 
  onBackToRegular, 
  onTryAgain 
}: SuperAdminAccessDeniedProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-red-900 via-purple-900 to-indigo-900 flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={onBackToRegular}
          className="mb-4 text-white hover:bg-white/10"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Regular Login
        </Button>

        <Card className="shadow-2xl border-0 bg-white/95 backdrop-blur-sm">
          <CardHeader className="text-center pb-4">
            <div className="flex justify-center mb-4">
              <div className="p-3 bg-red-100 rounded-full">
                <Shield className="h-8 w-8 text-red-600" />
              </div>
            </div>
            <CardTitle className="text-2xl font-bold text-gray-900">
              Access Restricted
            </CardTitle>
            <p className="text-gray-600 mt-2">
              Super Admin Portal access is limited to authorized personnel only
            </p>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Main Error Alert */}
            <Alert className="bg-red-50 border-red-200">
              <AlertTriangle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">
                <strong>Email Authorization Required</strong>
                <br />
                The email address {email && `"${email}"`} is not authorized for super admin access.
                {email && (
                  <>
                    <br />
                    <span className="text-sm mt-1 block">
                      Reason: {getSuperAdminEmailDenialReason(email)}
                    </span>
                  </>
                )}
              </AlertDescription>
            </Alert>

            {/* Requirements Section */}
            <div className="bg-gray-50 rounded-lg p-4 space-y-3">
              <h3 className="font-semibold text-gray-900 flex items-center">
                <Mail className="h-4 w-4 mr-2 text-gray-600" />
                Authorized Email Requirements
              </h3>
              
              <div className="text-sm text-gray-700 space-y-2">
                <p>Your email must meet one of these criteria:</p>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Use domain: <code className="bg-gray-200 px-1 rounded">@pharmacyms.com</code></li>
                  <li>Use domain: <code className="bg-gray-200 px-1 rounded">@admin.pharmacyms.com</code></li>
                  <li>Use domain: <code className="bg-gray-200 px-1 rounded">@superadmin.pharmacyms.com</code></li>
                  <li>Use domain: <code className="bg-gray-200 px-1 rounded">@gmail.com</code></li>
                </ul>
              </div>
            </div>

            {/* What to do section */}
            <div className="bg-blue-50 rounded-lg p-4 space-y-3">
              <h3 className="font-semibold text-gray-900 flex items-center">
                <User className="h-4 w-4 mr-2 text-blue-600" />
                What should I do?
              </h3>
              
              <div className="text-sm text-blue-800 space-y-2">
                <p><strong>If you are a software owner or developer:</strong></p>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Use your official @pharmacyms.com email address</li>
                  <li>Or use your authorized @gmail.com email address</li>
                  <li>Contact the development team if you need domain access</li>
                </ul>
                
                <p className="mt-3"><strong>If you are a pharmacy owner or manager:</strong></p>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Use the regular login instead</li>
                  <li>Super admin access is only for software system management</li>
                  <li>Your pharmacy management features are available in the regular portal</li>
                </ul>
              </div>
            </div>

            {/* Contact Information */}
            <div className="bg-purple-50 rounded-lg p-4 space-y-3">
              <h3 className="font-semibold text-gray-900 flex items-center">
                <Phone className="h-4 w-4 mr-2 text-purple-600" />
                Need Super Admin Access?
              </h3>
              
              <div className="text-sm text-purple-800 space-y-2">
                <p>If you believe you should have super admin access:</p>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Contact the Pharmacy Management System development team</li>
                  <li>Provide proof of software ownership or development authorization</li>
                  <li>Request domain access for your email address</li>
                </ul>
                
                <div className="mt-3 p-3 bg-purple-100 rounded border">
                  <p className="font-medium">Contact: Pharmacy MS Development Team</p>
                  <p>Email: admin@pharmacyms.com</p>
                  <p className="text-xs mt-1">Please include your role and organization details</p>
                </div>
              </div>
            </div>

            {/* Development Mode Notice */}
            {isDevelopment && (
              <Alert className="bg-yellow-50 border-yellow-200">
                <AlertTriangle className="h-4 w-4 text-yellow-600" />
                <AlertDescription className="text-yellow-800">
                  <strong>Development Mode Notice:</strong> 
                  Email restrictions should be disabled in development. 
                  If you're seeing this error in development mode, there may be a configuration issue.
                </AlertDescription>
              </Alert>
            )}

            {/* Action Buttons */}
            <div className="space-y-3">
              <Button
                onClick={onTryAgain}
                className="w-full bg-purple-600 hover:bg-purple-700"
              >
                Try Different Email
              </Button>
              
              <Button
                onClick={onBackToRegular}
                variant="outline"
                className="w-full border-gray-300 text-gray-700 hover:bg-gray-50"
              >
                Continue to Regular Login
              </Button>
            </div>

            {/* Security Notice */}
            <Alert className="bg-gray-50 border-gray-200">
              <Building className="h-4 w-4 text-gray-600" />
              <AlertDescription className="text-gray-700 text-xs">
                <strong>Security Notice:</strong> Super admin access provides system-wide control 
                over all pharmacy accounts and software settings. Access is restricted to 
                authorized software owners and developers only.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-6 text-white/70 text-sm">
          <p>Pharmacy Management System - Access Control</p>
          <p className="mt-1">Unauthorized access attempts are logged and monitored</p>
        </div>
      </div>
    </div>
  );
}