import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { AlertTriangle, CheckCircle, Loader2, Zap, RefreshCw } from 'lucide-react';

interface APIDebugTesterProps {
  onClose?: () => void;
}

export function APIDebugTester({ onClose }: APIDebugTesterProps) {
  const [testResults, setTestResults] = useState<any[]>([]);
  const [testing, setTesting] = useState(false);

  const runAPITests = async () => {
    setTesting(true);
    setTestResults([]);
    const results: any[] = [];

    try {
      // Test 1: GET request to check if endpoint exists
      console.log('🧪 Test 1: GET request to /api/generate-report');
      const getResponse = await fetch('/api/generate-report', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      let getData;
      const getResponseClone = getResponse.clone();
      try {
        getData = await getResponse.json();
      } catch (parseError) {
        getData = await getResponseClone.text();
      }

      results.push({
        test: 'GET /api/generate-report',
        status: getResponse.status,
        success: getResponse.ok,
        data: getData,
        error: !getResponse.ok ? `HTTP ${getResponse.status}` : null
      });

      // Test 2: POST request with minimal payload
      console.log('🧪 Test 2: POST request to /api/generate-report');
      const testPayload = {
        type: 'business_intelligence',
        data: {
          pharmacyName: 'Test Pharmacy',
          timeframe: 'Test Period',
          metrics: {
            revenue: 100000,
            transactions: 50,
            products: 10,
            activeProducts: 8,
            lowStock: 2,
            expiring: 1,
            expired: 0,
            avgTransactionValue: 2000,
            monthlyGrowth: 5.5
          },
          topProducts: [
            { name: 'Test Product', sales: 10, revenue: 20000 }
          ],
          recentActivity: 5
        },
        userProfile: {
          role: 'owner',
          pharmacyType: 'community_pharmacy'
        }
      };

      const postResponse = await fetch('/api/generate-report', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(testPayload),
      });

      let postData;
      const postResponseClone = postResponse.clone();
      try {
        postData = await postResponse.json();
      } catch (parseError) {
        postData = await postResponseClone.text();
      }

      results.push({
        test: 'POST /api/generate-report',
        status: postResponse.status,
        success: postResponse.ok,
        data: postData,
        error: !postResponse.ok ? `HTTP ${postResponse.status}` : null
      });

      // Test 3: Check if App Router is being used
      console.log('🧪 Test 3: Checking App Router vs Pages Router');
      const debugResponse = await fetch('/api/generate-report?debug=true', {
        method: 'GET',
      });

      let debugData;
      const debugResponseClone = debugResponse.clone();
      try {
        debugData = await debugResponse.json();
      } catch (parseError) {
        debugData = await debugResponseClone.text();
      }

      results.push({
        test: 'Router Detection',
        status: debugResponse.status,
        success: debugResponse.ok,
        data: debugData,
        error: !debugResponse.ok ? `HTTP ${debugResponse.status}` : null
      });

    } catch (error: any) {
      console.error('🧪 API Test Error:', error);
      results.push({
        test: 'API Connection',
        status: 0,
        success: false,
        data: null,
        error: error.message || 'Network error'
      });
    }

    setTestResults(results);
    setTesting(false);
  };

  const getStatusBadge = (result: any) => {
    if (result.success) {
      return <Badge className="bg-green-100 text-green-800"><CheckCircle className="h-3 w-3 mr-1" />Success</Badge>;
    } else {
      return <Badge className="bg-red-100 text-red-800"><AlertTriangle className="h-3 w-3 mr-1" />Failed</Badge>;
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="h-5 w-5 text-blue-600" />
          API Debug Tester
          {onClose && (
            <Button 
              onClick={onClose} 
              variant="outline" 
              size="sm" 
              className="ml-auto"
            >
              Close
            </Button>
          )}
        </CardTitle>
        <p className="text-sm text-gray-600">
          Test the AI Business Intelligence API endpoint to diagnose connectivity issues
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-4">
          <Button
            onClick={runAPITests}
            disabled={testing}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {testing ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <RefreshCw className="h-4 w-4 mr-2" />
            )}
            {testing ? 'Running Tests...' : 'Run API Tests'}
          </Button>
          
          {testing && (
            <div className="text-sm text-gray-600 flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" />
              Testing API endpoints...
            </div>
          )}
        </div>

        {testResults.length > 0 && (
          <div className="space-y-4">
            <h3 className="font-semibold text-lg">Test Results</h3>
            
            {testResults.map((result, index) => (
              <Card key={index} className="border-l-4 border-l-blue-500">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">{result.test}</h4>
                    <div className="flex items-center gap-2">
                      {getStatusBadge(result)}
                      <Badge variant="outline">HTTP {result.status}</Badge>
                    </div>
                  </div>
                  
                  {result.error && (
                    <div className="mb-2 p-2 bg-red-50 border border-red-200 rounded text-sm text-red-700">
                      <strong>Error:</strong> {result.error}
                    </div>
                  )}
                  
                  {result.data && (
                    <div className="bg-gray-50 p-3 rounded text-sm overflow-auto">
                      <strong>Response:</strong>
                      <pre className="mt-1 whitespace-pre-wrap">
                        {typeof result.data === 'string' 
                          ? result.data 
                          : JSON.stringify(result.data, null, 2)
                        }
                      </pre>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
            
            {/* Summary */}
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="p-4">
                <h4 className="font-medium mb-2">Summary</h4>
                <div className="text-sm space-y-1">
                  <div>Total Tests: {testResults.length}</div>
                  <div>Passed: {testResults.filter(r => r.success).length}</div>
                  <div>Failed: {testResults.filter(r => !r.success).length}</div>
                  {testResults.some(r => r.success) && (
                    <div className="text-green-700 font-medium mt-2">
                      ✅ API endpoint is accessible and functional
                    </div>
                  )}
                  {testResults.every(r => !r.success) && (
                    <div className="text-red-700 font-medium mt-2">
                      ❌ API endpoint is not working properly
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </CardContent>
    </Card>
  );
}