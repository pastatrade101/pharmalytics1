import React, { useState, useEffect, useRef } from 'react';
import { Camera, X, Zap, RotateCw, Square, CheckCircle, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { toast } from 'sonner';

interface BarcodeScannerProps {
  isOpen: boolean;
  onClose: () => void;
  onScanSuccess: (data: ScannedProductData) => void;
  onError?: (error: string) => void;
}

interface ScannedProductData {
  barcode: string;
  productName?: string;
  brand?: string;
  category?: string;
  manufacturer?: string;
  description?: string;
  suggestedSku: string;
  confidence: 'high' | 'medium' | 'low';
  rawData: string;
}

interface QRScanner {
  start: () => Promise<void>;
  stop: () => void;
  destroy: () => void;
  setCamera: (deviceId: string) => Promise<void>;
}

export function BarcodeScanner({ isOpen, onClose, onScanSuccess, onError }: BarcodeScannerProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [availableCameras, setAvailableCameras] = useState<MediaDeviceInfo[]>([]);
  const [currentCameraId, setCurrentCameraId] = useState<string>('');
  const [scanResult, setScanResult] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string>('');
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const scannerRef = useRef<QRScanner | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Initialize QR Scanner dynamically
  useEffect(() => {
    let isMounted = true;
    
    const initScanner = async () => {
      if (!isOpen || !videoRef.current) return;
      
      try {
        // Dynamic import of QR Scanner
        const QrScanner = (await import('qr-scanner')).default;
        
        if (!isMounted) return;
        
        const scanner = new QrScanner(
          videoRef.current,
          (result: { data: string }) => handleScanResult(result.data),
          {
            returnDetailedScanResult: true,
            highlightScanRegion: true,
            highlightCodeOutline: true,
            preferredCamera: 'environment',
          }
        );
        
        scannerRef.current = scanner as unknown as QRScanner;
        
        await startScanning();
        
      } catch (error: any) {
        console.error('Failed to initialize scanner:', error);
        setError('Failed to initialize camera scanner. Please ensure your browser supports camera access.');
        if (onError) onError('Scanner initialization failed');
      }
    };
    
    if (isOpen) {
      initScanner();
    }
    
    return () => {
      isMounted = false;
      cleanup();
    };
  }, [isOpen]);

  // Get available cameras
  useEffect(() => {
    const getCameras = async () => {
      try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const cameras = devices.filter(device => device.kind === 'videoinput');
        setAvailableCameras(cameras);
        
        if (cameras.length > 0 && !currentCameraId) {
          // Prefer back camera for mobile, or first available camera
          const backCamera = cameras.find(camera => 
            camera.label.toLowerCase().includes('back') || 
            camera.label.toLowerCase().includes('rear')
          );
          setCurrentCameraId(backCamera?.deviceId || cameras[0].deviceId);
        }
      } catch (error) {
        console.error('Failed to get cameras:', error);
      }
    };
    
    if (isOpen) {
      getCameras();
    }
  }, [isOpen]);

  const requestCameraPermission = async (): Promise<boolean> => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'environment',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        } 
      });
      
      streamRef.current = stream;
      setHasPermission(true);
      return true;
    } catch (error: any) {
      console.error('Camera permission denied:', error);
      setHasPermission(false);
      setError('Camera access denied. Please allow camera permissions and try again.');
      return false;
    }
  };

  const startScanning = async () => {
    try {
      setIsScanning(true);
      setError('');
      
      if (!hasPermission) {
        const granted = await requestCameraPermission();
        if (!granted) return;
      }
      
      if (scannerRef.current) {
        await scannerRef.current.start();
        toast.success('Scanner ready! Point camera at barcode or QR code');
      }
    } catch (error: any) {
      console.error('Failed to start scanning:', error);
      setError('Failed to start camera. Please check permissions and try again.');
      setIsScanning(false);
      if (onError) onError('Failed to start scanner');
    }
  };

  const stopScanning = () => {
    setIsScanning(false);
    if (scannerRef.current) {
      scannerRef.current.stop();
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
  };

  const cleanup = () => {
    stopScanning();
    if (scannerRef.current) {
      scannerRef.current.destroy();
      scannerRef.current = null;
    }
  };

  const handleScanResult = async (data: string) => {
    if (!data || isProcessing) return;
    
    setIsProcessing(true);
    setScanResult(data);
    
    try {
      console.log('🔍 Scanned data:', data);
      
      // Process the scanned data
      const productData = await processScannedData(data);
      
      // Stop scanning after successful scan
      stopScanning();
      
      toast.success('Product scanned successfully!', {
        description: `Found: ${productData.productName || 'Product'}`
      });
      
      onScanSuccess(productData);
      onClose();
      
    } catch (error: any) {
      console.error('Error processing scan result:', error);
      toast.error('Scan processing failed', {
        description: 'Could not extract product information from scan'
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const processScannedData = async (data: string): Promise<ScannedProductData> => {
    // Generate auto SKU based on scanned data
    const suggestedSku = generateAutoSku(data);
    
    // Try to extract product information from the scanned data
    const productInfo = await extractProductInfo(data);
    
    return {
      barcode: data,
      ...productInfo,
      suggestedSku,
      rawData: data
    };
  };

  const generateAutoSku = (barcode: string): string => {
    const timestamp = Date.now().toString().slice(-6); // Last 6 digits of timestamp
    const barcodeHash = barcode.slice(-4); // Last 4 digits/chars of barcode
    const prefix = 'SKU'; // Standard prefix
    
    return `${prefix}${barcodeHash}${timestamp}`.toUpperCase();
  };

  const extractProductInfo = async (data: string): Promise<Partial<ScannedProductData>> => {
    // Default values
    let productInfo: Partial<ScannedProductData> = {
      confidence: 'low'
    };
    
    // Try to determine if it's a UPC/EAN barcode (numeric)
    const isNumericBarcode = /^\d+$/.test(data);
    
    if (isNumericBarcode) {
      // It's likely a UPC/EAN barcode
      productInfo = {
        ...productInfo,
        productName: `Product ${data.slice(-4)}`, // Fallback name
        category: 'Medicine', // Default for pharmacy
        confidence: 'medium'
      };
      
      // Try to look up product in known databases (mock implementation)
      const lookupResult = await lookupProductByBarcode(data);
      if (lookupResult) {
        productInfo = { ...productInfo, ...lookupResult, confidence: 'high' };
      }
    } else {
      // It might be a QR code with structured data
      try {
        const parsed = JSON.parse(data);
        if (parsed.name || parsed.product) {
          productInfo = {
            ...productInfo,
            productName: parsed.name || parsed.product,
            brand: parsed.brand,
            category: parsed.category || 'Medicine',
            manufacturer: parsed.manufacturer,
            description: parsed.description,
            confidence: 'high'
          };
        }
      } catch {
        // Not JSON, treat as plain text
        productInfo = {
          ...productInfo,
          productName: data.length > 50 ? `${data.slice(0, 50)}...` : data,
          confidence: 'low'
        };
      }
    }
    
    return productInfo;
  };

  const lookupProductByBarcode = async (barcode: string): Promise<Partial<ScannedProductData> | null> => {
    // Mock product database lookup
    // In a real implementation, this would call an external API like Open Food Facts or UPC Database
    
    const mockDatabase: { [key: string]: Partial<ScannedProductData> } = {
      '123456789': {
        productName: 'Paracetamol 500mg',
        brand: 'Generic',
        category: 'Pain Relief',
        manufacturer: 'PharmaCorp',
        description: 'Pain relief and fever reducer'
      },
      '987654321': {
        productName: 'Vitamin C 1000mg',
        brand: 'HealthPlus',
        category: 'Vitamins & Supplements',
        manufacturer: 'VitaLabs',
        description: 'High-potency vitamin C supplement'
      }
    };
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return mockDatabase[barcode] || null;
  };

  const switchCamera = async () => {
    if (availableCameras.length <= 1) return;
    
    const currentIndex = availableCameras.findIndex(cam => cam.deviceId === currentCameraId);
    const nextIndex = (currentIndex + 1) % availableCameras.length;
    const nextCamera = availableCameras[nextIndex];
    
    setCurrentCameraId(nextCamera.deviceId);
    
    if (scannerRef.current) {
      try {
        await scannerRef.current.setCamera(nextCamera.deviceId);
        toast.success('Camera switched successfully');
      } catch (error) {
        console.error('Failed to switch camera:', error);
        toast.error('Failed to switch camera');
      }
    }
  };

  const handleClose = () => {
    cleanup();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-hidden">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="flex items-center gap-2">
            <Camera className="h-5 w-5" />
            Barcode Scanner
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={handleClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          {hasPermission === false && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Camera access is required for scanning. Please allow camera permissions and refresh the page.
              </AlertDescription>
            </Alert>
          )}
          
          {/* Camera View */}
          <div className="relative bg-black rounded-lg overflow-hidden" style={{ aspectRatio: '16/9' }}>
            <video
              ref={videoRef}
              className="w-full h-full object-cover"
              playsInline
              muted
            />
            
            {/* Scanning Overlay */}
            {isScanning && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="relative">
                  {/* Scanning Frame */}
                  <div className="w-64 h-64 border-2 border-green-500 rounded-lg relative">
                    <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-green-500"></div>
                    <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-green-500"></div>
                    <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-green-500"></div>
                    <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-green-500"></div>
                    
                    {/* Scanning Line */}
                    <div className="absolute inset-x-0 top-1/2 h-0.5 bg-green-500 animate-pulse"></div>
                  </div>
                  
                  {/* Instructions */}
                  <div className="absolute -bottom-16 left-1/2 transform -translate-x-1/2 text-white text-center">
                    <p className="text-sm font-medium">Point camera at barcode or QR code</p>
                    <p className="text-xs opacity-75">Hold steady for best results</p>
                  </div>
                </div>
              </div>
            )}
            
            {/* Processing Overlay */}
            {isProcessing && (
              <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                <div className="text-white text-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-4 border-green-500 border-t-transparent mx-auto mb-4"></div>
                  <p className="text-sm font-medium">Processing scan...</p>
                </div>
              </div>
            )}
          </div>
          
          {/* Controls */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Badge variant={isScanning ? "default" : "secondary"}>
                {isScanning ? "Scanning" : "Ready"}
              </Badge>
              
              {scanResult && (
                <Badge variant="outline" className="font-mono text-xs">
                  {scanResult.length > 20 ? `${scanResult.slice(0, 20)}...` : scanResult}
                </Badge>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              {availableCameras.length > 1 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={switchCamera}
                  disabled={!isScanning}
                >
                  <RotateCw className="h-4 w-4" />
                </Button>
              )}
              
              <Button
                variant="outline"
                size="sm"
                onClick={isScanning ? stopScanning : startScanning}
                disabled={hasPermission === false}
              >
                {isScanning ? (
                  <>
                    <Square className="h-4 w-4 mr-2" />
                    Stop
                  </>
                ) : (
                  <>
                    <Zap className="h-4 w-4 mr-2" />
                    Start
                  </>
                )}
              </Button>
            </div>
          </div>
          
          {/* Camera Info */}
          {availableCameras.length > 0 && (
            <div className="text-xs text-gray-600">
              Camera: {availableCameras.find(cam => cam.deviceId === currentCameraId)?.label || 'Unknown'}
              {availableCameras.length > 1 && ` (${availableCameras.length} available)`}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}