import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Users, TrendingUp, AlertTriangle, BarChart3 } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';

interface CustomerReportsProps {
  userProfile: any;
  onBack: () => void;
  onSetCurrentView: (view: any) => void;
}

export function CustomerReports({ userProfile, onBack, onSetCurrentView }: CustomerReportsProps) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center">
            <Users className="h-6 w-6 mr-2" />
            Customer Analytics
          </h1>
          <p className="text-gray-600 mt-1">Customer behavior and loyalty analysis</p>
        </div>
        <Button onClick={onBack} variant="outline">Back to Dashboard</Button>
      </div>

      <Alert className="border-blue-200 bg-blue-50">
        <AlertTriangle className="h-4 w-4 text-blue-600" />
        <AlertDescription>
          <strong className="text-blue-900">Customer Analytics Coming Soon</strong>
          <br />
          <span className="text-blue-800">Customer behavior analysis, loyalty tracking, and segmentation</span>
        </AlertDescription>
      </Alert>

      <div className="text-center py-12">
        <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-600 mb-2">Customer Analytics</h3>
        <p className="text-gray-500 mb-6">Customer insights and behavior analysis</p>
        <Button onClick={() => onSetCurrentView('customer-accounts')} variant="outline">View Customer Accounts</Button>
      </div>
    </div>
  );
}