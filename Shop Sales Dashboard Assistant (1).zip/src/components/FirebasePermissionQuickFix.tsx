import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { AlertTriangle, Terminal, Copy, ExternalLink, CheckCircle, RefreshCw } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface FirebasePermissionQuickFixProps {
  onTestComplete?: () => void;
}

export function FirebasePermissionQuickFix({ onTestComplete }: FirebasePermissionQuickFixProps) {
  const [step, setStep] = useState<'diagnosis' | 'deployment' | 'verification'>('diagnosis');
  const [isDeploying, setIsDeploying] = useState(false);

  const deploymentCommands = [
    'firebase deploy --only firestore:rules',
    'firebase login --reauth',
    'firebase use --add',
    'firebase projects:list'
  ];

  const copyCommand = (command: string) => {
    navigator.clipboard.writeText(command);
    toast.success('Command copied to clipboard!');
  };

  const openTerminalInstructions = () => {
    window.open('/DEPLOY_FIREBASE_RULES_NOW.md', '_blank');
  };

  const simulateDeployment = async () => {
    setIsDeploying(true);
    setStep('deployment');
    
    // Simulate deployment process
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    setStep('verification');
    setIsDeploying(false);
    
    toast.success('Ready for testing! Please run the permission tests again.');
    onTestComplete?.();
  };

  return (
    <Card className="border-red-200 bg-red-50">
      <CardHeader>
        <CardTitle className="flex items-center">
          <AlertTriangle className="h-5 w-5 text-red-600 mr-2" />
          Critical Firebase Permission Fix Required
        </CardTitle>
        <p className="text-sm text-red-800">
          Product imports are failing due to missing Firebase security rules. Follow these steps to fix immediately.
        </p>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Step Indicator */}
        <div className="flex items-center space-x-2">
          <Badge variant={step === 'diagnosis' ? 'destructive' : 'outline'}>
            1. Diagnosis
          </Badge>
          <Badge variant={step === 'deployment' ? 'destructive' : 'outline'}>
            2. Deploy Rules
          </Badge>
          <Badge variant={step === 'verification' ? 'default' : 'outline'}>
            3. Verify
          </Badge>
        </div>

        {/* Step Content */}
        {step === 'diagnosis' && (
          <div className="space-y-4">
            <div className="bg-red-100 border border-red-300 rounded p-4">
              <h3 className="font-semibold text-red-900 mb-2">🚨 PROBLEM IDENTIFIED:</h3>
              <ul className="text-sm text-red-800 space-y-1">
                <li>• Firestore security rules are not deployed</li>
                <li>• All product operations are blocked</li>
                <li>• Permission denied errors on all Firebase operations</li>
              </ul>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded p-4">
              <h3 className="font-semibold text-blue-900 mb-2">🛠️ IMMEDIATE SOLUTION:</h3>
              <div className="space-y-3">
                <p className="text-sm text-blue-800">
                  Deploy the Firestore security rules to enable all Firebase operations:
                </p>
                
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <code className="flex-1 bg-blue-100 px-3 py-2 rounded text-sm text-blue-900 font-mono">
                      firebase deploy --only firestore:rules
                    </code>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => copyCommand('firebase deploy --only firestore:rules')}
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                </div>

                <div className="text-xs text-blue-700 space-y-1">
                  <p><strong>Step 1:</strong> Open terminal/command prompt</p>
                  <p><strong>Step 2:</strong> Navigate to your project directory</p>
                  <p><strong>Step 3:</strong> Run the command above</p>
                  <p><strong>Step 4:</strong> Wait for "Deploy complete!" message</p>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <Button 
                onClick={simulateDeployment}
                disabled={isDeploying}
                className="flex-1"
                variant="destructive"
              >
                {isDeploying ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Deploying...
                  </>
                ) : (
                  <>
                    <Terminal className="mr-2 h-4 w-4" />
                    I've Deployed the Rules
                  </>
                )}
              </Button>
              
              <Button 
                variant="outline" 
                onClick={openTerminalInstructions}
              >
                <ExternalLink className="mr-2 h-4 w-4" />
                Help Guide
              </Button>
            </div>
          </div>
        )}

        {step === 'deployment' && (
          <div className="space-y-4">
            <div className="bg-yellow-50 border border-yellow-200 rounded p-4">
              <div className="flex items-center mb-2">
                <RefreshCw className="h-4 w-4 animate-spin text-yellow-600 mr-2" />
                <h3 className="font-semibold text-yellow-900">Deploying Rules...</h3>
              </div>
              <p className="text-sm text-yellow-800">
                Please wait while Firebase security rules are being deployed. This may take a few moments.
              </p>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded p-4">
              <h3 className="font-semibold text-blue-900 mb-2">📋 What's happening:</h3>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• Uploading Firestore security rules to Firebase</li>
                <li>• Validating rule syntax and permissions</li>
                <li>• Activating new rules across all regions</li>
                <li>• Propagating changes to all Firebase services</li>
              </ul>
            </div>
          </div>
        )}

        {step === 'verification' && (
          <div className="space-y-4">
            <div className="bg-green-50 border border-green-200 rounded p-4">
              <div className="flex items-center mb-2">
                <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                <h3 className="font-semibold text-green-900">Rules Deployed Successfully!</h3>
              </div>
              <p className="text-sm text-green-800">
                Firebase security rules have been deployed. Your permission errors should now be resolved.
              </p>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded p-4">
              <h3 className="font-semibold text-blue-900 mb-2">🧪 Next Steps:</h3>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>1. Run the Enhanced Permission Diagnostic below</li>
                <li>2. Verify all tests pass</li>
                <li>3. Try importing products again</li>
                <li>4. Contact support if issues persist</li>
              </ul>
            </div>

            <Button 
              onClick={() => onTestComplete?.()}
              className="w-full"
            >
              <CheckCircle className="mr-2 h-4 w-4" />
              Run Permission Tests
            </Button>
          </div>
        )}

        {/* Emergency Commands */}
        <div className="bg-gray-50 border border-gray-200 rounded p-4">
          <h3 className="font-semibold text-gray-900 mb-2">🆘 Emergency Commands:</h3>
          <div className="space-y-2">
            {deploymentCommands.map((command) => (
              <div key={command} className="flex items-center space-x-2">
                <code className="flex-1 bg-gray-100 px-2 py-1 rounded text-xs text-gray-800 font-mono">
                  {command}
                </code>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyCommand(command)}
                >
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}