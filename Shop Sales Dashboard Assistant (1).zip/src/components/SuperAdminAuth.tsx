import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { 
  Shield, 
  Eye, 
  EyeOff, 
  Lock, 
  Mail, 
  User, 
  AlertTriangle,
  Loader2,
  ArrowLeft,
  Crown,
  Store
} from 'lucide-react';
import { FirebaseService } from '../lib/firebase';
import { canAccessSuperAdminPortal } from '../lib/app-constants';
import { useError } from '../contexts/ErrorContext';
import { SuperAdminAccessDenied } from './SuperAdminAccessDenied';

interface SuperAdminAuthProps {
  onAuthSuccess: () => void;
  onBackToRegular: () => void;
}

export function SuperAdminAuth({ onAuthSuccess, onBackToRegular }: SuperAdminAuthProps) {
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showAccessDenied, setShowAccessDenied] = useState(false);
  const [deniedEmail, setDeniedEmail] = useState('');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    fullName: '',
    accessCode: ''
  });

  const { addError, addSuccess } = useError();

  // Super Admin access code
  const SUPER_ADMIN_ACCESS_CODE = 'PHARMACY_MS_OWNER_2024';

  const validateForm = (): { errors: string[], hasEmailError: boolean } => {
    const errors: string[] = [];
    let hasEmailError = false;
    
    if (!formData.email.trim()) {
      errors.push('Email is required');
    } else if (!formData.email.includes('@')) {
      errors.push('Please enter a valid email address');
    } else if (!canAccessSuperAdminPortal(formData.email)) {
      hasEmailError = true;
      // Don't add to errors array - we'll handle this gracefully
    }

    if (!formData.password) {
      errors.push('Password is required');
    } else if (formData.password.length < 8) {
      errors.push('Password must be at least 8 characters long');
    }

    if (mode === 'signup') {
      if (!formData.fullName.trim()) {
        errors.push('Full name is required');
      }
      
      if (formData.password !== formData.confirmPassword) {
        errors.push('Passwords do not match');
      }
      
      if (formData.accessCode !== SUPER_ADMIN_ACCESS_CODE) {
        errors.push('Invalid access code');
      }
    }

    return { errors, hasEmailError };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const validation = validateForm();
      
      // Handle email authorization error gracefully
      if (validation.hasEmailError) {
        setDeniedEmail(formData.email);
        setShowAccessDenied(true);
        setIsLoading(false);
        return;
      }
      
      // Handle other validation errors
      if (validation.errors.length > 0) {
        validation.errors.forEach(error => {
          addError(new Error(error), 'Super Admin Auth', error);
        });
        return;
      }

      if (mode === 'signup') {
        // Create super admin account (NO PHARMACY CREATED)
        console.log('🛡️ Creating super admin account (no pharmacy will be created)...');
        await FirebaseService.createSuperAdminAccount({
          email: formData.email,
          password: formData.password,
          fullName: formData.fullName,
          role: 'super_admin'
        });
        
        addSuccess('Super admin account created successfully', 'Super Admin Auth');
        console.log('✅ Super admin account created - user will have system oversight capabilities');
        onAuthSuccess();
      } else {
        // Sign in super admin
        await FirebaseService.signInSuperAdmin(formData.email, formData.password);
        addSuccess('Super admin signed in successfully', 'Super Admin Auth');
        onAuthSuccess();
      }
    } catch (error: any) {
      console.error('[Super Admin Auth] ERROR:', {
        message: mode === 'signup' ? 'Failed to create super admin account' : 'Failed to sign in as super admin',
        type: 'error',
        action: 'Review Error Details',
        instructions: 'Try signing out and signing back in. If the problem persists, clear your browser cache.',
        originalError: error
      });
      
      // Handle Firebase authentication errors gracefully
      let errorMessage = mode === 'signup' 
        ? 'Failed to create super admin account' 
        : 'Failed to sign in as super admin';
        
      // Check for specific Firebase auth errors
      if (error?.code === 'auth/user-not-found') {
        errorMessage = 'No super admin account found with this email address. Please check your email or create an account.';
      } else if (error?.code === 'auth/wrong-password') {
        errorMessage = 'Incorrect password. Please check your password and try again.';
      } else if (error?.code === 'auth/email-already-in-use') {
        errorMessage = 'An account with this email already exists. Try signing in instead.';
      } else if (error?.code === 'auth/weak-password') {
        errorMessage = 'Password is too weak. Please choose a stronger password.';
      } else if (error?.code === 'auth/invalid-email') {
        errorMessage = 'Invalid email address format. Please check your email.';
      } else if (error?.code === 'auth/too-many-requests') {
        errorMessage = 'Too many failed attempts. Please wait a few minutes before trying again.';
      } else if (error?.name === 'SuperAdminAccessDenied') {
        errorMessage = error.message || 'Access denied. This account is not authorized for super admin access.';
      } else if (error?.name === 'SuperAdminProfileNotFound') {
        errorMessage = 'Super admin profile not found. Please contact the system administrator.';
      } else if (error?.name === 'SuperAdminProfileCreationFailed') {
        errorMessage = error.message || 'Failed to create super admin profile. Please contact the system administrator.';
      } else if (error?.message) {
        errorMessage = error.message;
      }
      
      console.error('[Super Admin Auth] Enhanced error details:', {
        code: error?.code,
        name: error?.name,
        message: errorMessage,
        originalMessage: error?.message,
        context: mode,
        email: formData.email
      });
      
      addError(error, 'Super Admin Auth', errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleMode = () => {
    setMode(mode === 'signin' ? 'signup' : 'signin');
    setFormData({
      email: '',
      password: '',
      confirmPassword: '',
      fullName: '',
      accessCode: ''
    });
  };

  const handleTryAgain = () => {
    setShowAccessDenied(false);
    setDeniedEmail('');
    setFormData({
      email: '',
      password: '',
      confirmPassword: '',
      fullName: '',
      accessCode: ''
    });
  };

  // Show access denied screen if email is not authorized
  if (showAccessDenied) {
    return (
      <SuperAdminAccessDenied
        email={deniedEmail}
        onBackToRegular={onBackToRegular}
        onTryAgain={handleTryAgain}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={onBackToRegular}
          className="mb-4 text-white hover:bg-white/10"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Regular Login
        </Button>

        <Card className="shadow-2xl border-0 bg-white/95 backdrop-blur-sm">
          <CardHeader className="text-center pb-4">
            <div className="flex justify-center mb-4">
              <div className="p-3 bg-purple-100 rounded-full">
                <Shield className="h-8 w-8 text-purple-600" />
              </div>
            </div>
            <CardTitle className="text-2xl font-bold text-gray-900">
              Super Admin Portal
            </CardTitle>
            <p className="text-gray-600 mt-2">
              {mode === 'signin' 
                ? 'Sign in to access the software owner dashboard' 
                : 'Create your super admin account'
              }
            </p>
          </CardHeader>

          <CardContent className="space-y-4">
            <Alert className="bg-purple-50 border-purple-200">
              <Shield className="h-4 w-4 text-purple-600" />
              <AlertDescription className="text-purple-800">
                This portal is restricted to authorized software owners only. 
                Only specific email domains (@pharmacyms.com, @gmail.com) are permitted.
              </AlertDescription>
            </Alert>

            {/* Important Notice for Super Admin Registration */}
            {mode === 'signup' && (
              <Alert className="bg-blue-50 border-blue-200">
                <Crown className="h-4 w-4 text-blue-600" />
                <AlertDescription className="text-blue-800">
                  <strong>Super Admin Account:</strong> This creates a system administrator account with full oversight capabilities. No pharmacy business will be created with this account.
                </AlertDescription>
              </Alert>
            )}

            {/* Notice about Pharmacy Owner Registration */}
            <Alert className="bg-amber-50 border-amber-200">
              <Store className="h-4 w-4 text-amber-600" />
              <AlertDescription className="text-amber-800 text-sm">
                <strong>Looking to create a pharmacy business?</strong> Use the regular registration on the main login page and select "Pharmacy Owner" to create your pharmacy management system.
              </AlertDescription>
            </Alert>

            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'signup' && (
                <div className="space-y-2">
                  <Label htmlFor="fullName" className="text-sm font-medium">
                    Full Name
                  </Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="fullName"
                      type="text"
                      placeholder="Enter your full name"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium">
                  Email Address
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="admin@pharmacyms.com or admin@gmail.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="pl-10"
                    required
                  />
                </div>
                <p className="text-xs text-gray-500">
                  Must use an authorized email domain (@pharmacyms.com, @admin.pharmacyms.com, @superadmin.pharmacyms.com, @gmail.com)
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium">
                  Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter your password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="pl-10 pr-10"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-1 top-1 h-8 w-8 p-0"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 text-gray-400" />
                    ) : (
                      <Eye className="h-4 w-4 text-gray-400" />
                    )}
                  </Button>
                </div>
              </div>

              {mode === 'signup' && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword" className="text-sm font-medium">
                      Confirm Password
                    </Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="confirmPassword"
                        type="password"
                        placeholder="Confirm your password"
                        value={formData.confirmPassword}
                        onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                        className="pl-10"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="accessCode" className="text-sm font-medium">
                      Super Admin Access Code
                    </Label>
                    <div className="relative">
                      <Shield className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="accessCode"
                        type="password"
                        placeholder="Enter the super admin access code"
                        value={formData.accessCode}
                        onChange={(e) => setFormData({ ...formData, accessCode: e.target.value })}
                        className="pl-10"
                        required
                      />
                    </div>
                    <p className="text-xs text-gray-500">
                      Contact the software development team for the access code
                    </p>
                  </div>
                </>
              )}

              <Button
                type="submit"
                className="w-full bg-purple-600 hover:bg-purple-700"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {mode === 'signin' ? 'Signing In...' : 'Creating Account...'}
                  </>
                ) : (
                  <>
                    <Shield className="mr-2 h-4 w-4" />
                    {mode === 'signin' ? 'Sign In as Super Admin' : 'Create Super Admin Account'}
                  </>
                )}
              </Button>
            </form>

            <Separator />

            <div className="text-center">
              <Button
                variant="ghost"
                onClick={toggleMode}
                className="text-purple-600 hover:text-purple-700"
              >
                {mode === 'signin' 
                  ? "Don't have a super admin account? Create one" 
                  : 'Already have an account? Sign in'
                }
              </Button>
            </div>

            {/* Security Notice */}
            <Alert className="bg-amber-50 border-amber-200">
              <AlertTriangle className="h-4 w-4 text-amber-600" />
              <AlertDescription className="text-amber-800 text-xs">
                <strong>Security Notice:</strong> Super admin access provides full system control. 
                Only authorized personnel should have access. All actions are logged and monitored.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-6 text-white/70 text-sm">
          <p>Pharmacy Management System - Super Admin Portal</p>
          <p className="mt-1">Restricted Access • All Activity Monitored</p>
        </div>
      </div>
    </div>
  );
}