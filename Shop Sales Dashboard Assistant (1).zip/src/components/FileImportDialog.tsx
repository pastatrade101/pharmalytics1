import React, { useState, useRef } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Progress } from './ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { Upload, File, X, AlertTriangle, CheckCircle, FileText, Table } from 'lucide-react';
import { toast } from 'sonner';
import { UserProfile, FirebaseService } from '../lib/firebase';
import { canImportProducts } from '../lib/app-constants';

interface FileImportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  userProfile: UserProfile | null;
  onImportComplete: () => void;
}

interface ImportProgress {
  current: number;
  total: number;
  percentage: number;
  currentItem?: string;
  status: 'idle' | 'parsing' | 'importing' | 'complete' | 'error';
  errors: string[];
  successCount: number;
  failedCount: number;
}

interface ParsedProduct {
  name: string;
  generic_name?: string;
  brand_name?: string;
  description?: string;
  category: string;
  strength?: string;
  manufacturer: string;
  sku: string;
  cost_price: number;
  retail_price: number;
  stock_quantity: number;
  min_stock_level: number;
  expiry_date?: Date;
  batch_number?: string;
  supplier_info?: string;
  status: 'active' | 'inactive';
}

export function FileImportDialog({ open, onOpenChange, userProfile, onImportComplete }: FileImportDialogProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [importProgress, setImportProgress] = useState<ImportProgress>({
    current: 0,
    total: 0,
    percentage: 0,
    status: 'idle',
    errors: [],
    successCount: 0,
    failedCount: 0
  });
  const [parsedProducts, setParsedProducts] = useState<ParsedProduct[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const supportedFormats = ['.csv', '.xlsx', '.xls'];
  const maxFileSize = 5 * 1024 * 1024; // 5MB

  const resetImportState = () => {
    setSelectedFile(null);
    setParsedProducts([]);
    setImportProgress({
      current: 0,
      total: 0,
      percentage: 0,
      status: 'idle',
      errors: [],
      successCount: 0,
      failedCount: 0
    });
  };

  const handleFileSelect = (file: File) => {
    // Validate file type
    const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
    if (!supportedFormats.includes(fileExtension)) {
      toast.error('Unsupported file format', {
        description: `Please select a CSV or Excel file. Supported formats: ${supportedFormats.join(', ')}`,
        duration: 5000
      });
      return;
    }

    // Validate file size
    if (file.size > maxFileSize) {
      toast.error('File too large', {
        description: `File size must be less than ${maxFileSize / 1024 / 1024}MB. Current file: ${(file.size / 1024 / 1024).toFixed(2)}MB`,
        duration: 5000
      });
      return;
    }

    setSelectedFile(file);
    toast.success('File selected successfully', {
      description: `Ready to import ${file.name}`,
      duration: 3000
    });
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileSelect(e.target.files[0]);
    }
  };

  const parseCSV = (content: string): ParsedProduct[] => {
    const lines = content.split('\n').filter(line => line.trim());
    if (lines.length < 2) {
      throw new Error('File must contain at least a header row and one data row');
    }

    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, '').toLowerCase());
    const products: ParsedProduct[] = [];

    // Expected column mapping
    const columnMapping = {
      name: ['name', 'product name', 'product_name', 'productname'],
      generic_name: ['generic name', 'generic_name', 'genericname', 'generic'],
      brand_name: ['brand name', 'brand_name', 'brandname', 'brand'],
      description: ['description', 'desc', 'product description'],
      category: ['category', 'product category', 'type'],
      strength: ['strength', 'dosage', 'dose'],
      manufacturer: ['manufacturer', 'mfg', 'company'],
      sku: ['sku', 'product code', 'code', 'item code'],
      cost_price: ['cost price', 'cost_price', 'costprice', 'cost', 'purchase price'],
      retail_price: ['retail price', 'retail_price', 'retailprice', 'price', 'selling price'],
      stock_quantity: ['stock quantity', 'stock_quantity', 'stockquantity', 'stock', 'quantity', 'qty'],
      min_stock_level: ['min stock level', 'min_stock_level', 'minstocklevel', 'min stock', 'minimum stock'],
      expiry_date: ['expiry date', 'expiry_date', 'expirydate', 'expiry', 'exp date'],
      batch_number: ['batch number', 'batch_number', 'batchnumber', 'batch', 'lot'],
      supplier_info: ['supplier', 'supplier info', 'supplier_info', 'vendor'],
      status: ['status', 'active', 'state']
    };

    // Find column indices
    const columnIndices: { [key: string]: number } = {};
    for (const [field, aliases] of Object.entries(columnMapping)) {
      const index = headers.findIndex(header => aliases.includes(header));
      if (index !== -1) {
        columnIndices[field] = index;
      }
    }

    // Validate required columns
    const requiredColumns = ['name', 'sku', 'manufacturer', 'retail_price', 'cost_price', 'stock_quantity', 'min_stock_level'];
    const missingColumns = requiredColumns.filter(col => columnIndices[col] === undefined);
    
    if (missingColumns.length > 0) {
      throw new Error(`Missing required columns: ${missingColumns.join(', ')}`);
    }

    // Parse data rows
    for (let i = 1; i < lines.length; i++) {
      try {
        const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
        
        if (values.length < headers.length) {
          console.warn(`Row ${i + 1}: Insufficient columns, skipping`);
          continue;
        }

        const product: ParsedProduct = {
          name: values[columnIndices.name] || '',
          generic_name: values[columnIndices.generic_name] || undefined,
          brand_name: values[columnIndices.brand_name] || undefined,
          description: values[columnIndices.description] || undefined,
          category: values[columnIndices.category] || 'Over-the-Counter',
          strength: values[columnIndices.strength] || undefined,
          manufacturer: values[columnIndices.manufacturer] || '',
          sku: values[columnIndices.sku] || '',
          cost_price: parseFloat(values[columnIndices.cost_price] || '0'),
          retail_price: parseFloat(values[columnIndices.retail_price] || '0'),
          stock_quantity: parseInt(values[columnIndices.stock_quantity] || '0'),
          min_stock_level: parseInt(values[columnIndices.min_stock_level] || '0'),
          expiry_date: columnIndices.expiry_date && values[columnIndices.expiry_date] 
            ? new Date(values[columnIndices.expiry_date]) 
            : undefined,
          batch_number: values[columnIndices.batch_number] || undefined,
          supplier_info: values[columnIndices.supplier_info] || undefined,
          status: (values[columnIndices.status]?.toLowerCase() === 'inactive' ? 'inactive' : 'active') as 'active' | 'inactive'
        };

        // Validate product data
        if (!product.name || !product.sku || !product.manufacturer) {
          console.warn(`Row ${i + 1}: Missing required fields, skipping`);
          continue;
        }

        if (isNaN(product.cost_price) || isNaN(product.retail_price) || 
            isNaN(product.stock_quantity) || isNaN(product.min_stock_level)) {
          console.warn(`Row ${i + 1}: Invalid numeric values, skipping`);
          continue;
        }

        products.push(product);
      } catch (error) {
        console.warn(`Row ${i + 1}: Parse error, skipping:`, error);
      }
    }

    return products;
  };

  const parseFile = async (file: File): Promise<ParsedProduct[]> => {
    const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
    
    if (fileExtension === '.csv') {
      const content = await file.text();
      return parseCSV(content);
    } else if (fileExtension === '.xlsx' || fileExtension === '.xls') {
      // For Excel files, we'll convert to CSV first
      // Note: In a real implementation, you'd use a library like xlsx
      toast.error('Excel import not yet implemented', {
        description: 'Please convert your Excel file to CSV format for now.',
        duration: 5000
      });
      throw new Error('Excel import not yet implemented');
    } else {
      throw new Error('Unsupported file format');
    }
  };

  const handleStartImport = async () => {
    if (!selectedFile || !userProfile) {
      toast.error('Missing requirements', {
        description: 'Please select a file and ensure you are logged in.',
        duration: 5000
      });
      return;
    }

    // CRITICAL FIX: Check user permissions before starting import with up-to-date validation
    const allowedRoles = ['product_manager', 'owner', 'admin', 'super_admin'];
    const hasPermission = allowedRoles.includes(userProfile.role);
    
    if (!hasPermission) {
      const error = {
        message: `Your role (${userProfile.role}) doesn't have permission to import products. Required roles: ${allowedRoles.join(', ')}`,
        type: 'error',
        action: 'Review Error Details',
        instructions: 'Review the error details and try refreshing the page. Contact support if the issue persists.',
        originalError: {}
      };
      
      setImportProgress(prev => ({
        ...prev,
        status: 'error',
        errors: [error.message]
      }));

      toast.error('❌ Permission Denied', {
        description: error.message,
        duration: 8000
      });
      return;
    }

    setImportProgress(prev => ({ ...prev, status: 'parsing' }));

    try {
      // Parse the file
      toast.info('📋 Parsing file...', {
        description: `Reading data from ${selectedFile.name}`,
        duration: 3000
      });

      const products = await parseFile(selectedFile);
      setParsedProducts(products);

      setImportProgress({
        current: 0,
        total: products.length,
        percentage: 0,
        status: 'importing',
        errors: [],
        successCount: 0,
        failedCount: 0
      });

      // Start importing products with progress tracking
      toast.info('🚀 Starting product import...', {
        description: `Importing ${products.length} products to your pharmacy`,
        duration: 3000
      });

      let successCount = 0;
      let failedCount = 0;
      const errors: string[] = [];

      for (let i = 0; i < products.length; i++) {
        const product = products[i];
        
        setImportProgress(prev => ({
          ...prev,
          current: i + 1,
          percentage: Math.round(((i + 1) / products.length) * 100),
          currentItem: product.name
        }));

        try {
          await FirebaseService.createProduct({
            name: product.name,
            generic_name: product.generic_name,
            brand_name: product.brand_name,
            description: product.description,
            category: product.category,
            strength: product.strength,
            manufacturer: product.manufacturer,
            sku: product.sku,
            cost_price: product.cost_price,
            retail_price: product.retail_price,
            stock_quantity: product.stock_quantity,
            min_stock_level: product.min_stock_level,
            expiry_date: product.expiry_date,
            status: product.status,
            created_by: userProfile.id
          });

          successCount++;
        } catch (error: any) {
          failedCount++;
          const errorMsg = `${product.name} (${product.sku}): ${error.message}`;
          errors.push(errorMsg);
          console.warn('Failed to import product:', errorMsg);
        }

        // Add small delay to prevent overwhelming Firebase
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      setImportProgress(prev => ({
        ...prev,
        status: 'complete',
        successCount,
        failedCount,
        errors
      }));

      toast.success('✅ Import Complete!', {
        description: `Successfully imported ${successCount} products. ${failedCount > 0 ? `${failedCount} failed.` : ''}`,
        duration: 8000
      });

      onImportComplete();

    } catch (error: any) {
      console.error('Import failed:', error);
      setImportProgress(prev => ({
        ...prev,
        status: 'error',
        errors: [error.message]
      }));

      toast.error('❌ Import Failed', {
        description: error.message || 'Failed to import products. Please check your file format.',
        duration: 8000
      });
    }
  };

  const handleClose = () => {
    if (importProgress.status === 'importing') {
      toast.warning('Import in progress', {
        description: 'Please wait for the import to complete before closing.',
        duration: 3000
      });
      return;
    }
    resetImportState();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Import Products from File
          </DialogTitle>
          <DialogDescription>
            Upload a CSV or Excel file containing your product data. Ensure all required columns are included and properly formatted.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* File Upload Area */}
          {importProgress.status === 'idle' && (
            <div className="space-y-4">
              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                  dragActive
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-300 hover:border-gray-400'
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <div className="flex flex-col items-center space-y-4">
                  <div className="p-3 bg-gray-100 rounded-full">
                    <FileText className="h-8 w-8 text-gray-500" />
                  </div>
                  
                  {selectedFile ? (
                    <div className="space-y-2">
                      <div className="flex items-center justify-center space-x-2">
                        <File className="h-5 w-5 text-green-600" />
                        <span className="font-medium text-green-600">{selectedFile.name}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setSelectedFile(null)}
                          className="h-6 w-6 p-0"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                      <p className="text-sm text-gray-500">
                        Size: {(selectedFile.size / 1024 / 1024).toFixed(2)}MB
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <p className="text-lg">Drop your file here or click to browse</p>
                      <p className="text-sm text-gray-500">
                        Supported formats: {supportedFormats.join(', ')} • Max size: 5MB
                      </p>
                    </div>
                  )}
                  
                  <Button
                    variant="outline"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={importProgress.status === 'importing'}
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Select File
                  </Button>
                  
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept={supportedFormats.join(',')}
                    onChange={handleFileInputChange}
                    className="hidden"
                  />
                </div>
              </div>

              {/* File Requirements */}
              <Alert>
                <Table className="h-4 w-4" />
                <AlertDescription>
                  <strong>Required columns:</strong> Name, SKU, Manufacturer, Retail Price, Cost Price, Stock Quantity, Min Stock Level
                  <br />
                  <strong>Optional columns:</strong> Generic Name, Brand Name, Description, Category, Strength, Expiry Date, Batch Number, Supplier, Status
                </AlertDescription>
              </Alert>
            </div>
          )}

          {/* Import Progress */}
          {(importProgress.status === 'parsing' || importProgress.status === 'importing') && (
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>
                    {importProgress.status === 'parsing' ? 'Parsing file...' : 'Importing products...'}
                  </span>
                  <span>{importProgress.percentage}%</span>
                </div>
                <Progress value={importProgress.percentage} className="w-full" />
              </div>

              {importProgress.currentItem && (
                <p className="text-sm text-gray-600">
                  Current: {importProgress.currentItem} ({importProgress.current} of {importProgress.total})
                </p>
              )}

              <div className="flex justify-between text-sm">
                <span className="text-green-600">Success: {importProgress.successCount}</span>
                <span className="text-red-600">Failed: {importProgress.failedCount}</span>
              </div>
            </div>
          )}

          {/* Import Complete */}
          {importProgress.status === 'complete' && (
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-green-600">
                <CheckCircle className="h-5 w-5" />
                <span className="font-medium">Import completed successfully!</span>
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="bg-green-50 p-3 rounded-lg">
                  <div className="font-medium text-green-800">Successful</div>
                  <div className="text-2xl font-bold text-green-600">{importProgress.successCount}</div>
                </div>
                <div className="bg-red-50 p-3 rounded-lg">
                  <div className="font-medium text-red-800">Failed</div>
                  <div className="text-2xl font-bold text-red-600">{importProgress.failedCount}</div>
                </div>
              </div>

              {importProgress.errors.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-medium text-red-800">Errors:</h4>
                  <div className="max-h-32 overflow-y-auto bg-red-50 p-3 rounded border">
                    {importProgress.errors.slice(0, 10).map((error, index) => (
                      <p key={index} className="text-sm text-red-700">{error}</p>
                    ))}
                    {importProgress.errors.length > 10 && (
                      <p className="text-sm text-red-600 italic">
                        ... and {importProgress.errors.length - 10} more errors
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Import Error */}
          {importProgress.status === 'error' && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Import failed:</strong> {importProgress.errors[0] || 'Unknown error occurred'}
              </AlertDescription>
            </Alert>
          )}

          <Separator />

          {/* Actions */}
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={handleClose}
              disabled={importProgress.status === 'importing'}
            >
              {importProgress.status === 'complete' ? 'Close' : 'Cancel'}
            </Button>
            
            {importProgress.status === 'idle' && selectedFile && (
              <Button onClick={handleStartImport}>
                <Upload className="h-4 w-4 mr-2" />
                Start Import
              </Button>
            )}

            {importProgress.status === 'complete' && (
              <Button onClick={resetImportState}>
                Import Another File
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}