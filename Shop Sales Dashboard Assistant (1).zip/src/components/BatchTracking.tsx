import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Package, AlertTriangle, Calendar, Truck } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';

interface BatchTrackingProps {
  userProfile: any;
  onBack: () => void;
  onSetCurrentView: (view: any) => void;
}

export function BatchTracking({ userProfile, onBack, onSetCurrentView }: BatchTrackingProps) {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center">
            <Package className="h-6 w-6 mr-2" />
            Batch Tracking
          </h1>
          <p className="text-gray-600 mt-1">Track product batches, lot numbers, and expiry dates</p>
        </div>
        <Button onClick={onBack} variant="outline">
          Back to Dashboard
        </Button>
      </div>

      {/* Feature Coming Soon */}
      <Alert className="border-blue-200 bg-blue-50">
        <AlertTriangle className="h-4 w-4 text-blue-600" />
        <AlertDescription>
          <strong className="text-blue-900">Batch Tracking System Coming Soon</strong>
          <br />
          <span className="text-blue-800">
            This feature will enable comprehensive tracking of pharmaceutical batches, lot numbers, 
            expiry dates, and supplier information for regulatory compliance.
          </span>
        </AlertDescription>
      </Alert>

      {/* Placeholder Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="cursor-pointer hover:shadow-md transition-shadow opacity-60">
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <Package className="h-8 w-8 text-blue-600" />
              <div>
                <h3 className="font-medium">Active Batches</h3>
                <p className="text-sm text-gray-500">Track current product batches</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow opacity-60">
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <Calendar className="h-8 w-8 text-orange-600" />
              <div>
                <h3 className="font-medium">Expiry Monitoring</h3>
                <p className="text-sm text-gray-500">Monitor expiring batches</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow opacity-60">
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <Truck className="h-8 w-8 text-green-600" />
              <div>
                <h3 className="font-medium">Supplier Tracking</h3>
                <p className="text-sm text-gray-500">Track batch suppliers</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="text-center py-12">
        <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-600 mb-2">Batch Tracking System</h3>
        <p className="text-gray-500 mb-6">
          Comprehensive pharmaceutical batch management coming soon
        </p>
        <Button onClick={() => onSetCurrentView('inventory')} variant="outline">
          View Inventory Management
        </Button>
      </div>
    </div>
  );
}