import React, { useState, useEffect } from 'react';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent } from './ui/card';
import { AlertTriangle, Wrench, CheckCircle, Loader2, X } from 'lucide-react';
import { ProductMigrationService } from '../lib/firebase-products-migration';
import { formatTZS } from '../lib/currency-utils';
import { toast } from 'sonner';

interface ProductPricingAlertProps {
  shopId: string;
  hasPermissionErrors?: boolean;
  onMigrationComplete?: () => void;
}

export function ProductPricingAlert({ shopId, hasPermissionErrors = false, onMigrationComplete }: ProductPricingAlertProps) {
  const [isChecking, setIsChecking] = useState(false);
  const [isMigrating, setIsMigrating] = useState(false);
  const [issues, setIssues] = useState<any[]>([]);
  const [hasChecked, setHasChecked] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);
  const [migrationComplete, setMigrationComplete] = useState(false);

  // Early return if permission errors exist - component should not have been rendered
  if (hasPermissionErrors) {
    console.warn('⚠️ ProductPricingAlert rendered with permission errors - this component should be conditionally rendered');
    return null;
  }

  useEffect(() => {
    // Only auto-check for issues if there are no permission errors
    if (!hasPermissionErrors) {
      checkForIssues();
    }
  }, [shopId, hasPermissionErrors]);

  const checkForIssues = async () => {
    if (!shopId || isChecking || hasPermissionErrors) return;

    setIsChecking(true);
    try {
      const preview = await ProductMigrationService.previewProductFixes(shopId);
      setIssues(preview);
      setHasChecked(true);
      
      if (preview.length > 0) {
        console.log(`🚨 Found ${preview.length} products with pricing issues`);
      }
    } catch (error: any) {
      console.error('Error checking for pricing issues:', error);
      
      // If it's a permission error, don't show the alert
      if (error?.code === 'permission-denied' || error?.message?.includes('permission')) {
        console.log('⚠️ Permission denied - Firebase rules not deployed yet');
        setHasChecked(true); // Mark as checked to prevent retries
        return;
      }
      
      // For other errors, mark as checked but don't show issues
      setHasChecked(true);
    } finally {
      setIsChecking(false);
    }
  };

  const handleFixPricing = async () => {
    if (hasPermissionErrors) {
      toast.error('Cannot fix pricing - Firebase rules need to be deployed first');
      return;
    }

    setIsMigrating(true);
    try {
      await ProductMigrationService.fixShopProductPricing(shopId);
      setMigrationComplete(true);
      setIssues([]);
      
      toast.success('Product pricing fixed successfully!');
      
      if (onMigrationComplete) {
        onMigrationComplete();
      }
      
      // Auto-hide after successful migration
      setTimeout(() => {
        setIsDismissed(true);
      }, 3000);
      
    } catch (error: any) {
      console.error('Migration failed:', error);
      
      if (error?.code === 'permission-denied') {
        toast.error('Permission denied - Please deploy Firebase rules first');
      } else {
        toast.error('Failed to fix product pricing');
      }
    } finally {
      setIsMigrating(false);
    }
  };

  // Don't show if dismissed or no shopId
  if (isDismissed || !shopId) {
    return null;
  }

  // Show permission error state
  if (hasPermissionErrors) {
    return (
      <Alert className="border-red-200 bg-red-50 mb-4">
        <AlertTriangle className="h-4 w-4 text-red-600" />
        <div className="flex items-start justify-between w-full">
          <div className="flex-1">
            <AlertTitle className="text-red-800">Firebase Rules Required</AlertTitle>
            <AlertDescription className="text-red-700">
              Deploy Firebase security rules to check for product pricing issues and enable the migration tool.
            </AlertDescription>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setIsDismissed(true)}
            className="text-red-600 hover:text-red-800"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </Alert>
    );
  }

  // Don't show if no issues found after checking
  if (hasChecked && issues.length === 0) {
    return null;
  }

  // Show checking state
  if (isChecking) {
    return (
      <Card className="border-blue-200 bg-blue-50 mb-4">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <Loader2 className="h-5 w-5 animate-spin text-blue-600" />
            <div>
              <h4 className="font-medium text-blue-800">Checking product data...</h4>
              <p className="text-blue-700 text-sm">Scanning for pricing issues in your inventory</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Show success state
  if (migrationComplete) {
    return (
      <Alert className="border-green-200 bg-green-50 mb-4">
        <CheckCircle className="h-4 w-4 text-green-600" />
        <div className="flex items-center justify-between w-full">
          <div>
            <AlertTitle className="text-green-800">Pricing Issues Fixed!</AlertTitle>
            <AlertDescription className="text-green-700">
              All product pricing data has been updated. Your POS system should now display correct prices.
            </AlertDescription>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setIsDismissed(true)}
            className="text-green-600 hover:text-green-800"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </Alert>
    );
  }

  // Show issues found
  if (hasChecked && issues.length > 0) {
    return (
      <Alert className="border-amber-200 bg-amber-50 mb-4">
        <AlertTriangle className="h-4 w-4 text-amber-600" />
        <div className="flex items-start justify-between w-full">
          <div className="flex-1">
            <AlertTitle className="text-amber-800">Product Pricing Issues Detected</AlertTitle>
            <AlertDescription className="text-amber-700 mb-3">
              Found {issues.length} products with missing or invalid prices. This causes "NaN" to appear in your POS system.
            </AlertDescription>
            
            <div className="flex items-center gap-3 mb-3">
              <Badge variant="outline" className="text-amber-700 border-amber-300">
                {issues.length} products affected
              </Badge>
              <Badge variant="outline" className="text-amber-700 border-amber-300">
                Default prices will be applied
              </Badge>
            </div>
            
            <div className="flex gap-2">
              <Button 
                onClick={handleFixPricing}
                disabled={isMigrating || hasPermissionErrors}
                size="sm"
                className="bg-amber-600 hover:bg-amber-700 text-white disabled:opacity-50"
              >
                {isMigrating ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <Wrench className="h-4 w-4 mr-2" />
                )}
                {hasPermissionErrors ? 'Deploy Rules First' : 'Fix Pricing Now'}
              </Button>
              
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setIsDismissed(true)}
                className="text-amber-700 border-amber-300 hover:bg-amber-100"
              >
                Dismiss
              </Button>
            </div>
          </div>
        </div>
      </Alert>
    );
  }

  return null;
}