import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface APITestResult {
  method: string;
  status: number;
  success: boolean;
  data: any;
  error?: string;
  url: string;
  timestamp: string;
}

export function SimpleAPITester() {
  const [results, setResults] = useState<APITestResult[]>([]);
  const [testing, setTesting] = useState(false);

  const testAPI = async (method: 'GET' | 'POST', endpoint: string = '/api/generate-report') => {
    setTesting(true);
    const timestamp = new Date().toISOString();
    
    try {
      const options: RequestInit = {
        method,
        headers: {
          'Content-Type': 'application/json',
        }
      };

      if (method === 'POST') {
        if (endpoint.includes('health')) {
          options.body = JSON.stringify({ test: 'health check data' });
        } else {
          options.body = JSON.stringify({
            type: 'business_intelligence',
            data: {
              pharmacyName: 'Test Pharmacy',
              timeframe: 'Test',
              metrics: {
                revenue: 100000,
                transactions: 50,
                products: 10,
                activeProducts: 8,
                lowStock: 2,
                expiring: 1,
                expired: 0,
                avgTransactionValue: 2000,
                monthlyGrowth: 5.5
              },
              topProducts: [{ name: 'Test Product', sales: 10, revenue: 20000 }],
              recentActivity: 5
            },
            userProfile: {
              role: 'owner',
              pharmacyType: 'community_pharmacy'
            }
          });
        }
      }

      console.log(`🧪 Testing ${method} ${endpoint}`);
      const response = await fetch(endpoint, options);
      
      let data;
      const responseClone = response.clone();
      try {
        data = await response.json();
      } catch (parseError) {
        console.log('JSON parse failed, trying text:', parseError);
        data = await responseClone.text();
      }
      
      const result: APITestResult = {
        method,
        status: response.status,
        success: response.ok,
        data,
        url: response.url,
        timestamp,
        error: response.ok ? undefined : `HTTP ${response.status} ${response.statusText}`
      };

      setResults(prev => [result, ...prev.slice(0, 4)]); // Keep last 5 results
      
    } catch (error: any) {
      const result: APITestResult = {
        method,
        status: 0,
        success: false,
        data: null,
        url: endpoint,
        timestamp,
        error: error.message || 'Network error'
      };
      
      setResults(prev => [result, ...prev.slice(0, 4)]);
    }
    
    setTesting(false);
  };

  const clearResults = () => {
    setResults([]);
  };

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          🧪 Simple API Tester
          <Badge variant="outline" className="ml-auto">
            /api/generate-report
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2 flex-wrap">
          <Button 
            onClick={() => testAPI('GET', '/api/health')} 
            disabled={testing}
            size="sm"
            variant="outline"
          >
            Health GET
          </Button>
          <Button 
            onClick={() => testAPI('POST', '/api/health')} 
            disabled={testing}
            size="sm"
            variant="outline"
          >
            Health POST
          </Button>
          <Button 
            onClick={() => testAPI('GET')} 
            disabled={testing}
            size="sm"
            variant="outline"
          >
            Report GET
          </Button>
          <Button 
            onClick={() => testAPI('POST')} 
            disabled={testing}
            size="sm"
            variant="outline"
          >
            Report POST
          </Button>
          <Button 
            onClick={clearResults} 
            disabled={testing || results.length === 0}
            size="sm"
            variant="ghost"
          >
            Clear
          </Button>
        </div>

        <div className="space-y-2">
          {results.map((result, index) => (
            <Card key={index} className={`border-l-4 ${
              result.success ? 'border-l-green-500' : 'border-l-red-500'
            }`}>
              <CardContent className="p-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">{result.method} Request</span>
                  <div className="flex items-center gap-2">
                    <Badge className={result.success ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                      {result.status || 'ERR'}
                    </Badge>
                    <span className="text-xs text-gray-500">
                      {new Date(result.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                </div>
                
                {result.error && (
                  <div className="text-sm text-red-600 mb-2">
                    Error: {result.error}
                  </div>
                )}
                
                <details className="text-xs">
                  <summary className="cursor-pointer text-gray-600 hover:text-gray-800">
                    View Response
                  </summary>
                  <pre className="mt-2 p-2 bg-gray-50 rounded overflow-auto">
                    {typeof result.data === 'string' 
                      ? result.data 
                      : JSON.stringify(result.data, null, 2)
                    }
                  </pre>
                </details>
              </CardContent>
            </Card>
          ))}
        </div>

        {results.length === 0 && (
          <div className="text-center text-gray-500 py-4">
            No tests run yet. Click a button above to test the API.
          </div>
        )}
      </CardContent>
    </Card>
  );
}