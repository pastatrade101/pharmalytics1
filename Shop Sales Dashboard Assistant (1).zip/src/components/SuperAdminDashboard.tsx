import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Separator } from './ui/separator';
import { 
  Building2, 
  Users, 
  TrendingUp, 
  DollarSign, 
  Search, 
  Filter, 
  Eye, 
  Activity,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
  BarChart3,
  PieChart,
  Calendar,
  Download,
  RefreshCw,
  Settings,
  Shield,
  ArrowUp,
  ArrowDown,
  Minus
} from 'lucide-react';
import { UserProfile, FirebaseService, SalesService } from '../lib/firebase';
import { formatTZS } from '../lib/currency-utils';
import { useError } from '../contexts/ErrorContext';
import { 
  calculateInventoryValue, 
  calculateTotalRevenue, 
  safeString, 
  safeParseDate,
  createErrorContext,
  isValidShopData
} from '../lib/data-validation-utils';

// Enhanced types for real Firestore data
interface SuperAdminMetrics {
  totalPharmacies: number;
  activePharmacies: number;
  totalUsers: number;
  totalRevenue: number;
  monthlyGrowth: number;
  systemHealth: 'good' | 'warning' | 'critical';
  lastUpdated: Date;
}

interface PharmacyOverview {
  id: string;
  name: string;
  owner: string;
  ownerEmail: string;
  location: string;
  status: 'active' | 'inactive' | 'suspended';
  createdAt: Date;
  lastActivity: Date;
  totalUsers: number;
  monthlyRevenue: number;
  inventoryValue: number;
  healthScore: number;
  settings?: {
    currency?: string;
    timezone?: string;
  };
}

interface SuperAdminDashboardProps {
  userProfile: UserProfile | null;
  onViewPharmacy: (pharmacyId: string) => void;
  onNavigate: (view: string) => void;
}

export function SuperAdminDashboard({ userProfile, onViewPharmacy, onNavigate }: SuperAdminDashboardProps) {
  const [metrics, setMetrics] = useState<SuperAdminMetrics | null>(null);
  const [pharmacies, setPharmacies] = useState<PharmacyOverview[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive' | 'suspended'>('all');
  const [sortBy, setSortBy] = useState<'name' | 'revenue' | 'users' | 'health'>('revenue');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const { addError, addSuccess } = useError();

  useEffect(() => {
    loadSuperAdminData();
  }, []);

  const loadSuperAdminData = async () => {
    setLoading(true);
    try {
      console.log('🛡️ Loading real Super Admin data from Firestore...');
      
      // Load system metrics and pharmacy overviews in parallel
      const [systemMetrics, pharmacyList] = await Promise.all([
        loadRealSystemMetrics(),
        loadRealPharmacyOverviews()
      ]);
      
      setMetrics(systemMetrics);
      setPharmacies(pharmacyList);
      addSuccess('Real system data loaded successfully from Firestore', 'Super Admin');
    } catch (error: any) {
      console.error('❌ Error loading Super Admin data:', error);
      addError(error, 'Super Admin', 'Failed to load real system data from Firestore');
    } finally {
      setLoading(false);
    }
  };

  const loadRealSystemMetrics = async (): Promise<SuperAdminMetrics> => {
    try {
      console.log('📊 Calculating real system metrics from Firestore...');
      
      // Get all pharmacies/shops from Firebase
      const allPharmacies = await FirebaseService.getAllShops();
      console.log('🏥 Retrieved pharmacies:', allPharmacies.length);
      
      // Calculate basic metrics
      const totalPharmacies = allPharmacies.length;
      const activePharmacies = allPharmacies.filter(shop => shop.status === 'active').length;
      
      // Get all users from all pharmacies
      let totalUsers = 0;
      const userPromises = allPharmacies.map(async (pharmacy) => {
        try {
          const users = await FirebaseService.getShopUsers(pharmacy.id);
          return users.length;
        } catch (error) {
          console.warn(`⚠️ Could not get users for pharmacy ${pharmacy.id}:`, error);
          return 0;
        }
      });
      
      const userCounts = await Promise.all(userPromises);
      totalUsers = userCounts.reduce((sum, count) => sum + count, 0);
      console.log('👥 Total users across all pharmacies:', totalUsers);
      
      // Calculate revenue from sales data
      let totalRevenue = 0;
      let monthlyGrowth = 0;
      
      // Get current month and previous month date ranges
      const now = new Date();
      const currentMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      const previousMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const previousMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0);
      
      const revenuePromises = allPharmacies.map(async (pharmacy) => {
        try {
          // Get current month sales
          const currentMonthSales = await SalesService.getSalesByShop(pharmacy.id, 100, {
            start: currentMonthStart.toISOString(),
            end: now.toISOString()
          });
          
          // Get previous month sales
          const previousMonthSales = await SalesService.getSalesByShop(pharmacy.id, 100, {
            start: previousMonthStart.toISOString(),
            end: previousMonthEnd.toISOString()
          });
          
          const currentRevenue = calculateTotalRevenue(currentMonthSales, pharmacy.id);
          const previousRevenue = calculateTotalRevenue(previousMonthSales, pharmacy.id);
          
          return { currentRevenue, previousRevenue };
        } catch (error) {
          console.warn(`⚠️ Could not get sales for pharmacy ${pharmacy.id}:`, error);
          return { currentRevenue: 0, previousRevenue: 0 };
        }
      });
      
      const revenueData = await Promise.all(revenuePromises);
      const totalCurrentRevenue = revenueData.reduce((sum, data) => sum + data.currentRevenue, 0);
      const totalPreviousRevenue = revenueData.reduce((sum, data) => sum + data.previousRevenue, 0);
      
      totalRevenue = totalCurrentRevenue;
      
      // Calculate monthly growth percentage
      if (totalPreviousRevenue > 0) {
        monthlyGrowth = ((totalCurrentRevenue - totalPreviousRevenue) / totalPreviousRevenue) * 100;
      }
      
      // Determine system health based on metrics
      let systemHealth: 'good' | 'warning' | 'critical' = 'good';
      const activePercentage = totalPharmacies > 0 ? (activePharmacies / totalPharmacies) * 100 : 0;
      
      if (activePercentage < 50) {
        systemHealth = 'critical';
      } else if (activePercentage < 80 || monthlyGrowth < -10) {
        systemHealth = 'warning';
      }
      
      const metrics = {
        totalPharmacies,
        activePharmacies,
        totalUsers,
        totalRevenue,
        monthlyGrowth,
        systemHealth,
        lastUpdated: new Date()
      };
      
      console.log('✅ Real system metrics calculated:', metrics);
      return metrics;
      
    } catch (error) {
      console.error('❌ Error calculating system metrics:', error);
      
      // Return fallback metrics
      return {
        totalPharmacies: 0,
        activePharmacies: 0,
        totalUsers: 0,
        totalRevenue: 0,
        monthlyGrowth: 0,
        systemHealth: 'critical' as const,
        lastUpdated: new Date()
      };
    }
  };

  const loadRealPharmacyOverviews = async (): Promise<PharmacyOverview[]> => {
    try {
      console.log('🏥 Loading real pharmacy overviews from Firestore...');
      
      // Get all pharmacies from Firebase
      const allPharmacies = await FirebaseService.getAllShops();
      
      // Enhanced data gathering for each pharmacy with validation
      const validPharmacies = allPharmacies.filter(isValidShopData);
      console.log(`🔍 Processing ${validPharmacies.length} valid pharmacies out of ${allPharmacies.length} total`);
      
      const pharmacyOverviews = await Promise.all(
        validPharmacies.map(async (pharmacy) => {
          try {
            // Get owner information with safe string handling
            let ownerName = 'Unknown Owner';
            let ownerEmail = 'unknown@example.com';
            
            try {
              // Try to get owner profile
              const users = await FirebaseService.getShopUsers(pharmacy.id);
              const owner = users.find(user => user.role === 'owner' || user.id === pharmacy.owner_id);
              if (owner) {
                ownerName = safeString(owner.full_name, 'Unknown Owner');
                ownerEmail = safeString(owner.email, 'unknown@example.com');
              }
            } catch (error) {
              console.warn(createErrorContext(pharmacy.id, 'owner information retrieval', error));
            }
            
            // Get user count
            let totalUsers = 0;
            try {
              const users = await FirebaseService.getShopUsers(pharmacy.id);
              totalUsers = users.length;
            } catch (error) {
              console.warn(`⚠️ Could not get user count for pharmacy ${pharmacy.id}:`, error);
            }
            
            // Calculate monthly revenue
            let monthlyRevenue = 0;
            try {
              const now = new Date();
              const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
              const sales = await SalesService.getSalesByShop(pharmacy.id, 100, {
                start: monthStart.toISOString(),
                end: now.toISOString()
              });
              
              monthlyRevenue = calculateTotalRevenue(sales, pharmacy.id);
            } catch (error) {
              console.warn(`⚠️ Could not get sales data for pharmacy ${pharmacy.id}:`, error);
            }
            
            // Calculate inventory value using safe utility function
            let inventoryValue = 0;
            try {
              // Note: Products service not implemented yet - using placeholder
              console.log(`⚠️ Inventory calculation skipped for pharmacy ${pharmacy.id} - products service not implemented`);
              inventoryValue = 0; // Placeholder until products service is implemented
            } catch (error) {
              console.warn(createErrorContext(pharmacy.id, 'inventory calculation', error));
            }
            
            // Calculate health score (based on various factors)
            let healthScore = 100; // Start with perfect score
            
            // Reduce score based on inactivity using safe date parsing
            const lastActivity = safeParseDate(
              pharmacy.updated_at || pharmacy.created_at, 
              new Date(pharmacy.created_at || Date.now())
            );
            const daysSinceActivity = Math.floor((Date.now() - lastActivity.getTime()) / (1000 * 60 * 60 * 24));
            
            if (daysSinceActivity > 30) healthScore -= 20;
            else if (daysSinceActivity > 7) healthScore -= 10;
            
            // Reduce score for low user engagement
            if (totalUsers < 2) healthScore -= 15;
            else if (totalUsers < 5) healthScore -= 5;
            
            // Reduce score for low revenue
            if (monthlyRevenue === 0) healthScore -= 25;
            else if (monthlyRevenue < 100000) healthScore -= 10; // Less than 100k TZS
            
            // Ensure score doesn't go below 0
            healthScore = Math.max(0, healthScore);
            
            const overview: PharmacyOverview = {
              id: safeString(pharmacy.id, 'unknown'),
              name: safeString(pharmacy.name, 'Unknown Pharmacy'),
              owner: ownerName,
              ownerEmail,
              location: safeString(pharmacy.address, 'Location not specified'),
              status: safeString(pharmacy.status, 'inactive') as 'active' | 'inactive' | 'suspended',
              createdAt: safeParseDate(pharmacy.created_at),
              lastActivity,
              totalUsers,
              monthlyRevenue,
              inventoryValue,
              healthScore,
              settings: pharmacy.settings
            };
            
            return overview;
            
          } catch (error) {
            console.error(`❌ Error processing pharmacy ${pharmacy.id}:`, error);
            
            // Return basic overview for failed pharmacy with safe data extraction
            return {
              id: safeString(pharmacy.id, 'unknown'),
              name: safeString(pharmacy.name, 'Unknown Pharmacy'),
              owner: 'Unknown Owner',
              ownerEmail: 'unknown@example.com',
              location: safeString(pharmacy.address, 'Unknown location'),
              status: 'inactive' as const,
              createdAt: safeParseDate(pharmacy.created_at),
              lastActivity: safeParseDate(pharmacy.created_at),
              totalUsers: 0,
              monthlyRevenue: 0,
              inventoryValue: 0,
              healthScore: 0,
              settings: pharmacy.settings
            };
          }
        })
      );
      
      console.log('✅ Real pharmacy overviews loaded:', pharmacyOverviews.length);
      return pharmacyOverviews;
      
    } catch (error) {
      console.error('❌ Error loading pharmacy overviews:', error);
      return [];
    }
  };

  // Filter and sort pharmacies
  const filteredPharmacies = pharmacies
    .filter(pharmacy => {
      const matchesSearch = pharmacy.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           pharmacy.owner.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           pharmacy.location.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'all' || pharmacy.status === statusFilter;
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      let comparison = 0;
      switch (sortBy) {
        case 'name':
          comparison = a.name.localeCompare(b.name);
          break;
        case 'revenue':
          comparison = a.monthlyRevenue - b.monthlyRevenue;
          break;
        case 'users':
          comparison = a.totalUsers - b.totalUsers;
          break;
        case 'health':
          comparison = a.healthScore - b.healthScore;
          break;
      }
      return sortOrder === 'asc' ? comparison : -comparison;
    });

  const getStatusBadge = (status: PharmacyOverview['status']) => {
    const variants = {
      active: { variant: 'default' as const, icon: CheckCircle, color: 'text-green-600' },
      inactive: { variant: 'secondary' as const, icon: Clock, color: 'text-yellow-600' },
      suspended: { variant: 'destructive' as const, icon: XCircle, color: 'text-red-600' }
    };
    
    // Provide fallback for unknown status
    const config = variants[status] || variants.inactive;
    const Icon = config.icon;
    
    return (
      <Badge variant={config.variant} className="flex items-center gap-1">
        <Icon className="h-3 w-3" />
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const getHealthScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getHealthScoreIcon = (score: number) => {
    if (score >= 90) return <ArrowUp className="h-4 w-4 text-green-600" />;
    if (score >= 70) return <Minus className="h-4 w-4 text-yellow-600" />;
    return <ArrowDown className="h-4 w-4 text-red-600" />;
  };

  const getSystemHealthColor = (health: SuperAdminMetrics['systemHealth']) => {
    switch (health) {
      case 'good': return 'text-green-600';
      case 'warning': return 'text-yellow-600';
      case 'critical': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const formatLastActivity = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
      return diffInHours === 1 ? '1 hour ago' : `${diffInHours} hours ago`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return diffInDays === 1 ? '1 day ago' : `${diffInDays} days ago`;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <RefreshCw className="h-8 w-8 animate-spin text-indigo-600 mr-2" />
        <div className="text-center">
          <span className="block text-lg">Loading real system data from Firestore...</span>
          <span className="text-sm text-gray-600 mt-1">This may take a moment as we aggregate data from all pharmacies</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-purple-600" />
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Super Admin Portal</h1>
                <p className="text-gray-600 mt-1">
                  System overview and pharmacy management
                  {metrics?.lastUpdated && (
                    <span className="block text-sm text-gray-500">
                      Last updated: {metrics.lastUpdated.toLocaleString()}
                    </span>
                  )}
                </p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Button 
              onClick={() => onNavigate('system-overview')}
              variant="outline"
              className="flex items-center gap-2"
            >
              <BarChart3 className="h-4 w-4" />
              System Analytics
            </Button>
            <Button 
              onClick={() => onNavigate('software-settings')}
              variant="outline"
              className="flex items-center gap-2"
            >
              <Settings className="h-4 w-4" />
              Settings
            </Button>
            <Button 
              onClick={loadSuperAdminData}
              className="bg-purple-600 hover:bg-purple-700 flex items-center gap-2"
            >
              <RefreshCw className="h-4 w-4" />
              Refresh Data
            </Button>
          </div>
        </div>

        {/* Real System Metrics */}
        {metrics && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-blue-600 mb-1">Total Pharmacies</p>
                    <p className="text-3xl font-bold text-blue-900">{metrics.totalPharmacies}</p>
                    <p className="text-sm text-blue-600 mt-1">
                      {metrics.activePharmacies} active
                    </p>
                  </div>
                  <Building2 className="h-8 w-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-green-600 mb-1">Total Users</p>
                    <p className="text-3xl font-bold text-green-900">{metrics.totalUsers}</p>
                    <p className="text-sm text-green-600 mt-1">
                      Across all pharmacies
                    </p>
                  </div>
                  <Users className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-purple-600 mb-1">Total Revenue</p>
                    <p className="text-3xl font-bold text-purple-900">
                      {formatTZS(metrics.totalRevenue)}
                    </p>
                    <p className={`text-sm text-purple-600 mt-1 flex items-center ${
                      metrics.monthlyGrowth >= 0 ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {metrics.monthlyGrowth >= 0 ? (
                        <TrendingUp className="h-3 w-3 mr-1" />
                      ) : (
                        <ArrowDown className="h-3 w-3 mr-1" />
                      )}
                      {metrics.monthlyGrowth >= 0 ? '+' : ''}{metrics.monthlyGrowth.toFixed(1)}% this month
                    </p>
                  </div>
                  <DollarSign className="h-8 w-8 text-purple-500" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-orange-600 mb-1">System Health</p>
                    <p className={`text-3xl font-bold capitalize ${getSystemHealthColor(metrics.systemHealth)}`}>
                      {metrics.systemHealth}
                    </p>
                    <p className="text-sm text-orange-600 mt-1">
                      {metrics.systemHealth === 'good' ? 'All systems operational' : 
                       metrics.systemHealth === 'warning' ? 'Some issues detected' : 
                       'Critical issues found'}
                    </p>
                  </div>
                  <Activity className="h-8 w-8 text-orange-500" />
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Pharmacy Management */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Pharmacy Management ({filteredPharmacies.length} pharmacies)
            </CardTitle>
          </CardHeader>
          <CardContent>
            {/* Search and Filter Controls */}
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Search pharmacies, owners, or locations..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <div className="flex gap-2">
                <Select value={statusFilter} onValueChange={(value: any) => setStatusFilter(value)}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                    <SelectItem value="suspended">Suspended</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="revenue">Revenue</SelectItem>
                    <SelectItem value="name">Name</SelectItem>
                    <SelectItem value="users">Users</SelectItem>
                    <SelectItem value="health">Health</SelectItem>
                  </SelectContent>
                </Select>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
                >
                  {sortOrder === 'asc' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />}
                </Button>

                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </div>
            </div>

            {/* Pharmacy Table */}
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Pharmacy</TableHead>
                    <TableHead>Owner</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Users</TableHead>
                    <TableHead>Monthly Revenue</TableHead>
                    <TableHead>Health Score</TableHead>
                    <TableHead>Last Activity</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPharmacies.map((pharmacy) => (
                    <TableRow key={pharmacy.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{pharmacy.name}</div>
                          <div className="text-sm text-gray-500">
                            Created {pharmacy.createdAt.toLocaleDateString()}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{pharmacy.owner}</div>
                          <div className="text-sm text-gray-500">{pharmacy.ownerEmail}</div>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm">{pharmacy.location}</TableCell>
                      <TableCell>{getStatusBadge(pharmacy.status)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4 text-gray-400" />
                          {pharmacy.totalUsers}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium text-green-600">
                          {formatTZS(pharmacy.monthlyRevenue)}
                        </div>
                        <div className="text-sm text-gray-500">
                          Inventory: {formatTZS(pharmacy.inventoryValue)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className={`flex items-center gap-1 font-medium ${getHealthScoreColor(pharmacy.healthScore)}`}>
                          {getHealthScoreIcon(pharmacy.healthScore)}
                          {pharmacy.healthScore}%
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-gray-500">
                        {formatLastActivity(pharmacy.lastActivity)}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onViewPharmacy(pharmacy.id)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onNavigate(`pharmacy-analytics?id=${pharmacy.id}`)}
                          >
                            <BarChart3 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {filteredPharmacies.length === 0 && (
              <div className="text-center py-12">
                <Building2 className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No pharmacies found</h3>
                <p className="text-gray-600">
                  {searchTerm || statusFilter !== 'all' 
                    ? 'Try adjusting your search or filter criteria.' 
                    : 'No pharmacies have been registered yet.'
                  }
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => onNavigate('system-overview')}>
            <CardContent className="p-6 text-center">
              <PieChart className="h-12 w-12 text-blue-500 mx-auto mb-4" />
              <h3 className="font-semibold text-gray-900 mb-2">System Analytics</h3>
              <p className="text-sm text-gray-600">
                Detailed analytics across all pharmacies and system performance metrics.
              </p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => onNavigate('all-pharmacies')}>
            <CardContent className="p-6 text-center">
              <Building2 className="h-12 w-12 text-green-500 mx-auto mb-4" />
              <h3 className="font-semibold text-gray-900 mb-2">All Pharmacies</h3>
              <p className="text-sm text-gray-600">
                Comprehensive view of all registered pharmacies and their operations.
              </p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => onNavigate('software-settings')}>
            <CardContent className="p-6 text-center">
              <Settings className="h-12 w-12 text-purple-500 mx-auto mb-4" />
              <h3 className="font-semibold text-gray-900 mb-2">System Settings</h3>
              <p className="text-sm text-gray-600">
                Configure system-wide settings and manage platform features.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}