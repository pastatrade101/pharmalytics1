import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { AlertTriangle, CheckCircle, XCircle, RefreshCw, Zap } from 'lucide-react';
import { FirebaseService, UserProfile } from '../lib/firebase';
import { toast } from 'sonner@2.0.3';

interface FirebasePermissionTesterProps {
  userProfile: UserProfile | null;
}

export function FirebasePermissionTester({ userProfile }: FirebasePermissionTesterProps) {
  const [testing, setTesting] = useState(false);
  const [testResults, setTestResults] = useState<{
    profileCheck: 'pending' | 'success' | 'error';
    permissionCheck: 'pending' | 'success' | 'error';
    productCreationTest: 'pending' | 'success' | 'error';
    details: string[];
  }>({
    profileCheck: 'pending',
    permissionCheck: 'pending', 
    productCreationTest: 'pending',
    details: []
  });

  // Test user profile data
  const testUserProfile = () => {
    const details: string[] = [];
    let status: 'success' | 'error' = 'success';

    if (!userProfile) {
      details.push('❌ User profile not loaded');
      status = 'error';
    } else {
      details.push(`✅ User profile loaded: ${userProfile.full_name}`);
      details.push(`📧 Email: ${userProfile.email}`);
      details.push(`🔑 Role: ${userProfile.role}`);
      details.push(`🏪 Shop ID: ${userProfile.shop_id || 'Not assigned'}`);
      details.push(`👤 User ID: ${userProfile.uid}`);

      // Check required fields
      const allowedRoles = ['manager', 'owner', 'admin'];
      if (!allowedRoles.includes(userProfile.role)) {
        details.push(`❌ Invalid role: ${userProfile.role}. Required: ${allowedRoles.join(', ')}`);
        status = 'error';
      } else {
        details.push(`✅ Role check passed: ${userProfile.role}`);
      }

      if (!userProfile.shop_id) {
        details.push('❌ No shop assignment found');
        status = 'error';
      } else {
        details.push(`✅ Shop assignment found: ${userProfile.shop_id}`);
      }
    }

    return { status, details };
  };

  // Test Firebase permissions
  const testFirebasePermissions = async () => {
    const details: string[] = [];
    
    try {
      // Try to read products (should work if rules are deployed)
      await FirebaseService.getProducts(userProfile?.shop_id || 'test');
      details.push('✅ Firebase read permissions working');
      return { status: 'success' as const, details };
    } catch (error: any) {
      if (error.code === 'permission-denied') {
        details.push('❌ Firebase permission denied - Rules not deployed');
        details.push('🚨 Run: firebase deploy --only firestore:rules');
      } else {
        details.push(`❌ Firebase error: ${error.message}`);
      }
      return { status: 'error' as const, details };
    }
  };

  // Test product creation
  const testProductCreation = async () => {
    const details: string[] = [];
    
    if (!userProfile?.shop_id) {
      details.push('❌ Cannot test - no shop ID available');
      return { status: 'error' as const, details };
    }

    try {
      const testProduct = {
        name: 'TEST - Permission Test Product',
        sku: `TEST-${Date.now()}`,
        category: 'otc',
        price: 1000,
        cost: 800,
        stock_quantity: 1,
        min_stock_level: 1,
        status: 'active' as const,
        shop_id: userProfile.shop_id,
        description: 'This is a test product to verify Firebase permissions'
      };

      const createdProduct = await FirebaseService.createProduct(testProduct);
      details.push(`✅ Test product created successfully: ${createdProduct.id}`);
      details.push('✅ Firebase write permissions working');
      
      // Clean up test product
      try {
        await FirebaseService.deleteProduct(createdProduct.id);
        details.push('✅ Test product cleaned up');
      } catch (cleanupError) {
        details.push('⚠️ Could not clean up test product (not critical)');
      }
      
      return { status: 'success' as const, details };
    } catch (error: any) {
      if (error.message.includes('permission-denied') || error.message.includes('CRITICAL: Firebase permission')) {
        details.push('❌ Product creation failed - Permission denied');
        details.push('🚨 CRITICAL: Deploy Firebase rules immediately');
        details.push('📋 Command: firebase deploy --only firestore:rules');
      } else if (error.message.includes('already exists')) {
        details.push('❌ Product creation failed - Duplicate SKU');
        details.push('✅ But this means permissions are working!');
        return { status: 'success' as const, details };
      } else {
        details.push(`❌ Product creation failed: ${error.message}`);
      }
      return { status: 'error' as const, details };
    }
  };

  // Run all tests
  const runTests = async () => {
    setTesting(true);
    
    // Test 1: User Profile
    const profileTest = testUserProfile();
    setTestResults(prev => ({
      ...prev,
      profileCheck: profileTest.status,
      details: [...prev.details, '=== USER PROFILE TEST ===', ...profileTest.details, '']
    }));

    // Test 2: Firebase Permissions
    try {
      const permissionTest = await testFirebasePermissions();
      setTestResults(prev => ({
        ...prev,
        permissionCheck: permissionTest.status,
        details: [...prev.details, '=== FIREBASE PERMISSIONS TEST ===', ...permissionTest.details, '']
      }));

      // Test 3: Product Creation (only if permissions work)
      if (permissionTest.status === 'success' && profileTest.status === 'success') {
        const productTest = await testProductCreation();
        setTestResults(prev => ({
          ...prev,
          productCreationTest: productTest.status,
          details: [...prev.details, '=== PRODUCT CREATION TEST ===', ...productTest.details]
        }));

        if (productTest.status === 'success') {
          toast.success('🎉 All tests passed! Import should work now.');
        }
      } else {
        setTestResults(prev => ({
          ...prev,
          productCreationTest: 'error',
          details: [...prev.details, '=== PRODUCT CREATION TEST ===', '❌ Skipped due to previous failures']
        }));
      }
    } catch (error) {
      console.error('Test failed:', error);
    }

    setTesting(false);
  };

  // Reset tests
  const resetTests = () => {
    setTestResults({
      profileCheck: 'pending',
      permissionCheck: 'pending',
      productCreationTest: 'pending',
      details: []
    });
  };

  const getStatusIcon = (status: 'pending' | 'success' | 'error') => {
    switch (status) {
      case 'success': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'error': return <XCircle className="h-4 w-4 text-red-600" />;
      default: return <RefreshCw className="h-4 w-4 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: 'pending' | 'success' | 'error') => {
    switch (status) {
      case 'success': return <Badge variant="default" className="bg-green-100 text-green-800">Passed</Badge>;
      case 'error': return <Badge variant="destructive">Failed</Badge>;
      default: return <Badge variant="outline">Pending</Badge>;
    }
  };

  return (
    <Card className="border-yellow-200 bg-yellow-50">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Zap className="h-5 w-5 text-yellow-600 mr-2" />
          Firebase Permission Tester
        </CardTitle>
        <p className="text-sm text-gray-600">
          Run comprehensive tests to diagnose and fix Firebase permission issues.
        </p>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Test Status */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              {getStatusIcon(testResults.profileCheck)}
              <span className="text-sm">User Profile Check</span>
            </div>
            {getStatusBadge(testResults.profileCheck)}
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              {getStatusIcon(testResults.permissionCheck)}
              <span className="text-sm">Firebase Rules Check</span>
            </div>
            {getStatusBadge(testResults.permissionCheck)}
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              {getStatusIcon(testResults.productCreationTest)}
              <span className="text-sm">Product Creation Test</span>
            </div>
            {getStatusBadge(testResults.productCreationTest)}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2">
          <Button 
            onClick={runTests} 
            disabled={testing}
            className="flex-1"
          >
            {testing ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Testing...
              </>
            ) : (
              <>
                <Zap className="mr-2 h-4 w-4" />
                Run Tests
              </>
            )}
          </Button>
          
          <Button variant="outline" onClick={resetTests}>
            Reset
          </Button>
        </div>

        {/* Test Results */}
        {testResults.details.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-medium text-sm">Test Results:</h4>
            <div className="bg-gray-900 text-green-400 p-4 rounded text-xs font-mono max-h-60 overflow-y-auto">
              {testResults.details.map((detail, index) => (
                <div key={index} className={detail.startsWith('===') ? 'text-yellow-400 font-bold mt-2' : ''}>
                  {detail}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Quick Fix Instructions */}
        {testResults.permissionCheck === 'error' && (
          <div className="bg-red-50 border border-red-200 rounded p-4">
            <div className="flex items-center mb-2">
              <AlertTriangle className="h-4 w-4 text-red-600 mr-2" />
              <h4 className="font-medium text-red-900">URGENT: Deploy Firebase Rules</h4>
            </div>
            <div className="text-sm text-red-800 space-y-1">
              <p>Your Firebase security rules are not deployed. Run this command:</p>
              <code className="bg-red-100 px-2 py-1 rounded text-xs">firebase deploy --only firestore:rules</code>
              <p className="mt-2">Then refresh the page and test again.</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}