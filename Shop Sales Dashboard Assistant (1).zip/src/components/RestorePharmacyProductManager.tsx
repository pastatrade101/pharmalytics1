import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { 
  Plus, 
  Pill, 
  Edit, 
  Trash2, 
  Search, 
  ArrowLeft, 
  Save, 
  X, 
  AlertTriangle,
  Zap,
  TrendingUp,
  BarChart3,
  Calculator,
  CheckCircle,
  ChevronRight,
  ShoppingCart,
  DollarSign,
  Package2,
  AlertCircle,
  Calendar,
  Heart,
  Shield,
  Thermometer,
  Brain,
  Eye,
  Stethoscope,
  Upload,
  Download,
  FileSpreadsheet,
  FileText,
  CheckSquare,
  XCircle,
  RefreshCw,
  Info
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { UserProfile, Product, FirebaseService } from '../lib/firebase';
import { useError } from '../contexts/ErrorContext';
import { ErrorDisplay } from './ErrorDisplay';
import { FirebasePermissionTester } from './FirebasePermissionTester';
import { ComprehensiveProductForm } from './ComprehensiveProductForm';

interface PharmacyProductManagerProps {
  onBack: () => void;
  userProfile: UserProfile | null;
}

// Pharmacy-specific categories with medical descriptions
const PHARMACY_CATEGORIES = [
  { id: 'prescription', name: 'Prescription Medicines', description: 'Prescription-only medicines (POM)', icon: '💊', color: 'bg-red-50 text-red-700' },
  { id: 'otc', name: 'Over-the-Counter', description: 'Non-prescription medicines', icon: '🏥', color: 'bg-blue-50 text-blue-700' },
  { id: 'painkillers', name: 'Pain Relief', description: 'Analgesics, NSAIDs, pain management', icon: '🎯', color: 'bg-orange-50 text-orange-700' },
  { id: 'antibiotics', name: 'Antibiotics', description: 'Antimicrobial medicines', icon: '🦠', color: 'bg-purple-50 text-purple-700' },
  { id: 'vitamins', name: 'Vitamins & Supplements', description: 'Nutritional supplements, multivitamins', icon: '🌟', color: 'bg-yellow-50 text-yellow-700' },
  { id: 'cold_flu', name: 'Cold & Flu', description: 'Cough syrups, decongestants, throat lozenges', icon: '🤧', color: 'bg-teal-50 text-teal-700' },
  { id: 'digestive', name: 'Digestive Health', description: 'Antacids, laxatives, probiotics', icon: '🫁', color: 'bg-green-50 text-green-700' },
  { id: 'skincare', name: 'Dermatological', description: 'Topical creams, ointments, skin treatments', icon: '🧴', color: 'bg-pink-50 text-pink-700' },
  { id: 'baby_care', name: 'Baby & Child Care', description: 'Pediatric medicines, baby care products', icon: '🍼', color: 'bg-indigo-50 text-indigo-700' },
  { id: 'medical_devices', name: 'Medical Devices', description: 'Thermometers, blood pressure monitors, glucose meters', icon: '🩺', color: 'bg-gray-50 text-gray-700' },
  { id: 'first_aid', name: 'First Aid', description: 'Bandages, antiseptics, wound care', icon: '🩹', color: 'bg-red-50 text-red-700' },
  { id: 'personal_care', name: 'Personal Care', description: 'Hygiene products, contraceptives', icon: '🧼', color: 'bg-cyan-50 text-cyan-700' }
];

export function RestorePharmacyProductManager({ onBack, userProfile }: PharmacyProductManagerProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [loading, setLoading] = useState(true);
  
  // Product form states
  const [showAddProductDialog, setShowAddProductDialog] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);
  
  // Import-related states
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importPreviewData, setImportPreviewData] = useState<any[]>([]);
  const [importProgress, setImportProgress] = useState(0);
  const [importing, setImporting] = useState(false);
  const [importResults, setImportResults] = useState<{
    successful: number;
    failed: number;
    errors: string[];
  }>({ successful: 0, failed: 0, errors: [] });
  const [importStep, setImportStep] = useState<'select' | 'preview' | 'importing' | 'results'>('select');

  const { 
    addError, 
    addSuccess, 
    addWarning, 
    clearErrorsByContext, 
    hasErrorsInContext,
    getErrorsByContext 
  } = useError();

  useEffect(() => {
    loadProducts();
  }, [userProfile]);

  const loadProducts = async () => {
    setLoading(true);
    clearErrorsByContext('Product Loading');
    
    try {
      if (!userProfile?.shop_id) {
        addWarning('No pharmacy associated with your account', 'Product Loading');
        setLoading(false);
        return;
      }

      console.log('🔄 Loading pharmacy products for shop:', userProfile.shop_id);
      const loadedProducts = await FirebaseService.getProducts(userProfile.shop_id);
      
      const activeProducts = loadedProducts.filter(p => p.status !== 'deleted');
      setProducts(activeProducts);
      addSuccess(`Successfully loaded ${loadedProducts.length} pharmacy products`, 'Product Loading');
      console.log('✅ Pharmacy products loaded successfully:', loadedProducts.length);
      
    } catch (error) {
      console.error('❌ Error loading pharmacy products:', error);
      addError(
        error, 
        'Product Loading',
        'Failed to load pharmacy products from database. Please check your connection and Firebase rules.'
      );
    } finally {
      setLoading(false);
    }
  };

  // Format TZS currency
  const formatTZS = (amount: number) => {
    return new Intl.NumberFormat('sw-TZ', {
      style: 'currency',
      currency: 'TZS',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  // File import handlers
  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    console.log('🔄 File selection started');
    const file = event.target.files?.[0];
    if (!file) {
      console.log('❌ No file selected');
      return;
    }

    console.log('📁 File selected:', {
      name: file.name,
      type: file.type,
      size: file.size
    });

    const allowedTypes = [
      'text/csv',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/json'
    ];

    if (!allowedTypes.includes(file.type)) {
      console.log('❌ Invalid file type:', file.type);
      addError(
        new Error('Invalid file type'),
        'File Import',
        'Please select a CSV, Excel, or JSON file'
      );
      return;
    }

    setImportFile(file);
    
    try {
      console.log('🔄 Starting file parsing...');
      const previewData = await parseImportFile(file);
      console.log('✅ File parsed successfully. Products found:', previewData.length);
      setImportPreviewData(previewData);
      setImportStep('preview');
    } catch (error) {
      console.error('❌ Error parsing file:', error);
      addError(error, 'File Import', 'Failed to parse the selected file');
    }
  };

  const parseImportFile = async (file: File): Promise<any[]> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const content = e.target?.result as string;
          let data: any[] = [];

          if (file.type === 'application/json') {
            const jsonData = JSON.parse(content);
            data = Array.isArray(jsonData) ? jsonData : [jsonData];
          } else if (file.type === 'text/csv' || file.name.endsWith('.csv')) {
            data = parseCSV(content);
          } else {
            reject(new Error('Excel files require a specialized parser. Please convert to CSV format.'));
            return;
          }

          const normalizedData = data.map((item, index) => {
            return normalizeImportData(item, index);
          });

          resolve(normalizedData.filter(item => item !== null));
        } catch (error) {
          reject(error);
        }
      };

      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsText(file);
    });
  };

  const parseCSV = (content: string): any[] => {
    const lines = content.trim().split('\n');
    if (lines.length < 2) return [];

    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    const data: any[] = [];

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
      if (values.length !== headers.length) continue;

      const row: any = {};
      headers.forEach((header, index) => {
        row[header.toLowerCase().replace(/\s+/g, '_')] = values[index];
      });
      data.push(row);
    }

    return data;
  };

  const normalizeImportData = (item: any, index: number): any | null => {
    try {
      const fieldMappings: { [key: string]: string[] } = {
        'name': ['name', 'product_name', 'medicine_name', 'title'],
        'description': ['description', 'desc', 'details'],
        'category': ['category', 'type', 'group'],
        'sku': ['sku', 'code', 'product_code', 'item_code'],
        'generic_name': ['generic_name', 'generic', 'active_ingredient'],
        'brand_name': ['brand_name', 'brand', 'manufacturer_name'],
        'strength': ['strength', 'dose', 'dosage_strength'],
        'dosage_form': ['dosage_form', 'form', 'type'],
        'manufacturer': ['manufacturer', 'company', 'supplier'],
        'retail_price': ['price', 'selling_price', 'retail_price'],
        'cost_price': ['cost', 'cost_price', 'wholesale_price', 'purchase_price'],
        'stock_quantity': ['stock_quantity', 'stock', 'quantity', 'qty'],
        'min_stock_level': ['min_stock_level', 'min_stock', 'reorder_level'],
        'requires_prescription': ['requires_prescription', 'prescription_required', 'rx_required']
      };

      const normalized: any = {};

      Object.keys(fieldMappings).forEach(targetField => {
        const possibleFields = fieldMappings[targetField];
        for (const field of possibleFields) {
          if (item[field] !== undefined && item[field] !== '') {
            normalized[targetField] = item[field];
            break;
          }
        }
      });

      if (!normalized.name || !normalized.sku) {
        console.warn(`Row ${index + 1}: Missing required fields (name or sku)`);
        return null;
      }

      if (normalized.requires_prescription) {
        const val = normalized.requires_prescription.toString().toLowerCase();
        normalized.requires_prescription = ['true', '1', 'yes', 'y'].includes(val);
      } else {
        normalized.requires_prescription = false;
      }

      ['retail_price', 'cost_price', 'stock_quantity', 'min_stock_level'].forEach(field => {
        if (normalized[field]) {
          const num = parseFloat(normalized[field].toString().replace(/[^\d.-]/g, ''));
          if (!isNaN(num)) {
            normalized[field] = num;
          }
        }
      });

      if (!normalized.category) {
        normalized.category = 'Over-the-Counter';
      }

      normalized.status = 'active';
      normalized.retail_price = normalized.retail_price || 0;
      normalized.cost_price = normalized.cost_price || 0;
      normalized.stock_quantity = normalized.stock_quantity || 0;
      normalized.min_stock_level = normalized.min_stock_level || 1;
      normalized.reorder_level = normalized.min_stock_level || 1;
      normalized.reorder_quantity = normalized.min_stock_level || 1;

      return normalized;
    } catch (error) {
      console.error(`Error normalizing row ${index + 1}:`, error);
      return null;
    }
  };

  const validateImportData = (data: any[]): { valid: any[], invalid: any[], errors: string[] } => {
    const valid: any[] = [];
    const invalid: any[] = [];
    const errors: string[] = [];

    data.forEach((item, index) => {
      const itemErrors: string[] = [];

      if (!item.name?.trim()) itemErrors.push('Missing name');
      if (!item.sku?.trim()) itemErrors.push('Missing SKU');
      if (!item.retail_price || item.retail_price <= 0) itemErrors.push('Invalid price');
      if (!item.cost_price || item.cost_price < 0) itemErrors.push('Invalid cost');
      if (!item.stock_quantity || item.stock_quantity < 0) itemErrors.push('Invalid stock quantity');

      const duplicateIndex = data.findIndex((otherItem, otherIndex) => 
        otherIndex !== index && otherItem.sku === item.sku
      );
      if (duplicateIndex !== -1) {
        itemErrors.push(`Duplicate SKU in row ${duplicateIndex + 1}`);
      }

      const existingSKU = products.find(p => p.sku === item.sku);
      if (existingSKU) {
        itemErrors.push(`SKU already exists in inventory`);
      }

      if (itemErrors.length > 0) {
        invalid.push({ ...item, _errors: itemErrors, _rowIndex: index + 1 });
        errors.push(`Row ${index + 1}: ${itemErrors.join(', ')}`);
      } else {
        valid.push(item);
      }
    });

    return { valid, invalid, errors };
  };

  const handleImport = async () => {
    if (!userProfile?.shop_id) {
      addError(new Error('No shop ID'), 'Import', 'No pharmacy associated with your account');
      return;
    }

    // Enhanced debugging for permission issues
    console.log('🔍 Import Debug - User Profile:', {
      uid: userProfile?.uid,
      role: userProfile?.role,
      shop_id: userProfile?.shop_id,
      email: userProfile?.email,
      full_name: userProfile?.full_name
    });

    // FIXED: Check if user has permission to create products with updated roles
    const allowedRoles = ['product_manager', 'owner', 'admin', 'super_admin'];
    if (!allowedRoles.includes(userProfile.role)) {
      addError(
        new Error('Insufficient permissions'), 
        'Import', 
        `Your role (${userProfile.role}) doesn't have permission to import products. Required roles: ${allowedRoles.join(', ')}`
      );
      return;
    }

    setImporting(true);
    setImportStep('importing');
    setImportProgress(0);
    
    const { valid } = validateImportData(importPreviewData);
    let successful = 0;
    let failed = 0;
    const importErrors: string[] = [];

    try {
      for (let i = 0; i < valid.length; i++) {
        const item = valid[i];
        
        try {
          const productData = {
            ...item,
            description: item.description || '',
            name: item.name.trim(),
            sku: item.sku.trim(),
            manufacturer: item.manufacturer || 'Unknown',
            shop_id: userProfile.shop_id
          };

          console.log(`🔄 Importing product ${i + 1}/${valid.length}: ${productData.name}`);
          await FirebaseService.createProduct(productData);
          successful++;
          
          setImportProgress(((i + 1) / valid.length) * 100);
          
        } catch (error) {
          console.error(`❌ Failed to import product ${item.name}:`, error);
          failed++;
          
          // Enhanced error reporting
          let errorMessage = 'Unknown error';
          if (error instanceof Error) {
            if (error.message.includes('permission-denied') || error.message.includes('CRITICAL: Firebase permission')) {
              errorMessage = 'Permission denied - Firebase rules not deployed';
            } else if (error.message.includes('already exists')) {
              errorMessage = 'Product with this SKU already exists';
            } else {
              errorMessage = error.message;
            }
          }
          
          importErrors.push(`${item.name} (${item.sku}): ${errorMessage}`);
        }
        
        // Add small delay to prevent overwhelming Firestore
        if (i < valid.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      }

      // Only reload products if we had some success
      if (successful > 0) {
        await loadProducts();
      }
      
      setImportResults({ successful, failed, errors: importErrors });
      setImportStep('results');
      
      if (successful > 0) {
        addSuccess(`Successfully imported ${successful} products`, 'Import');
      }
      if (failed > 0) {
        addWarning(`Failed to import ${failed} products`, 'Import');
        
        // Show specific guidance for permission errors
        const hasPermissionErrors = importErrors.some(error => 
          error.includes('Permission denied') || error.includes('Firebase permission')
        );
        
        if (hasPermissionErrors) {
          addError(
            new Error('Firebase permission error'),
            'Import',
            '🚨 CRITICAL: Firebase security rules are not deployed. Run "firebase deploy --only firestore:rules" to fix this issue.'
          );
        }
      }
      
    } catch (error) {
      console.error('❌ Import process failed:', error);
      addError(error, 'Import', 'Failed to complete the import process');
    } finally {
      setImporting(false);
    }
  };

  const resetImport = () => {
    setImportFile(null);
    setImportPreviewData([]);
    setImportProgress(0);
    setImportResults({ successful: 0, failed: 0, errors: [] });
    setImportStep('select');
    setShowImportDialog(false);
  };

  const downloadSampleCSV = () => {
    const sampleData = [
      'name,sku,category,generic_name,brand_name,strength,manufacturer,retail_price,cost_price,stock_quantity,min_stock_level,requires_prescription,description',
      'Paracetamol 500mg,PAR-001,Pain Relief,Paracetamol,Panadol,500mg,GSK,2000,1500,100,10,false,Pain relief and fever reducer',
      'Amoxicillin 250mg,AMX-002,Antibiotics,Amoxicillin,Augmentin,250mg,Pfizer,3500,2800,50,5,true,Broad spectrum antibiotic',
      'Vitamin C Tablets,VIT-003,Vitamins & Supplements,Ascorbic Acid,Redoxon,1000mg,Bayer,1500,1000,200,20,false,Immune system support'
    ].join('\n');

    const blob = new Blob([sampleData], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'pharmacy_products_sample.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    toast.success('Sample CSV file downloaded');
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    setShowAddProductDialog(true);
  };

  const handleDeleteProduct = async (product: Product) => {
    if (!confirm(`Are you sure you want to delete "${product.name}"? This action cannot be undone.`)) {
      return;
    }

    try {
      await FirebaseService.deleteProduct(product.id);
      setProducts(prev => prev.filter(p => p.id !== product.id));
      toast.success(`Product "${product.name}" deleted successfully`);
    } catch (error) {
      console.error('Error deleting product:', error);
      toast.error('Failed to delete product');
    }
  };

  // Filter products
  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.generic_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.brand_name?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categoriesWithCounts = PHARMACY_CATEGORIES.map(category => ({
    ...category,
    count: products.filter(p => p.category === category.name).length
  }));

  const hasLoadingErrors = hasErrorsInContext('Product Loading');
  const hasCreationErrors = hasErrorsInContext('Product Creation') || hasErrorsInContext('Import');

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="mx-auto h-12 w-12 text-blue-600 animate-spin mb-4" />
          <h2 className="text-xl font-semibold text-gray-900">Loading Products...</h2>
          <p className="text-gray-600">Please wait while we fetch your pharmacy inventory.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Firebase Permission Tester - Shows when there are creation errors */}
        {hasCreationErrors && (
          <div className="mb-4">
            <FirebasePermissionTester userProfile={userProfile} />
          </div>
        )}

        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Button onClick={onBack} variant="outline" size="sm" className="mr-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
            <div>
              <div className="flex items-center">
                <Pill className="h-8 w-8 text-indigo-600 mr-2" />
                <h1 className="text-3xl font-bold text-gray-900">Pharmacy Product Management</h1>
              </div>
              {userProfile && (
                <p className="text-gray-600 mt-1">
                  {userProfile.shop?.name || 'Your Pharmacy'} • {products.length} medicines & products • TZS Currency
                </p>
              )}
            </div>
          </div>
          
          <div className="flex gap-2">
            {/* Add Product Button - FIXED */}
            <Button 
              onClick={() => {
                setEditingProduct(null);
                setShowAddProductDialog(true);
              }}
              className="bg-indigo-600 hover:bg-indigo-700"
              disabled={!userProfile?.shop_id}
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Product
            </Button>
            
            {/* Import Dialog */}
            <Dialog open={showImportDialog} onOpenChange={(open) => {
              if (!open) {
                resetImport();
              }
            }}>
              <DialogTrigger asChild>
                <Button 
                  variant="outline"
                  onClick={() => setShowImportDialog(true)}
                  disabled={!userProfile?.shop_id}
                >
                  <Upload className="mr-2 h-4 w-4" />
                  Import Catalog
                </Button>
              </DialogTrigger>
              
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="flex items-center">
                    <Upload className="mr-2 h-5 w-5" />
                    Import Product Catalog
                  </DialogTitle>
                  <DialogDescription>
                    Import products from CSV, Excel, or JSON files. Download a sample template to get started.
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-6">
                  {importStep === 'select' && (
                    <div className="space-y-4">
                      {/* File Selection */}
                      <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                        <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                        <div className="space-y-2">
                          <h3 className="text-lg font-semibold">Select File to Import</h3>
                          <p className="text-gray-600">Choose a CSV, Excel, or JSON file containing your product data</p>
                          <input
                            type="file"
                            accept=".csv,.xlsx,.xls,.json"
                            onChange={handleFileSelect}
                            className="hidden"
                            id="import-file"
                          />
                          <div className="flex gap-2 justify-center">
                            <Button 
                              variant="outline" 
                              onClick={() => {
                                const input = document.getElementById('import-file') as HTMLInputElement;
                                input?.click();
                              }}
                            >
                              <FileSpreadsheet className="mr-2 h-4 w-4" />
                              Choose File
                            </Button>
                            
                            <Button variant="outline" onClick={downloadSampleCSV}>
                              <Download className="mr-2 h-4 w-4" />
                              Download Sample
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {importStep === 'preview' && (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="text-lg font-semibold">Preview Import Data</h3>
                        <Badge variant="outline">{importPreviewData.length} products</Badge>
                      </div>
                      
                      <div className="border rounded-lg overflow-hidden">
                        <div className="max-h-64 overflow-y-auto">
                          <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-50">
                              <tr>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">SKU</th>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Stock</th>
                              </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                              {importPreviewData.slice(0, 10).map((item, index) => (
                                <tr key={index}>
                                  <td className="px-4 py-2 text-sm text-gray-900">{item.name}</td>
                                  <td className="px-4 py-2 text-sm text-gray-500">{item.sku}</td>
                                  <td className="px-4 py-2 text-sm text-gray-500">{item.category}</td>
                                  <td className="px-4 py-2 text-sm text-gray-900">{formatTZS(item.retail_price)}</td>
                                  <td className="px-4 py-2 text-sm text-gray-500">{item.stock_quantity}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                      
                      <div className="flex gap-2 justify-end">
                        <Button variant="outline" onClick={() => setImportStep('select')}>
                          <ArrowLeft className="mr-2 h-4 w-4" />
                          Back
                        </Button>
                        <Button onClick={handleImport} disabled={importing}>
                          <CheckCircle className="mr-2 h-4 w-4" />
                          Import {importPreviewData.length} Products
                        </Button>
                      </div>
                    </div>
                  )}

                  {importStep === 'importing' && (
                    <div className="space-y-4">
                      <div className="text-center">
                        <RefreshCw className="mx-auto h-12 w-12 text-blue-600 animate-spin mb-4" />
                        <h3 className="text-lg font-semibold">Importing Products...</h3>
                        <p className="text-gray-600">Please wait while we add products to your inventory</p>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span>{Math.round(importProgress)}%</span>
                        </div>
                        <Progress value={importProgress} className="w-full" />
                      </div>
                    </div>
                  )}

                  {importStep === 'results' && (
                    <div className="space-y-4">
                      <div className="text-center">
                        <CheckCircle className="mx-auto h-12 w-12 text-green-600 mb-4" />
                        <h3 className="text-lg font-semibold">Import Complete</h3>
                        <div className="grid grid-cols-2 gap-4 mt-4">
                          <div className="bg-green-50 p-4 rounded-lg">
                            <div className="text-2xl font-bold text-green-900">{importResults.successful}</div>
                            <div className="text-sm text-green-700">Successfully Imported</div>
                          </div>
                          <div className="bg-red-50 p-4 rounded-lg">
                            <div className="text-2xl font-bold text-red-900">{importResults.failed}</div>
                            <div className="text-sm text-red-700">Failed to Import</div>
                          </div>
                        </div>
                      </div>
                      
                      {importResults.errors.length > 0 && (
                        <div className="space-y-2">
                          <h4 className="font-medium text-red-900">Import Errors:</h4>
                          <div className="bg-red-50 border border-red-200 rounded-lg p-4 max-h-40 overflow-y-auto">
                            {importResults.errors.map((error, index) => (
                              <div key={index} className="text-sm text-red-700 mb-1">
                                {error}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      <div className="flex gap-2 justify-end">
                        <Button variant="outline" onClick={resetImport}>
                          <X className="mr-2 h-4 w-4" />
                          Close
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Error Display */}
        {(hasLoadingErrors || hasCreationErrors) && (
          <div className="mb-6">
            <ErrorDisplay />
          </div>
        )}

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex gap-4 items-center">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Search medicines by name, SKU, generic name, or brand..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="w-48">
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories ({products.length})</SelectItem>
                    {categoriesWithCounts.map(category => (
                      <SelectItem key={category.id} value={category.name}>
                        {category.name} ({category.count})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => (
            <Card key={product.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{product.name}</h3>
                      <p className="text-sm text-gray-600">{product.sku}</p>
                      {product.generic_name && (
                        <p className="text-sm text-gray-500">Generic: {product.generic_name}</p>
                      )}
                    </div>
                    <Badge 
                      variant={product.stock_quantity <= product.min_stock_level ? "destructive" : "secondary"}
                    >
                      {product.stock_quantity} in stock
                    </Badge>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Price:</span>
                      <span className="font-semibold">{formatTZS(product.retail_price)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Category:</span>
                      <Badge variant="outline" className={PHARMACY_CATEGORIES.find(c => c.name === product.category)?.color || ""}>
                        {product.category}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 pt-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1"
                      onClick={() => handleEditProduct(product)}
                    >
                      <Edit className="mr-2 h-4 w-4" />
                      Edit
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1"
                      onClick={() => handleDeleteProduct(product)}
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      Delete
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {filteredProducts.length === 0 && !loading && (
          <Card className="p-12 text-center">
            <Package2 className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No products found</h3>
            <p className="text-gray-600 mb-4">
              {searchTerm || selectedCategory !== 'all' 
                ? 'Try adjusting your search or filter criteria.'
                : 'Get started by importing your product catalog or adding individual products.'
              }
            </p>
            <div className="flex gap-2 justify-center">
              <Button onClick={() => setShowAddProductDialog(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Add Product
              </Button>
              <Button onClick={() => setShowImportDialog(true)} variant="outline">
                <Upload className="mr-2 h-4 w-4" />
                Import Products
              </Button>
            </div>
          </Card>
        )}

        {/* Comprehensive Product Form Dialog */}
        <ComprehensiveProductForm
          open={showAddProductDialog}
          onOpenChange={(open) => {
            setShowAddProductDialog(open);
            if (!open) {
              setEditingProduct(null); // Reset editing state when dialog closes
            }
          }}
          userProfile={userProfile}
          onProductAdded={loadProducts}
          editingProduct={editingProduct}
        />
      </div>
    </div>
  );
}