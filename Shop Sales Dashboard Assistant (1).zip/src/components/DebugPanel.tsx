import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';
import {
  Bug,
  AlertTriangle,
  CheckCircle,
  RefreshCw,
  Zap,
  Terminal,
  Database,
  Shield,
  Settings,
  X,
  ChevronDown,
  ChevronUp,
  Copy,
  ExternalLink
} from 'lucide-react';
import { FirebasePermissionTester } from './FirebasePermissionTester';
import { EnhancedFirebasePermissionTester } from './EnhancedFirebasePermissionTester';
import { FirebasePermissionQuickFix } from './FirebasePermissionQuickFix';
import { FirebaseService, UserProfile } from '../lib/firebase';
import { useError } from '../contexts/ErrorContext';
import { toast } from 'sonner@2.0.3';
import { debugLog, SessionFlags } from '../lib/debug-utils';

interface DebugPanelProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile | null;
  errors: any[];
  hasPermissionErrors: boolean;
  hasIndexErrors: boolean;
  hasNetworkErrors: boolean;
  hasValidationErrors: boolean;
  permissionErrorsLength: number;
  aiSystemStatus?: string;
}

export function DebugPanel({
  isOpen,
  onClose,
  userProfile,
  errors,
  hasPermissionErrors,
  hasIndexErrors,
  hasNetworkErrors,
  hasValidationErrors,
  permissionErrorsLength,
  aiSystemStatus
}: DebugPanelProps) {
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [systemInfo, setSystemInfo] = useState<any>({});
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [testingFirebase, setTestingFirebase] = useState(false);
  const [showQuickFix, setShowQuickFix] = useState(false);

  const { getPermissionErrors, getIndexErrors, clearErrorsByContext } = useError();

  // Determine which tab to show based on errors
  useEffect(() => {
    if (hasPermissionErrors) {
      setActiveTab('permissions');
      setShowQuickFix(true);
    } else if (hasIndexErrors) {
      setActiveTab('database');
    } else if (hasNetworkErrors) {
      setActiveTab('network');
    } else {
      setActiveTab('overview');
      setShowQuickFix(false);
    }
  }, [hasPermissionErrors, hasIndexErrors, hasNetworkErrors]);

  // Collect system information
  useEffect(() => {
    const collectSystemInfo = () => {
      setSystemInfo({
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent,
        url: window.location.href,
        viewport: `${window.innerWidth}x${window.innerHeight}`,
        connection: (navigator as any)?.connection?.effectiveType || 'unknown',
        online: navigator.onLine,
        language: navigator.language,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        sessionFlags: SessionFlags.getAllFlags()
      });
    };

    if (isOpen) {
      collectSystemInfo();
    }
  }, [isOpen]);

  const runFirebaseTest = async () => {
    setTestingFirebase(true);
    try {
      // Quick Firebase connectivity test
      await FirebaseService.getCurrentUserProfile();
      toast.success('Firebase connectivity test passed');
    } catch (error: any) {
      toast.error(`Firebase test failed: ${error.message}`);
    } finally {
      setTestingFirebase(false);
    }
  };

  const testAPIEndpoints = async () => {
    try {
      console.log('🧪 Testing API endpoints...');
      
      // Test health endpoint
      const healthResponse = await fetch('/api/health');
      const healthData = await healthResponse.json();
      
      console.log('🏥 Health API test:', healthResponse.status, healthData);
      
      // Test generate-report endpoint
      const reportResponse = await fetch('/api/generate-report');
      const reportData = await reportResponse.json();
      
      console.log('🤖 Generate Report API test:', reportResponse.status, reportData);
      
      if (healthResponse.ok && reportResponse.ok) {
        toast.success('✅ API endpoints are working correctly');
      } else {
        toast.error(`❌ API endpoints failing: Health(${healthResponse.status}) Report(${reportResponse.status})`);
      }
      
    } catch (error: any) {
      console.error('❌ API test error:', error);
      toast.error(`API test failed: ${error.message}`);
    }
  };

  const clearAllErrors = () => {
    clearErrorsByContext('All');
    toast.success('All errors cleared');
  };

  const copySystemInfo = () => {
    const info = {
      ...systemInfo,
      userProfile: userProfile ? {
        uid: userProfile.uid,
        role: userProfile.role,
        shop_id: userProfile.shop_id,
        email: userProfile.email
      } : null,
      errorCounts: {
        total: errors.length,
        permission: permissionErrorsLength,
        index: getIndexErrors().length,
        network: hasNetworkErrors ? 1 : 0,
        validation: hasValidationErrors ? 1 : 0
      }
    };
    
    navigator.clipboard.writeText(JSON.stringify(info, null, 2));
    toast.success('System info copied to clipboard');
  };

  const exportDebugLog = () => {
    const debugData = {
      timestamp: new Date().toISOString(),
      systemInfo,
      userProfile,
      errors: errors.map(error => ({
        type: error.type,
        message: error.message,
        context: error.context,
        timestamp: error.timestamp
      })),
      aiSystemStatus,
      sessionFlags: SessionFlags.getAllFlags()
    };
    
    const blob = new Blob([JSON.stringify(debugData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `debug-log-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    
    toast.success('Debug log exported');
  };

  if (!isOpen) return null;

  const overallStatus = hasPermissionErrors ? 'critical' : hasIndexErrors ? 'warning' : 'healthy';

  return (
    <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-4">
      <Card className={`w-full max-w-6xl h-[90vh] flex flex-col ${
        overallStatus === 'critical' ? 'border-red-300' : 
        overallStatus === 'warning' ? 'border-yellow-300' : 'border-green-300'
      }`}>
        <CardHeader className="flex-shrink-0">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center">
              <Bug className="h-5 w-5 mr-2" />
              Firebase Diagnostic Panel
              <Badge 
                variant={overallStatus === 'critical' ? 'destructive' : overallStatus === 'warning' ? 'outline' : 'default'}
                className="ml-2"
              >
                {overallStatus === 'critical' ? 'Critical Issues' : 
                 overallStatus === 'warning' ? 'Warnings' : 'System Healthy'}
              </Badge>
            </CardTitle>
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsCollapsed(!isCollapsed)}
              >
                {isCollapsed ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
              </Button>
              <Button variant="ghost" size="sm" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          {!isCollapsed && (
            <div className="flex items-center space-x-4 text-sm text-gray-600">
              <div className="flex items-center space-x-1">
                <Shield className="h-4 w-4" />
                <span>Permissions: {hasPermissionErrors ? `${permissionErrorsLength} errors` : 'OK'}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Database className="h-4 w-4" />
                <span>Database: {hasIndexErrors ? 'Index issues' : 'OK'}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Zap className="h-4 w-4" />
                <span>AI: {aiSystemStatus || 'Unknown'}</span>
              </div>
            </div>
          )}
        </CardHeader>

        {!isCollapsed && (
          <CardContent className="flex-1 overflow-hidden">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
              <TabsList className="grid w-full grid-cols-6 flex-shrink-0">
                <TabsTrigger value="overview" className="text-xs">Overview</TabsTrigger>
                <TabsTrigger value="permissions" className="text-xs">
                  Permissions
                  {hasPermissionErrors && <Badge variant="destructive" className="ml-1 text-xs">{permissionErrorsLength}</Badge>}
                </TabsTrigger>
                <TabsTrigger value="database" className="text-xs">
                  Database
                  {hasIndexErrors && <Badge variant="outline" className="ml-1 text-xs">!</Badge>}
                </TabsTrigger>
                <TabsTrigger value="testing" className="text-xs">Testing</TabsTrigger>
                <TabsTrigger value="system" className="text-xs">System</TabsTrigger>
                <TabsTrigger value="export" className="text-xs">Export</TabsTrigger>
              </TabsList>

              <div className="flex-1 overflow-hidden mt-4">
                <TabsContent value="overview" className="h-full">
                  <ScrollArea className="h-full">
                    <div className="space-y-4">
                      {/* System Status Overview */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <Card className={`${hasPermissionErrors ? 'border-red-200 bg-red-50' : 'border-green-200 bg-green-50'}`}>
                          <CardContent className="p-4">
                            <div className="flex items-center space-x-2">
                              <Shield className={`h-5 w-5 ${hasPermissionErrors ? 'text-red-600' : 'text-green-600'}`} />
                              <div>
                                <p className="font-medium">Firebase Permissions</p>
                                <p className="text-sm text-gray-600">
                                  {hasPermissionErrors ? `${permissionErrorsLength} errors detected` : 'All permissions working'}
                                </p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>

                        <Card className={`${hasIndexErrors ? 'border-yellow-200 bg-yellow-50' : 'border-green-200 bg-green-50'}`}>
                          <CardContent className="p-4">
                            <div className="flex items-center space-x-2">
                              <Database className={`h-5 w-5 ${hasIndexErrors ? 'text-yellow-600' : 'text-green-600'}`} />
                              <div>
                                <p className="font-medium">Database Status</p>
                                <p className="text-sm text-gray-600">
                                  {hasIndexErrors ? 'Index configuration needed' : 'Database indexes optimal'}
                                </p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>

                        <Card className="border-blue-200 bg-blue-50">
                          <CardContent className="p-4">
                            <div className="flex items-center space-x-2">
                              <Zap className="h-5 w-5 text-blue-600" />
                              <div>
                                <p className="font-medium">AI System</p>
                                <p className="text-sm text-gray-600">
                                  {aiSystemStatus === 'connected' ? 'Fully operational' :
                                   aiSystemStatus === 'quota-exceeded' ? 'Quota limit reached' :
                                   aiSystemStatus === 'auth-error' ? 'Authentication failed' :
                                   'Status unknown'}
                                </p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>

                      {/* Quick Actions */}
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base">Quick Actions</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="flex flex-wrap gap-2">
                            <Button size="sm" onClick={runFirebaseTest} disabled={testingFirebase}>
                              {testingFirebase ? <RefreshCw className="h-4 w-4 animate-spin mr-2" /> : <Zap className="h-4 w-4 mr-2" />}
                              Test Firebase
                            </Button>
                            <Button size="sm" variant="outline" onClick={clearAllErrors}>
                              Clear Errors
                            </Button>
                            <Button size="sm" variant="outline" onClick={copySystemInfo}>
                              <Copy className="h-4 w-4 mr-2" />
                              Copy Info
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => window.open('/FIREBASE_PERMISSION_DEBUGGING.md', '_blank')}>
                              <ExternalLink className="h-4 w-4 mr-2" />
                              Help Guide
                            </Button>
                          </div>
                        </CardContent>
                      </Card>

                      {/* User Profile Info */}
                      {userProfile && (
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-base">User Profile</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="grid grid-cols-2 gap-4 text-sm">
                              <div>
                                <span className="font-medium">Name:</span> {userProfile.full_name}
                              </div>
                              <div>
                                <span className="font-medium">Role:</span> {userProfile.role}
                              </div>
                              <div>
                                <span className="font-medium">Email:</span> {userProfile.email}
                              </div>
                              <div>
                                <span className="font-medium">Shop ID:</span> {userProfile.shop_id || 'Not assigned'}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      )}
                    </div>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="permissions" className="h-full">
                  <ScrollArea className="h-full">
                    <div className="space-y-4">
                      {/* Quick Fix Component */}
                      {showQuickFix && hasPermissionErrors && (
                        <FirebasePermissionQuickFix 
                          onTestComplete={() => {
                            setActiveTab('testing');
                            setShowQuickFix(false);
                          }}
                        />
                      )}

                      {/* Permission Errors List */}
                      {hasPermissionErrors && (
                        <Card className="border-red-200">
                          <CardHeader>
                            <CardTitle className="text-base text-red-900">Permission Errors</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-2">
                              {getPermissionErrors().map((error, index) => (
                                <div key={index} className="bg-red-50 border border-red-200 rounded p-3">
                                  <p className="font-medium text-red-900">{error.context}</p>
                                  <p className="text-sm text-red-700">{error.message}</p>
                                  <p className="text-xs text-red-600">{error.timestamp}</p>
                                </div>
                              ))}
                            </div>
                          </CardContent>
                        </Card>
                      )}

                      {/* Basic Permission Tester */}
                      <FirebasePermissionTester userProfile={userProfile} />
                    </div>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="database" className="h-full">
                  <ScrollArea className="h-full">
                    <div className="space-y-4">
                      {/* Database Index Errors */}
                      {hasIndexErrors && (
                        <Card className="border-yellow-200">
                          <CardHeader>
                            <CardTitle className="text-base text-yellow-900">Database Index Issues</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-2">
                              {getIndexErrors().map((error, index) => (
                                <div key={index} className="bg-yellow-50 border border-yellow-200 rounded p-3">
                                  <p className="font-medium text-yellow-900">{error.context}</p>
                                  <p className="text-sm text-yellow-700">{error.message}</p>
                                  <p className="text-xs text-yellow-600">{error.timestamp}</p>
                                </div>
                              ))}
                            </div>
                          </CardContent>
                        </Card>
                      )}

                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base">Database Status</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-gray-600">
                            {hasIndexErrors ? 
                              'Some database operations may be slow due to missing indexes. Check the Firestore console for recommended indexes.' :
                              'Database indexes are properly configured for optimal performance.'
                            }
                          </p>
                        </CardContent>
                      </Card>
                    </div>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="testing" className="h-full">
                  <ScrollArea className="h-full">
                    <div className="space-y-4">
                      <EnhancedFirebasePermissionTester userProfile={userProfile} />
                    </div>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="system" className="h-full">
                  <ScrollArea className="h-full">
                    <div className="space-y-4">
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base">System Information</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2 text-sm font-mono">
                            <div><strong>Timestamp:</strong> {systemInfo.timestamp}</div>
                            <div><strong>URL:</strong> {systemInfo.url}</div>
                            <div><strong>Viewport:</strong> {systemInfo.viewport}</div>
                            <div><strong>Connection:</strong> {systemInfo.connection}</div>
                            <div><strong>Online:</strong> {systemInfo.online ? 'Yes' : 'No'}</div>
                            <div><strong>Language:</strong> {systemInfo.language}</div>
                            <div><strong>Timezone:</strong> {systemInfo.timezone}</div>
                          </div>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base">Session Flags</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-sm font-mono">
                            {Object.keys(systemInfo.sessionFlags || {}).length === 0 ? (
                              <p className="text-gray-500">No session flags set</p>
                            ) : (
                              <pre className="whitespace-pre-wrap">
                                {JSON.stringify(systemInfo.sessionFlags, null, 2)}
                              </pre>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="export" className="h-full">
                  <ScrollArea className="h-full">
                    <div className="space-y-4">
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base">Export Debug Information</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <p className="text-sm text-gray-600">
                            Export comprehensive debug information to share with support or for troubleshooting.
                          </p>
                          
                          <div className="flex gap-2">
                            <Button onClick={exportDebugLog}>
                              <ExternalLink className="h-4 w-4 mr-2" />
                              Export Debug Log
                            </Button>
                            <Button variant="outline" onClick={copySystemInfo}>
                              <Copy className="h-4 w-4 mr-2" />
                              Copy System Info
                            </Button>
                          </div>

                          <Separator />

                          <div className="space-y-2">
                            <h4 className="font-medium">Included Information:</h4>
                            <ul className="text-sm text-gray-600 space-y-1">
                              <li>• System and browser information</li>
                              <li>• User profile and permissions</li>
                              <li>• Error logs and contexts</li>
                              <li>• Firebase connection status</li>
                              <li>• AI system status</li>
                              <li>• Session flags and debugging data</li>
                            </ul>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </ScrollArea>
                </TabsContent>
              </div>
            </Tabs>
          </CardContent>
        )}
      </Card>
    </div>
  );
}