import React from 'react';
import { MainDashboard } from './MainDashboard';
import { UserManagement } from './UserManagement';
import { UserProfile } from './UserProfile';
import { ProductManager } from './ProductManager';
import { EnhancedProductManager } from './EnhancedProductManager';
import { PharmacyProductManager } from './PharmacyProductManager';
import { WorkingProductManager } from './WorkingProductManager';
import { RestorePharmacyProductManager } from './RestorePharmacyProductManager';
import { POSSystemWrapper } from './POSSystemWrapper';
import { SalesHistory } from './SalesHistory';
import { SalesReports } from './SalesReports';
import { InventoryReports } from './InventoryReports';
import { FinancialReports } from './FinancialReports';
import { CustomerReports } from './CustomerReports';
import { SupplierReports } from './SupplierReports';
import { ExpiryManagement } from './ExpiryManagement';
import { BatchTracking } from './BatchTracking';
import { StockTransfers } from './StockTransfers';
import { ReorderManagement } from './ReorderManagement';
import { ReturnsRefunds } from './ReturnsRefunds';
import { PrescriptionManager } from './PrescriptionManager';
import { CustomerAccounts } from './CustomerAccounts';
import { BranchManagement } from './BranchManagement';
import { AuditLogs } from './AuditLogs';
import { AIBusinessIntelligence } from './AIBusinessIntelligence';
import { NotificationCenter } from './NotificationCenter';
import { MobileManager } from './MobileManager';
import { BusinessSettings } from './BusinessSettings';
import { SuperAdminDashboard } from './SuperAdminDashboard';
import { ShopManagement } from './ShopManagement';
import { DebugPanel } from './DebugPanel';
import { ErrorDisplay } from './ErrorDisplay';
import { View } from '../lib/app-constants';
import { UserProfile as UserProfileType } from '../lib/firebase';

interface ViewRouterProps {
  currentView: View;
  userProfile: UserProfileType | null;
  aiSystemStatus: string;
  errors: any[];
  hasPermissionErrors: boolean;
  hasIndexErrors: boolean;
  hasNetworkErrors: boolean;
  hasValidationErrors: boolean;
  hasErrors: () => boolean;
  permissionErrorsLength: number;
  hasCriticalErrors: boolean;
  showDebugPanel: boolean;
  onSetCurrentView: (view: View) => void;
  onSignOut: () => void;
}

export function ViewRouter({
  currentView,
  userProfile,
  aiSystemStatus,
  errors,
  hasPermissionErrors,
  hasIndexErrors,
  hasNetworkErrors,
  hasValidationErrors,
  hasErrors,
  permissionErrorsLength,
  hasCriticalErrors,
  showDebugPanel,
  onSetCurrentView,
  onSignOut
}: ViewRouterProps) {

  // Render the current view based on the currentView state
  const renderView = () => {
    switch (currentView) {
      case 'home':
        return (
          <MainDashboard 
            userProfile={userProfile} 
            aiSystemStatus={aiSystemStatus}
            errors={errors}
            hasPermissionErrors={hasPermissionErrors}
            hasIndexErrors={hasIndexErrors}
            hasNetworkErrors={hasNetworkErrors}
            hasValidationErrors={hasValidationErrors}
            hasErrors={hasErrors}
            permissionErrorsLength={permissionErrorsLength}
            hasCriticalErrors={hasCriticalErrors}
            showDebugPanel={showDebugPanel}
            criticalErrorModalOpen={false}
            onSetCurrentView={onSetCurrentView}
            onSignOut={onSignOut}
            onToggleDebugPanel={() => {}}
            onCloseCriticalErrorModal={() => {}}
          />
        );
      
      // User Management
      case 'user-management':
        return <UserManagement userProfile={userProfile} />;
      case 'profile':
        return <UserProfile userProfile={userProfile} />;

      // Product & Inventory Management
      case 'product-management':
        return <RestorePharmacyProductManager userProfile={userProfile} onBack={() => onSetCurrentView('home')} />;
      case 'enhanced-product-manager':
        return <RestorePharmacyProductManager userProfile={userProfile} onBack={() => onSetCurrentView('home')} />;
      case 'batch-tracking':
        return <BatchTracking userProfile={userProfile} />;
      case 'expiry-management':
        return <ExpiryManagement userProfile={userProfile} />;
      case 'stock-transfers':
        return <StockTransfers userProfile={userProfile} />;
      case 'reorder-management':
        return <ReorderManagement userProfile={userProfile} />;

      // Sales & POS
      case 'pos-system':
        return <POSSystemWrapper userProfile={userProfile} />;
      case 'sales-history':
        return <SalesHistory userProfile={userProfile} />;
      case 'returns-refunds':
        return <ReturnsRefunds userProfile={userProfile} />;
      case 'prescriptions':
        return <PrescriptionManager userProfile={userProfile} />;
      case 'customer-accounts':
        return <CustomerAccounts userProfile={userProfile} />;

      // Reports & Analytics
      case 'sales-reports':
        return <SalesReports userProfile={userProfile} />;
      case 'inventory-reports':
        return <InventoryReports userProfile={userProfile} />;
      case 'financial-reports':
        return <FinancialReports userProfile={userProfile} />;
      case 'customer-reports':
        return <CustomerReports userProfile={userProfile} />;
      case 'supplier-reports':
        return <SupplierReports userProfile={userProfile} />;

      // Administration
      case 'branch-management':
        return <BranchManagement userProfile={userProfile} />;
      case 'audit-logs':
        return <AuditLogs userProfile={userProfile} />;

      // Smart Features
      case 'ai-business-intelligence':
        return <AIBusinessIntelligence userProfile={userProfile} aiSystemStatus={aiSystemStatus} />;
      case 'notifications':
        return <NotificationCenter userProfile={userProfile} />;
      case 'mobile-manager':
        return <MobileManager userProfile={userProfile} />;

      // Settings
      case 'settings':
        return <BusinessSettings userProfile={userProfile} />;

      // Super Admin Views
      case 'super-admin-dashboard':
        return (
          <SuperAdminDashboard 
            userProfile={userProfile} 
            onViewPharmacy={(pharmacyId: string) => {
              console.log('Viewing pharmacy:', pharmacyId);
              onSetCurrentView('all-pharmacies');
            }}
            onNavigate={onSetCurrentView}
          />
        );
      case 'all-pharmacies':
        return <ShopManagement userProfile={userProfile} />;
      case 'system-overview':
        return (
          <SuperAdminDashboard 
            userProfile={userProfile} 
            onViewPharmacy={(pharmacyId: string) => {
              console.log('Viewing pharmacy:', pharmacyId);
              onSetCurrentView('all-pharmacies');
            }}
            onNavigate={onSetCurrentView}
          />
        );
      case 'software-settings':
        return <BusinessSettings userProfile={userProfile} />;

      default:
        return (
          <MainDashboard 
            userProfile={userProfile} 
            aiSystemStatus={aiSystemStatus}
            errors={errors}
            hasPermissionErrors={hasPermissionErrors}
            hasIndexErrors={hasIndexErrors}
            hasNetworkErrors={hasNetworkErrors}
            hasValidationErrors={hasValidationErrors}
            hasErrors={hasErrors}
            permissionErrorsLength={permissionErrorsLength}
            hasCriticalErrors={hasCriticalErrors}
            showDebugPanel={showDebugPanel}
            criticalErrorModalOpen={false}
            onSetCurrentView={onSetCurrentView}
            onSignOut={onSignOut}
            onToggleDebugPanel={() => {}}
            onCloseCriticalErrorModal={() => {}}
          />
        );
    }
  };

  return (
    <>
      {renderView()}
      
      {/* Debug Panel - Only show in development */}
      {showDebugPanel && (
        <DebugPanel
          isOpen={showDebugPanel}
          onClose={() => {}}
          userProfile={userProfile}
          errors={errors}
          hasPermissionErrors={hasPermissionErrors}
          hasIndexErrors={hasIndexErrors}
          hasNetworkErrors={hasNetworkErrors}
          hasValidationErrors={hasValidationErrors}
          permissionErrorsLength={permissionErrorsLength}
          aiSystemStatus={aiSystemStatus}
        />
      )}
      
      {/* Error Display - Only show critical errors */}
      {hasCriticalErrors && (
        <ErrorDisplay 
          context="Critical System Errors" 
          compact={true}
          className="fixed bottom-4 right-4 max-w-md z-50"
        />
      )}
    </>
  );
}