import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Badge } from './ui/badge';
import { 
  Package, 
  Hash, 
  Calendar as CalendarIcon,
  X,
  Save,
  Zap
} from 'lucide-react';
import { toast } from 'sonner';
import { UserProfile, FirebaseService } from '../lib/firebase';
import { formatTZS } from '../lib/currency-utils';
import { format } from 'date-fns';

interface ComprehensiveProductFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  userProfile: UserProfile | null;
  onProductAdded: () => void;
  editingProduct?: any;
}

const CATEGORIES = [
  'Prescription Medicines',
  'Over-the-Counter', 
  'Pain Relief',
  'Antibiotics',
  'Vitamins & Supplements',
  'Cold & Flu',
  'Digestive Health',
  'Dermatological',
  'Baby & Child Care',
  'Medical Devices',
  'First Aid',
  'Personal Care'
];

const STATUS_OPTIONS = [
  { value: 'active', label: 'Active' },
  { value: 'inactive', label: 'Inactive' },
  { value: 'discontinued', label: 'Discontinued' }
];

export function ComprehensiveProductForm({ 
  open, 
  onOpenChange, 
  userProfile, 
  onProductAdded, 
  editingProduct 
}: ComprehensiveProductFormProps) {
  const [loading, setLoading] = useState(false);
  const [expiryDate, setExpiryDate] = useState<Date | undefined>();
  const [showCalendar, setShowCalendar] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    category: 'Over-the-Counter',
    generic_name: '',
    brand_name: '',
    description: '',
    manufacturer: '',
    strength: '',
    sku: '',
    barcode: '',
    cost_price: '',
    retail_price: '',
    stock_quantity: '',
    min_stock_level: '',
    status: 'active'
  });

  // Update form data when editingProduct changes or dialog opens
  useEffect(() => {
    if (open) {
      if (editingProduct) {
        // Populate form with existing product data
        setFormData({
          name: editingProduct.name || '',
          category: editingProduct.category || 'Over-the-Counter',
          generic_name: editingProduct.generic_name || editingProduct.active_ingredient || '',
          brand_name: editingProduct.brand_name || '',
          description: editingProduct.description || '',
          manufacturer: editingProduct.manufacturer || '',
          strength: editingProduct.strength || '',
          sku: editingProduct.sku || '',
          barcode: editingProduct.barcode || '',
          cost_price: editingProduct.cost_price?.toString() || '',
          retail_price: editingProduct.retail_price?.toString() || '',
          stock_quantity: editingProduct.stock_quantity?.toString() || '',
          min_stock_level: editingProduct.min_stock_level?.toString() || '',
          status: editingProduct.status || 'active'
        });
        
        // Set expiry date if exists
        setExpiryDate(editingProduct.expiry_date ? new Date(editingProduct.expiry_date) : undefined);
      } else {
        // Reset form for new product
        setFormData({
          name: '',
          category: 'Over-the-Counter',
          generic_name: '',
          brand_name: '',
          description: '',
          manufacturer: '',
          strength: '',
          sku: '',
          barcode: '',
          cost_price: '',
          retail_price: '',
          stock_quantity: '',
          min_stock_level: '',
          status: 'active'
        });
        setExpiryDate(undefined);
      }
    }
  }, [open, editingProduct]);

  const generateSKU = () => {
    if (!formData.name.trim()) {
      toast.error('Please enter product name first');
      return;
    }
    
    const timestamp = Date.now().toString().slice(-4);
    const categoryCode = formData.category.substring(0, 3).toUpperCase();
    const nameCode = formData.name.replace(/[^a-zA-Z0-9]/g, '').substring(0, 3).toUpperCase();
    const randomNum = Math.floor(Math.random() * 100).toString().padStart(2, '0');
    
    const newSKU = `${categoryCode}${nameCode}${randomNum}${timestamp}`;
    setFormData(prev => ({ ...prev, sku: newSKU }));
    
    toast.success('SKU generated successfully!', {
      description: `Generated: ${newSKU}`
    });
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateForm = (): string[] => {
    const errors: string[] = [];
    
    if (!formData.name.trim()) errors.push('Product name is required');
    if (!formData.category) errors.push('Category is required');
    if (!formData.manufacturer.trim()) errors.push('Manufacturer is required');
    if (!formData.sku.trim()) errors.push('SKU is required');
    const costPrice = parseFloat(formData.cost_price);
    const retailPrice = parseFloat(formData.retail_price);
    
    if (!formData.cost_price.trim() || isNaN(costPrice) || costPrice < 0) {
      errors.push('Valid cost price is required (must be 0 or greater)');
    }
    if (!formData.retail_price.trim() || isNaN(retailPrice) || retailPrice <= 0) {
      errors.push('Valid retail price is required (must be greater than 0)');
    }
    if (!formData.stock_quantity || parseInt(formData.stock_quantity) < 0) {
      errors.push('Valid stock quantity is required');
    }
    if (!formData.min_stock_level || parseInt(formData.min_stock_level) < 0) {
      errors.push('Valid minimum stock level is required');
    }
    
    if (!isNaN(costPrice) && !isNaN(retailPrice) && retailPrice <= costPrice) {
      errors.push('Retail price must be higher than cost price');
    }
    
    return errors;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const validationErrors = validateForm();
    if (validationErrors.length > 0) {
      validationErrors.forEach(error => {
        toast.error('Validation Error', { description: error });
      });
      return;
    }

    setLoading(true);
    
    try {
      console.log('📊 Form data before creating product:', {
        name: formData.name,
        cost_price: formData.cost_price,
        retail_price: formData.retail_price,
        cost_price_parsed: parseFloat(formData.cost_price),
        retail_price_parsed: parseFloat(formData.retail_price)
      });

      const productData = {
        name: formData.name.trim(),
        generic_name: formData.generic_name.trim() || undefined,
        active_ingredient: formData.generic_name.trim() || undefined,
        brand_name: formData.brand_name.trim() || undefined,
        description: formData.description.trim() || undefined,
        category: formData.category,
        strength: formData.strength.trim() || undefined,
        manufacturer: formData.manufacturer.trim(),
        sku: formData.sku.trim(),
        barcode: formData.barcode.trim() || undefined,
        cost_price: parseFloat(formData.cost_price),
        retail_price: parseFloat(formData.retail_price),
        stock_quantity: parseInt(formData.stock_quantity),
        min_stock_level: parseInt(formData.min_stock_level),
        reorder_level: parseInt(formData.min_stock_level),
        reorder_quantity: parseInt(formData.min_stock_level),
        expiry_date: expiryDate?.toISOString(),
        status: formData.status as 'active' | 'inactive',
        shop_id: userProfile?.shop_id,
        created_by: userProfile?.id
      };

      console.log('📦 Final product data being sent:', productData);

      if (editingProduct) {
        await FirebaseService.updateProduct(editingProduct.id, productData);
        toast.success('Product Updated!', {
          description: `"${productData.name}" has been updated successfully.`
        });
      } else {
        await FirebaseService.createProduct(productData);
        toast.success('Product Added!', {
          description: `"${productData.name}" has been added to your inventory.`
        });
      }

      onProductAdded();
      onOpenChange(false);
      
      // Form will be reset by useEffect when dialog closes and reopens

    } catch (error: any) {
      console.error('Error saving product:', error);
      toast.error('Save Failed', {
        description: error.message || 'Failed to save product. Please try again.'
      });
    } finally {
      setLoading(false);
    }
  };

  const calculateProfit = () => {
    const cost = parseFloat(formData.cost_price) || 0;
    const retail = parseFloat(formData.retail_price) || 0;
    return retail - cost;
  };

  const calculateMargin = () => {
    const cost = parseFloat(formData.cost_price) || 0;
    const retail = parseFloat(formData.retail_price) || 0;
    if (retail === 0) return 0;
    return ((retail - cost) / retail) * 100;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            {editingProduct ? 'Edit Product' : 'Add Product'}
          </DialogTitle>
          <DialogDescription>
            {editingProduct 
              ? 'Update the product information below. All required fields must be completed.'
              : 'Fill in the product details below. Required fields are marked with an asterisk (*).'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Product Name *</Label>
              <Input
                id="name"
                placeholder="Enter product name"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="category">Category *</Label>
              <Select value={formData.category} onValueChange={(value) => handleInputChange('category', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map(category => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="generic_name">Generic Name</Label>
              <Input
                id="generic_name"
                placeholder="Generic name"
                value={formData.generic_name}
                onChange={(e) => handleInputChange('generic_name', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="brand_name">Brand Name</Label>
              <Input
                id="brand_name"
                placeholder="Brand name"
                value={formData.brand_name}
                onChange={(e) => handleInputChange('brand_name', e.target.value)}
              />
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Product description"
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              rows={3}
            />
          </div>

          {/* Manufacturer and Strength */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="manufacturer">Manufacturer *</Label>
              <Input
                id="manufacturer"
                placeholder="Manufacturer name"
                value={formData.manufacturer}
                onChange={(e) => handleInputChange('manufacturer', e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="strength">Strength</Label>
              <Input
                id="strength"
                placeholder="e.g., 500mg, 10ml"
                value={formData.strength}
                onChange={(e) => handleInputChange('strength', e.target.value)}
              />
            </div>
          </div>

          {/* SKU and Barcode */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="sku">SKU *</Label>
              <div className="flex gap-2">
                <Input
                  id="sku"
                  placeholder="Stock Keeping Unit"
                  value={formData.sku}
                  onChange={(e) => handleInputChange('sku', e.target.value)}
                  required
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={generateSKU}
                  className="flex items-center gap-1"
                >
                  <Hash className="h-4 w-4" />
                  Generate
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="barcode">Barcode</Label>
              <Input
                id="barcode"
                placeholder="Barcode number"
                value={formData.barcode}
                onChange={(e) => handleInputChange('barcode', e.target.value)}
              />
            </div>
          </div>

          {/* Pricing */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="cost_price">Cost Price (TZS) *</Label>
              <Input
                id="cost_price"
                type="number"
                step="0.01"
                placeholder="0.00"
                value={formData.cost_price}
                onChange={(e) => handleInputChange('cost_price', e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="retail_price">Retail Price (TZS) *</Label>
              <Input
                id="retail_price"
                type="number"
                step="0.01"
                placeholder="0.00"
                value={formData.retail_price}
                onChange={(e) => handleInputChange('retail_price', e.target.value)}
                required
              />
            </div>
          </div>

          {/* Profit Calculation Display */}
          {formData.cost_price && formData.retail_price && (
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex justify-between items-center text-sm">
                <span>Profit: <span className="font-semibold">{formatTZS(calculateProfit())}</span></span>
                <span>Margin: <span className="font-semibold">{calculateMargin().toFixed(1)}%</span></span>
              </div>
            </div>
          )}

          {/* Stock Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="stock_quantity">Stock Quantity *</Label>
              <Input
                id="stock_quantity"
                type="number"
                placeholder="0"
                value={formData.stock_quantity}
                onChange={(e) => handleInputChange('stock_quantity', e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="min_stock_level">Minimum Stock Level *</Label>
              <Input
                id="min_stock_level"
                type="number"
                placeholder="0"
                value={formData.min_stock_level}
                onChange={(e) => handleInputChange('min_stock_level', e.target.value)}
                required
              />
            </div>
          </div>

          {/* Expiry Date and Status */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Expiry Date</Label>
              <Popover open={showCalendar} onOpenChange={setShowCalendar}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left font-normal"
                    onClick={() => setShowCalendar(true)}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {expiryDate ? format(expiryDate, 'dd/MM/yyyy') : 'dd/mm/yyyy'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0 calendar-popover" align="start">
                  <Calendar
                    mode="single"
                    selected={expiryDate}
                    onSelect={(date) => {
                      setExpiryDate(date);
                      setShowCalendar(false);
                    }}
                    disabled={(date) => date < new Date()}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={formData.status} onValueChange={(value) => handleInputChange('status', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  {STATUS_OPTIONS.map(option => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex justify-between pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={loading}
            >
              Cancel
            </Button>
            
            <Button
              type="submit"
              disabled={loading}
              className="flex items-center gap-2"
            >
              {loading ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
              ) : (
                <Save className="h-4 w-4" />
              )}
              {editingProduct ? 'Update Product' : 'Add Product'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}