import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { 
  AlertTriangle, 
  Shield, 
  Copy, 
  CheckCircle, 
  XCircle, 
  Clock,
  ExternalLink,
  Zap
} from 'lucide-react';

interface FirebaseRulesDeploymentBannerProps {
  hasPermissionErrors: boolean;
  errorCount: number;
  onDismiss?: () => void;
}

export function FirebaseRulesDeploymentBanner({ 
  hasPermissionErrors, 
  errorCount, 
  onDismiss 
}: FirebaseRulesDeploymentBannerProps) {
  const [step, setStep] = useState<'problem' | 'temp-rules' | 'production-rules'>('problem');
  const [isDismissed, setIsDismissed] = useState(false);

  const tempRules = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // TEMPORARY RULES FOR TESTING ONLY
    // ⚠️ THESE RULES ARE NOT SECURE - REPLACE WITH PROPER RULES ASAP
    
    match /{document=**} {
      // Allow all authenticated users to read/write everything (TEMPORARY ONLY)
      allow read, write: if request.auth != null;
    }
    
    // Note: These are temporary testing rules only
    // Deploy proper security rules from FIRESTORE_RULES_DEPLOYMENT_GUIDE.md after testing
  }
}`;

  const copyTempRules = () => {
    navigator.clipboard.writeText(tempRules).then(() => {
      alert('Temporary rules copied! Paste them in Firebase Console → Firestore → Rules tab');
    });
  };

  const copyProductionInstructions = () => {
    const instructions = `
🔥 FIREBASE RULES DEPLOYMENT - PRODUCTION SECURITY

After testing with temporary rules, deploy proper security:

1. Open Firebase Console: https://console.firebase.google.com
2. Select project: shopsalesai
3. Go to: Firestore Database → Rules tab
4. Copy complete rules from: FIRESTORE_RULES_DEPLOYMENT_GUIDE.md
5. Replace temporary rules and click "Publish"

This will enable proper role-based security for your Shop Sales Dashboard.
    `.trim();
    
    navigator.clipboard.writeText(instructions).then(() => {
      alert('Production deployment instructions copied!');
    });
  };

  const openFirebaseConsole = () => {
    window.open('https://console.firebase.google.com', '_blank');
  };

  const handleDismiss = () => {
    setIsDismissed(true);
    onDismiss?.();
  };

  if (!hasPermissionErrors || isDismissed) {
    return null;
  }

  return (
    <div className="fixed top-0 left-0 right-0 z-50 bg-red-600 text-white p-2">
      <div className="container mx-auto">
        <Card className="bg-red-50 border-red-300">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <Shield className="h-6 w-6 text-red-600" />
                  <CardTitle className="text-red-900">🚨 FIREBASE RULES NOT DEPLOYED</CardTitle>
                </div>
                <Badge variant="destructive" className="bg-red-600">
                  {errorCount} Permission Errors
                </Badge>
              </div>
              <Button onClick={handleDismiss} variant="outline" size="sm" className="text-red-700 border-red-300">
                ✕
              </Button>
            </div>
          </CardHeader>

          <CardContent className="space-y-4">
            {step === 'problem' && (
              <div className="space-y-4">
                <Alert className="bg-red-100 border-red-300">
                  <AlertTriangle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-800">
                    <strong>Your Shop Sales Dashboard is blocked by permission errors.</strong>
                    <br />
                    Firebase security rules need to be deployed to enable product management, user management, and analytics features.
                  </AlertDescription>
                </Alert>

                <div className="bg-amber-50 border border-amber-300 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <Clock className="h-5 w-5 text-amber-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-amber-900">Quick Fix Available (2 minutes)</h4>
                      <p className="text-amber-800 text-sm mt-1">
                        Deploy temporary testing rules now, then secure with production rules afterward.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button 
                    onClick={() => setStep('temp-rules')} 
                    className="flex-1 bg-red-600 hover:bg-red-700"
                  >
                    <Zap className="mr-2 h-4 w-4" />
                    Fix Now (Deploy Temp Rules)
                  </Button>
                  <Button 
                    onClick={openFirebaseConsole} 
                    variant="outline" 
                    className="border-red-300 text-red-700"
                  >
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Open Firebase Console
                  </Button>
                </div>
              </div>
            )}

            {step === 'temp-rules' && (
              <div className="space-y-4">
                <div className="bg-blue-50 border border-blue-300 rounded-lg p-4">
                  <h4 className="font-semibold text-blue-900 mb-2">Step 1: Deploy Temporary Rules (For Testing)</h4>
                  <ol className="text-blue-800 text-sm space-y-2 list-decimal list-inside">
                    <li>Open Firebase Console (button below opens it)</li>
                    <li>Select your <code className="bg-blue-100 px-1 rounded">shopsalesai</code> project</li>
                    <li>Navigate to <strong>Firestore Database → Rules</strong> tab</li>
                    <li>Delete all existing rules</li>
                    <li>Copy and paste the temporary rules below</li>
                    <li>Click <strong>"Publish"</strong> to deploy</li>
                  </ol>
                </div>

                <div className="bg-gray-100 border rounded-lg">
                  <div className="flex items-center justify-between p-3 border-b bg-gray-50 rounded-t-lg">
                    <span className="text-sm font-medium text-gray-700">Temporary Rules (Copy This)</span>
                    <Button onClick={copyTempRules} size="sm" variant="outline">
                      <Copy className="mr-1 h-3 w-3" />
                      Copy Rules
                    </Button>
                  </div>
                  <pre className="p-3 text-xs overflow-auto max-h-40 bg-white text-gray-800">
                    {tempRules}
                  </pre>
                </div>

                <Alert className="bg-amber-50 border-amber-300">
                  <AlertTriangle className="h-4 w-4 text-amber-600" />
                  <AlertDescription className="text-amber-800">
                    <strong>⚠️ Security Warning:</strong> These temporary rules allow any authenticated user to access all data. 
                    Use only for testing. Deploy production security rules immediately after testing.
                  </AlertDescription>
                </Alert>

                <div className="flex gap-3">
                  <Button onClick={openFirebaseConsole} className="flex-1">
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Open Firebase Console
                  </Button>
                  <Button onClick={() => setStep('production-rules')} variant="outline">
                    Next: Production Rules →
                  </Button>
                </div>
              </div>
            )}

            {step === 'production-rules' && (
              <div className="space-y-4">
                <div className="bg-green-50 border border-green-300 rounded-lg p-4">
                  <h4 className="font-semibold text-green-900 mb-2">Step 2: Deploy Production Security Rules</h4>
                  <p className="text-green-800 text-sm mb-3">
                    After your app is working with temporary rules, deploy proper role-based security.
                  </p>
                  <ol className="text-green-800 text-sm space-y-2 list-decimal list-inside">
                    <li>Open the <code className="bg-green-100 px-1 rounded">FIRESTORE_RULES_DEPLOYMENT_GUIDE.md</code> file</li>
                    <li>Copy the complete production security rules</li>
                    <li>Replace temporary rules in Firebase Console</li>
                    <li>Click "Publish" to deploy secure rules</li>
                  </ol>
                </div>

                <div className="bg-blue-50 border border-blue-300 rounded-lg p-3">
                  <h5 className="font-medium text-blue-900 mb-2">Production Rules Include:</h5>
                  <div className="grid grid-cols-2 gap-2 text-blue-800 text-sm">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-3 w-3 text-green-600" />
                      <span>Role-based access control</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-3 w-3 text-green-600" />
                      <span>Shop data isolation</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-3 w-3 text-green-600" />
                      <span>User permission enforcement</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-3 w-3 text-green-600" />
                      <span>Production-ready security</span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button onClick={copyProductionInstructions} className="flex-1">
                    <Copy className="mr-2 h-4 w-4" />
                    Copy Production Instructions
                  </Button>
                  <Button onClick={openFirebaseConsole} variant="outline">
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Firebase Console
                  </Button>
                </div>
              </div>
            )}

            <div className="text-center">
              <p className="text-xs text-gray-600">
                Need help? Copy debug info from the debug panel and share with your Firebase administrator.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}