import React, { useState, useEffect } from 'react';
import { BarChart3, TrendingUp, DollarSign, ShoppingCart, Calendar, Download, Filter, Eye, Loader2, AlertCircle, User, ChevronDown, X, Settings } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Alert, AlertDescription } from './ui/alert';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from './ui/sheet';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { formatTZS } from '../lib/currency-utils';
import { SalesService } from '../lib/firebase-sales';
import { Sale } from '../lib/firebase-types';
import { UserProfile, FirebaseService } from '../lib/firebase';

interface SalesReportsProps {
  userProfile: UserProfile;
  onBack: () => void;
  onSetCurrentView: (view: any) => void;
}

interface SalesOverview {
  totalSales: number;
  totalTransactions: number;
  averageTransaction: number;
  topSellingCategory: string;
  growth: number;
}

interface ProductSales {
  name: string;
  quantity: number;
  revenue: number;
  category: string;
}

interface CategorySales {
  category: string;
  sales: number;
  percentage: number;
  transactions: number;
}

interface HourlySales {
  hour: string;
  sales: number;
  transactions: number;
}

interface PaymentMethodData {
  method: string;
  amount: number;
  percentage: number;
  transactions: number;
}

interface SellerSales {
  sellerId: string;
  sellerName: string;
  sales: number;
  transactions: number;
  averageTransaction: number;
  percentage: number;
}

export function SalesReports({ userProfile, onBack, onSetCurrentView }: SalesReportsProps) {
  const [dateRange, setDateRange] = useState('today');
  const [reportType, setReportType] = useState('overview');
  const [isLoading, setIsLoading] = useState(true);
  const [salesData, setSalesData] = useState<Sale[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [filtersExpanded, setFiltersExpanded] = useState(false);

  // Processed data states
  const [salesOverview, setSalesOverview] = useState<SalesOverview>({
    totalSales: 0,
    totalTransactions: 0,
    averageTransaction: 0,
    topSellingCategory: 'No Sales',
    growth: 0
  });
  const [topProducts, setTopProducts] = useState<ProductSales[]>([]);
  const [salesByCategory, setSalesByCategory] = useState<CategorySales[]>([]);
  const [salesByHour, setSalesByHour] = useState<HourlySales[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethodData[]>([]);
  const [salesBySeller, setSalesBySeller] = useState<SellerSales[]>([]);
  const [sellerProfiles, setSellerProfiles] = useState<{ [key: string]: string }>({});
  const [filterSeller, setFilterSeller] = useState<string>('all');

  // Fetch sales data based on date range
  useEffect(() => {
    const fetchSalesData = async () => {
      if (!userProfile?.shop_id) {
        setError('No pharmacy information available');
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);
        setError(null);
        console.log('📊 Fetching sales data for date range:', dateRange);

        const dateRangeFilter = getDateRangeFilter(dateRange);
        let sales: Sale[] = [];

        if (dateRangeFilter) {
          sales = await SalesService.getSalesByShop(userProfile.shop_id, 200, dateRangeFilter);
        } else {
          // For specific ranges like 'today', use specialized methods
          if (dateRange === 'today') {
            sales = await SalesService.getTodaysSales(userProfile.shop_id);
          } else {
            sales = await SalesService.getSalesByShop(userProfile.shop_id, 200);
          }
        }

        console.log(`✅ Fetched ${sales.length} sales records for ${dateRange}`);
        setSalesData(sales);
        await processSalesDataForReports(sales);
        setIsLoading(false);
      } catch (error: any) {
        console.error('❌ Error fetching sales data:', error);
        setError(error.message || 'Failed to load sales data');
        setIsLoading(false);
      }
    };

    fetchSalesData();
  }, [dateRange, userProfile?.shop_id]);

  // Re-process data when seller filter changes
  useEffect(() => {
    if (salesData.length > 0) {
      const filteredSales = getFilteredSales();
      processSalesDataForReports(filteredSales).catch(error => {
        console.error('Error re-processing sales data for filter:', error);
      });
    }
  }, [filterSeller]);

  // Get date range filter for API calls
  const getDateRangeFilter = (range: string) => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    switch (range) {
      case 'yesterday':
        const yesterday = new Date(today);
        yesterday.setDate(yesterday.getDate() - 1);
        return {
          start: yesterday.toISOString(),
          end: today.toISOString()
        };
        
      case 'week':
        const weekStart = new Date(today);
        weekStart.setDate(today.getDate() - today.getDay()); // Start of current week
        return {
          start: weekStart.toISOString(),
          end: now.toISOString()
        };
        
      case 'month':
        const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
        return {
          start: monthStart.toISOString(),
          end: now.toISOString()
        };
        
      case 'quarter':
        const quarter = Math.floor(today.getMonth() / 3);
        const quarterStart = new Date(today.getFullYear(), quarter * 3, 1);
        return {
          start: quarterStart.toISOString(),
          end: now.toISOString()
        };
        
      case 'year':
        const yearStart = new Date(today.getFullYear(), 0, 1);
        return {
          start: yearStart.toISOString(),
          end: now.toISOString()
        };
        
      default:
        return null; // For 'today', we'll use the specialized method
    }
  };

  // Fetch seller names for given cashier IDs
  const fetchSellerNames = async (cashierIds: string[]) => {
    const profiles: { [key: string]: string } = {};
    
    try {
      // Get unique cashier IDs and filter out empty ones
      const uniqueCashierIds = [...new Set(cashierIds)].filter(id => id && id.trim() !== '');
      
      if (uniqueCashierIds.length === 0) {
        console.log('No valid cashier IDs to fetch');
        setSellerProfiles(profiles);
        return profiles;
      }

      console.log('Fetching profiles for cashier IDs:', uniqueCashierIds);
      
      for (const cashierId of uniqueCashierIds) {
        try {
          console.log('Fetching profile for cashier:', cashierId);
          const userDoc = await FirebaseService.getUserProfile(cashierId);
          if (userDoc && userDoc.full_name) {
            profiles[cashierId] = userDoc.full_name;
            console.log('✅ Found profile for cashier:', cashierId, '->', userDoc.full_name);
          } else {
            console.warn('No profile data found for cashier:', cashierId);
            profiles[cashierId] = 'Unknown Seller';
          }
        } catch (error) {
          console.warn(`Could not fetch profile for cashier ${cashierId}:`, error);
          profiles[cashierId] = 'Unknown Seller';
        }
      }
      
      console.log('Final seller profiles:', profiles);
    } catch (error) {
      console.error('Error fetching seller profiles:', error);
    }
    
    setSellerProfiles(profiles);
    return profiles;
  };

  // Filter sales by seller if a specific seller is selected
  const getFilteredSales = () => {
    if (filterSeller === 'all') {
      return salesData;
    }
    return salesData.filter(sale => sale.cashier_id === filterSeller);
  };

  // Process sales data to generate reports
  const processSalesDataForReports = async (sales: Sale[]) => {
    if (sales.length === 0) {
      // Set empty state
      setSalesOverview({
        totalSales: 0,
        totalTransactions: 0,
        averageTransaction: 0,
        topSellingCategory: 'No Sales',
        growth: 0
      });
      setTopProducts([]);
      setSalesByCategory([]);
      setSalesByHour([]);
      setPaymentMethods([]);
      setSalesBySeller([]);
      return;
    }

    // Fetch seller names first
    console.log('Processing sales data for', sales.length, 'sales');
    const cashierIds = sales.map(sale => sale.cashier_id).filter(Boolean);
    console.log('Found cashier IDs:', cashierIds);
    
    let profiles: { [key: string]: string } = {};
    try {
      profiles = await fetchSellerNames(cashierIds);
    } catch (error) {
      console.error('Failed to fetch seller names, continuing with unknown sellers:', error);
      // Continue processing with empty profiles - sellers will show as "Unknown Seller"
    }

    // Calculate overview metrics
    const totalTransactions = sales.length;
    const totalSales = sales.reduce((sum, sale) => {
      try {
        const price = parseFloat(sale.total_price?.toString() || '0');
        return sum + (isNaN(price) ? 0 : price);
      } catch (error) {
        console.warn('Error parsing total_price for sale:', sale.id, error);
        return sum;
      }
    }, 0);
    const averageTransaction = totalTransactions > 0 ? totalSales / totalTransactions : 0;

    // Process products
    const productSales: { [key: string]: { quantity: number; revenue: number; category: string } } = {};
    
    sales.forEach(sale => {
      if (!sale.items || !Array.isArray(sale.items)) {
        console.warn('Sale has no items array:', sale.id);
        return;
      }
      
      sale.items.forEach(item => {
        if (!item.product_name) {
          console.warn('Sale item has no product_name:', item);
          return;
        }
        
        const key = item.product_name;
        if (!productSales[key]) {
          productSales[key] = {
            quantity: 0,
            revenue: 0,
            category: item.category || 'Medicine' // Better fallback for pharmacy context
          };
        }
        
        try {
          const quantity = parseInt(item.quantity?.toString() || '0') || 0;
          const unitPrice = parseFloat(item.unit_price?.toString() || '0') || 0;
          
          productSales[key].quantity += quantity;
          productSales[key].revenue += quantity * unitPrice;
        } catch (error) {
          console.warn('Error processing sale item:', item, error);
        }
      });
    });

    // Get top products
    const topProductsList = Object.entries(productSales)
      .map(([name, data]) => ({
        name,
        quantity: data.quantity,
        revenue: data.revenue,
        category: data.category
      }))
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10);

    // Process categories
    const categorySales: { [key: string]: { sales: number; transactions: Set<string> } } = {};
    
    sales.forEach(sale => {
      if (!sale.items || !Array.isArray(sale.items) || !sale.id) {
        return;
      }
      
      sale.items.forEach(item => {
        try {
          const category = item.category || 'Medicine';
          if (!categorySales[category]) {
            categorySales[category] = {
              sales: 0,
              transactions: new Set()
            };
          }
          
          const quantity = parseInt(item.quantity?.toString() || '0') || 0;
          const unitPrice = parseFloat(item.unit_price?.toString() || '0') || 0;
          
          categorySales[category].sales += quantity * unitPrice;
          categorySales[category].transactions.add(sale.id);
        } catch (error) {
          console.warn('Error processing category data:', item, error);
        }
      });
    });

    const categoryList = Object.entries(categorySales)
      .map(([category, data]) => ({
        category,
        sales: data.sales,
        percentage: (data.sales / totalSales) * 100,
        transactions: data.transactions.size
      }))
      .sort((a, b) => b.sales - a.sales);

    const topCategory = categoryList.length > 0 ? categoryList[0].category : 'No Sales';

    // Process hourly sales
    const hourlySales: { [key: string]: { sales: number; transactions: number } } = {};
    
    sales.forEach(sale => {
      try {
        if (!sale.timestamp) {
          console.warn('Sale has no timestamp:', sale.id);
          return;
        }
        
        const saleDate = new Date(sale.timestamp);
        if (isNaN(saleDate.getTime())) {
          console.warn('Invalid timestamp for sale:', sale.id, sale.timestamp);
          return;
        }
        
        const hour = saleDate.getHours();
        const hourKey = `${hour.toString().padStart(2, '0')}:00`;
        
        if (!hourlySales[hourKey]) {
          hourlySales[hourKey] = { sales: 0, transactions: 0 };
        }
        
        const saleAmount = parseFloat(sale.total_price?.toString() || '0') || 0;
        hourlySales[hourKey].sales += saleAmount;
        hourlySales[hourKey].transactions += 1;
      } catch (error) {
        console.warn('Error processing hourly sale data:', sale, error);
      }
    });

    const hourlyList = Object.entries(hourlySales)
      .map(([hour, data]) => ({
        hour,
        sales: data.sales,
        transactions: data.transactions
      }))
      .sort((a, b) => a.hour.localeCompare(b.hour));

    // Process payment methods
    const paymentMethodSales: { [key: string]: { amount: number; transactions: number } } = {};
    
    sales.forEach(sale => {
      const method = sale.payment_method || 'Cash';
      if (!paymentMethodSales[method]) {
        paymentMethodSales[method] = { amount: 0, transactions: 0 };
      }
      
      paymentMethodSales[method].amount += parseFloat(sale.total_price.toString());
      paymentMethodSales[method].transactions += 1;
    });

    const paymentMethodList = Object.entries(paymentMethodSales)
      .map(([method, data]) => ({
        method,
        amount: data.amount,
        percentage: (data.amount / totalSales) * 100,
        transactions: data.transactions
      }))
      .sort((a, b) => b.amount - a.amount);

    // Process sales by seller
    const sellerSales: { [key: string]: { sales: number; transactions: number } } = {};
    
    sales.forEach(sale => {
      try {
        const cashierId = sale.cashier_id || 'unknown';
        if (!sellerSales[cashierId]) {
          sellerSales[cashierId] = { sales: 0, transactions: 0 };
        }
        
        const saleAmount = parseFloat(sale.total_price?.toString() || '0') || 0;
        sellerSales[cashierId].sales += saleAmount;
        sellerSales[cashierId].transactions += 1;
      } catch (error) {
        console.warn('Error processing seller sale data:', sale, error);
      }
    });

    const sellerList = Object.entries(sellerSales)
      .map(([sellerId, data]) => ({
        sellerId,
        sellerName: profiles[sellerId] || 'Unknown Seller',
        sales: data.sales,
        transactions: data.transactions,
        averageTransaction: data.transactions > 0 ? data.sales / data.transactions : 0,
        percentage: (data.sales / totalSales) * 100
      }))
      .sort((a, b) => b.sales - a.sales);

    // Update state
    setSalesOverview({
      totalSales,
      totalTransactions,
      averageTransaction,
      topSellingCategory: topCategory,
      growth: 0 // TODO: Calculate growth from previous period
    });
    
    setTopProducts(topProductsList);
    setSalesByCategory(categoryList);
    setSalesByHour(hourlyList);
    setPaymentMethods(paymentMethodList);
    setSalesBySeller(sellerList);
  };

  const getDateRangeText = (range: string) => {
    switch (range) {
      case 'today': return 'Today';
      case 'yesterday': return 'Yesterday';
      case 'week': return 'This Week';
      case 'month': return 'This Month';
      case 'quarter': return 'This Quarter';
      case 'year': return 'This Year';
      default: return 'Today';
    }
  };

  // Export report functionality
  const handleExportReport = () => {
    const reportData = {
      reportTitle: `Sales Report - ${getDateRangeText(dateRange)}`,
      generatedDate: new Date().toLocaleString(),
      pharmacy: userProfile.shop?.name || 'Pharmacy',
      dateRange: getDateRangeText(dateRange),
      overview: salesOverview,
      topProducts: topProducts,
      salesByCategory: salesByCategory,
      salesByHour: salesByHour,
      paymentMethods: paymentMethods,
      salesBySeller: salesBySeller,
      totalRecords: salesData.length
    };

    // Create CSV content
    let csvContent = `Sales Report - ${getDateRangeText(dateRange)}\n`;
    csvContent += `Generated: ${new Date().toLocaleString()}\n`;
    csvContent += `Pharmacy: ${userProfile.shop?.name || 'Pharmacy'}\n\n`;
    
    csvContent += `OVERVIEW\n`;
    csvContent += `Total Sales,${salesOverview.totalSales}\n`;
    csvContent += `Total Transactions,${salesOverview.totalTransactions}\n`;
    csvContent += `Average Transaction,${salesOverview.averageTransaction}\n`;
    csvContent += `Top Category,${salesOverview.topSellingCategory}\n\n`;
    
    csvContent += `TOP PRODUCTS\n`;
    csvContent += `Product Name,Category,Quantity Sold,Revenue,Percentage\n`;
    topProducts.forEach(product => {
      const percentage = salesOverview.totalSales > 0 ? ((product.revenue / salesOverview.totalSales) * 100).toFixed(1) : '0.0';
      csvContent += `"${product.name}","${product.category}",${product.quantity},${product.revenue},${percentage}%\n`;
    });
    
    csvContent += `\nSALES BY SELLER\n`;
    csvContent += `Seller Name,Total Sales,Transactions,Average Transaction,Percentage\n`;
    salesBySeller.forEach(seller => {
      csvContent += `"${seller.sellerName}",${seller.sales},${seller.transactions},${seller.averageTransaction.toFixed(2)},${seller.percentage.toFixed(1)}%\n`;
    });
    
    // Download the CSV
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `sales-report-${dateRange}-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Get active filter count
  const getActiveFilterCount = () => {
    let count = 0;
    if (dateRange !== 'today') count++;
    if (reportType !== 'overview') count++;
    if (filterSeller !== 'all') count++;
    return count;
  };

  // Mobile Filter Panel Component
  const MobileFilterPanel = () => (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline" size="sm" className="min-h-[44px] gap-2">
          <Filter className="h-4 w-4" />
          <span>Filters</span>
          {getActiveFilterCount() > 0 && (
            <Badge variant="secondary" className="h-5 w-5 p-0 flex items-center justify-center text-xs">
              {getActiveFilterCount()}
            </Badge>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent side="bottom" className="h-[80vh]">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Report Filters
          </SheetTitle>
        </SheetHeader>
        <div className="space-y-6 mt-6">
          {/* Date Range Filter */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-900">Time Period</label>
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="h-12 text-base">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="today" className="text-base py-3">Today</SelectItem>
                <SelectItem value="yesterday" className="text-base py-3">Yesterday</SelectItem>
                <SelectItem value="week" className="text-base py-3">This Week</SelectItem>
                <SelectItem value="month" className="text-base py-3">This Month</SelectItem>
                <SelectItem value="quarter" className="text-base py-3">This Quarter</SelectItem>
                <SelectItem value="year" className="text-base py-3">This Year</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Report Type Filter */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-900">Report Type</label>
            <Select value={reportType} onValueChange={setReportType}>
              <SelectTrigger className="h-12 text-base">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="overview" className="text-base py-3">Overview</SelectItem>
                <SelectItem value="detailed" className="text-base py-3">Detailed</SelectItem>
                <SelectItem value="comparative" className="text-base py-3">Comparative</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Seller Filter */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-900">Filter by Seller</label>
            <Select value={filterSeller} onValueChange={setFilterSeller}>
              <SelectTrigger className="h-12 text-base">
                <SelectValue placeholder="All sellers" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all" className="text-base py-3">All Sellers</SelectItem>
                {salesBySeller.map((seller) => (
                  <SelectItem key={seller.sellerId} value={seller.sellerId} className="text-base py-3">
                    {seller.sellerName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Clear Filters */}
          <Button 
            variant="outline" 
            onClick={() => {
              setDateRange('today');
              setReportType('overview');
              setFilterSeller('all');
            }}
            className="w-full h-12"
          >
            Clear All Filters
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );

  // Desktop Collapsible Filters
  const DesktopFilters = () => (
    <Collapsible open={filtersExpanded} onOpenChange={setFiltersExpanded}>
      <div className="flex items-center justify-between">
        <CollapsibleTrigger asChild>
          <Button variant="ghost" size="sm" className="gap-2">
            <Filter className="h-4 w-4" />
            <span>Filters</span>
            <ChevronDown className={`h-4 w-4 transition-transform ${filtersExpanded ? 'rotate-180' : ''}`} />
            {getActiveFilterCount() > 0 && (
              <Badge variant="secondary" className="h-5 w-5 p-0 flex items-center justify-center text-xs">
                {getActiveFilterCount()}
              </Badge>
            )}
          </Button>
        </CollapsibleTrigger>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => handleExportReport()}
            disabled={salesData.length === 0}
            className="gap-2"
          >
            <Download className="h-4 w-4" />
            <span className="hidden sm:inline">Export</span>
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => window.print()}
            disabled={salesData.length === 0}
            className="gap-2"
          >
            <Eye className="h-4 w-4" />
            <span className="hidden sm:inline">Print</span>
          </Button>
        </div>
      </div>

      <CollapsibleContent className="space-y-4 mt-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Time Period</label>
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="yesterday">Yesterday</SelectItem>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
                <SelectItem value="quarter">This Quarter</SelectItem>
                <SelectItem value="year">This Year</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Report Type</label>
            <Select value={reportType} onValueChange={setReportType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="overview">Overview</SelectItem>
                <SelectItem value="detailed">Detailed</SelectItem>
                <SelectItem value="comparative">Comparative</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Filter by Seller</label>
            <Select value={filterSeller} onValueChange={setFilterSeller}>
              <SelectTrigger>
                <SelectValue placeholder="All sellers" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sellers</SelectItem>
                {salesBySeller.map((seller) => (
                  <SelectItem key={seller.sellerId} value={seller.sellerId}>
                    {seller.sellerName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {getActiveFilterCount() > 0 && (
            <div className="flex items-end">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  setDateRange('today');
                  setReportType('overview');
                  setFilterSeller('all');
                }}
                className="w-full"
              >
                Clear Filters
              </Button>
            </div>
          )}
        </div>

        {/* Filter Summary */}
        {salesData.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 text-sm text-gray-600">
            <span>Showing:</span>
            <Badge variant="outline">{getDateRangeText(dateRange)}</Badge>
            <Badge variant="outline">{reportType} report</Badge>
            {filterSeller !== 'all' && (
              <Badge variant="outline">
                {sellerProfiles[filterSeller] || 'Unknown Seller'}
              </Badge>
            )}
            <span>•</span>
            <span>{getFilteredSales().length} records</span>
            <span>•</span>
            <span>Updated: {new Date().toLocaleTimeString()}</span>
          </div>
        )}
      </CollapsibleContent>
    </Collapsible>
  );

  // Loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Loading sales reports...</p>
          <p className="text-sm text-gray-500 mt-1">Fetching data for {getDateRangeText(dateRange).toLowerCase()}</p>
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="space-y-6">
        <Alert className="border-red-200 bg-red-50">
          <AlertCircle className="h-4 w-4 text-red-600" />
          <AlertDescription>
            <div className="space-y-2">
              <p className="font-medium text-red-900">Failed to Load Sales Reports</p>
              <p className="text-red-800 text-sm">{error}</p>
              <Button
                onClick={() => window.location.reload()}
                variant="outline"
                size="sm"
                className="border-red-300 text-red-700 hover:bg-red-100"
              >
                Retry Loading
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  // No data state
  if (salesData.length === 0) {
    return (
      <div className="space-y-6">
        {/* Mobile-First Filter Controls */}
        <div className="flex items-center justify-between">
          {/* Mobile: Sheet trigger */}
          <div className="lg:hidden">
            <MobileFilterPanel />
          </div>
          
          {/* Desktop: Collapsible filters */}
          <div className="hidden lg:block flex-1">
            <DesktopFilters />
          </div>
        </div>

        <div className="text-center py-12">
          <ShoppingCart className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-medium text-gray-900 mb-2">No Sales Data</h3>
          <p className="text-gray-600 mb-4">
            No sales were recorded for {getDateRangeText(dateRange).toLowerCase()}.
          </p>
          <div className="space-y-2">
            <Button
              onClick={() => onSetCurrentView('pos-system')}
              className="bg-green-600 hover:bg-green-700"
            >
              <ShoppingCart className="h-4 w-4 mr-2" />
              Start Making Sales
            </Button>
            <p className="text-sm text-gray-500">
              Or try selecting a different date range above
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Mobile-First Filter Controls */}
      <div className="flex items-center justify-between">
        {/* Mobile: Sheet trigger */}
        <div className="lg:hidden">
          <MobileFilterPanel />
        </div>
        
        {/* Desktop: Collapsible filters */}
        <div className="hidden lg:block flex-1">
          <DesktopFilters />
        </div>

        {/* Mobile action buttons */}
        <div className="flex items-center gap-2 lg:hidden">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => handleExportReport()}
            disabled={salesData.length === 0}
            className="min-h-[44px]"
          >
            <Download className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => window.print()}
            disabled={salesData.length === 0}
            className="min-h-[44px]"
          >
            <Eye className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Sales Overview Cards - Mobile-First Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl lg:text-2xl font-bold text-green-600">{formatTZS(salesOverview.totalSales)}</div>
            <p className="text-xs text-muted-foreground">
              {getFilteredSales().length > 0 ? `From ${getFilteredSales().length} sale${getFilteredSales().length === 1 ? '' : 's'}` : 'No sales recorded'}
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Transactions</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl lg:text-2xl font-bold">{salesOverview.totalTransactions}</div>
            <p className="text-xs text-muted-foreground">
              {getDateRangeText(dateRange).toLowerCase()} transactions
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Transaction</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl lg:text-2xl font-bold">{formatTZS(salesOverview.averageTransaction)}</div>
            <p className="text-xs text-muted-foreground">
              Per transaction value
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Top Category</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl lg:text-2xl font-bold truncate" title={salesOverview.topSellingCategory}>
              {salesOverview.topSellingCategory}
            </div>
            <p className="text-xs text-muted-foreground">
              Highest revenue category
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Top Seller</CardTitle>
            <User className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl lg:text-2xl font-bold truncate" title={salesBySeller[0]?.sellerName || 'No sales'}>
              {salesBySeller[0]?.sellerName || 'No sales'}
            </div>
            <p className="text-xs text-muted-foreground">
              {salesBySeller[0] ? `${salesBySeller[0].transactions} transactions` : 'No transactions yet'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Report Content - Mobile-Optimized Tabs */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4">
          <TabsTrigger value="overview" className="text-sm">Overview</TabsTrigger>
          <TabsTrigger value="products" className="text-sm">Products</TabsTrigger>
          <TabsTrigger value="sellers" className="text-sm lg:inline hidden">Sellers</TabsTrigger>
          <TabsTrigger value="trends" className="text-sm lg:inline hidden">Trends</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Sales by Category */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Sales by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {salesByCategory.slice(0, 5).map((category, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium truncate">{category.category}</span>
                          <span className="text-sm text-gray-500">{category.percentage.toFixed(1)}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full" 
                            style={{ width: `${Math.min(category.percentage, 100)}%` }}
                          />
                        </div>
                      </div>
                      <div className="ml-4 text-right">
                        <div className="text-sm font-bold">{formatTZS(category.sales)}</div>
                        <div className="text-xs text-gray-500">{category.transactions} txns</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Payment Methods */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Payment Methods</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {paymentMethods.map((payment, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium">{payment.method}</span>
                          <span className="text-sm text-gray-500">{payment.percentage.toFixed(1)}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-green-600 h-2 rounded-full" 
                            style={{ width: `${Math.min(payment.percentage, 100)}%` }}
                          />
                        </div>
                      </div>
                      <div className="ml-4 text-right">
                        <div className="text-sm font-bold">{formatTZS(payment.amount)}</div>
                        <div className="text-xs text-gray-500">{payment.transactions} txns</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="products" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Top Products</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="min-w-[200px]">Product</TableHead>
                      <TableHead className="text-right">Quantity</TableHead>
                      <TableHead className="text-right">Revenue</TableHead>
                      <TableHead className="hidden sm:table-cell">Category</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {topProducts.slice(0, 10).map((product, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">
                          <div className="truncate max-w-[200px]" title={product.name}>
                            {product.name}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">{product.quantity}</TableCell>
                        <TableCell className="text-right font-semibold">{formatTZS(product.revenue)}</TableCell>
                        <TableCell className="hidden sm:table-cell">
                          <Badge variant="outline" className="text-xs">
                            {product.category}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sellers" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Sales Performance by Seller</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="min-w-[150px]">Seller</TableHead>
                      <TableHead className="text-right">Sales</TableHead>
                      <TableHead className="text-right">Transactions</TableHead>
                      <TableHead className="text-right hidden sm:table-cell">Average</TableHead>
                      <TableHead className="text-right hidden sm:table-cell">Share</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {salesBySeller.map((seller, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">
                          <div className="truncate max-w-[150px]" title={seller.sellerName}>
                            {seller.sellerName}
                          </div>
                        </TableCell>
                        <TableCell className="text-right font-semibold">{formatTZS(seller.sales)}</TableCell>
                        <TableCell className="text-right">{seller.transactions}</TableCell>
                        <TableCell className="text-right hidden sm:table-cell">{formatTZS(seller.averageTransaction)}</TableCell>
                        <TableCell className="text-right hidden sm:table-cell">{seller.percentage.toFixed(1)}%</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Hourly Sales Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {salesByHour.map((hourData, index) => {
                  const maxSales = Math.max(...salesByHour.map(h => h.sales));
                  const percentage = maxSales > 0 ? (hourData.sales / maxSales) * 100 : 0;
                  
                  return (
                    <div key={index} className="flex items-center space-x-4">
                      <div className="w-16 text-sm font-medium">{hourData.hour}</div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm text-gray-600">{hourData.transactions} transactions</span>
                          <span className="text-sm font-medium">{formatTZS(hourData.sales)}</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-purple-600 h-2 rounded-full transition-all" 
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}