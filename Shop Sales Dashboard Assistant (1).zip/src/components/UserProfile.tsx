import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from './ui/dropdown-menu';
import { User, LogOut, Settings, Store, ChevronDown, Shield, Clock, Calendar, Package, Building, ArrowLeft, Edit } from 'lucide-react';
import { Navigation } from './Navigation';
import { UserProfile as UserProfileType } from '../lib/firebase';
import { AIConnectionStatus } from '../hooks/useAIConnection';
import { View } from '../lib/app-constants';

interface UserProfileProps {
  userProfile: UserProfileType | null;
  onSignOut: () => void;
  onNavigateToSettings?: () => void;
  onBack?: () => void;
  onSetCurrentView?: (view: View) => void;
  className?: string;
  variant?: 'header' | 'card' | 'minimal' | 'page' | 'debug';
  aiSystemStatus?: AIConnectionStatus;
  hasPermissionErrors?: boolean;
  hasIndexErrors?: boolean;
}

// Type for Firestore Timestamp objects
interface FirestoreTimestamp {
  seconds: number;
  nanoseconds: number;
  type?: string;
}

export function UserProfile({ 
  userProfile, 
  onSignOut, 
  onNavigateToSettings, 
  onBack,
  onSetCurrentView,
  className = '', 
  variant = 'header',
  aiSystemStatus,
  hasPermissionErrors,
  hasIndexErrors
}: UserProfileProps) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  // FIXED: Move useEffect before any conditional returns to maintain hooks order
  // Debug: Log profile data to console for debugging
  React.useEffect(() => {
    if (userProfile) {
      console.log('🔍 UserProfile Debug Data:', {
        id: userProfile.id,
        email: userProfile.email,
        role: userProfile.role,
        shop_id: userProfile.shop_id,
        shop: userProfile.shop,
        hasShop: !!userProfile.shop,
        shopName: userProfile.shop?.name,
        shopSettings: userProfile.shop?.settings
      });
    }
  }, [userProfile]);

  if (!userProfile) {
    return null;
  }

  // Show debug information if shop_id exists but no shop object
  const showDebugInfo = userProfile.shop_id && !userProfile.shop;

  const getRoleDisplayName = (role: string) => {
    switch (role) {
      case 'seller': return 'Salesman';
      case 'owner': return 'Shop Owner';
      case 'manager': return 'Product Manager';
      default: return role;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'seller': return 'bg-green-100 text-green-800';
      case 'owner': return 'bg-blue-100 text-blue-800';
      case 'manager': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'seller': return User;
      case 'owner': return Shield;
      case 'manager': return Package; // Changed from Settings to Package
      default: return User;
    }
  };

  const getRoleDescription = (role: string) => {
    switch (role) {
      case 'seller': return 'Handles daily sales transactions and customer interactions';
      case 'owner': return 'Oversees business operations and strategic decision-making';
      case 'manager': return 'Manages product catalog, inventory, and pricing strategies';
      default: return 'Manages shop operations';
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word.charAt(0).toUpperCase())
      .join('')
      .slice(0, 2);
  };

  // Helper function to check if value is a Firestore Timestamp
  const isFirestoreTimestamp = (value: any): value is FirestoreTimestamp => {
    return value && 
           typeof value === 'object' && 
           typeof value.seconds === 'number' && 
           typeof value.nanoseconds === 'number';
  };

  // Enhanced date formatter that handles multiple input types
  const parseDate = (dateInput: any): Date | null => {
    if (!dateInput) {
      return null;
    }

    try {
      // Handle Firestore Timestamp objects
      if (isFirestoreTimestamp(dateInput)) {
        // Convert Firestore Timestamp to JavaScript Date
        // Firestore timestamps are in seconds, JavaScript Date expects milliseconds
        return new Date(dateInput.seconds * 1000 + dateInput.nanoseconds / 1000000);
      }

      // Handle Date objects
      if (dateInput instanceof Date) {
        return dateInput;
      }

      // Handle string inputs
      if (typeof dateInput === 'string') {
        // Check if it's a timestamp string (all digits)
        if (/^\d+$/.test(dateInput)) {
          return new Date(parseInt(dateInput));
        }
        // Try parsing as ISO string or other date format
        return new Date(dateInput);
      }

      // Handle number inputs (timestamps)
      if (typeof dateInput === 'number') {
        return new Date(dateInput);
      }

      console.warn('Unknown date format:', dateInput);
      return null;
    } catch (error) {
      console.error('Error parsing date:', error, 'Input:', dateInput);
      return null;
    }
  };

  const formatJoinDate = (dateInput: any) => {
    const date = parseDate(dateInput);
    
    if (!date || isNaN(date.getTime())) {
      console.warn('Invalid date input:', dateInput);
      return 'Not available';
    }

    try {
      return date.toLocaleDateString('en-US', {
        month: 'short',
        year: 'numeric'
      });
    } catch (error) {
      console.error('Error formatting date:', error, 'Date:', date);
      return 'Date unavailable';
    }
  };

  // Enhanced date formatter for full date display
  const formatFullDate = (dateInput: any) => {
    const date = parseDate(dateInput);
    
    if (!date || isNaN(date.getTime())) {
      console.warn('Invalid date input:', dateInput);
      return 'Not available';
    }

    try {
      return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      });
    } catch (error) {
      console.error('Error formatting full date:', error, 'Date:', date);
      return 'Date unavailable';
    }
  };

  // Minimal variant for compact display
  if (variant === 'minimal') {
    const RoleIcon = getRoleIcon(userProfile.role);
    
    return (
      <div className={`flex items-center gap-2 ${className}`}>
        <div className="flex items-center gap-2">
          <Avatar className="h-8 w-8">
            <AvatarFallback className="text-xs">
              {getInitials(userProfile.full_name)}
            </AvatarFallback>
          </Avatar>
          <div className="hidden sm:block">
            <p className="text-sm font-medium">{userProfile.full_name}</p>
            <p className="text-xs text-gray-500">{getRoleDisplayName(userProfile.role)}</p>
          </div>
        </div>
        <Button onClick={onSignOut} variant="outline" size="sm">
          <LogOut className="h-4 w-4" />
        </Button>
      </div>
    );
  }

  // Header variant with dropdown
  if (variant === 'header') {
    const RoleIcon = getRoleIcon(userProfile.role);
    
    return (
      <div className={`flex items-center gap-3 ${className}`}>
        {/* Demo Mode Badge */}
        {userProfile.id === 'demo-user-id' && (
          <Badge variant="secondary" className="bg-blue-100 text-blue-800">
            Demo Mode
          </Badge>
        )}

        {/* User Profile Dropdown */}
        <DropdownMenu open={isDropdownOpen} onOpenChange={setIsDropdownOpen}>
          <DropdownMenuTrigger asChild>
            <Button 
              variant="outline" 
              className="flex items-center gap-2 h-auto py-2 px-3 hover:bg-gray-50"
            >
              <Avatar className="h-8 w-8">
                <AvatarFallback>
                  {getInitials(userProfile.full_name)}
                </AvatarFallback>
              </Avatar>
              <div className="text-left">
                <p className="text-sm font-medium">{userProfile.full_name}</p>
                <div className="flex items-center gap-1">
                  <RoleIcon className="h-3 w-3" />
                  <p className="text-xs text-gray-500">{getRoleDisplayName(userProfile.role)}</p>
                </div>
              </div>
              <ChevronDown className="h-4 w-4 text-gray-400" />
            </Button>
          </DropdownMenuTrigger>
          
          <DropdownMenuContent align="end" className="w-80">
            <DropdownMenuLabel>
              <div className="flex items-center gap-3">
                <Avatar className="h-12 w-12">
                  <AvatarFallback className="text-lg">
                    {getInitials(userProfile.full_name)}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <p className="font-medium">{userProfile.full_name}</p>
                  <p className="text-sm text-gray-500">{userProfile.email}</p>
                  <Badge className={`mt-1 ${getRoleColor(userProfile.role)}`}>
                    <RoleIcon className="h-3 w-3 mr-1" />
                    {getRoleDisplayName(userProfile.role)}
                  </Badge>
                </div>
              </div>
            </DropdownMenuLabel>
            
            <DropdownMenuSeparator />
            
            {/* Role Description */}
            <div className="px-2 py-3">
              <div className="flex items-center gap-2 mb-2">
                <RoleIcon className="h-4 w-4 text-gray-500" />
                <span className="text-sm font-medium">Role Responsibilities</span>
              </div>
              <div className="ml-6">
                <p className="text-xs text-gray-600">{getRoleDescription(userProfile.role)}</p>
              </div>
            </div>
            
            <DropdownMenuSeparator />
            
            {/* Shop Information */}
            {userProfile.shop && (
              <>
                <div className="px-2 py-3">
                  <div className="flex items-center gap-2 mb-2">
                    <Store className="h-4 w-4 text-gray-500" />
                    <span className="text-sm font-medium">Shop Details</span>
                  </div>
                  <div className="ml-6 space-y-1">
                    <p className="text-sm font-medium">{userProfile.shop.name}</p>
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span>💰 {userProfile.shop.settings.currency}</span>
                      <span>🌍 {userProfile.shop.settings.timezone}</span>
                    </div>
                  </div>
                </div>
                <DropdownMenuSeparator />
              </>
            )}
            
            {/* Account Information */}
            <div className="px-2 py-3">
              <div className="flex items-center gap-2 mb-2">
                <Calendar className="h-4 w-4 text-gray-500" />
                <span className="text-sm font-medium">Account Info</span>
              </div>
              <div className="ml-6 space-y-1 text-xs text-gray-500">
                <p>Member since {formatJoinDate(userProfile.created_at)}</p>
                <p>Last updated {formatJoinDate(userProfile.updated_at)}</p>
              </div>
            </div>
            
            <DropdownMenuSeparator />
            
            {/* Actions */}
            {userProfile.role === 'owner' && onNavigateToSettings && (
              <DropdownMenuItem 
                onClick={onNavigateToSettings}
                className="text-blue-600 focus:text-blue-600 focus:bg-blue-50"
              >
                <Building className="h-4 w-4 mr-2" />
                Business Settings
              </DropdownMenuItem>
            )}
            
            <DropdownMenuItem 
              onClick={onSignOut}
              className="text-red-600 focus:text-red-600 focus:bg-red-50"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    );
  }

  // Page variant with navigation for full page view
  if (variant === 'page') {
    const RoleIcon = getRoleIcon(userProfile.role);
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <Navigation 
          userProfile={userProfile}
          currentView="profile"
          onNavigate={onSetCurrentView || (() => {})}
          onSignOut={onSignOut}
          aiSystemStatus={aiSystemStatus}
          hasPermissionErrors={hasPermissionErrors}
          hasIndexErrors={hasIndexErrors}
        />

        {/* Main content area */}
        <main className="min-h-screen">
          {/* Header */}
          <div className="mb-6 flex items-center gap-4">
            {onBack && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onBack}
                className="flex items-center gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to Dashboard
              </Button>
            )}
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
                <User className="h-8 w-8" />
                User Profile
              </h1>
              <p className="text-gray-600 mt-1">
                Manage your account settings and information
              </p>
            </div>
          </div>

          {/* Profile Content */}
          <div className="max-w-4xl">
            <Card className="shadow-lg">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <User className="h-5 w-5" />
                    Profile Information
                  </span>
                  <Button variant="outline" size="sm">
                    <Edit className="h-4 w-4 mr-2" />
                    Edit Profile
                  </Button>
                </CardTitle>
              </CardHeader>
              
              <CardContent className="space-y-6">
                {/* User Info */}
                <div className="flex items-start gap-6">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src="/placeholder-avatar.png" />
                    <AvatarFallback className="text-xl">
                      {getInitials(userProfile.full_name)}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold">{userProfile.full_name}</h3>
                    <p className="text-gray-600 mb-3">{userProfile.email}</p>
                    
                    <div className="flex items-center gap-3">
                      <Badge className={`${getRoleColor(userProfile.role)} px-3 py-1`}>
                        <RoleIcon className="h-4 w-4 mr-2" />
                        {getRoleDisplayName(userProfile.role)}
                      </Badge>
                      
                      {userProfile.id === 'demo-user-id' && (
                        <Badge variant="secondary" className="bg-blue-100 text-blue-800 px-3 py-1">
                          Demo Mode
                        </Badge>
                      )}
                    </div>
                    
                    <p className="text-sm text-gray-600 mt-3 max-w-md">{getRoleDescription(userProfile.role)}</p>
                  </div>
                </div>

                <Separator />

                {/* Shop Information */}
                {userProfile.shop && (
                  <>
                    <div>
                      <div className="flex items-center gap-2 mb-4">
                        <Store className="h-5 w-5 text-gray-500" />
                        <h4 className="text-lg font-medium">Shop Information</h4>
                      </div>
                      
                      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-4 rounded-lg border space-y-3">
                        <div>
                          <p className="text-lg font-semibold text-blue-900">{userProfile.shop.name}</p>
                          <p className="text-sm text-gray-600">Shop ID: {userProfile.shop.id}</p>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="bg-white p-3 rounded-md">
                            <p className="text-sm text-gray-500 mb-1">Currency</p>
                            <p className="font-medium text-green-600">💰 {userProfile.shop.settings.currency}</p>
                          </div>
                          <div className="bg-white p-3 rounded-md">
                            <p className="text-sm text-gray-500 mb-1">Timezone</p>
                            <p className="font-medium text-blue-600">🌍 {userProfile.shop.settings.timezone}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                  </>
                )}

                {/* Account Details */}
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <Clock className="h-5 w-5 text-gray-500" />
                    <h4 className="text-lg font-medium">Account Details</h4>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <p className="text-sm text-gray-500 mb-1">Member since</p>
                      <p className="font-medium">{formatFullDate(userProfile.created_at)}</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <p className="text-sm text-gray-500 mb-1">Last updated</p>
                      <p className="font-medium">{formatFullDate(userProfile.updated_at)}</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg md:col-span-2">
                      <p className="text-sm text-gray-500 mb-1">User ID</p>
                      <p className="font-mono text-sm bg-white px-2 py-1 rounded border">{userProfile.id}</p>
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Actions */}
                <div className="flex flex-col sm:flex-row gap-3">
                  {userProfile.role === 'owner' && onNavigateToSettings && (
                    <Button onClick={onNavigateToSettings} className="flex-1 bg-blue-600 hover:bg-blue-700">
                      <Building className="h-4 w-4 mr-2" />
                      Business Settings
                    </Button>
                  )}
                  <Button onClick={onSignOut} variant="outline" className="flex-1 text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700">
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    );
  }

  // Card variant for embedded profile display
  const RoleIcon = getRoleIcon(userProfile.role);
  
  return (
    <Card className={className}>
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2">
          <User className="h-5 w-5" />
          User Profile
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* User Info */}
        <div className="flex items-start gap-4">
          <Avatar className="h-16 w-16">
            <AvatarFallback className="text-lg">
              {getInitials(userProfile.full_name)}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1">
            <h3 className="text-lg font-medium">{userProfile.full_name}</h3>
            <p className="text-gray-600">{userProfile.email}</p>
            
            <div className="flex items-center gap-2 mt-2">
              <Badge className={getRoleColor(userProfile.role)}>
                <RoleIcon className="h-3 w-3 mr-1" />
                {getRoleDisplayName(userProfile.role)}
              </Badge>
              
              {userProfile.id === 'demo-user-id' && (
                <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                  Demo Mode
                </Badge>
              )}
            </div>
            
            <p className="text-sm text-gray-600 mt-2">{getRoleDescription(userProfile.role)}</p>
          </div>
        </div>

        <Separator />

        {/* Shop Information */}
        {userProfile.shop && (
          <>
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Store className="h-4 w-4 text-gray-500" />
                <h4 className="font-medium">Shop Information</h4>
              </div>
              
              <div className="bg-gray-50 p-3 rounded-lg space-y-2">
                <div>
                  <p className="font-medium">{userProfile.shop.name}</p>
                  <p className="text-sm text-gray-600">Shop ID: {userProfile.shop.id}</p>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-500">Currency</p>
                    <p className="font-medium">{userProfile.shop.settings.currency}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Timezone</p>
                    <p className="font-medium">{userProfile.shop.settings.timezone}</p>
                  </div>
                </div>
              </div>
            </div>
            
            <Separator />
          </>
        )}

        {/* Account Details */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Clock className="h-4 w-4 text-gray-500" />
            <h4 className="font-medium">Account Details</h4>
          </div>
          
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-500">Member since:</span>
              <span>{formatFullDate(userProfile.created_at)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Last updated:</span>
              <span>{formatFullDate(userProfile.updated_at)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">User ID:</span>
              <span className="font-mono text-xs">{userProfile.id}</span>
            </div>
          </div>
        </div>

        <Separator />

        {/* Actions */}
        <div className="flex gap-2">
          {userProfile.role === 'owner' && onNavigateToSettings && (
            <Button onClick={onNavigateToSettings} variant="outline" className="flex-1">
              <Building className="h-4 w-4 mr-2" />
              Business Settings
            </Button>
          )}
          <Button onClick={onSignOut} variant="outline" className="flex-1">
            <LogOut className="h-4 w-4 mr-2" />
            Sign Out
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}