import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { Settings, Store, Save, ArrowLeft, Globe, DollarSign, Clock, Building, AlertTriangle, CheckCircle } from 'lucide-react';
import { UserProfile as UserProfileType, FirebaseService } from '../lib/firebase';
import { toast } from 'sonner';

interface BusinessSettingsProps {
  userProfile: UserProfileType | null;
  onBack: () => void;
}

export function BusinessSettings({ userProfile, onBack }: BusinessSettingsProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasChanges, setHasChanges] = useState(false);
  
  const [shopData, setShopData] = useState({
    name: '',
    description: '',
    category: '',
    address: '',
    phone: '',
    currency: 'TZS',
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    reportTime: '20:00'
  });

  // Business categories with Pharmacy first as requested
  const shopCategories = [
    'Pharmacy',
    'Restaurant & Food',
    'Retail & Fashion',
    'Electronics & Technology',
    'Health & Beauty',
    'Books & Media',
    'Home & Garden',
    'Sports & Recreation',
    'Automotive',
    'Services',
    'Other'
  ];

  // Currency options with TZS first
  const currencies = [
    { code: 'TZS', name: 'Tanzanian Shilling (TSh)', symbol: 'TSh' },
    { code: 'USD', name: 'US Dollar ($)', symbol: '$' },
    { code: 'EUR', name: 'Euro (€)', symbol: '€' },
    { code: 'GBP', name: 'British Pound (£)', symbol: '£' },
    { code: 'CAD', name: 'Canadian Dollar (C$)', symbol: 'C$' },
    { code: 'AUD', name: 'Australian Dollar (A$)', symbol: 'A$' },
    { code: 'JPY', name: 'Japanese Yen (¥)', symbol: '¥' },
    { code: 'INR', name: 'Indian Rupee (₹)', symbol: '₹' },
    { code: 'BRL', name: 'Brazilian Real (R$)', symbol: 'R$' }
  ];

  // Load current shop data on component mount
  useEffect(() => {
    if (userProfile?.shop) {
      setShopData({
        name: userProfile.shop.name || '',
        description: userProfile.shop.description || '',
        category: userProfile.shop.category || '',
        address: userProfile.shop.address || '',
        phone: userProfile.shop.phone || '',
        currency: userProfile.shop.settings?.currency || 'TZS',
        timezone: userProfile.shop.settings?.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone,
        reportTime: userProfile.shop.settings?.report_time || '20:00'
      });
    }
  }, [userProfile]);

  // Track changes
  useEffect(() => {
    if (userProfile?.shop) {
      const hasDataChanged = 
        shopData.name !== (userProfile.shop.name || '') ||
        shopData.description !== (userProfile.shop.description || '') ||
        shopData.category !== (userProfile.shop.category || '') ||
        shopData.address !== (userProfile.shop.address || '') ||
        shopData.phone !== (userProfile.shop.phone || '') ||
        shopData.currency !== (userProfile.shop.settings?.currency || 'TZS') ||
        shopData.timezone !== (userProfile.shop.settings?.timezone || '') ||
        shopData.reportTime !== (userProfile.shop.settings?.report_time || '20:00');
      
      setHasChanges(hasDataChanged);
    }
  }, [shopData, userProfile]);

  // Check if user is owner
  const isOwner = userProfile?.role === 'owner';

  if (!isOwner) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <Button onClick={onBack} variant="outline" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
          
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Access denied. Only shop owners can modify business settings.
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  const handleSave = async () => {
    if (!userProfile?.shop_id) {
      setError('No shop found to update');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // Update shop with new settings
      await FirebaseService.updateShop(userProfile.shop_id, {
        name: shopData.name,
        description: shopData.description,
        category: shopData.category,
        address: shopData.address,
        phone: shopData.phone,
        settings: {
          currency: shopData.currency,
          timezone: shopData.timezone,
          report_time: shopData.reportTime
        }
      });

      toast.success('Business settings updated successfully!');
      setHasChanges(false);
      
      // Refresh the page to reflect changes
      window.location.reload();
      
    } catch (err: any) {
      console.error('Error updating business settings:', err);
      setError(err.message || 'Failed to update business settings');
      toast.error('Failed to update business settings');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    if (userProfile?.shop) {
      setShopData({
        name: userProfile.shop.name || '',
        description: userProfile.shop.description || '',
        category: userProfile.shop.category || '',
        address: userProfile.shop.address || '',
        phone: userProfile.shop.phone || '',
        currency: userProfile.shop.settings?.currency || 'TZS',
        timezone: userProfile.shop.settings?.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone,
        reportTime: userProfile.shop.settings?.report_time || '20:00'
      });
      setHasChanges(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Button onClick={onBack} variant="outline" size="sm" className="mr-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <Settings className="h-6 w-6" />
                Business Settings
              </h1>
              <p className="text-gray-600">Manage your shop information and business settings</p>
            </div>
          </div>

          {hasChanges && (
            <div className="flex items-center gap-2">
              <Button onClick={handleReset} variant="outline" size="sm">
                Reset Changes
              </Button>
              <Button onClick={handleSave} disabled={isLoading} size="sm">
                {isLoading ? (
                  <>
                    <Save className="h-4 w-4 mr-2 animate-pulse" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Save Changes
                  </>
                )}
              </Button>
            </div>
          )}
        </div>

        {/* Changes Indicator */}
        {hasChanges && (
          <Alert className="mb-6 bg-blue-50 border-blue-200">
            <CheckCircle className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-800">
              You have unsaved changes. Don't forget to save your updates!
            </AlertDescription>
          </Alert>
        )}

        {/* Error Alert */}
        {error && (
          <Alert className="mb-6" variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Shop Information */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Store className="h-5 w-5" />
                Shop Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="shop-name">Shop Name *</Label>
                  <Input
                    id="shop-name"
                    type="text"
                    placeholder="Enter your shop name"
                    value={shopData.name}
                    onChange={(e) => setShopData({ ...shopData, name: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="shop-description">Shop Description</Label>
                  <Textarea
                    id="shop-description"
                    placeholder="Describe your business"
                    value={shopData.description}
                    onChange={(e) => setShopData({ ...shopData, description: e.target.value })}
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="shop-category">Business Category *</Label>
                  <Select 
                    value={shopData.category} 
                    onValueChange={(value) => setShopData({ ...shopData, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {shopCategories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="shop-phone">Phone Number</Label>
                  <Input
                    id="shop-phone"
                    type="tel"
                    placeholder="Shop phone number"
                    value={shopData.phone}
                    onChange={(e) => setShopData({ ...shopData, phone: e.target.value })}
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="shop-address">Shop Address</Label>
                  <Input
                    id="shop-address"
                    type="text"
                    placeholder="Shop address"
                    value={shopData.address}
                    onChange={(e) => setShopData({ ...shopData, address: e.target.value })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Business Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Business Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Currency Setting */}
              <div className="space-y-2">
                <Label htmlFor="currency" className="flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  Currency
                </Label>
                <Select 
                  value={shopData.currency} 
                  onValueChange={(value) => setShopData({ ...shopData, currency: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {currencies.map((currency) => (
                      <SelectItem key={currency.code} value={currency.code}>
                        <div className="flex items-center">
                          <span className="mr-2">{currency.symbol}</span>
                          {currency.name}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-500">
                  This will be used for all sales transactions and reports.
                </p>
              </div>

              <Separator />

              {/* Timezone Setting */}
              <div className="space-y-2">
                <Label htmlFor="timezone" className="flex items-center gap-2">
                  <Globe className="h-4 w-4" />
                  Timezone
                </Label>
                <Input
                  id="timezone"
                  type="text"
                  value={shopData.timezone}
                  onChange={(e) => setShopData({ ...shopData, timezone: e.target.value })}
                  placeholder="Auto-detected"
                  className="bg-gray-50"
                />
                <p className="text-xs text-gray-500">
                  Used for scheduling reports and analytics.
                </p>
              </div>

              <Separator />

              {/* Report Time Setting */}
              <div className="space-y-2">
                <Label htmlFor="report-time" className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Daily Report Time
                </Label>
                <Select 
                  value={shopData.reportTime} 
                  onValueChange={(value) => setShopData({ ...shopData, reportTime: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="08:00">8:00 AM</SelectItem>
                    <SelectItem value="18:00">6:00 PM</SelectItem>
                    <SelectItem value="20:00">8:00 PM</SelectItem>
                    <SelectItem value="22:00">10:00 PM</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-500">
                  When AI-generated daily reports are sent.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Important Notes */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building className="h-5 w-5" />
              Important Notes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm text-gray-600">
              <div className="flex items-start gap-2">
                <span className="text-blue-600">•</span>
                <p><strong>Currency Changes:</strong> Changing currency will affect all future transactions and reports. Historical data will remain in their original currency.</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-blue-600">•</span>
                <p><strong>Pharmacy Category:</strong> If your business is a pharmacy, select "Pharmacy" as your category for specialized features and compliance settings.</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-blue-600">•</span>
                <p><strong>Report Timing:</strong> Daily AI reports will be generated and sent at your specified time. Choose a time when your shop is typically closed.</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-blue-600">•</span>
                <p><strong>Settings Access:</strong> Only shop owners can modify these settings. Team members can view but not edit business settings.</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}