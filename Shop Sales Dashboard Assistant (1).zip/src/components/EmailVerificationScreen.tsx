import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { 
  Mail, 
  RefreshCw, 
  CheckCircle, 
  AlertTriangle, 
  Send,
  LogOut,
  Clock,
  Shield
} from 'lucide-react';
import { auth } from '../lib/firebase';
import { sendEmailVerification, reload } from 'firebase/auth';
import { toast } from 'sonner';

interface EmailVerificationScreenProps {
  userEmail: string;
  onVerified: () => void;
  onSignOut: () => void;
}

export function EmailVerificationScreen({ 
  userEmail, 
  onVerified, 
  onSignOut 
}: EmailVerificationScreenProps) {
  const [isCheckingVerification, setIsCheckingVerification] = useState(false);
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const [lastEmailSent, setLastEmailSent] = useState<Date | null>(null);
  const [autoCheckInterval, setAutoCheckInterval] = useState<NodeJS.Timeout | null>(null);
  const [verificationAttempts, setVerificationAttempts] = useState(0);
  const [isRateLimited, setIsRateLimited] = useState(false);

  // Reduced auto-check frequency to prevent rate limiting (every 10 seconds instead of 3)
  useEffect(() => {
    const interval = setInterval(async () => {
      await checkVerificationStatus(false); // Silent check
    }, 10000); // Increased from 3 seconds to 10 seconds

    setAutoCheckInterval(interval);

    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, []);

  // Cleanup interval on unmount
  useEffect(() => {
    return () => {
      if (autoCheckInterval) {
        clearInterval(autoCheckInterval);
      }
    };
  }, [autoCheckInterval]);

  // Check for rate limiting on component mount
  useEffect(() => {
    const checkInitialRateLimit = () => {
      if (lastEmailSent) {
        const timeSinceLastEmail = Date.now() - lastEmailSent.getTime();
        if (timeSinceLastEmail < 300000) { // 5 minutes
          setIsRateLimited(true);
          setTimeout(() => setIsRateLimited(false), 300000 - timeSinceLastEmail);
        }
      }
    };

    checkInitialRateLimit();
  }, [lastEmailSent]);

  const checkVerificationStatus = async (showLoading = true) => {
    if (!auth.currentUser) return;

    if (showLoading) {
      setIsCheckingVerification(true);
    }

    try {
      // Reload user to get latest verification status
      await reload(auth.currentUser);
      
      if (auth.currentUser.emailVerified) {
        // Clear the auto-check interval
        if (autoCheckInterval) {
          clearInterval(autoCheckInterval);
          setAutoCheckInterval(null);
        }
        
        toast.success('✅ Email verified successfully!', {
          description: 'You can now access your pharmacy dashboard.'
        });
        
        onVerified();
      } else if (showLoading) {
        toast.info('Email not yet verified', {
          description: 'Please check your email and click the verification link.'
        });
      }
    } catch (error: any) {
      console.error('Error checking verification status:', error);
      
      if (error.code === 'auth/too-many-requests') {
        setIsRateLimited(true);
        toast.error('Rate limit exceeded', {
          description: 'Please wait a few minutes before checking again.'
        });
        
        // Set a 5-minute cooldown for rate limiting
        setTimeout(() => setIsRateLimited(false), 300000);
      } else if (showLoading) {
        toast.error('Failed to check verification status');
      }
    } finally {
      if (showLoading) {
        setIsCheckingVerification(false);
      }
    }
  };

  const handleResendVerification = async () => {
    if (!auth.currentUser) return;

    // Check if we're already rate limited
    if (isRateLimited) {
      toast.error('Please wait before resending', {
        description: 'You can resend verification email in a few minutes.'
      });
      return;
    }

    // Prevent too many attempts
    if (verificationAttempts >= 3) {
      toast.error('Too many attempts', {
        description: 'Please wait 15 minutes before trying again.'
      });
      setIsRateLimited(true);
      setTimeout(() => {
        setIsRateLimited(false);
        setVerificationAttempts(0);
      }, 900000); // 15 minutes
      return;
    }

    setIsSendingEmail(true);
    
    try {
      await sendEmailVerification(auth.currentUser);
      setLastEmailSent(new Date());
      setVerificationAttempts(prev => prev + 1);
      
      toast.success('📧 Verification email sent!', {
        description: 'Please check your email inbox and spam folder.'
      });

      // Set a temporary rate limit for 2 minutes after sending
      setIsRateLimited(true);
      setTimeout(() => setIsRateLimited(false), 120000); // 2 minutes
      
    } catch (error: any) {
      console.error('Error sending verification email:', error);
      
      if (error.code === 'auth/too-many-requests') {
        setIsRateLimited(true);
        toast.error('Too many requests', {
          description: 'Please wait at least 5 minutes before requesting another verification email.'
        });
        
        // Set a longer cooldown for rate limiting
        setTimeout(() => setIsRateLimited(false), 300000); // 5 minutes
      } else if (error.code === 'auth/requires-recent-login') {
        toast.error('Session expired', {
          description: 'Please sign in again to resend verification email.'
        });
      } else {
        toast.error('Failed to send verification email', {
          description: error.message || 'Please try again later.'
        });
      }
    } finally {
      setIsSendingEmail(false);
    }
  };

  const canResendEmail = () => {
    if (isRateLimited) return false;
    if (!lastEmailSent) return true;
    const timeDiff = Date.now() - lastEmailSent.getTime();
    return timeDiff > 120000; // 2 minute cooldown instead of 1 minute
  };

  const getRemainingTime = () => {
    if (!lastEmailSent) return 0;
    const timeDiff = Date.now() - lastEmailSent.getTime();
    return Math.max(0, 120 - Math.floor(timeDiff / 1000)); // 2 minutes
  };

  const getRateLimitMessage = () => {
    if (verificationAttempts >= 3) {
      return 'Maximum attempts reached. Please wait 15 minutes.';
    }
    return `${3 - verificationAttempts} attempts remaining.`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-white/90 backdrop-blur-sm shadow-xl">
        <CardHeader className="text-center space-y-4">
          <div className="mx-auto p-3 bg-blue-100 rounded-full w-fit">
            <Mail className="h-8 w-8 text-blue-600" />
          </div>
          <div>
            <CardTitle className="text-xl font-semibold text-gray-900">
              Verify Your Email Address
            </CardTitle>
            <p className="text-sm text-gray-600 mt-2">
              We've sent a verification link to your email address
            </p>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Email Address Display */}
          <div className="bg-gray-50 rounded-lg p-4 border">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white rounded-full">
                <Mail className="h-4 w-4 text-gray-600" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-gray-900">Email Address</p>
                <p className="text-sm text-gray-600 truncate">{userEmail}</p>
              </div>
            </div>
          </div>

          {/* Instructions */}
          <Alert className="bg-blue-50 border-blue-200">
            <Shield className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-800 text-sm">
              <strong>Security Verification Required:</strong>
              <br />
              1. Check your email inbox (and spam folder)
              <br />
              2. Click the verification link in the email
              <br />
              3. Return to this page - we'll detect verification automatically
            </AlertDescription>
          </Alert>

          {/* Rate Limiting Warning */}
          {(isRateLimited || verificationAttempts > 0) && (
            <Alert className="bg-yellow-50 border-yellow-200">
              <AlertTriangle className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-800 text-sm">
                <strong>Rate Limiting Active:</strong>
                <br />
                {getRateLimitMessage()}
              </AlertDescription>
            </Alert>
          )}

          {/* Auto-checking indicator - less aggressive */}
          <div className="flex items-center justify-center gap-2 text-sm text-gray-500">
            <Clock className="h-4 w-4" />
            <span>Checking every 10 seconds...</span>
            <div className="animate-spin rounded-full h-4 w-4 border-2 border-blue-600 border-t-transparent"></div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <Button
              onClick={() => checkVerificationStatus(true)}
              disabled={isCheckingVerification || isRateLimited}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              {isCheckingVerification ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Checking...
                </>
              ) : (
                <>
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Check Verification Status
                </>
              )}
            </Button>

            <Button
              onClick={handleResendVerification}
              disabled={isSendingEmail || !canResendEmail() || isRateLimited}
              variant="outline"
              className="w-full"
            >
              {isSendingEmail ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Sending...
                </>
              ) : isRateLimited ? (
                <>
                  <Clock className="h-4 w-4 mr-2" />
                  Rate Limited
                </>
              ) : !canResendEmail() ? (
                <>
                  <Clock className="h-4 w-4 mr-2" />
                  Resend in {getRemainingTime()}s
                </>
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Resend Verification Email
                </>
              )}
            </Button>
          </div>

          <Separator />

          {/* Troubleshooting */}
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-gray-900">Troubleshooting</h4>
            <div className="text-sm text-gray-600 space-y-2">
              <div className="flex items-start gap-2">
                <span className="text-blue-600 font-medium">•</span>
                <span>Check your spam/junk folder</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-blue-600 font-medium">•</span>
                <span>Verification emails may take a few minutes to arrive</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-blue-600 font-medium">•</span>
                <span>Make sure to click the link in the email from Firebase</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-blue-600 font-medium">•</span>
                <span>If rate limited, wait a few minutes before trying again</span>
              </div>
            </div>
          </div>

          {/* Rate Limiting Information */}
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
            <h4 className="text-sm font-medium text-amber-900 mb-2">Email Rate Limiting</h4>
            <div className="text-xs text-amber-800 space-y-1">
              <p>• Maximum 3 verification emails per session</p>
              <p>• 2-minute cooldown between sends</p>
              <p>• 5-minute timeout if rate limited</p>
            </div>
          </div>

          {/* Sign Out Option */}
          <div className="pt-4 border-t">
            <Button
              onClick={onSignOut}
              variant="ghost"
              className="w-full text-gray-600 hover:text-gray-800"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out and Use Different Account
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}