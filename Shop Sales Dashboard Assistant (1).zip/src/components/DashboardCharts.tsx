import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { formatTZS, formatCompactTZS } from '../lib/currency-utils';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell,
  ComposedChart,
  Area,
  AreaChart
} from 'recharts';

interface DashboardChartsProps {
  salesData: any[];
}

export function DashboardCharts({ salesData = [] }: DashboardChartsProps) {
  // Prepare data for charts
  const dailyData = salesData.map(item => ({
    date: new Date(item.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    sales: item.sales || 0,
    revenue: item.revenue || 0
  }));

  // Generate mock product data if no real data available (TZS amounts)
  const mockProductData = [
    { name: 'Coffee', quantity: 45, revenue: 180000 },
    { name: 'Sandwich', quantity: 32, revenue: 256000 },
    { name: 'Pastry', quantity: 28, revenue: 112000 },
    { name: 'Tea', quantity: 25, revenue: 75000 },
    { name: 'Salad', quantity: 18, revenue: 144000 }
  ];

  const productData = dailyData.length > 0 ? 
    // If we have real data, extract top products
    dailyData.slice(0, 5).map((item, index) => ({
      name: `Product ${index + 1}`,
      quantity: item.sales,
      revenue: item.revenue
    })) : 
    // Use mock data for demonstration
    mockProductData;

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

  // Weekly comparison data
  const weeklyData = dailyData.length > 7 ? 
    dailyData.slice(-14).map((item, index) => ({
      ...item,
      week: index < 7 ? 'Previous Week' : 'Current Week',
      day: index % 7
    })) : 
    dailyData;

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      {/* Sales Trend - Combined Chart */}
      <Card className="lg:col-span-2">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Sales Performance Trend</CardTitle>
            <div className="text-sm text-muted-foreground">
              Last {dailyData.length} days • TZS Currency
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            {dailyData.length > 0 ? (
              <ComposedChart data={dailyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis yAxisId="left" />
                <YAxis yAxisId="right" orientation="right" />
                <Tooltip 
                  formatter={(value, name) => [
                    name === 'revenue' ? formatTZS(Number(value)) : value,
                    name === 'revenue' ? 'Revenue (TZS)' : 'Sales Count'
                  ]}
                />
                <Area 
                  yAxisId="left" 
                  type="monotone" 
                  dataKey="sales" 
                  fill="#8884d8" 
                  fillOpacity={0.3}
                  stroke="#8884d8"
                  name="Sales Count"
                />
                <Line 
                  yAxisId="right" 
                  type="monotone" 
                  dataKey="revenue" 
                  stroke="#82ca9d" 
                  strokeWidth={3}
                  name="Revenue"
                  dot={{ fill: '#82ca9d', r: 4 }}
                />
              </ComposedChart>
            ) : (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <p className="text-gray-500">No sales data available</p>
                  <p className="text-sm text-gray-400">Start recording sales to see trends</p>
                </div>
              </div>
            )}
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Top Products Bar Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Top Products by Quantity</CardTitle>
          <p className="text-sm text-muted-foreground">
            Best performing products by units sold
          </p>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={productData} layout="horizontal">
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" />
              <YAxis dataKey="name" type="category" width={80} />
              <Tooltip formatter={(value) => [value, 'Quantity Sold']} />
              <Bar dataKey="quantity" fill="#8884d8" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Revenue Distribution Pie Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Revenue Distribution</CardTitle>
          <p className="text-sm text-muted-foreground">
            Revenue breakdown by product category (TZS)
          </p>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={productData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => 
                  percent > 5 ? `${name} ${(percent * 100).toFixed(0)}%` : ''
                }
                outerRadius={80}
                fill="#8884d8"
                dataKey="revenue"
              >
                {productData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [formatTZS(Number(value)), 'Revenue (TZS)']} />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Daily Revenue Trend */}
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle>Daily Revenue Analysis</CardTitle>
          <p className="text-sm text-muted-foreground">
            Revenue performance with AI-powered trend analysis (TZS)
          </p>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            {dailyData.length > 0 ? (
              <AreaChart data={dailyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip 
                  formatter={(value) => [formatTZS(Number(value)), 'Revenue (TZS)']}
                  labelFormatter={(label) => `Date: ${label}`}
                />
                <Area 
                  type="monotone" 
                  dataKey="revenue" 
                  stroke="#0088FE" 
                  fill="#0088FE" 
                  fillOpacity={0.6}
                />
              </AreaChart>
            ) : (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <p className="text-gray-500">No revenue data available</p>
                  <p className="text-sm text-gray-400">Complete some sales to view revenue trends</p>
                </div>
              </div>
            )}
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}