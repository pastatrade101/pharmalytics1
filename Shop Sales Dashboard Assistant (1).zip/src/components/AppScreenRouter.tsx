import React from 'react';
import { LoadingScreen } from './LoadingScreen';
import { AuthLayout } from './AuthLayout';
import { SuperAdminAuth } from './SuperAdminAuth';
import { EmailVerificationScreen } from './EmailVerificationScreen';
import { ShopActivationScreen } from './ShopActivationScreen';
import { ShopAssignmentScreen } from './ShopAssignmentScreen';
import { ViewRouter } from './ViewRouter';
import { DashboardLayout } from './DashboardLayout';
import { auth } from '../lib/firebase';
import { UserProfile as UserProfileType } from '../lib/firebase-types';
import { View, isSuperAdmin, canAccessView } from '../lib/app-constants';
import { toast } from 'sonner';

interface AppScreenRouterProps {
  // Auth state
  isAuthenticated: boolean | null;
  isLoading: boolean;
  emailVerified: boolean | null;
  authMode: 'regular' | 'super_admin';
  
  // User state
  userProfile: UserProfileType | null;
  shopActivated: boolean | null;
  
  // Current view
  currentView: View;
  setCurrentView: (view: View) => void;
  
  // AI system status
  aiSystemStatus: string;
  
  // Error state
  errorState: {
    permissionErrors: any[];
    indexErrors: any[];
    hasPermissionErrors: boolean;
    hasIndexErrors: boolean;
    hasNetworkErrors: boolean;
    hasValidationErrors: boolean;
    hasCriticalErrors: boolean;
    userActionableErrors: any[];
  };
  
  // Handlers
  onSignOut: () => void;
  onAuthSuccess: () => void;
  onSuperAdminAuthSuccess: () => void;
  onSwitchToSuperAdmin: () => void;
  onBackToRegular: () => void;
  onEmailVerified: () => void;
  onShopActivated: () => void;
  
  // Debug state
  showDebugPanel: boolean;
}

export function AppScreenRouter({
  isAuthenticated,
  isLoading,
  emailVerified,
  authMode,
  userProfile,
  shopActivated,
  currentView,
  setCurrentView,
  aiSystemStatus,
  errorState,
  onSignOut,
  onAuthSuccess,
  onSuperAdminAuthSuccess,
  onSwitchToSuperAdmin,
  onBackToRegular,
  onEmailVerified,
  onShopActivated,
  showDebugPanel
}: AppScreenRouterProps) {
  
  // Enhanced loading state with minimal system information
  if (isLoading || isAuthenticated === null) {
    return (
      <LoadingScreen 
        aiSystemStatus={aiSystemStatus} 
        errors={errorState.userActionableErrors}
        hasPermissionErrors={errorState.hasPermissionErrors}
        permissionErrorsCount={errorState.permissionErrors.length}
      />
    );
  }

  // Not authenticated - show appropriate auth form
  if (!isAuthenticated) {
    if (authMode === 'super_admin') {
      return (
        <SuperAdminAuth
          onAuthSuccess={onSuperAdminAuthSuccess}
          onBackToRegular={onBackToRegular}
        />
      );
    }

    return (
      <AuthLayout 
        aiSystemStatus={aiSystemStatus}
        errors={errorState.userActionableErrors}
        userProfile={userProfile}
        hasPermissionErrors={errorState.hasPermissionErrors}
        permissionErrorsCount={errorState.permissionErrors.length}
        onAuthSuccess={onAuthSuccess}
        // REMOVED: onSwitchToSuperAdmin prop to hide super admin creation UI
        // onSwitchToSuperAdmin={onSwitchToSuperAdmin}
      />
    );
  }

  // Authenticated but email not verified (super admins bypass verification)
  if (emailVerified === false && auth.currentUser && (!userProfile || !isSuperAdmin(userProfile.role))) {
    return (
      <EmailVerificationScreen
        userEmail={auth.currentUser.email || 'Unknown'}
        onVerified={onEmailVerified}
        onSignOut={onSignOut}
      />
    );
  }

  // Check if user is super admin - they get a different dashboard and bypass shop checks and email verification
  if (userProfile && isSuperAdmin(userProfile.role)) {
    console.log('🛡️ Super admin user detected, bypassing email verification and loading super admin dashboard');
    if (!emailVerified) {
      console.log('📧 Super admin bypassing email verification requirement');
    }
    return (
      <DashboardLayout
        currentView={currentView}
        userProfile={userProfile}
        aiSystemStatus={aiSystemStatus}
        hasPermissionErrors={errorState.hasPermissionErrors}
        hasIndexErrors={errorState.hasIndexErrors}
        onNavigate={setCurrentView}
        onSignOut={onSignOut}
      >
        <ViewRouter 
          currentView={currentView}
          userProfile={userProfile}
          aiSystemStatus={aiSystemStatus}
          errors={errorState.userActionableErrors}
          hasPermissionErrors={errorState.hasPermissionErrors}
          hasIndexErrors={errorState.hasIndexErrors}
          hasNetworkErrors={errorState.hasNetworkErrors}
          hasValidationErrors={errorState.hasValidationErrors}
          hasErrors={() => errorState.userActionableErrors.length > 0}
          permissionErrorsLength={errorState.permissionErrors.length}
          hasCriticalErrors={errorState.hasCriticalErrors}
          showDebugPanel={showDebugPanel}
          onSetCurrentView={setCurrentView}
          onSignOut={onSignOut}
        />
      </DashboardLayout>
    );
  }

  // Handle case where non-super admin users try to access super admin views
  if (userProfile && !canAccessView(userProfile.role, currentView)) {
    
    // Log the security violation
    console.warn(`🚫 Access denied: User with role '${userProfile.role}' attempted to access restricted view '${currentView}'`);
    
    // Reset to home view immediately without showing error in UI
    setCurrentView('home');
    
    // Show a clean toast notification for better UX
    toast.error('Access Denied', {
      description: 'You don\'t have permission to access that area. Redirected to dashboard.',
      duration: 5000
    });
    
    // Don't add to error context - this is handled gracefully
    return null;
  }

  // Check shop activation status for non-admin users
  if (userProfile && !['admin', 'super_admin'].includes(userProfile.role) && shopActivated === false) {
    return (
      <ShopActivationScreen
        userProfile={userProfile}
        onSignOut={onSignOut}
        onShopActivated={onShopActivated}
      />
    );
  }

  // FIXED: Admin users don't need pharmacy assignment - they can manage any pharmacy
  // Check if user account exists but has no pharmacy assignment
  // Only non-privileged roles (not admin, super_admin) need a pharmacy assignment
  if (userProfile && !['admin', 'super_admin'].includes(userProfile.role) && !userProfile.shop_id) {
    // If this is an owner without a shop_id, they need to complete setup
    // This handles edge cases where shop creation failed during registration
    if (userProfile.role === 'owner') {
      return (
        <ShopAssignmentScreen 
          userProfile={userProfile}
          errors={errorState.userActionableErrors}
          hasPermissionErrors={errorState.hasPermissionErrors}
          hasIndexErrors={errorState.hasIndexErrors}
          permissionErrorsLength={errorState.permissionErrors.length}
          onSignOut={onSignOut}
        />
      );
    }
    
    // For all other non-privileged roles, they need to be assigned by their pharmacy owner
    return (
      <ShopAssignmentScreen 
        userProfile={userProfile}
        errors={errorState.userActionableErrors}
        hasPermissionErrors={errorState.hasPermissionErrors}
        hasIndexErrors={errorState.hasIndexErrors}
        permissionErrorsLength={errorState.permissionErrors.length}
        onSignOut={onSignOut}
      />
    );
  }

  // Regular authenticated user (including admin) with proper access - show dashboard with persistent sidebar
  return (
    <DashboardLayout
      currentView={currentView}
      userProfile={userProfile}
      aiSystemStatus={aiSystemStatus}
      hasPermissionErrors={errorState.hasPermissionErrors}
      hasIndexErrors={errorState.hasIndexErrors}
      onNavigate={setCurrentView}
      onSignOut={onSignOut}
    >
      <ViewRouter 
        currentView={currentView}
        userProfile={userProfile}
        aiSystemStatus={aiSystemStatus}
        errors={errorState.userActionableErrors}
        hasPermissionErrors={errorState.hasPermissionErrors}
        hasIndexErrors={errorState.hasIndexErrors}
        hasNetworkErrors={errorState.hasNetworkErrors}
        hasValidationErrors={errorState.hasValidationErrors}
        hasErrors={() => errorState.userActionableErrors.length > 0}
        permissionErrorsLength={errorState.permissionErrors.length}
        hasCriticalErrors={errorState.hasCriticalErrors}
        showDebugPanel={showDebugPanel}
        onSetCurrentView={setCurrentView}
        onSignOut={onSignOut}
      />
    </DashboardLayout>
  );
}