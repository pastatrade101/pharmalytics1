import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { 
  AlertTriangle, 
  Shield, 
  Copy, 
  ExternalLink, 
  Clock,
  Zap,
  CheckCircle2,
  X
} from 'lucide-react';

interface EmergencyFixBannerProps {
  hasPermissionErrors: boolean;
  errorCount: number;
  onDismiss?: () => void;
}

export function EmergencyFixBanner({ hasPermissionErrors, errorCount, onDismiss }: EmergencyFixBannerProps) {
  const [step, setStep] = useState<'urgent' | 'rules' | 'deployed'>('urgent');
  const [isDismissed, setIsDismissed] = useState(false);

  const completeRules = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users can read and write their own profile
    match /profiles/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Allow authenticated users to create and read shops
    match /shops/{shopId} {
      allow read, write: if request.auth != null;
    }
    
    // Allow authenticated users to create and read sales
    match /sales/{saleId} {
      allow read, write: if request.auth != null;
    }
    
    // Allow authenticated users to create and read reports
    match /daily_reports/{reportId} {
      allow read, write: if request.auth != null;
    }
    
    // ⭐ THIS FIXES YOUR PRODUCT ERRORS
    match /products/{productId} {
      allow read, write: if request.auth != null;
    }
  }
}`;

  const copyRules = () => {
    navigator.clipboard.writeText(completeRules).then(() => {
      alert('✅ Complete rules copied! Now paste them in Firebase Console → Firestore → Rules tab and click "Publish"');
      setStep('deployed');
    });
  };

  const openFirebaseConsole = () => {
    window.open('https://console.firebase.google.com', '_blank');
  };

  const handleDismiss = () => {
    setIsDismissed(true);
    onDismiss?.();
  };

  if (!hasPermissionErrors || isDismissed) {
    return null;
  }

  return (
    <div className="fixed top-0 left-0 right-0 z-50 bg-red-600 shadow-xl">
      <div className="container mx-auto p-4">
        <Card className="bg-white border-4 border-red-500 shadow-2xl">
          <CardHeader className="bg-red-50 pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-8 w-8 text-red-600 animate-pulse" />
                  <div>
                    <CardTitle className="text-red-900 text-xl">
                      🚨 SHOP BLOCKED - IMMEDIATE ACTION REQUIRED
                    </CardTitle>
                    <p className="text-red-700 text-sm mt-1">
                      Your Shop Sales Dashboard cannot function until Firebase rules are deployed
                    </p>
                  </div>
                </div>
                <Badge variant="destructive" className="bg-red-600 text-white px-3 py-1">
                  {errorCount} PERMISSION ERRORS
                </Badge>
              </div>
              <Button onClick={handleDismiss} variant="ghost" size="sm" className="text-red-600">
                <X className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>

          <CardContent className="p-6">
            {step === 'urgent' && (
              <div className="space-y-6">
                <Alert className="bg-red-100 border-red-300">
                  <AlertTriangle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-800">
                    <strong>CRITICAL ERROR:</strong> Firebase security rules are missing from your project console. 
                    All product management, sales recording, and analytics are blocked until this is fixed.
                  </AlertDescription>
                </Alert>

                <div className="bg-blue-50 border-2 border-blue-300 rounded-lg p-4">
                  <h4 className="font-bold text-blue-900 mb-3 flex items-center">
                    <Clock className="h-5 w-5 mr-2" />
                    QUICK FIX AVAILABLE (3 Minutes Total)
                  </h4>
                  <div className="grid md:grid-cols-3 gap-4 text-sm">
                    <div className="text-center p-3 bg-blue-100 rounded">
                      <div className="font-semibold text-blue-900">Step 1: Copy Rules</div>
                      <div className="text-blue-700">30 seconds</div>
                    </div>
                    <div className="text-center p-3 bg-blue-100 rounded">
                      <div className="font-semibold text-blue-900">Step 2: Deploy</div>
                      <div className="text-blue-700">2 minutes</div>
                    </div>
                    <div className="text-center p-3 bg-green-100 rounded">
                      <div className="font-semibold text-green-900">Step 3: Works!</div>
                      <div className="text-green-700">Instant</div>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button 
                    onClick={() => setStep('rules')} 
                    className="flex-1 bg-red-600 hover:bg-red-700 text-white py-6 text-lg"
                  >
                    <Zap className="mr-2 h-5 w-5" />
                    🚀 FIX NOW - DEPLOY RULES
                  </Button>
                  <Button 
                    onClick={openFirebaseConsole} 
                    variant="outline" 
                    className="border-red-300 text-red-700 py-6"
                  >
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Open Firebase Console
                  </Button>
                </div>
              </div>
            )}

            {step === 'rules' && (
              <div className="space-y-6">
                <div className="bg-green-50 border-2 border-green-300 rounded-lg p-4">
                  <h4 className="font-bold text-green-900 mb-3">
                    ✅ SOLUTION: Complete Firestore Rules (Including Missing Products Rule)
                  </h4>
                  <p className="text-green-800 text-sm mb-3">
                    Your current rules were missing the <code className="bg-green-200 px-1 rounded">products</code> collection rule. 
                    Copy these complete rules to fix all permission errors:
                  </p>
                </div>

                <div className="bg-gray-100 border rounded-lg">
                  <div className="flex items-center justify-between p-3 border-b bg-gray-50 rounded-t-lg">
                    <span className="text-sm font-medium text-gray-700">
                      Complete Firestore Rules (Copy All)
                    </span>
                    <Button onClick={copyRules} size="sm" className="bg-green-600 hover:bg-green-700">
                      <Copy className="mr-1 h-3 w-3" />
                      📋 Copy Complete Rules
                    </Button>
                  </div>
                  <pre className="p-4 text-xs overflow-auto max-h-64 bg-white text-gray-800 font-mono">
                    {completeRules}
                  </pre>
                </div>

                <Alert className="bg-yellow-50 border-yellow-300">
                  <AlertTriangle className="h-4 w-4 text-yellow-600" />
                  <AlertDescription className="text-yellow-800">
                    <strong>⚠️ What was missing:</strong> The <code>products</code> collection rule was not in your Firebase Console, 
                    causing all "permission-denied" errors when adding products.
                  </AlertDescription>
                </Alert>

                <div className="bg-blue-50 border border-blue-300 rounded-lg p-4">
                  <h5 className="font-semibold text-blue-900 mb-3">📋 Deployment Steps:</h5>
                  <ol className="text-blue-800 text-sm space-y-2 list-decimal list-inside">
                    <li>Open <strong>Firebase Console</strong> (button opens it)</li>
                    <li>Select your <code className="bg-blue-100 px-1 rounded">shopsalesai</code> project</li>
                    <li>Go to <strong>Firestore Database → Rules</strong> tab</li>
                    <li><strong>Delete all existing rules</strong></li>
                    <li><strong>Paste the complete rules above</strong></li>
                    <li>Click <strong>"Publish"</strong> button</li>
                    <li><strong>Wait 30 seconds</strong> for deployment</li>
                    <li><strong>Refresh your app</strong> - errors gone!</li>
                  </ol>
                </div>

                <div className="flex gap-3">
                  <Button onClick={openFirebaseConsole} className="flex-1 bg-blue-600 hover:bg-blue-700">
                    <ExternalLink className="mr-2 h-4 w-4" />
                    🔥 Open Firebase Console
                  </Button>
                  <Button onClick={copyRules} variant="outline" className="border-green-300 text-green-700">
                    📋 Copy Rules Again
                  </Button>
                </div>
              </div>
            )}

            {step === 'deployed' && (
              <div className="space-y-6">
                <div className="bg-green-50 border-2 border-green-300 rounded-lg p-6 text-center">
                  <CheckCircle2 className="h-12 w-12 text-green-600 mx-auto mb-4" />
                  <h4 className="font-bold text-green-900 text-lg mb-2">
                    🎉 Rules Copied Successfully!
                  </h4>
                  <p className="text-green-800 mb-4">
                    Now paste them in Firebase Console and click "Publish" to fix all permission errors.
                  </p>
                  <div className="flex gap-3 justify-center">
                    <Button onClick={openFirebaseConsole} className="bg-green-600 hover:bg-green-700">
                      <ExternalLink className="mr-2 h-4 w-4" />
                      Complete Deployment in Console
                    </Button>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-300 rounded-lg p-4">
                  <h5 className="font-semibold text-blue-900 mb-2">🔍 After Deployment:</h5>
                  <div className="grid grid-cols-2 gap-2 text-blue-800 text-sm">
                    <div>✅ Product management works</div>
                    <div>✅ Sales recording enabled</div>
                    <div>✅ Owner dashboard accessible</div>
                    <div>✅ Analytics load properly</div>
                    <div>✅ No permission errors</div>
                    <div>✅ All features unlocked</div>
                  </div>
                </div>

                <Alert className="bg-amber-50 border-amber-300">
                  <AlertTriangle className="h-4 w-4 text-amber-600" />
                  <AlertDescription className="text-amber-800 text-sm">
                    <strong>Security Note:</strong> These rules allow basic functionality but aren't production-secure. 
                    For role-based security, deploy production rules from <code>FIRESTORE_RULES_DEPLOYMENT_GUIDE.md</code> after testing.
                  </AlertDescription>
                </Alert>
              </div>
            )}

            <div className="mt-6 text-center">
              <p className="text-xs text-gray-600">
                <strong>Your app is completely blocked until these rules are deployed.</strong><br />
                This is the fastest way to get your Shop Sales Dashboard working again.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}