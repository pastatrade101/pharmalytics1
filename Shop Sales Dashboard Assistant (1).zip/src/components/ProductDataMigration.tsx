import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';
import { 
  AlertTriangle, 
  CheckCircle, 
  Loader2, 
  Eye, 
  Wrench, 
  Package,
  DollarSign,
  BarChart3,
  ShoppingCart
} from 'lucide-react';
import { ProductMigrationService } from '../lib/firebase-products-migration';
import { formatTZS } from '../lib/currency-utils';
import { toast } from 'sonner';

interface ProductDataMigrationProps {
  shopId: string;
  onMigrationComplete?: () => void;
}

interface ProductIssue {
  id: string;
  name: string;
  issues: string[];
  updates: Record<string, any>;
}

export function ProductDataMigration({ shopId, onMigrationComplete }: ProductDataMigrationProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [isPreviewing, setIsPreviewing] = useState(false);
  const [isFixing, setIsFixing] = useState(false);
  const [preview, setPreview] = useState<ProductIssue[]>([]);
  const [migrationComplete, setMigrationComplete] = useState(false);

  const handlePreview = async () => {
    setIsPreviewing(true);
    try {
      const previewData = await ProductMigrationService.previewProductFixes(shopId);
      setPreview(previewData);
      
      if (previewData.length === 0) {
        toast.success('All products have valid pricing data!');
      } else {
        toast.info(`Found ${previewData.length} products that need fixes`);
      }
    } catch (error: any) {
      console.error('Preview failed:', error);
      toast.error('Failed to preview product fixes');
    } finally {
      setIsPreviewing(false);
    }
  };

  const handleFixProducts = async () => {
    setIsFixing(true);
    try {
      await ProductMigrationService.fixShopProductPricing(shopId);
      setMigrationComplete(true);
      toast.success('Product pricing migration completed successfully!');
      
      if (onMigrationComplete) {
        onMigrationComplete();
      }
    } catch (error: any) {
      console.error('Migration failed:', error);
      toast.error('Failed to fix product pricing');
    } finally {
      setIsFixing(false);
    }
  };

  const getIssueIcon = (issue: string) => {
    if (issue.includes('price')) return <DollarSign className="h-4 w-4" />;
    if (issue.includes('stock')) return <Package className="h-4 w-4" />;
    if (issue.includes('markup')) return <BarChart3 className="h-4 w-4" />;
    if (issue.includes('insurance')) return <ShoppingCart className="h-4 w-4" />;
    return <AlertTriangle className="h-4 w-4" />;
  };

  const getIssueVariant = (issue: string): "default" | "secondary" | "destructive" | "outline" => {
    if (issue.includes('Invalid')) return 'destructive';
    if (issue.includes('Missing')) return 'secondary';
    return 'default';
  };

  if (migrationComplete) {
    return (
      <Card className="border-green-200 bg-green-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-800">
            <CheckCircle className="h-5 w-5" />
            Migration Complete
          </CardTitle>
          <CardDescription className="text-green-700">
            All product pricing data has been successfully updated. Your POS system should now display correct prices.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button 
            onClick={() => window.location.reload()} 
            className="bg-green-600 hover:bg-green-700"
          >
            Refresh Application
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Wrench className="h-5 w-5" />
            Product Data Migration
          </CardTitle>
          <CardDescription>
            Fix products with missing or invalid pricing data. This will set reasonable default prices
            for pharmaceutical products based on industry standards.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-amber-200 bg-amber-50">
            <AlertTriangle className="h-4 w-4 text-amber-600" />
            <AlertTitle className="text-amber-800">Important</AlertTitle>
            <AlertDescription className="text-amber-700">
              This tool will update products with missing or invalid prices. Review the preview before applying changes.
              Default prices are set based on common pharmaceutical pricing in Tanzania (TZS).
            </AlertDescription>
          </Alert>

          <div className="flex gap-3">
            <Button 
              onClick={handlePreview}
              disabled={isPreviewing || isFixing}
              variant="outline"
              className="flex items-center gap-2"
            >
              {isPreviewing ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Eye className="h-4 w-4" />
              )}
              Preview Issues
            </Button>

            {preview.length > 0 && (
              <Button 
                onClick={handleFixProducts}
                disabled={isFixing || isPreviewing}
                className="flex items-center gap-2"
              >
                {isFixing ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Wrench className="h-4 w-4" />
                )}
                Fix {preview.length} Products
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {preview.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Products Needing Fixes ({preview.length})
            </CardTitle>
            <CardDescription>
              Review the issues and proposed fixes for each product
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96">
              <div className="space-y-4">
                {preview.map((product, index) => (
                  <div key={product.id} className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <h4 className="font-medium">{product.name}</h4>
                        <div className="flex flex-wrap gap-2">
                          {product.issues.map((issue, issueIndex) => (
                            <Badge 
                              key={issueIndex} 
                              variant={getIssueVariant(issue)}
                              className="text-xs flex items-center gap-1"
                            >
                              {getIssueIcon(issue)}
                              {issue}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 text-sm">
                      {product.updates.retail_price && (
                        <div className="bg-green-50 p-2 rounded border border-green-200">
                          <div className="font-medium text-green-800">Retail Price</div>
                          <div className="text-green-700">
                            {formatTZS(product.updates.retail_price)}
                          </div>
                        </div>
                      )}
                      
                      {product.updates.cost_price && (
                        <div className="bg-blue-50 p-2 rounded border border-blue-200">
                          <div className="font-medium text-blue-800">Cost Price</div>
                          <div className="text-blue-700">
                            {formatTZS(product.updates.cost_price)}
                          </div>
                        </div>
                      )}
                      
                      {product.updates.insurance_price && (
                        <div className="bg-purple-50 p-2 rounded border border-purple-200">
                          <div className="font-medium text-purple-800">Insurance Price</div>
                          <div className="text-purple-700">
                            {formatTZS(product.updates.insurance_price)}
                          </div>
                        </div>
                      )}
                      
                      {product.updates.markup_percentage && (
                        <div className="bg-orange-50 p-2 rounded border border-orange-200">
                          <div className="font-medium text-orange-800">Markup</div>
                          <div className="text-orange-700">
                            {product.updates.markup_percentage}%
                          </div>
                        </div>
                      )}
                      
                      {product.updates.stock_quantity && (
                        <div className="bg-gray-50 p-2 rounded border border-gray-200">
                          <div className="font-medium text-gray-800">Stock</div>
                          <div className="text-gray-700">
                            {product.updates.stock_quantity} units
                          </div>
                        </div>
                      )}
                      
                      {product.updates.min_stock_level && (
                        <div className="bg-yellow-50 p-2 rounded border border-yellow-200">
                          <div className="font-medium text-yellow-800">Min Stock</div>
                          <div className="text-yellow-700">
                            {product.updates.min_stock_level} units
                          </div>
                        </div>
                      )}
                    </div>

                    {index < preview.length - 1 && <Separator />}
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  );
}