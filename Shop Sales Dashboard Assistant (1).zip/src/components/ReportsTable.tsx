import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Download, Eye, Mail, MessageSquare, Brain, Calendar, TrendingUp } from 'lucide-react';
import { DailyReport } from '../lib/firebase';
import { formatTZS } from '../lib/currency-utils';
import { toast } from 'sonner@2.0.3';

interface ReportsTableProps {
  reports: DailyReport[];
}

export function ReportsTable({ reports = [] }: ReportsTableProps) {
  const handleAction = (action: string, report: DailyReport) => {
    switch (action) {
      case 'view':
        toast.info(`Viewing report for ${report.date}`, {
          description: `${report.total_sales} sales, ${formatTZS(report.total_revenue)} revenue`
        });
        break;
      case 'download':
        toast.info('Downloading report...', {
          description: 'PDF report will be generated and downloaded'
        });
        break;
      case 'email':
        toast.info('Sending email...', {
          description: 'Report will be sent to configured email addresses'
        });
        break;
      case 'whatsapp':
        toast.info('Sending WhatsApp notification...', {
          description: 'Report summary will be sent via WhatsApp Business API'
        });
        break;
      default:
        break;
    }
  };

  const getStatusBadgeVariant = (report: DailyReport) => {
    if (report.total_sales === 0) return 'destructive';
    if (report.total_revenue > 500000) return 'default'; // 500,000 TZS
    return 'secondary';
  };

  const getStatusText = (report: DailyReport) => {
    if (report.total_sales === 0) return 'No Sales';
    if (report.total_revenue > 500000) return 'Excellent'; // 500,000 TZS
    if (report.total_revenue > 200000) return 'Good'; // 200,000 TZS
    return 'Fair';
  };

  const getTrendIcon = (report: DailyReport) => {
    const trend = report.trends?.salesTrend || 'stable';
    switch (trend) {
      case 'increasing':
        return <TrendingUp className="h-3 w-3 text-green-600" />;
      case 'decreasing':
        return <TrendingUp className="h-3 w-3 text-red-600 rotate-180" />;
      default:
        return <TrendingUp className="h-3 w-3 text-gray-400" />;
    }
  };

  if (reports.length === 0) {
    return (
      <div className="text-center py-8">
        <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-500 mb-2">No reports available yet</p>
        <p className="text-sm text-gray-400">Generate your first AI-powered daily report to see it here</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Brain className="h-5 w-5 text-blue-600" />
          <span className="text-sm font-medium">AI-Generated Reports</span>
          <Badge variant="secondary" className="text-xs">
            {reports.length} reports
          </Badge>
        </div>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Date & Trend</TableHead>
            <TableHead>Sales Metrics</TableHead>
            <TableHead>Revenue (TZS)</TableHead>
            <TableHead>Top Product</TableHead>
            <TableHead>AI Insights</TableHead>
            <TableHead>Performance</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {reports.map((report) => (
            <TableRow key={report.id} className="hover:bg-gray-50">
              <TableCell>
                <div className="flex items-center gap-2">
                  <div>
                    <div className="font-medium">
                      {new Date(report.date).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                      })}
                    </div>
                    <div className="text-sm text-muted-foreground flex items-center gap-1">
                      {getTrendIcon(report)}
                      {report.trends?.salesTrend || 'stable'}
                    </div>
                  </div>
                </div>
              </TableCell>
              
              <TableCell>
                <div>
                  <Badge variant="secondary" className="mb-1">
                    {report.total_sales} sales
                  </Badge>
                  <div className="text-sm text-muted-foreground">
                    Avg: {formatTZS(report.average_transaction)}
                  </div>
                </div>
              </TableCell>
              
              <TableCell>
                <div className="font-medium text-lg">
                  {formatTZS(report.total_revenue)}
                </div>
                <div className="text-sm text-muted-foreground">
                  {report.trends?.peakHours || 'N/A'}
                </div>
              </TableCell>
              
              <TableCell>
                <div className="font-medium">
                  {report.top_selling_item || 'No sales'}
                </div>
                <div className="text-sm text-muted-foreground">
                  Best performer
                </div>
              </TableCell>
              
              <TableCell>
                <div className="space-y-1">
                  <div className="text-sm">
                    {report.insights?.length || 0} insights
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {report.recommendations?.length || 0} recommendations
                  </div>
                  {report.alerts && report.alerts.length > 0 && (
                    <Badge variant="destructive" className="text-xs">
                      {report.alerts.length} alerts
                    </Badge>
                  )}
                </div>
              </TableCell>
              
              <TableCell>
                <Badge variant={getStatusBadgeVariant(report)}>
                  {getStatusText(report)}
                </Badge>
              </TableCell>
              
              <TableCell>
                <div className="flex gap-1">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => handleAction('view', report)}
                    title="View detailed report"
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => handleAction('download', report)}
                    title="Download PDF report"
                  >
                    <Download className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => handleAction('email', report)}
                    title="Send via email"
                  >
                    <Mail className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => handleAction('whatsapp', report)}
                    title="Send WhatsApp notification"
                  >
                    <MessageSquare className="h-4 w-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      
      <div className="text-center text-sm text-muted-foreground">
        Showing {reports.length} AI-generated reports • All amounts in TZS • Powered by Google Gemini
      </div>
    </div>
  );
}