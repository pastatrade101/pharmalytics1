import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Navigation } from './Navigation';
import { DebugPanel } from './DebugPanel';
import { ErrorDisplay } from './ErrorDisplay';
import { QuotaManagementPanel } from './QuotaManagementPanel';
import { CriticalFirebaseRulesModal } from './CriticalFirebaseRulesModal';
import { FileImportDialog } from './FileImportDialog';
import { 
  TrendingUp, 
  Package, 
  Users, 
  DollarSign, 
  ShoppingCart, 
  AlertTriangle,
  Plus,
  BarChart3,
  Calendar,
  FileText,
  Activity,
  Clock,
  ChevronRight,
  Download,
  Upload,
  Database,
  Brain
} from 'lucide-react';
import { UserProfile, FirebaseService, SalesService } from '../lib/firebase';
import { AIConnectionStatus } from '../hooks/useAIConnection';
import { View, QUICK_ACTIONS, ROLE_PERMISSIONS } from '../lib/app-constants';
import { formatTZS } from '../lib/currency-utils';
import { toast } from 'sonner';

interface MainDashboardProps {
  aiSystemStatus: AIConnectionStatus;
  userProfile: UserProfile | null;
  errors: any[];
  hasPermissionErrors: boolean;
  hasIndexErrors: boolean;
  hasNetworkErrors: boolean;
  hasValidationErrors: boolean;
  hasCriticalErrors: boolean;
  hasErrors: () => boolean;
  permissionErrorsLength: number;
  showDebugPanel: boolean;
  criticalErrorModalOpen: boolean;
  onSetCurrentView: (view: View) => void;
  onSignOut: () => void;
  onToggleDebugPanel: () => void;
  onCloseCriticalErrorModal: () => void;
}

// Icon mapping to convert string names to React components
const IconMap = {
  Plus,
  Package,
  BarChart3,
  Users,
  TrendingUp,
  DollarSign,
  ShoppingCart,
  AlertTriangle,
  Calendar,
  FileText,
  Activity,
  Clock,
  ChevronRight,
  Download,
  Upload,
  Database
} as const;

export function MainDashboard({
  aiSystemStatus,
  userProfile,
  errors,
  hasPermissionErrors,
  hasIndexErrors,
  hasNetworkErrors,
  hasValidationErrors,
  hasCriticalErrors,
  hasErrors,
  permissionErrorsLength,
  showDebugPanel,
  criticalErrorModalOpen,
  onSetCurrentView,
  onSignOut,
  onToggleDebugPanel,
  onCloseCriticalErrorModal
}: MainDashboardProps) {
  const [dashboardData, setDashboardData] = useState({
    totalSales: 0,
    totalTransactions: 0,
    totalProducts: 0,
    lowStockItems: 0,
    expiringSoon: 0,
    salesThisMonth: 0,
    recentTransactions: [],
    loading: true
  });
  
  const [showImportDialog, setShowImportDialog] = useState(false);

  // Load real dashboard data from Firebase
  const loadDashboardData = useCallback(async () => {
    if (!userProfile?.shop_id) {
      console.log('⚠️ No shop ID available for dashboard data');
      setDashboardData(prev => ({ ...prev, loading: false }));
      return;
    }

    try {
      console.log('📊 Loading dashboard data for shop:', userProfile.shop_id);
      setDashboardData(prev => ({ ...prev, loading: true }));

      const shopId = userProfile.shop_id;
      
      // Get current date ranges
      const now = new Date();
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);
      const startOfYear = new Date(now.getFullYear(), 0, 1);
      
      // Load data in parallel
      const [
        allSales,
        monthSales,
        products,
        lowStockProducts,
        expiringProducts
      ] = await Promise.all([
        // Get all sales for total calculations - FIXED: use getSalesByShop
        SalesService.getSalesByShop(shopId, 200).catch(error => {
          console.warn('⚠️ Error loading all sales:', error);
          return [];
        }),
        
        // Get this month's sales - FIXED: use getSalesByShop with date range
        SalesService.getSalesByShop(shopId, 100, {
          start: startOfMonth.toISOString(),
          end: endOfMonth.toISOString()
        }).catch(error => {
          console.warn('⚠️ Error loading month sales:', error);
          return [];
        }),
        
        // Get all products
        FirebaseService.getProducts(shopId).catch(error => {
          console.warn('⚠️ Error loading products:', error);
          return [];
        }),
        
        // Get low stock products
        FirebaseService.getLowStockProducts(shopId).catch(error => {
          console.warn('⚠️ Error loading low stock products:', error);
          return [];
        }),
        
        // Get expiring products (next 30 days)
        FirebaseService.getExpiringProducts(shopId, 30).catch(error => {
          console.warn('⚠️ Error loading expiring products:', error);
          return [];
        })
      ]);

      // Calculate metrics
      const totalSales = allSales.reduce((sum, sale) => sum + (parseFloat(sale.total_price?.toString() || '0')), 0);
      const totalTransactions = allSales.length;
      const salesThisMonth = monthSales.reduce((sum, sale) => sum + (parseFloat(sale.total_price?.toString() || '0')), 0);
      
      // Get recent transactions (last 10)
      const recentTransactions = allSales
        .slice(0, 10)
        .map((sale, index) => ({
          id: sale.id || index,
          customer: sale.customer_name || 'Walk-in Customer',
          amount: parseFloat(sale.total_price?.toString() || '0'),
          time: formatTimeAgo(sale.timestamp || sale.created_at)
        }));

      const newDashboardData = {
        totalSales,
        totalTransactions,
        totalProducts: products.length,
        lowStockItems: lowStockProducts.length,
        expiringSoon: expiringProducts.length,
        salesThisMonth,
        recentTransactions,
        loading: false
      };

      setDashboardData(newDashboardData);
      
      console.log('✅ Dashboard data loaded successfully:', {
        totalSales: formatTZS(totalSales),
        totalTransactions,
        totalProducts: products.length,
        lowStockItems: lowStockProducts.length,
        expiringSoon: expiringProducts.length,
        salesThisMonth: formatTZS(salesThisMonth)
      });

    } catch (error: any) {
      console.error('❌ Error loading dashboard data:', error);
      
      // Set fallback data for display
      setDashboardData({
        totalSales: 0,
        totalTransactions: 0,
        totalProducts: 0,
        lowStockItems: 0,
        expiringSoon: 0,
        salesThisMonth: 0,
        recentTransactions: [],
        loading: false
      });
      
      // Only show error toast for permission issues
      if (error?.code === 'permission-denied') {
        toast.warning('📊 Dashboard Data Unavailable', {
          description: 'Firebase rules need to be deployed to load real pharmacy data.',
          duration: 5000
        });
      }
    }
  }, [userProfile?.shop_id]);

  // Helper function to format time ago
  const formatTimeAgo = (timestamp: string) => {
    try {
      const now = new Date();
      const saleTime = new Date(timestamp);
      const diffInMinutes = Math.floor((now.getTime() - saleTime.getTime()) / (1000 * 60));
      
      if (diffInMinutes < 60) {
        return `${diffInMinutes} minutes ago`;
      } else if (diffInMinutes < 1440) {
        const hours = Math.floor(diffInMinutes / 60);
        return `${hours} ${hours === 1 ? 'hour' : 'hours'} ago`;
      } else {
        const days = Math.floor(diffInMinutes / 1440);
        return `${days} ${days === 1 ? 'day' : 'days'} ago`;
      }
    } catch (error) {
      return 'Recently';
    }
  };

  // Load data when component mounts or user profile changes
  useEffect(() => {
    loadDashboardData();
  }, [loadDashboardData]);

  const userPermissions = userProfile?.role ? ROLE_PERMISSIONS[userProfile.role] : null;

  // Filter quick actions based on user role
  const availableQuickActions = QUICK_ACTIONS.filter(action => 
    action.roles.includes(userProfile?.role || '')
  );

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  const handleQuickAction = (actionId: string) => {
    console.log(`🚀 Quick action clicked: ${actionId}`);
    // Convert action ID to view - this handles the mapping from action id to actual view
    const viewMap: Record<string, View> = {
      'pos-system': 'pos-system',
      'product-management': 'product-management',
      'sales-reports': 'sales-reports',
      'inventory-reports': 'inventory-reports',
      'user-management': 'user-management',
      'expiry-management': 'expiry-management'
    };
    
    const view = viewMap[actionId] || actionId as View;
    onSetCurrentView(view);
  };

  const handleNavigationItemClick = (view: View) => {
    console.log(`📊 Navigation item clicked: ${view}`);
    onSetCurrentView(view);
  };

  const handleImportComplete = () => {
    setShowImportDialog(false);
    loadDashboardData();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Navigation 
        userProfile={userProfile}
        currentView="home"
        onNavigate={handleNavigationItemClick}
        onSignOut={onSignOut}
        aiSystemStatus={aiSystemStatus}
        hasPermissionErrors={hasPermissionErrors}
        hasIndexErrors={hasIndexErrors}
      />

      {/* Main content area with proper desktop sidebar spacing */}
      <main className="min-h-screen">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">
            {getGreeting()}, {userProfile?.full_name?.split(' ')[0] || 'User'}!
          </h1>
          <p className="text-gray-600 mt-1">
            Welcome to your pharmacy management dashboard
          </p>
        </div>

        {/* Error Display */}
        {hasErrors() && (
          <div className="mb-6">
            <ErrorDisplay 
              context="Dashboard" 
              compact={true}
            />
          </div>
        )}

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4 text-gray-800">Quick Actions</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {availableQuickActions.map((action) => {
              const IconComponent = IconMap[action.icon as keyof typeof IconMap];
              return (
                <Button
                  key={action.id}
                  onClick={() => handleQuickAction(action.id)}
                  className={`${action.color} text-white p-6 h-auto flex flex-col items-center justify-center space-y-2 hover:shadow-lg transition-all duration-200`}
                >
                  {IconComponent && <IconComponent className="h-8 w-8" />}
                  <span className="font-medium">{action.title}</span>
                  <span className="text-xs opacity-90 text-center">{action.description}</span>
                </Button>
              );
            })}
          </div>
        </div>

        {/* Dashboard Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="hover:shadow-lg transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {dashboardData.loading ? '...' : formatTZS(dashboardData.totalSales)}
              </div>
              <p className="text-xs text-muted-foreground">
                {dashboardData.loading ? 'Loading...' : 'All time sales'}
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Transactions</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {dashboardData.loading ? '...' : dashboardData.totalTransactions}
              </div>
              <p className="text-xs text-muted-foreground">
                {dashboardData.loading ? 'Loading...' : 'All time transactions'}
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Products</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {dashboardData.loading ? '...' : dashboardData.totalProducts}
              </div>
              <p className="text-xs text-muted-foreground">
                {dashboardData.loading ? 'Loading...' : 'Active inventory items'}
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Alerts</CardTitle>
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">
                {dashboardData.loading ? '...' : (dashboardData.lowStockItems + dashboardData.expiringSoon)}
              </div>
              <p className="text-xs text-muted-foreground">
                {dashboardData.loading ? 'Loading...' : `${dashboardData.lowStockItems} low stock, ${dashboardData.expiringSoon} expiring`}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Management Sections */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          
          {/* Inventory Management */}
          {userPermissions?.includes('product-management') && (
            <Card className="hover:shadow-lg transition-shadow duration-200">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Package className="mr-2 h-5 w-5" />
                  Inventory Management
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{dashboardData.totalProducts}</div>
                    <div className="text-sm text-gray-600">Total Products</div>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">{dashboardData.lowStockItems}</div>
                    <div className="text-sm text-gray-600">Low Stock</div>
                  </div>
                </div>
                <div className="space-y-2">
                  <Button 
                    onClick={() => onSetCurrentView('product-management')}
                    className="w-full justify-between"
                    variant="outline"
                  >
                    Product Catalog
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                  <Button 
                    onClick={() => onSetCurrentView('expiry-management')}
                    className="w-full justify-between"
                    variant="outline"
                  >
                    Expiry Management
                    <Badge variant="destructive" className="ml-2">
                      {dashboardData.expiringSoon}
                    </Badge>
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
                
                {/* File Import Section */}
                <div className="mt-4 p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg border">
                  <h4 className="font-medium text-gray-900 mb-3 flex items-center">
                    <Upload className="h-4 w-4 mr-2 text-purple-600" />
                    Import Products
                  </h4>
                  <Button 
                    onClick={() => setShowImportDialog(true)}
                    className="bg-purple-600 hover:bg-purple-700 text-white w-full"
                    size="sm"
                  >
                    <Upload className="h-3 w-3 mr-2" />
                    Import from File (CSV/Excel)
                  </Button>
                  <p className="text-xs text-gray-600 mt-2">
                    Upload your product catalog from CSV or Excel files
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Sales & POS */}
          {userPermissions?.includes('pos-system') && (
            <Card className="hover:shadow-lg transition-shadow duration-200">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <ShoppingCart className="mr-2 h-5 w-5" />
                  Sales & Point of Sale
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{formatTZS(dashboardData.salesThisMonth)}</div>
                    <div className="text-sm text-gray-600">This Month</div>
                  </div>
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{dashboardData.totalTransactions}</div>
                    <div className="text-sm text-gray-600">Transactions</div>
                  </div>
                </div>
                <div className="space-y-2">
                  <Button 
                    onClick={() => onSetCurrentView('pos-system')}
                    className="w-full justify-between bg-green-600 hover:bg-green-700"
                  >
                    Open POS System
                    <Plus className="h-4 w-4" />
                  </Button>
                  <Button 
                    onClick={() => onSetCurrentView('sales-history')}
                    className="w-full justify-between"
                    variant="outline"
                  >
                    Sales History
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Reports & Analytics */}
          {userPermissions?.includes('sales-reports') && (
            <Card className="hover:shadow-lg transition-shadow duration-200">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="mr-2 h-5 w-5" />
                  Reports & Analytics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center p-4 bg-gradient-to-r from-purple-50 to-indigo-50 rounded-lg border border-purple-100">
                  <div className="text-lg font-semibold text-purple-600">Business Intelligence</div>
                  <div className="text-sm text-gray-600">Track performance and trends</div>
                </div>

                {/* AI Business Intelligence - Featured for Owners */}
                {userProfile?.role === 'owner' && (
                  <Button 
                    onClick={() => onSetCurrentView('ai-business-intelligence')}
                    className="w-full justify-between bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white"
                  >
                    <div className="flex items-center">
                      <Brain className="h-4 w-4 mr-2" />
                      AI Business Intelligence
                    </div>
                    <Badge variant="secondary" className="ml-2 bg-white/20 text-white border-white/30">
                      AI
                    </Badge>
                  </Button>
                )}

                <div className="space-y-2">
                  <Button 
                    onClick={() => onSetCurrentView('sales-reports')}
                    className="w-full justify-between"
                    variant="outline"
                  >
                    Sales Reports
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                  <Button 
                    onClick={() => onSetCurrentView('financial-reports')}
                    className="w-full justify-between"
                    variant="outline"
                  >
                    Financial Reports
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* User Management */}
          {userPermissions?.includes('user-management') && (
            <Card className="hover:shadow-lg transition-shadow duration-200">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="mr-2 h-5 w-5" />
                  User Management
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center p-4 bg-indigo-50 rounded-lg">
                  <div className="text-lg font-semibold text-indigo-600">Team Administration</div>
                  <div className="text-sm text-gray-600">Manage staff and permissions</div>
                </div>
                <div className="space-y-2">
                  <Button 
                    onClick={() => onSetCurrentView('user-management')}
                    className="w-full justify-between"
                    variant="outline"
                  >
                    Manage Users
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                  <Button 
                    onClick={() => onSetCurrentView('settings')}
                    className="w-full justify-between"
                    variant="outline"
                  >
                    Business Settings
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Recent Activity */}
        <Card className="hover:shadow-lg transition-shadow duration-200">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Clock className="mr-2 h-5 w-5" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            {dashboardData.loading ? (
              <div className="text-center py-8">
                <div className="text-gray-500">Loading recent transactions...</div>
              </div>
            ) : dashboardData.recentTransactions.length === 0 ? (
              <div className="text-center py-8">
                <div className="text-gray-500">No recent transactions</div>
                <p className="text-sm text-gray-400 mt-1">Sales will appear here once you start processing transactions</p>
              </div>
            ) : (
              <div className="space-y-3">
                {dashboardData.recentTransactions.map((transaction, index) => (
                  <div key={transaction.id || index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="h-10 w-10 bg-green-100 rounded-full flex items-center justify-center mr-3">
                        <ShoppingCart className="h-5 w-5 text-green-600" />
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">{transaction.customer}</div>
                        <div className="text-sm text-gray-500">{transaction.time}</div>
                      </div>
                    </div>
                    <div className="text-lg font-semibold text-green-600">
                      {formatTZS(transaction.amount)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Profile Debug Section - Show if shop_id exists but shop object is missing */}
        {userProfile?.shop_id && !userProfile.shop && (
          <Card className="mt-8 border-amber-200 bg-amber-50">
            <CardHeader>
              <CardTitle className="flex items-center text-amber-800">
                <AlertTriangle className="mr-2 h-5 w-5" />
                Profile Debug Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-white p-4 rounded-lg border border-amber-200">
                <h4 className="font-semibold text-amber-800 mb-3">🔍 Profile Status</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p><span className="font-medium">User ID:</span> {userProfile.id}</p>
                    <p><span className="font-medium">Email:</span> {userProfile.email}</p>
                    <p><span className="font-medium">Role:</span> {userProfile.role}</p>
                  </div>
                  <div>
                    <p><span className="font-medium">Shop ID:</span> {userProfile.shop_id}</p>
                    <p><span className="font-medium">Shop Object:</span> <span className="text-red-600">Missing</span></p>
                    <p><span className="font-medium">Issue:</span> Shop details not loading</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-red-50 border border-red-200 p-4 rounded-lg">
                <h4 className="font-semibold text-red-800 mb-2">🚨 Potential Issue</h4>
                <p className="text-red-700 text-sm mb-3">
                  Your profile shows a shop ID ({userProfile.shop_id}) but the shop details couldn't be loaded. 
                  This could indicate:
                </p>
                <ul className="text-red-700 text-sm list-disc list-inside space-y-1">
                  <li>The shop doesn't exist in the database</li>
                  <li>Firebase security rules are blocking shop access</li>
                  <li>There's a temporary connection issue</li>
                </ul>
              </div>
              
              <div className="flex gap-3">
                <Button
                  onClick={() => {
                    console.log('🔍 Full Profile Object:', userProfile);
                    console.log('🔍 JSON Profile:', JSON.stringify(userProfile, null, 2));
                    toast.info('Profile data logged to browser console');
                  }}
                  variant="outline"
                  size="sm"
                >
                  Log Profile to Console
                </Button>
                <Button
                  onClick={() => loadDashboardData()}
                  variant="outline"
                  size="sm"
                >
                  Retry Loading Data
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Debug Panel */}
        {showDebugPanel && (
          <div className="mt-8">
            <DebugPanel 
              onClose={onToggleDebugPanel}
              userProfile={userProfile}
              aiSystemStatus={aiSystemStatus}
              errors={errors}
              hasPermissionErrors={hasPermissionErrors}
              hasIndexErrors={hasIndexErrors}
              hasNetworkErrors={hasNetworkErrors}
              hasValidationErrors={hasValidationErrors}
              permissionErrorsLength={permissionErrorsLength}
            />
          </div>
        )}

        {/* Quota Management */}
        {aiSystemStatus === 'quota-exceeded' && (
          <div className="mt-8">
            <QuotaManagementPanel />
          </div>
        )}

        {/* Critical Firebase Rules Modal */}
        <CriticalFirebaseRulesModal 
          open={criticalErrorModalOpen}
          onClose={onCloseCriticalErrorModal}
          permissionErrorsCount={permissionErrorsLength}
          hasIndexErrors={hasIndexErrors}
        />

        {/* File Import Dialog */}
        <FileImportDialog
          open={showImportDialog}
          onOpenChange={setShowImportDialog}
          userProfile={userProfile}
          onImportComplete={handleImportComplete}
        />
      </main>
    </div>
  );
}