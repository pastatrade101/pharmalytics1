import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Progress } from './ui/progress';
import { Alert, AlertDescription } from './ui/alert';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from './ui/sheet';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { 
  BarChart3, Package, TrendingUp, AlertTriangle, DollarSign, 
  Calendar, Truck, Download, RefreshCw, Filter, Search,
  Package2, ShoppingCart, Clock, Target, Loader2, 
  TrendingDown, AlertCircle, CheckCircle, ArrowUpRight,
  ArrowDownRight, Eye, FileText, PieChart, Wifi, WifiOff,
  Database, Timer, Activity, ChevronDown, Settings, 
  BarChart, Menu, X
} from 'lucide-react';
import { 
  BarChart as RechartsBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart as RechartsPieChart, Cell, LineChart, Line, ComposedChart, Area,
  AreaChart, Pie
} from 'recharts';
import { FirebaseService } from '../lib/firebase';
import { SalesService } from '../lib/firebase-sales';
import { formatTZS } from '../lib/currency-utils';
import { Input } from './ui/input';
import { toast } from 'sonner';

interface Product {
  id: string;
  name: string;
  category: string;
  price?: number;  // Legacy field
  retail_price?: number;  // New standard field
  cost_price?: number;
  stock_quantity: number;
  min_stock_level?: number;
  max_stock_level?: number;
  supplier_name?: string;
  manufacturer?: string;
  expiry_date?: string;
  status: string;
  sku?: string;
  unit_of_measure?: string;
  created_at?: string;
  updated_at?: string;
  shop_id: string;
}

interface Sale {
  id: string;
  items: Array<{
    product_id: string;
    product_name: string;
    quantity: number;
    price: number;
  }>;
  timestamp: string;
  total_price: number;
}

interface InventoryMetrics {
  totalProducts: number;
  totalValue: number;
  totalCostValue: number;
  potentialProfit: number;
  lowStockItems: number;
  outOfStockItems: number;
  nearExpiryItems: number;
  expiredItems: number;
  activeSuppliers: number;
  averageStockLevel: number;
  stockTurnoverRate: number;
  dataQuality: 'excellent' | 'good' | 'fair' | 'poor';
}

interface CategoryAnalysis {
  category: string;
  productCount: number;
  totalValue: number;
  totalCost: number;
  profit: number;
  profitMargin: number;
  averageStock: number;
  color: string;
}

interface SupplierAnalysis {
  supplier: string;
  productCount: number;
  totalValue: number;
  totalCost: number;
  averagePrice: number;
  stockLevel: number;
  performance: 'excellent' | 'good' | 'average' | 'poor';
}

interface StockAlert {
  id: string;
  product: string;
  type: 'low_stock' | 'out_of_stock' | 'overstock' | 'near_expiry' | 'expired';
  severity: 'critical' | 'high' | 'medium' | 'low';
  current: number;
  recommended: number;
  message: string;
  action: string;
}

interface InventoryReportsProps {
  userProfile: any;
  onBack: () => void;
  onSetCurrentView: (view: any) => void;
}

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#0088fe', '#00c49f', '#ffbb28', '#ff8042'];

// Helper function to safely format currency values
const safeCurrencyFormat = (value: number | null | undefined): string => {
  if (value == null || isNaN(value)) {
    return formatTZS(0);
  }
  return formatTZS(value);
};

// Helper function to safely get numeric values
const safeNumber = (value: number | null | undefined, defaultValue: number = 0): number => {
  if (value == null || isNaN(value)) {
    return defaultValue;
  }
  return value;
};

// Helper function to get product price (handles both legacy and new field names)
const getProductPrice = (product: Product): number => {
  return safeNumber(product.retail_price) || safeNumber(product.price) || 0;
};

// Helper function to validate product data quality
const validateProductData = (product: Product): boolean => {
  return !!(product.name && 
           product.category && 
           (product.retail_price || product.price) && 
           typeof product.stock_quantity === 'number');
};

export function InventoryReports({ userProfile, onBack, onSetCurrentView }: InventoryReportsProps) {
  // State management
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'disconnected' | 'reconnecting'>('connected');
  const [dataFreshness, setDataFreshness] = useState<'fresh' | 'stale' | 'cached'>('fresh');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedSupplier, setSelectedSupplier] = useState('all');
  const [sortBy, setSortBy] = useState<'name' | 'value' | 'stock' | 'profit'>('value');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [filtersExpanded, setFiltersExpanded] = useState(false);
  const [viewMode, setViewMode] = useState<'overview' | 'detailed'>('overview');

  // Data state
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [retryCount, setRetryCount] = useState(0);

  // Refs for cleanup and real-time subscriptions
  const unsubscribeProducts = useRef<(() => void) | null>(null);
  const retryTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const autoRefreshIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Enhanced data validation
  const validateAndCleanProducts = useCallback((rawProducts: Product[]): Product[] => {
    console.log('🔍 Validating product data quality:', rawProducts.length, 'products');
    
    const validProducts = rawProducts.filter(product => {
      const isValid = validateProductData(product);
      if (!isValid) {
        console.warn('⚠️ Invalid product data found:', {
          id: product.id,
          name: product.name,
          hasPrice: !!(product.retail_price || product.price),
          hasStock: typeof product.stock_quantity === 'number'
        });
      }
      return isValid;
    });

    // Clean and normalize product data
    const cleanedProducts = validProducts.map(product => ({
      ...product,
      // Normalize price fields
      retail_price: getProductPrice(product),
      cost_price: safeNumber(product.cost_price, getProductPrice(product) * 0.6),
      
      // Normalize stock fields
      stock_quantity: safeNumber(product.stock_quantity),
      min_stock_level: safeNumber(product.min_stock_level, 10),
      max_stock_level: product.max_stock_level ? safeNumber(product.max_stock_level) : undefined,
      
      // Normalize string fields
      category: product.category || 'Uncategorized',
      supplier_name: product.supplier_name || product.manufacturer || 'Unknown Supplier',
      sku: product.sku || `AUTO-${product.id.slice(-6)}`,
      unit_of_measure: product.unit_of_measure || 'piece'
    }));

    console.log('✅ Data validation complete:', {
      total: rawProducts.length,
      valid: cleanedProducts.length,
      invalid: rawProducts.length - cleanedProducts.length,
      qualityScore: ((cleanedProducts.length / rawProducts.length) * 100).toFixed(1) + '%'
    });

    return cleanedProducts;
  }, []);

  // Enhanced error handling with retry logic
  const handleDataLoadingError = useCallback((error: any, context: string) => {
    console.error(`❌ Error in ${context}:`, error);
    
    if (error?.code === 'permission-denied') {
      setError('Firebase permissions not configured. Please deploy the latest security rules.');
      setConnectionStatus('disconnected');
      return;
    }
    
    if (error?.code === 'unavailable' || error?.message?.includes('network')) {
      setConnectionStatus('disconnected');
      
      // Auto-retry for network errors
      if (retryCount < 3) {
        console.log(`🔄 Network error - auto-retry ${retryCount + 1}/3 in 2 seconds`);
        setRetryCount(prev => prev + 1);
        retryTimeoutRef.current = setTimeout(() => {
          loadInventoryData(true);
        }, 2000);
        return;
      }
    }
    
    setError(`Failed to load ${context}. ${error?.message || 'Please try refreshing.'}`);
  }, [retryCount]);

  // Real-time data subscription
  const setupRealTimeSubscription = useCallback((shopId: string) => {
    console.log('🔄 Setting up real-time inventory subscription for shop:', shopId);
    
    try {
      // Subscribe to product changes
      unsubscribeProducts.current = FirebaseService.subscribeToProducts(shopId, (updatedProducts) => {
        console.log('📦 Real-time products update received:', updatedProducts.length);
        
        if (updatedProducts.length > 0) {
          const validatedProducts = validateAndCleanProducts(updatedProducts);
          setProducts(validatedProducts);
          setLastUpdated(new Date());
          setDataFreshness('fresh');
          setConnectionStatus('connected');
          setRetryCount(0); // Reset retry count on successful update
        }
      });

      setConnectionStatus('connected');
      
    } catch (error) {
      console.error('❌ Error setting up real-time subscription:', error);
      handleDataLoadingError(error, 'real-time subscription');
    }
  }, [validateAndCleanProducts, handleDataLoadingError]);

  // Enhanced data loading with retry and fallback mechanisms
  const loadInventoryData = useCallback(async (refresh = false) => {
    if (!userProfile?.shop_id) {
      setError('No pharmacy assigned to your account');
      setIsLoading(false);
      return;
    }

    try {
      if (refresh) {
        setIsRefreshing(true);
        setConnectionStatus('reconnecting');
      } else {
        setIsLoading(true);
      }
      setError(null);

      console.log('📦 Loading enhanced inventory data for shop:', userProfile.shop_id);

      // Load products with enhanced error handling
      let productsData: Product[] = [];
      try {
        productsData = await FirebaseService.getProducts(userProfile.shop_id);
        console.log('✅ Products loaded successfully:', productsData.length);
      } catch (productError) {
        console.warn('⚠️ Error loading products:', productError);
        handleDataLoadingError(productError, 'products');
        return;
      }

      // Load sales data with fallback
      let salesData: Sale[] = [];
      try {
        salesData = await SalesService.getSalesByShop(userProfile.shop_id, 200);
        console.log('✅ Sales data loaded successfully:', salesData.length);
      } catch (salesError) {
        console.warn('⚠️ Error loading sales (non-critical):', salesError);
        // Sales data is not critical for inventory reports
        salesData = [];
      }

      // Validate and clean data
      const validatedProducts = validateAndCleanProducts(productsData);
      
      setProducts(validatedProducts);
      setSales(salesData);
      setLastUpdated(new Date());
      setDataFreshness('fresh');
      setConnectionStatus('connected');
      setRetryCount(0);

      // Set up real-time subscription if not already active
      if (!unsubscribeProducts.current) {
        setupRealTimeSubscription(userProfile.shop_id);
      }

      console.log('✅ Inventory data loaded successfully:', {
        products: validatedProducts.length,
        sales: salesData.length,
        validationRate: ((validatedProducts.length / productsData.length) * 100).toFixed(1) + '%'
      });

    } catch (err: any) {
      handleDataLoadingError(err, 'inventory data');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, [userProfile?.shop_id, validateAndCleanProducts, handleDataLoadingError, setupRealTimeSubscription]);

  // Auto-refresh for data freshness
  useEffect(() => {
    if (products.length > 0) {
      // Set up auto-refresh every 5 minutes for data freshness
      autoRefreshIntervalRef.current = setInterval(() => {
        console.log('🔄 Auto-refreshing inventory data for freshness');
        setDataFreshness('stale');
        loadInventoryData(true);
      }, 5 * 60 * 1000); // 5 minutes
    }

    return () => {
      if (autoRefreshIntervalRef.current) {
        clearInterval(autoRefreshIntervalRef.current);
        autoRefreshIntervalRef.current = null;
      }
    };
  }, [products.length, loadInventoryData]);

  // Load data on component mount and handle cleanup
  useEffect(() => {
    loadInventoryData();

    return () => {
      // Cleanup subscriptions and timers
      if (unsubscribeProducts.current) {
        unsubscribeProducts.current();
        unsubscribeProducts.current = null;
      }
      if (retryTimeoutRef.current) {
        clearTimeout(retryTimeoutRef.current);
        retryTimeoutRef.current = null;
      }
      if (autoRefreshIntervalRef.current) {
        clearInterval(autoRefreshIntervalRef.current);
        autoRefreshIntervalRef.current = null;
      }
    };
  }, [loadInventoryData]);

  // Enhanced inventory metrics calculation with data quality assessment
  const inventoryMetrics = useMemo((): InventoryMetrics => {
    if (!products.length) {
      return {
        totalProducts: 0,
        totalValue: 0,
        totalCostValue: 0,
        potentialProfit: 0,
        lowStockItems: 0,
        outOfStockItems: 0,
        nearExpiryItems: 0,
        expiredItems: 0,
        activeSuppliers: 0,
        averageStockLevel: 0,
        stockTurnoverRate: 0,
        dataQuality: 'poor'
      };
    }

    const now = new Date();
    const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

    const totalProducts = products.length;
    const totalValue = products.reduce((sum, p) => sum + (getProductPrice(p) * safeNumber(p.stock_quantity)), 0);
    const totalCostValue = products.reduce((sum, p) => sum + (safeNumber(p.cost_price) * safeNumber(p.stock_quantity)), 0);
    const potentialProfit = totalValue - totalCostValue;

    const lowStockItems = products.filter(p => 
      safeNumber(p.stock_quantity) <= safeNumber(p.min_stock_level, 10) && safeNumber(p.stock_quantity) > 0
    ).length;

    const outOfStockItems = products.filter(p => safeNumber(p.stock_quantity) === 0).length;

    const nearExpiryItems = products.filter(p => {
      if (!p.expiry_date) return false;
      try {
        const expiryDate = new Date(p.expiry_date);
        return expiryDate <= thirtyDaysFromNow && expiryDate > now;
      } catch {
        return false;
      }
    }).length;

    const expiredItems = products.filter(p => {
      if (!p.expiry_date) return false;
      try {
        return new Date(p.expiry_date) <= now;
      } catch {
        return false;
      }
    }).length;

    const suppliers = new Set(products.map(p => p.supplier_name).filter(Boolean));
    const activeSuppliers = suppliers.size;

    const averageStockLevel = products.length > 0 ? 
      products.reduce((sum, p) => sum + safeNumber(p.stock_quantity), 0) / products.length : 0;

    // Enhanced stock turnover calculation with sales data
    const totalSoldQuantity = sales.reduce((total, sale) => 
      total + sale.items.reduce((sum, item) => sum + safeNumber(item.quantity), 0), 0
    );
    const totalCurrentStock = products.reduce((sum, p) => sum + safeNumber(p.stock_quantity), 0);
    const stockTurnoverRate = totalCurrentStock > 0 ? totalSoldQuantity / totalCurrentStock : 0;

    // Data quality assessment
    const productsWithCompleteData = products.filter(p => 
      p.name && p.category && getProductPrice(p) > 0 && p.supplier_name && p.sku
    ).length;
    const dataQualityScore = productsWithCompleteData / totalProducts;
    
    let dataQuality: 'excellent' | 'good' | 'fair' | 'poor' = 'poor';
    if (dataQualityScore >= 0.9) dataQuality = 'excellent';
    else if (dataQualityScore >= 0.75) dataQuality = 'good';
    else if (dataQualityScore >= 0.5) dataQuality = 'fair';

    return {
      totalProducts,
      totalValue,
      totalCostValue,
      potentialProfit,
      lowStockItems,
      outOfStockItems,
      nearExpiryItems,
      expiredItems,
      activeSuppliers,
      averageStockLevel,
      stockTurnoverRate,
      dataQuality
    };
  }, [products, sales]);

  // Enhanced category analysis with better data handling
  const categoryAnalysis = useMemo((): CategoryAnalysis[] => {
    if (!products.length) return [];

    const categoryMap = new Map<string, {
      products: Product[];
      totalValue: number;
      totalCost: number;
    }>();

    products.forEach(product => {
      const category = product.category || 'Uncategorized';
      if (!categoryMap.has(category)) {
        categoryMap.set(category, {
          products: [],
          totalValue: 0,
          totalCost: 0
        });
      }

      const categoryData = categoryMap.get(category)!;
      categoryData.products.push(product);
      
      const productPrice = getProductPrice(product);
      const productCost = safeNumber(product.cost_price);
      const stockQuantity = safeNumber(product.stock_quantity);
      
      categoryData.totalValue += productPrice * stockQuantity;
      categoryData.totalCost += productCost * stockQuantity;
    });

    return Array.from(categoryMap.entries()).map(([category, data], index) => {
      const profit = data.totalValue - data.totalCost;
      const profitMargin = data.totalValue > 0 ? (profit / data.totalValue) * 100 : 0;
      const averageStock = data.products.reduce((sum, p) => sum + safeNumber(p.stock_quantity), 0) / data.products.length;

      return {
        category,
        productCount: data.products.length,
        totalValue: data.totalValue,
        totalCost: data.totalCost,
        profit,
        profitMargin,
        averageStock,
        color: COLORS[index % COLORS.length]
      };
    }).sort((a, b) => b.totalValue - a.totalValue);
  }, [products]);

  // Enhanced stock alerts with better categorization
  const stockAlerts = useMemo((): StockAlert[] => {
    if (!products.length) return [];

    const alerts: StockAlert[] = [];
    const now = new Date();
    const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

    products.forEach(product => {
      const stockQuantity = safeNumber(product.stock_quantity);
      const minStockLevel = safeNumber(product.min_stock_level, 10);
      const maxStockLevel = safeNumber(product.max_stock_level, 0);

      // Out of stock
      if (stockQuantity === 0) {
        alerts.push({
          id: `${product.id}-out-of-stock`,
          product: product.name,
          type: 'out_of_stock',
          severity: 'critical',
          current: 0,
          recommended: minStockLevel,
          message: 'Product is out of stock',
          action: 'Urgent reorder required'
        });
      }
      // Low stock
      else if (stockQuantity <= minStockLevel) {
        alerts.push({
          id: `${product.id}-low-stock`,
          product: product.name,
          type: 'low_stock',
          severity: stockQuantity <= minStockLevel * 0.5 ? 'high' : 'medium',
          current: stockQuantity,
          recommended: minStockLevel * 2,
          message: `Stock level is ${stockQuantity <= minStockLevel * 0.5 ? 'critically' : ''} low (${stockQuantity} remaining)`,
          action: stockQuantity <= minStockLevel * 0.5 ? 'Immediate reorder needed' : 'Reorder soon'
        });
      }

      // Expiry checks
      if (product.expiry_date) {
        try {
          const expiryDate = new Date(product.expiry_date);
          
          // Expired
          if (expiryDate <= now) {
            alerts.push({
              id: `${product.id}-expired`,
              product: product.name,
              type: 'expired',
              severity: 'critical',
              current: stockQuantity,
              recommended: 0,
              message: 'Product has expired',
              action: 'Remove from stock immediately'
            });
          }
          // Near expiry
          else if (expiryDate <= thirtyDaysFromNow) {
            const daysToExpiry = Math.ceil((expiryDate.getTime() - now.getTime()) / (24 * 60 * 60 * 1000));
            alerts.push({
              id: `${product.id}-near-expiry`,
              product: product.name,
              type: 'near_expiry',
              severity: daysToExpiry <= 7 ? 'high' : 'medium',
              current: stockQuantity,
              recommended: 0,
              message: `Expires in ${daysToExpiry} day${daysToExpiry === 1 ? '' : 's'}`,
              action: daysToExpiry <= 7 ? 'Urgent sale needed' : 'Plan discount or promotion'
            });
          }
        } catch (error) {
          console.warn('Invalid expiry date for product:', product.name);
        }
      }
    });

    return alerts.sort((a, b) => {
      const severityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
      return severityOrder[a.severity] - severityOrder[b.severity];
    });
  }, [products]);

  // Get unique categories and suppliers for filters
  const categories = useMemo(() => {
    const cats = new Set(products.map(p => p.category).filter(Boolean));
    return Array.from(cats).sort();
  }, [products]);

  const suppliers = useMemo(() => {
    const sups = new Set(products.map(p => p.supplier_name).filter(Boolean));
    return Array.from(sups).sort();
  }, [products]);

  // Get active filter count
  const getActiveFilterCount = () => {
    let count = 0;
    if (searchTerm) count++;
    if (selectedCategory !== 'all') count++;
    if (selectedSupplier !== 'all') count++;
    if (sortBy !== 'value' || sortOrder !== 'desc') count++;
    return count;
  };

  // Get connection status color and icon
  const getConnectionStatusDisplay = () => {
    switch (connectionStatus) {
      case 'connected':
        return { icon: Wifi, color: 'text-green-600', text: 'connected' };
      case 'disconnected':
        return { icon: WifiOff, color: 'text-red-600', text: 'disconnected' };
      case 'reconnecting':
        return { icon: Loader2, color: 'text-yellow-600', text: 'reconnecting' };
      default:
        return { icon: Wifi, color: 'text-gray-600', text: 'unknown' };
    }
  };

  // Get data freshness color and text
  const getDataFreshnessDisplay = () => {
    switch (dataFreshness) {
      case 'fresh':
        return { color: 'text-green-600', text: 'fresh data' };
      case 'stale':
        return { color: 'text-yellow-600', text: 'updating...' };
      case 'cached':
        return { color: 'text-gray-600', text: 'cached data' };
      default:
        return { color: 'text-gray-600', text: 'unknown' };
    }
  };

  // Get data quality color and display
  const getDataQualityDisplay = () => {
    switch (inventoryMetrics.dataQuality) {
      case 'excellent':
        return { color: 'text-green-600', text: 'excellent quality', bgColor: 'bg-green-50' };
      case 'good':
        return { color: 'text-blue-600', text: 'good quality', bgColor: 'bg-blue-50' };
      case 'fair':
        return { color: 'text-yellow-600', text: 'fair quality', bgColor: 'bg-yellow-50' };
      case 'poor':
        return { color: 'text-red-600', text: 'poor quality', bgColor: 'bg-red-50' };
      default:
        return { color: 'text-gray-600', text: 'unknown', bgColor: 'bg-gray-50' };
    }
  };

  // Mobile Status Panel Component
  const MobileStatusPanel = () => {
    const connectionDisplay = getConnectionStatusDisplay();
    const ConnectionIcon = connectionDisplay.icon;
    const freshnessDisplay = getDataFreshnessDisplay();
    const qualityDisplay = getDataQualityDisplay();

    return (
      <div className="bg-white border rounded-lg p-3 mb-4 lg:hidden">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-purple-600" />
            <h1 className="text-lg font-semibold text-gray-900">Inventory Analytics</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => loadInventoryData(true)}
              disabled={isRefreshing}
              className="min-h-[44px] w-10 p-0"
            >
              <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setViewMode(viewMode === 'overview' ? 'detailed' : 'overview')}
              className="min-h-[44px] w-10 p-0"
            >
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Status Badges - Mobile Optimized */}
        <div className="flex flex-wrap gap-2">
          <div className="flex items-center gap-1.5 px-2 py-1 bg-gray-50 rounded-md">
            <ConnectionIcon className={`h-3 w-3 ${connectionDisplay.color} ${connectionStatus === 'reconnecting' ? 'animate-spin' : ''}`} />
            <span className={`text-xs ${connectionDisplay.color}`}>{connectionDisplay.text}</span>
          </div>
          
          <div className="flex items-center gap-1.5 px-2 py-1 bg-gray-50 rounded-md">
            <Database className={`h-3 w-3 ${freshnessDisplay.color}`} />
            <span className={`text-xs ${freshnessDisplay.color}`}>{freshnessDisplay.text}</span>
          </div>
          
          <div className={`flex items-center gap-1.5 px-2 py-1 rounded-md ${qualityDisplay.bgColor}`}>
            <Target className={`h-3 w-3 ${qualityDisplay.color}`} />
            <span className={`text-xs ${qualityDisplay.color}`}>{qualityDisplay.text}</span>
          </div>
        </div>

        {/* Last Updated - Mobile */}
        <div className="mt-2 text-xs text-gray-500">
          Last updated: {lastUpdated.toLocaleTimeString()}
        </div>
      </div>
    );
  };

  // Desktop Header Component
  const DesktopHeader = () => {
    const connectionDisplay = getConnectionStatusDisplay();
    const ConnectionIcon = connectionDisplay.icon;
    const freshnessDisplay = getDataFreshnessDisplay();
    const qualityDisplay = getDataQualityDisplay();

    return (
      <div className="hidden lg:block bg-white border rounded-lg p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <BarChart3 className="h-6 w-6 text-purple-600" />
            <div>
              <h1 className="text-2xl font-semibold text-gray-900">Inventory Analytics</h1>
              <p className="text-sm text-gray-600 mt-1">
                Comprehensive analysis of your product catalog
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              onClick={() => loadInventoryData(true)}
              disabled={isRefreshing}
              className="gap-2"
            >
              <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setViewMode(viewMode === 'overview' ? 'detailed' : 'overview')}
              className="gap-2"
            >
              <Settings className="h-4 w-4" />
              {viewMode === 'overview' ? 'Detailed' : 'Overview'}
            </Button>
          </div>
        </div>

        {/* Status Row - Desktop */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <ConnectionIcon className={`h-4 w-4 ${connectionDisplay.color} ${connectionStatus === 'reconnecting' ? 'animate-spin' : ''}`} />
              <span className={`text-sm ${connectionDisplay.color}`}>{connectionDisplay.text}</span>
            </div>
            
            <div className="flex items-center gap-2">
              <Database className={`h-4 w-4 ${freshnessDisplay.color}`} />
              <span className={`text-sm ${freshnessDisplay.color}`}>{freshnessDisplay.text}</span>
            </div>
            
            <div className={`flex items-center gap-2 px-3 py-1 rounded-md ${qualityDisplay.bgColor}`}>
              <Target className={`h-4 w-4 ${qualityDisplay.color}`} />
              <span className={`text-sm ${qualityDisplay.color}`}>{qualityDisplay.text}</span>
            </div>
          </div>

          <div className="text-sm text-gray-500">
            Last updated: {lastUpdated.toLocaleTimeString()}
          </div>
        </div>
      </div>
    );
  };

  // Mobile Filter Panel Component
  const MobileFilterPanel = () => (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline" size="sm" className="min-h-[44px] gap-2">
          <Filter className="h-4 w-4" />
          <span>Filters</span>
          {getActiveFilterCount() > 0 && (
            <Badge variant="secondary" className="h-5 w-5 p-0 flex items-center justify-center text-xs">
              {getActiveFilterCount()}
            </Badge>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent side="bottom" className="h-[85vh]">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Inventory Filters
          </SheetTitle>
        </SheetHeader>
        <div className="space-y-6 mt-6">
          {/* Search Filter */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-900">Search Products</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search by name, category, or SKU..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="h-12 pl-10 text-base"
              />
            </div>
          </div>

          {/* Category Filter */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-900">Category</label>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="h-12 text-base">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all" className="text-base py-3">All Categories</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category} value={category} className="text-base py-3">
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Supplier Filter */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-900">Supplier</label>
            <Select value={selectedSupplier} onValueChange={setSelectedSupplier}>
              <SelectTrigger className="h-12 text-base">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all" className="text-base py-3">All Suppliers</SelectItem>
                {suppliers.map((supplier) => (
                  <SelectItem key={supplier} value={supplier} className="text-base py-3">
                    {supplier}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Sort Options */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-900">Sort By</label>
            <div className="grid grid-cols-2 gap-3">
              <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                <SelectTrigger className="h-12 text-base">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name" className="text-base py-3">Name</SelectItem>
                  <SelectItem value="value" className="text-base py-3">Value</SelectItem>
                  <SelectItem value="stock" className="text-base py-3">Stock</SelectItem>
                  <SelectItem value="profit" className="text-base py-3">Profit</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={sortOrder} onValueChange={(value: any) => setSortOrder(value)}>
                <SelectTrigger className="h-12 text-base">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="desc" className="text-base py-3">High to Low</SelectItem>
                  <SelectItem value="asc" className="text-base py-3">Low to High</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Clear Filters */}
          <Button 
            variant="outline" 
            onClick={() => {
              setSearchTerm('');
              setSelectedCategory('all');
              setSelectedSupplier('all');
              setSortBy('value');
              setSortOrder('desc');
            }}
            className="w-full h-12"
          >
            Clear All Filters
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );

  // Desktop Filters Component
  const DesktopFilters = () => (
    <Collapsible open={filtersExpanded} onOpenChange={setFiltersExpanded}>
      <div className="flex items-center justify-between mb-4">
        <CollapsibleTrigger asChild>
          <Button variant="ghost" size="sm" className="gap-2">
            <Filter className="h-4 w-4" />
            <span>Filters & Search</span>
            <ChevronDown className={`h-4 w-4 transition-transform ${filtersExpanded ? 'rotate-180' : ''}`} />
            {getActiveFilterCount() > 0 && (
              <Badge variant="secondary" className="h-5 w-5 p-0 flex items-center justify-center text-xs">
                {getActiveFilterCount()}
              </Badge>
            )}
          </Button>
        </CollapsibleTrigger>
        
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => toast.success('Export functionality coming soon!')}
            className="gap-2"
          >
            <Download className="h-4 w-4" />
            Export
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => window.print()}
            className="gap-2"
          >
            <Eye className="h-4 w-4" />
            Print
          </Button>
        </div>
      </div>

      <CollapsibleContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg">
          {/* Search */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Search Products</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Category */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Category</label>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Supplier */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Supplier</label>
            <Select value={selectedSupplier} onValueChange={setSelectedSupplier}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Suppliers</SelectItem>
                {suppliers.map((supplier) => (
                  <SelectItem key={supplier} value={supplier}>
                    {supplier}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Sort */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Sort</label>
            <div className="flex gap-2">
              <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                <SelectTrigger className="flex-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">Name</SelectItem>
                  <SelectItem value="value">Value</SelectItem>
                  <SelectItem value="stock">Stock</SelectItem>
                  <SelectItem value="profit">Profit</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={sortOrder} onValueChange={(value: any) => setSortOrder(value)}>
                <SelectTrigger className="w-20">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="desc">↓</SelectItem>
                  <SelectItem value="asc">↑</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Active Filters Summary */}
        {(searchTerm || selectedCategory !== 'all' || selectedSupplier !== 'all') && (
          <div className="flex flex-wrap items-center gap-2 text-sm text-gray-600">
            <span>Active filters:</span>
            {searchTerm && <Badge variant="outline">Search: "{searchTerm}"</Badge>}
            {selectedCategory !== 'all' && <Badge variant="outline">Category: {selectedCategory}</Badge>}
            {selectedSupplier !== 'all' && <Badge variant="outline">Supplier: {selectedSupplier}</Badge>}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('all');
                setSelectedSupplier('all');
              }}
              className="h-6 px-2 text-xs"
            >
              Clear
            </Button>
          </div>
        )}
      </CollapsibleContent>
    </Collapsible>
  );

  // Loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-purple-600" />
          <p className="text-gray-600">Loading inventory analytics...</p>
          <p className="text-sm text-gray-500 mt-1">Analyzing your product catalog</p>
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="space-y-6">
        <Alert className="border-red-200 bg-red-50">
          <AlertCircle className="h-4 w-4 text-red-600" />
          <AlertDescription>
            <div className="space-y-2">
              <p className="font-medium text-red-900">Failed to Load Inventory Analytics</p>
              <p className="text-red-800 text-sm">{error}</p>
              <Button
                onClick={() => loadInventoryData(true)}
                variant="outline"
                size="sm"
                className="border-red-300 text-red-700 hover:bg-red-100"
              >
                Retry Loading
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  // No data state
  if (products.length === 0) {
    return (
      <div className="space-y-6">
        <MobileStatusPanel />
        <DesktopHeader />
        
        <div className="text-center py-12">
          <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-medium text-gray-900 mb-2">No Inventory Data</h3>
          <p className="text-gray-600 mb-4">
            Add products to your inventory to see analytics and insights.
          </p>
          <div className="space-y-2">
            <Button
              onClick={() => onSetCurrentView('inventory-manager')}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Package className="h-4 w-4 mr-2" />
              Add Products
            </Button>
            <p className="text-sm text-gray-500">
              Start by adding products to your pharmacy inventory
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Mobile-First Header */}
      <MobileStatusPanel />
      <DesktopHeader />

      {/* Mobile-First Filter Controls */}
      <div className="flex items-center justify-between">
        {/* Mobile: Sheet trigger */}
        <div className="lg:hidden">
          <MobileFilterPanel />
        </div>
        
        {/* Desktop: Collapsible filters */}
        <div className="hidden lg:block flex-1">
          <DesktopFilters />
        </div>

        {/* Mobile action buttons */}
        <div className="flex items-center gap-2 lg:hidden">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => toast.success('Export functionality coming soon!')}
            className="min-h-[44px]"
          >
            <Download className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => window.print()}
            className="min-h-[44px]"
          >
            <Eye className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Key Metrics - Mobile-First Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Inventory Value</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl lg:text-2xl font-bold text-green-600">
              {safeCurrencyFormat(inventoryMetrics.totalValue)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Cost: {safeCurrencyFormat(inventoryMetrics.totalCostValue)} • 
              Profit: {safeCurrencyFormat(inventoryMetrics.potentialProfit)}
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Products</CardTitle>
            <Package2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl lg:text-2xl font-bold">{inventoryMetrics.totalProducts}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {suppliers.length} suppliers • Avg stock: {inventoryMetrics.averageStockLevel.toFixed(1)}
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Stock Alerts</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl lg:text-2xl font-bold text-orange-600">
              {inventoryMetrics.lowStockItems + inventoryMetrics.outOfStockItems}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {inventoryMetrics.outOfStockItems} out of stock • {inventoryMetrics.lowStockItems} low stock
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Expiry Alerts</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl lg:text-2xl font-bold text-red-600">
              {inventoryMetrics.expiredItems + inventoryMetrics.nearExpiryItems}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {inventoryMetrics.expiredItems} expired • {inventoryMetrics.nearExpiryItems} expiring soon
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content - Mobile-Optimized Tabs */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4">
          <TabsTrigger value="overview" className="text-sm">Overview</TabsTrigger>
          <TabsTrigger value="categories" className="text-sm">Categories</TabsTrigger>
          <TabsTrigger value="alerts" className="text-sm lg:inline hidden">Alerts</TabsTrigger>
          <TabsTrigger value="analytics" className="text-sm lg:inline hidden">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Category Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Inventory by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {categoryAnalysis.slice(0, 5).map((category, index) => {
                    const percentage = inventoryMetrics.totalValue > 0 ? 
                      (category.totalValue / inventoryMetrics.totalValue) * 100 : 0;
                    
                    return (
                      <div key={index} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div 
                              className="w-3 h-3 rounded-full" 
                              style={{ backgroundColor: category.color }}
                            />
                            <span className="text-sm font-medium truncate max-w-[120px]" title={category.category}>
                              {category.category}
                            </span>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-bold">{safeCurrencyFormat(category.totalValue)}</div>
                            <div className="text-xs text-gray-500">{category.productCount} items</div>
                          </div>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="h-2 rounded-full" 
                            style={{ 
                              width: `${Math.min(percentage, 100)}%`,
                              backgroundColor: category.color 
                            }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Stock Status Overview */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Stock Status Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Stock Level Distribution */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">
                        {products.filter(p => safeNumber(p.stock_quantity) > safeNumber(p.min_stock_level, 10)).length}
                      </div>
                      <div className="text-xs text-green-800">Well Stocked</div>
                    </div>
                    
                    <div className="text-center p-3 bg-yellow-50 rounded-lg">
                      <div className="text-2xl font-bold text-yellow-600">
                        {inventoryMetrics.lowStockItems}
                      </div>
                      <div className="text-xs text-yellow-800">Low Stock</div>
                    </div>
                    
                    <div className="text-center p-3 bg-red-50 rounded-lg">
                      <div className="text-2xl font-bold text-red-600">
                        {inventoryMetrics.outOfStockItems}
                      </div>
                      <div className="text-xs text-red-800">Out of Stock</div>
                    </div>
                    
                    <div className="text-center p-3 bg-purple-50 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">
                        {inventoryMetrics.activeSuppliers}
                      </div>
                      <div className="text-xs text-purple-800">Active Suppliers</div>
                    </div>
                  </div>

                  {/* Quick Actions */}
                  <div className="space-y-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onSetCurrentView('reorder-management')}
                      className="w-full justify-start gap-2"
                    >
                      <ShoppingCart className="h-4 w-4" />
                      Manage Reorders
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onSetCurrentView('expiry-management')}
                      className="w-full justify-start gap-2"
                    >
                      <Calendar className="h-4 w-4" />
                      Check Expiry Dates
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="categories" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Category Performance Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="min-w-[150px]">Category</TableHead>
                      <TableHead className="text-right">Products</TableHead>
                      <TableHead className="text-right">Value</TableHead>
                      <TableHead className="text-right hidden sm:table-cell">Profit</TableHead>
                      <TableHead className="text-right hidden sm:table-cell">Margin</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {categoryAnalysis.map((category, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <div 
                              className="w-3 h-3 rounded-full" 
                              style={{ backgroundColor: category.color }}
                            />
                            <span className="truncate max-w-[120px]" title={category.category}>
                              {category.category}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">{category.productCount}</TableCell>
                        <TableCell className="text-right font-semibold">
                          {safeCurrencyFormat(category.totalValue)}
                        </TableCell>
                        <TableCell className="text-right hidden sm:table-cell">
                          {safeCurrencyFormat(category.profit)}
                        </TableCell>
                        <TableCell className="text-right hidden sm:table-cell">
                          <Badge 
                            variant={category.profitMargin > 30 ? 'default' : category.profitMargin > 15 ? 'secondary' : 'destructive'}
                            className="text-xs"
                          >
                            {category.profitMargin.toFixed(1)}%
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Stock & Expiry Alerts</CardTitle>
            </CardHeader>
            <CardContent>
              {stockAlerts.length === 0 ? (
                <div className="text-center py-8">
                  <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
                  <p className="text-gray-600">No alerts! Your inventory is in good condition.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {stockAlerts.slice(0, 10).map((alert) => (
                    <div
                      key={alert.id}
                      className={`p-3 rounded-lg border-l-4 ${
                        alert.severity === 'critical' 
                          ? 'border-red-500 bg-red-50' 
                          : alert.severity === 'high'
                          ? 'border-orange-500 bg-orange-50'
                          : 'border-yellow-500 bg-yellow-50'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge 
                              variant={alert.severity === 'critical' ? 'destructive' : 'secondary'}
                              className="text-xs"
                            >
                              {alert.severity.toUpperCase()}
                            </Badge>
                            <span className="text-sm font-medium truncate" title={alert.product}>
                              {alert.product}
                            </span>
                          </div>
                          <p className="text-sm text-gray-600">{alert.message}</p>
                          <p className="text-xs text-gray-500 mt-1">{alert.action}</p>
                        </div>
                        <div className="text-right text-sm">
                          <div className="font-semibold">Current: {alert.current}</div>
                          {alert.recommended > 0 && (
                            <div className="text-gray-500">Target: {alert.recommended}</div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Turnover Rate */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Performance Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div>
                      <div className="text-sm text-blue-800">Stock Turnover Rate</div>
                      <div className="text-2xl font-bold text-blue-600">
                        {inventoryMetrics.stockTurnoverRate.toFixed(2)}x
                      </div>
                    </div>
                    <TrendingUp className="h-8 w-8 text-blue-600" />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <div>
                      <div className="text-sm text-green-800">Average Stock Level</div>
                      <div className="text-2xl font-bold text-green-600">
                        {inventoryMetrics.averageStockLevel.toFixed(0)}
                      </div>
                    </div>
                    <Package className="h-8 w-8 text-green-600" />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                    <div>
                      <div className="text-sm text-purple-800">Data Quality Score</div>
                      <div className="text-2xl font-bold text-purple-600">
                        {((products.filter(p => p.name && p.category && getProductPrice(p) > 0 && p.supplier_name && p.sku).length / products.length) * 100).toFixed(0)}%
                      </div>
                    </div>
                    <Database className="h-8 w-8 text-purple-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Button
                    variant="outline"
                    onClick={() => onSetCurrentView('inventory-manager')}
                    className="w-full justify-start gap-3 h-12"
                  >
                    <Package className="h-5 w-5" />
                    <div className="text-left">
                      <div className="font-medium">Manage Products</div>
                      <div className="text-xs text-gray-500">Add, edit, or remove products</div>
                    </div>
                  </Button>
                  
                  <Button
                    variant="outline"
                    onClick={() => onSetCurrentView('reorder-management')}
                    className="w-full justify-start gap-3 h-12"
                  >
                    <ShoppingCart className="h-5 w-5" />
                    <div className="text-left">
                      <div className="font-medium">Reorder Management</div>
                      <div className="text-xs text-gray-500">Handle low stock alerts</div>
                    </div>
                  </Button>
                  
                  <Button
                    variant="outline"
                    onClick={() => onSetCurrentView('expiry-management')}
                    className="w-full justify-start gap-3 h-12"
                  >
                    <Calendar className="h-5 w-5" />
                    <div className="text-left">
                      <div className="font-medium">Expiry Management</div>
                      <div className="text-xs text-gray-500">Track product expiration</div>
                    </div>
                  </Button>
                  
                  <Button
                    variant="outline"
                    onClick={() => onSetCurrentView('supplier-reports')}
                    className="w-full justify-start gap-3 h-12"
                  >
                    <Truck className="h-5 w-5" />
                    <div className="text-left">
                      <div className="font-medium">Supplier Reports</div>
                      <div className="text-xs text-gray-500">Analyze supplier performance</div>
                    </div>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}