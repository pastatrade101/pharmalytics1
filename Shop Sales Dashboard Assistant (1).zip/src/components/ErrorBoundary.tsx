import React, { Component, ReactNode } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { AlertTriangle, Copy, RotateCcw } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: any;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null };
  }

  componentDidCatch(error: Error, errorInfo: any) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
    this.state.error = error;
    this.state.errorInfo = errorInfo;
  }

  handleReload = () => {
    window.location.reload();
  };

  handleCopyError = () => {
    const errorText = `
Error: ${this.state.error?.message}
Stack: ${this.state.error?.stack}
Component Stack: ${this.state.errorInfo?.componentStack}
URL: ${window.location.href}
Timestamp: ${new Date().toISOString()}
    `.trim();
    
    navigator.clipboard.writeText(errorText).then(() => {
      alert('Error details copied to clipboard');
    });
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-red-50 to-red-100 flex items-center justify-center p-4">
          <Card className="max-w-2xl w-full">
            <CardHeader>
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-6 w-6 text-red-600" />
                <CardTitle className="text-red-900">Application Error</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Error:</strong> {this.state.error?.message || 'Unknown error occurred'}
                </AlertDescription>
              </Alert>

              <div className="space-y-2">
                <h4 className="font-medium text-gray-900">Error Details:</h4>
                <div className="bg-gray-100 p-3 rounded text-sm font-mono text-gray-800 max-h-40 overflow-auto">
                  <div><strong>Message:</strong> {this.state.error?.message}</div>
                  <div><strong>URL:</strong> {window.location.href}</div>
                  <div><strong>Timestamp:</strong> {new Date().toISOString()}</div>
                </div>
              </div>

              {this.state.error?.stack && (
                <details className="space-y-2">
                  <summary className="cursor-pointer font-medium text-gray-900">
                    Stack Trace (Click to expand)
                  </summary>
                  <div className="bg-gray-100 p-3 rounded text-xs font-mono text-gray-800 max-h-60 overflow-auto whitespace-pre-wrap">
                    {this.state.error.stack}
                  </div>
                </details>
              )}

              {this.state.errorInfo?.componentStack && (
                <details className="space-y-2">
                  <summary className="cursor-pointer font-medium text-gray-900">
                    Component Stack (Click to expand)
                  </summary>
                  <div className="bg-gray-100 p-3 rounded text-xs font-mono text-gray-800 max-h-40 overflow-auto whitespace-pre-wrap">
                    {this.state.errorInfo.componentStack}
                  </div>
                </details>
              )}

              <div className="flex gap-2">
                <Button onClick={this.handleReload} className="flex-1">
                  <RotateCcw className="mr-2 h-4 w-4" />
                  Reload Page
                </Button>
                <Button onClick={this.handleCopyError} variant="outline">
                  <Copy className="mr-2 h-4 w-4" />
                  Copy Error
                </Button>
              </div>

              <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded">
                <p className="text-blue-800 text-sm">
                  <strong>Next Steps:</strong>
                </p>
                <ul className="text-blue-700 text-sm mt-1 list-disc list-inside">
                  <li>Try refreshing the page</li>
                  <li>Check your internet connection</li>
                  <li>Verify Firebase configuration</li>
                  <li>Check browser console for additional errors</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}