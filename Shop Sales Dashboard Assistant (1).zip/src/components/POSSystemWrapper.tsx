import React, { useState, useEffect } from 'react';
import { Package, AlertTriangle, RefreshCw } from 'lucide-react';
import { POSSystem } from './POSSystem';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { toast } from 'sonner';
import { ProductsService } from '../lib/firebase-products';
import { SalesService } from '../lib/firebase-sales';
import { Product, Customer, Sale, UserProfile as UserProfileType } from '../lib/firebase-types';

interface POSSystemWrapperProps {
  userProfile: UserProfileType | null;
  onBack?: () => void;
  onSetCurrentView?: (view: any) => void;
  onSignOut?: () => void;
}

export function POSSystemWrapper({ 
  userProfile, 
  onBack, 
  onSetCurrentView, 
  onSignOut 
}: POSSystemWrapperProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [hasShopId, setHasShopId] = useState(false);

  // Check if user has shop assignment
  useEffect(() => {
    if (!userProfile) {
      setError('User profile not found');
      setIsLoading(false);
      return;
    }

    if (!userProfile.shop_id) {
      setError('No pharmacy assignment found. Please contact your pharmacy owner to assign you to a pharmacy.');
      setHasShopId(false);
      setIsLoading(false);
      return;
    }

    setHasShopId(true);
    loadPOSData();
  }, [userProfile]);

  // Load products and customers for POS
  const loadPOSData = async () => {
    if (!userProfile?.shop_id) {
      console.warn('⚠️ No shop_id available for loading POS data');
      return;
    }

    console.log('🔄 Loading POS data for shop:', userProfile.shop_id);
    setIsLoading(true);
    setError(null);

    try {
      // Load products and customers in parallel
      const [productsData, customersData] = await Promise.allSettled([
        ProductsService.getActiveProducts(userProfile.shop_id),
        // TODO: Add customers service when available
        Promise.resolve([]) // Placeholder for customers
      ]);

      // Handle products result
      if (productsData.status === 'fulfilled') {
        console.log('✅ Products loaded successfully:', productsData.value.length);
        setProducts(productsData.value);
        
        if (productsData.value.length === 0) {
          toast.info('No active products found', {
            description: 'Import or add products to your inventory to use the POS system.',
            duration: 6000,
            action: {
              label: 'Add Products',
              onClick: () => onSetCurrentView?.('products')
            }
          });
        }
      } else {
        console.error('❌ Failed to load products:', productsData.reason);
        
        if (productsData.reason?.isPermissionError || productsData.reason?.code === 'permission-denied') {
          setError('Permission denied: Firebase rules not deployed. Please deploy security rules to access your product data.');
          toast.error('🚨 Firebase Rules Required', {
            description: 'Deploy security rules to access your pharmacy products.',
            duration: 8000,
            action: {
              label: 'View Fix Guide',
              onClick: () => {
                window.open('/PRODUCT_PERMISSION_ROLES.md', '_blank');
              }
            }
          });
        } else {
          setError(`Failed to load products: ${productsData.reason?.message || 'Unknown error'}`);
        }
      }

      // Handle customers result (currently just empty array)
      if (customersData.status === 'fulfilled') {
        setCustomers(customersData.value);
      }

    } catch (error: any) {
      console.error('❌ Error loading POS data:', error);
      setError(`Failed to load POS data: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle sale completion
  const handleSaleComplete = async (saleData: Sale) => {
    if (!userProfile?.shop_id) {
      toast.error('Shop information not available');
      return;
    }
    
    // Validate user profile has required auth fields
    if (!userProfile.uid && !userProfile.id) {
      toast.error('User authentication information missing');
      console.error('❌ User profile missing uid/id fields:', userProfile);
      return;
    }
    
    // Validate cashier_id matches current user
    const expectedCashierId = userProfile.uid || userProfile.id;
    if (saleData.cashier_id !== expectedCashierId) {
      console.error('❌ Cashier ID mismatch:', {
        saleData_cashier_id: saleData.cashier_id,
        expected_cashier_id: expectedCashierId,
        userProfile_uid: userProfile.uid,
        userProfile_id: userProfile.id
      });
      toast.error('Authentication error: User ID mismatch');
      return;
    }
    
    // Validate transaction structure before processing sale
    console.log('🔍 Pre-transaction validation for sale:', {
      saleNumber: saleData.sale_number,
      itemsCount: saleData.items.length,
      totalPrice: saleData.total_price,
      cashierId: saleData.cashier_id,
      shopId: saleData.shop_id,
      authUid: userProfile.uid || userProfile.id
    });
    
    // Validate stock availability for all items before processing sale
    for (const item of saleData.items) {
      if (item.product_id) {
        // Note: This is a pre-validation. The actual stock check happens in the transaction
        // to ensure atomic consistency, but this helps catch obvious issues early
        console.log('🔍 Pre-validating item:', {
          productName: item.product_name,
          productId: item.product_id,
          requestedQuantity: item.quantity,
          unitPrice: item.unit_price,
          totalPrice: item.total
        });
        
        // Validate item structure
        if (!item.product_name || item.quantity <= 0 || item.unit_price < 0) {
          toast.error(`Invalid item data for ${item.product_name}`);
          console.error('❌ Invalid item structure:', item);
          return;
        }
      }
    }
    
    // Final validation before transaction
    if (!saleData.items.length) {
      toast.error('Cannot process sale with no items');
      return;
    }
    
    if (!saleData.sale_number || !saleData.cashier_id || !saleData.shop_id) {
      toast.error('Missing required sale information');
      console.error('❌ Missing required fields:', {
        hasSaleNumber: !!saleData.sale_number,
        hasCashierId: !!saleData.cashier_id,
        hasShopId: !!saleData.shop_id
      });
      return;
    }

    try {
      console.log('💰 Processing sale:', saleData.sale_number);
      
      // Show processing toast for better user feedback
      const totalAmount = saleData.total_amount || 0;
      const paymentMethod = saleData.payment_method || 'cash';
      
      toast.loading('Processing sale...', {
        description: `Processing payment of TZS ${totalAmount.toFixed(2)} via ${paymentMethod.toUpperCase()}`,
        duration: Infinity, // Keep showing until we dismiss it
        id: 'processing-sale' // Use ID to dismiss this specific toast later
      });
      
      // Save sale to database - this will handle stock updates internally
      const createdSale = await SalesService.createSale(saleData);
      
      console.log('✅ Sale created with ID:', createdSale?.id);
      
      // Reload products to reflect updated stock
      await loadPOSData();
      
      // Dismiss the processing toast
      toast.dismiss('processing-sale');
      
      // Calculate change if applicable - with safe defaults
      const paymentAmount = saleData.payment_amount || 0;
      const saleNumber = saleData.sale_number || 'Unknown';
      
      const changeAmount = paymentAmount - totalAmount;
      const changeText = changeAmount > 0 ? ` | Change: TZS ${changeAmount.toFixed(2)}` : '';
      
      toast.success('🎉 Sale Completed Successfully!', {
        description: `Sale #${saleNumber} • Total: TZS ${totalAmount.toFixed(2)} • Payment: ${paymentMethod.toUpperCase()}${changeText}`,
        duration: 6000,
        action: {
          label: 'Print Receipt',
          onClick: () => {
            // TODO: Implement receipt printing
            toast.info('Receipt printing not yet implemented');
          }
        }
      });
      
    } catch (error: any) {
      console.error('❌ Error completing sale:', error);
      
      // Dismiss the processing toast
      toast.dismiss('processing-sale');
      
      // Provide specific error messages based on error type
      let errorMessage = 'Please try again.';
      
      if (error?.message?.includes('shop_id is required')) {
        errorMessage = 'Shop information is missing. Please refresh and try again.';
      } else if (error?.message?.includes('cashier_id is required')) {
        errorMessage = 'User information is missing. Please sign out and back in.';
      } else if (error?.code === 'permission-denied') {
        if (error?.message?.includes('stock') || error?.message?.includes('product')) {
          errorMessage = 'Permission denied for stock updates. Your role may not have permission to update product inventory.';
        } else {
          errorMessage = 'Permission denied. Please ensure Firebase rules are deployed and your account has proper permissions.';
        }
      } else if (error?.code === 'invalid-argument') {
        if (error?.message?.includes('reads to be executed before all writes')) {
          errorMessage = 'Transaction error: Database operation order issue. This has been fixed - please try again.';
        } else {
          errorMessage = 'Invalid data provided. Please check all required fields.';
        }
      } else if (error?.code === 'unavailable') {
        errorMessage = 'Invalid data provided. Please check all required fields.';
      } else if (error?.message) {
        errorMessage = error.message;
      }
      
      toast.error('❌ Sale Failed', {
        description: errorMessage,
        duration: 8000,
        action: {
          label: 'Try Again',
          onClick: () => {
            // The sale will remain in the cart for the user to try again
            toast.info('Review your sale details and try processing the payment again');
          }
        }
      });
      
      throw error; // Re-throw so POS system can handle it
    }
  };

  // Error state - No shop assignment
  if (!hasShopId && !isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-50">
        <Card className="max-w-md mx-auto">
          <CardHeader className="text-center">
            <AlertTriangle className="h-16 w-16 text-orange-500 mx-auto mb-4" />
            <CardTitle>No Pharmacy Assignment</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-gray-600">
              You need to be assigned to a pharmacy before you can access the Point of Sale system.
            </p>
            <div className="text-sm text-gray-500">
              <p>Role: {userProfile?.role}</p>
              <p>Contact your pharmacy owner for assignment.</p>
            </div>
            <div className="space-y-2 pt-4">
              <Button onClick={onBack} variant="outline" className="w-full">
                ← Back to Dashboard
              </Button>
              {onSignOut && (
                <Button onClick={onSignOut} variant="ghost" size="sm" className="w-full">
                  Sign Out
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Loading state
  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-50">
        <Card className="max-w-md mx-auto">
          <CardContent className="text-center py-12">
            <RefreshCw className="h-16 w-16 text-blue-500 mx-auto mb-4 animate-spin" />
            <h2 className="text-xl font-semibold mb-2">Loading POS System</h2>
            <div className="space-y-2 text-sm text-gray-600">
              <p>✓ Connecting to pharmacy database</p>
              <p>⏳ Loading product inventory...</p>
              <p>⏳ Setting up point of sale...</p>
            </div>
            
            <div className="mt-6 text-xs text-gray-500">
              Shop: {userProfile?.shop?.name || userProfile?.shop_id}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Error state - Permission or loading errors
  if (error) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-50">
        <Card className="max-w-2xl mx-auto">
          <CardHeader className="text-center">
            <AlertTriangle className="h-16 w-16 text-red-500 mx-auto mb-4" />
            <CardTitle>POS System Error</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                {error}
              </AlertDescription>
            </Alert>

            {/* Specific help for permission errors */}
            {error.includes('permission') && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 className="font-semibold text-blue-900 mb-2">🔧 Quick Fix Required:</h3>
                <div className="text-sm text-blue-800 space-y-2">
                  <p>1. <strong>Deploy Firebase Rules:</strong> Run the deployment script</p>
                  <p>2. <strong>Wait 1-2 minutes</strong> for changes to take effect</p>
                  <p>3. <strong>Refresh this page</strong> or click "Retry" below</p>
                </div>
              </div>
            )}

            {/* Role-specific help */}
            {userProfile && (
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 text-sm">
                <div className="grid grid-cols-2 gap-4 text-gray-700">
                  <div>
                    <strong>Your Role:</strong> {userProfile.role}
                  </div>
                  <div>
                    <strong>Shop:</strong> {userProfile.shop?.name || 'Not assigned'}
                  </div>
                  <div>
                    <strong>Shop ID:</strong> {userProfile.shop_id || 'None'}
                  </div>
                  <div>
                    <strong>Products Loaded:</strong> {products.length}
                  </div>
                </div>
              </div>
            )}

            <div className="flex gap-3 justify-center">
              <Button onClick={loadPOSData} variant="default">
                <RefreshCw className="h-4 w-4 mr-2" />
                Retry Loading
              </Button>
              <Button onClick={onBack} variant="outline">
                ← Back to Dashboard
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Success state - Load POS system with data
  console.log('🎉 POS System ready with', products.length, 'products');
  
  return (
    <POSSystem
      userProfile={userProfile}
      products={products}
      customers={customers}
      isLoading={false}
      onBack={onBack}
      onSetCurrentView={onSetCurrentView}
      onSaleComplete={handleSaleComplete}
    />
  );
}