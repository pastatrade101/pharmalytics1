# 🚨 URGENT: Deploy Enhanced Firestore Rules to Fix Permission Errors

## Current Problem
Your pharmacy management system is encountering these permission errors:
```
❌ Listener sales_jBsPUd3a5t84QFQhW4rY error: permission-denied Missing or insufficient permissions.
❌ Error in managed sales subscription: FirebaseError: [code=permission-denied]: Missing or insufficient permissions.
❌ Error in real-time sales subscription: FirebaseError: [code=permission-denied]: Missing or insufficient permissions.
```

## Solution: Deploy Enhanced Firestore Security Rules

The new rules provide:
- ✅ **Role-based Access Control**: Proper permissions for admin, owner, manager, cashier, seller
- ✅ **Shop-based Data Isolation**: Users only access their shop's data
- ✅ **Real-time Subscriptions**: Fixed permission errors for sales listeners
- ✅ **Comprehensive Security**: All pharmacy collections properly protected
- ✅ **Backward Compatibility**: Supports existing data structures

### Quick Deploy (Recommended)

```bash
# 1. Ensure Firebase CLI is installed
npm install -g firebase-tools

# 2. Login to Firebase (if not already)
firebase login

# 3. Set your project
firebase use YOUR_PROJECT_ID

# 4. Deploy the rules
firebase deploy --only firestore:rules
```

### Alternative: Firebase Console Deploy

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Select your project
3. Navigate to **Firestore Database** → **Rules**
4. Copy the entire content from `/firestore.rules` file
5. Paste it in the rules editor
6. Click **Publish**

## What These Rules Enable

### ✅ **Enhanced User Roles**
- **Admin**: Full system access across all shops
- **Owner**: Business analytics, user management, and shop oversight
- **Manager**: Inventory management, product catalog, and sales operations
- **Cashier**: Point of sale, customer management, and prescription handling
- **Seller**: Basic sales recording and product lookup

### ✅ **Pharmacy Collections Fully Supported**
- **Products**: Pharmaceutical catalog with batch tracking
- **Sales**: POS transactions with real-time subscriptions ✅
- **Customers**: Customer accounts and insurance information
- **Prescriptions**: Prescription tracking and dispensing
- **Product Batches**: Expiry management and lot tracking
- **Suppliers**: Supplier relationship management
- **Stock Movements**: Inventory tracking and audit trail
- **Purchase Orders**: Procurement management
- **Stock Transfers**: Inter-branch operations
- **Return Transactions**: Returns and refunds processing
- **Insurance Claims**: Insurance billing support
- **Branches**: Multi-location pharmacy chains
- **Daily Reports**: AI-generated analytics
- **Notifications**: System alerts and warnings
- **Audit Logs**: Security and compliance tracking

### ✅ **Security Features**
- **Shop Data Isolation**: Users only see their shop's data
- **Real-time Access**: Sales subscriptions work without permission errors
- **Role Enforcement**: Proper permissions prevent unauthorized access
- **Audit Trail**: All actions tracked for compliance
- **Legacy Support**: Existing collections still work

## Verification Steps

After deployment, these operations should work without permission errors:

### 1. **User Profile Loading**
```javascript
// Should work for all authenticated users
const profile = await FirebaseService.getCurrentUserProfile();
```

### 2. **Sales Data Access** ✅ (Fixes your main error)
```javascript
// Should work without permission-denied errors
const salesListener = SalesService.subscribeToSales(shopId, callback);
```

### 3. **Product Management**
```javascript
// Should work for managers and owners
await ProductService.createProduct(productData);
```

### 4. **POS Operations**
```javascript
// Should work for cashiers and sellers
await SalesService.processSale(saleData);
```

## Required User Profile Structure

For the rules to work properly, ensure user profiles have these fields:

```javascript
{
  id: "user_id",
  email: "user@example.com",
  full_name: "User Name",
  role: "owner", // or "admin", "manager", "cashier", "seller"
  shop_id: "shop_123", // Required for non-admin users
  branch_id: "branch_456", // Optional for multi-branch
  is_active: true,
  created_at: "2024-01-15T10:30:00Z",
  updated_at: "2024-01-15T10:30:00Z"
}
```

## Troubleshooting

### If you still get permission errors:

1. **Check User Profile Structure**
   ```bash
   # Verify user has proper role and shop_id
   firebase firestore:data:get profiles/USER_ID
   ```

2. **Verify Rules Deployment**
   ```bash
   firebase firestore:rules:get
   ```

3. **Test Shop Assignment**
   ```javascript
   // Ensure user is assigned to a shop
   if (!userProfile.shop_id && userProfile.role !== 'admin') {
     // User needs shop assignment
   }
   ```

### Common Issues:

**Issue**: "Permission denied" still occurs
**Solution**: 
- Check if user profile exists and has correct `role` and `shop_id`
- Ensure shop document exists in `/shops/{shopId}`
- Verify the user is authenticated

**Issue**: "Failed to get document" for profiles
**Solution**: User needs to complete profile creation

**Issue**: Sales subscriptions fail
**Solution**: Ensure sales documents have `shop_id` field that matches user's shop

## Testing the Deployment

Run these commands to verify everything works:

```bash
# Test basic connectivity
firebase firestore:data:get profiles --limit 1

# Check a specific user profile
firebase firestore:data:get profiles/YOUR_USER_ID

# Verify shop access
firebase firestore:data:get shops/YOUR_SHOP_ID
```

## Role Assignment Guide

### For Shop Owners:
1. Sign up creates `owner` role automatically
2. Create shop document with `owner_id` field
3. Assign staff to shop via User Management

### For Staff Members:
1. Admin/Owner creates user with appropriate role
2. Assigns `shop_id` to link user to shop
3. User can then access shop-specific data

## Emergency Rollback

If you need to rollback to simple rules temporarily:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

**Deploy this temporarily if needed, but use enhanced rules for production security.**

## Next Steps After Successful Deployment

1. **Test All Pharmacy Features**:
   - POS system operations
   - Inventory management
   - Product catalog access
   - Reports and analytics
   - User management

2. **Verify Role-based Access**:
   - Test with different user roles
   - Ensure proper data isolation
   - Check that permissions work correctly

3. **Monitor for Issues**:
   - Check browser console for errors
   - Verify real-time subscriptions work
   - Test offline functionality

**Your pharmacy management system should work perfectly with these comprehensive security rules!** 🎉

The permission-denied errors will be completely resolved while maintaining proper security for your pharmacy operations.