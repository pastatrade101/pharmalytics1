# 🚨 URGENT: Firebase Permission Fix Guide

## Problem Summary
Your pharmacy management system is experiencing permission-denied errors when trying to create products. This is preventing product imports and other critical operations.

## Root Cause
**Firebase Firestore security rules are not deployed** to your Firebase project. Without these rules, Firestore blocks all operations by default.

## Immediate Solution

### Step 1: Verify Project Structure
```bash
# Check you're in the correct directory
pwd

# Verify these files exist
ls -la firebase.json firestore.rules
```

### Step 2: Login to Firebase
```bash
# Login to Firebase CLI
firebase login

# Verify you're logged in
firebase projects:list
```

### Step 3: Select Your Project
```bash
# List available projects
firebase projects:list

# Use your project (replace YOUR_PROJECT_ID with actual project ID)
firebase use YOUR_PROJECT_ID

# Verify current project
firebase use --current
```

### Step 4: Deploy Security Rules
```bash
# Deploy ONLY the Firestore rules
firebase deploy --only firestore:rules
```

**Expected Output:**
```
=== Deploying to 'your-project-id'...

i  deploying firestore
i  firestore: checking firestore.rules for compilation errors...
✔  firestore: rules file firestore.rules compiled successfully
i  firestore: uploading rules firestore.rules...
✔  firestore: released rules firestore.rules to cloud.firestore

✔  Deploy complete!
```

### Step 5: Verify Deployment
1. Refresh your web application
2. Run the Firebase Permission Tester
3. Try importing products again

## Troubleshooting

### Error: "No project selected"
```bash
firebase use --add
# Select your project from the list
```

### Error: "Permission denied"
```bash
# Re-authenticate
firebase login --reauth
```

### Error: "Rules compilation failed"
Check your `firestore.rules` file for syntax errors. The rules should start with:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Your rules here
  }
}
```

### Error: "Firebase CLI not found"
```bash
# Install Firebase CLI
npm install -g firebase-tools

# Or using yarn
yarn global add firebase-tools
```

## Verification Steps

### 1. Check Firebase Console
1. Go to [Firebase Console](https://console.firebase.google.com)
2. Select your project
3. Navigate to Firestore Database > Rules
4. Verify rules are deployed with recent timestamp

### 2. Test in Application
1. Use the Enhanced Firebase Permission Tester
2. All tests should pass
3. Product import should work

### 3. Automated Verification
```bash
# Run the verification script
node scripts/verify-firebase-deployment.js
```

## Quick Fix Scripts

### Make Deploy Script Executable
```bash
chmod +x scripts/deploy-rules-fix.sh
./scripts/deploy-rules-fix.sh
```

### Manual Rule Deployment
```bash
# Force deploy with fresh rules
firebase deploy --only firestore:rules --force
```

## Environment Variables Check

Ensure these are set in your `.env.local`:
```env
NEXT_PUBLIC_FIREBASE_API_KEY=your_api_key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_project_id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your_project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
NEXT_PUBLIC_FIREBASE_APP_ID=your_app_id
```

## Common Issues and Solutions

### Issue: Rules deployed but still getting errors
**Solution:** Wait 1-2 minutes for rules to propagate globally, then refresh your browser.

### Issue: User profile not found
**Solution:** Ensure your user profile document exists in Firestore with correct fields:
- `role`: 'admin', 'owner', or 'manager' for product creation
- `shop_id`: Valid shop ID you belong to
- `email`: Your email address

### Issue: Shop assignment problems
**Solution:** Contact your system administrator to assign you to a shop.

### Issue: Wrong user role
**Solution:** You need 'admin', 'owner', or 'manager' role to create products. Contact admin to update your role.

## Prevention

### Always Deploy Rules When:
1. Setting up a new Firebase project
2. Modifying security rules
3. Adding new collections or features
4. Switching between environments

### Automated Deployment
Add to your CI/CD pipeline:
```yaml
# GitHub Actions example
- name: Deploy Firebase Rules
  run: |
    npm install -g firebase-tools
    firebase deploy --only firestore:rules --token ${{ secrets.FIREBASE_TOKEN }}
```

## Emergency Contacts

If this guide doesn't resolve the issue:
1. Check all files are present and correct
2. Verify your Firebase project permissions
3. Contact your Firebase project administrator
4. Review the detailed error logs in the debug panel

## Success Indicators

✅ Firebase CLI commands work without errors
✅ `firebase deploy --only firestore:rules` completes successfully
✅ Firebase Console shows rules with recent timestamp
✅ Permission Tester shows all tests passing
✅ Product import works without errors
✅ No more "permission-denied" errors in console

---

**⏰ This fix usually takes 2-5 minutes to complete and resolves 95% of permission issues.**