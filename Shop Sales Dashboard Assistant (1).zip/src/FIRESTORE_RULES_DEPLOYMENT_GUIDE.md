# 🔥 Firestore Security Rules Deployment Guide

## ⚠️ CRITICAL: These rules MUST be deployed to Firebase Console to fix permission errors

### Current Status:
- **❌ Permission Denied Errors** - Rules not deployed
- **❌ Product Management Blocked** - No access permissions
- **❌ User Management Blocked** - Database operations failing

### 🎯 Step-by-Step Deployment Instructions:

#### 1. **Open Firebase Console**
   - Go to [Firebase Console](https://console.firebase.google.com)
   - Select your `shopsalesai` project

#### 2. **Navigate to Firestore Database**
   - Click **"Firestore Database"** in left sidebar
   - Click **"Rules"** tab at the top

#### 3. **Replace Current Rules**
   - **DELETE** all existing rules in the editor
   - **COPY** the complete rules below and paste them

#### 4. **Deploy Rules**
   - Click **"Publish"** button
   - Confirm deployment

---

## 📋 Complete Firestore Security Rules (Copy This Entire Block)

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Helper function to check if user is authenticated
    function isAuthenticated() {
      return request.auth != null;
    }
    
    // Helper function to get user profile
    function getUserProfile() {
      return get(/databases/$(database)/documents/profiles/$(request.auth.uid)).data;
    }
    
    // Helper function to check user role
    function hasRole(role) {
      return isAuthenticated() && getUserProfile().role == role;
    }
    
    // Helper function to check if user belongs to shop
    function belongsToShop(shopId) {
      return isAuthenticated() && getUserProfile().shop_id == shopId;
    }
    
    // Helper function to check if user is shop owner
    function isShopOwner(shopId) {
      return isAuthenticated() && 
             hasRole('owner') && 
             belongsToShop(shopId);
    }
    
    // User Profiles Collection
    match /profiles/{userId} {
      // Users can read their own profile
      allow read: if isAuthenticated() && request.auth.uid == userId;
      
      // Users can create their own profile during signup
      allow create: if isAuthenticated() && 
                       request.auth.uid == userId &&
                       request.auth.uid == resource.id;
      
      // Users can update their own profile
      allow update: if isAuthenticated() && request.auth.uid == userId;
      
      // Shop owners can read profiles of users in their shop
      allow read: if isAuthenticated() && 
                     hasRole('owner') && 
                     resource.data.shop_id == getUserProfile().shop_id;
      
      // Shop owners can update profiles of users in their shop (for assignments)
      allow update: if isAuthenticated() && 
                       hasRole('owner') && 
                       (resource.data.shop_id == getUserProfile().shop_id || 
                        resource.data.shop_id == null);
      
      // Additional rule for owners to see unassigned users for shop management
      allow read: if isAuthenticated() && 
                     hasRole('owner') && 
                     (resource.data.shop_id == null || 
                      resource.data.shop_id == getUserProfile().shop_id);
    }
    
    // Shops Collection
    match /shops/{shopId} {
      // Shop owners can read their own shop
      allow read: if isAuthenticated() && 
                     hasRole('owner') && 
                     resource.data.owner_id == request.auth.uid;
      
      // Shop owners can create their own shop
      allow create: if isAuthenticated() && 
                       hasRole('owner') && 
                       request.auth.uid == resource.data.owner_id;
      
      // Shop owners can update their own shop
      allow update: if isAuthenticated() && 
                       hasRole('owner') && 
                       resource.data.owner_id == request.auth.uid;
      
      // All shop members can read shop info
      allow read: if belongsToShop(shopId);
    }
    
    // Sales Collection
    match /sales/{saleId} {
      // All shop members can read sales from their shop
      allow read: if belongsToShop(resource.data.shop_id);
      
      // Sellers and managers can create sales for their shop
      allow create: if isAuthenticated() && 
                       (hasRole('seller') || hasRole('manager')) &&
                       belongsToShop(resource.data.shop_id) &&
                       resource.data.seller_id == request.auth.uid;
      
      // Sellers can update their own sales, managers can update any sales in their shop
      allow update: if isAuthenticated() && 
                       ((hasRole('seller') && resource.data.seller_id == request.auth.uid) ||
                        (hasRole('manager') && belongsToShop(resource.data.shop_id)));
      
      // Shop owners can read/write all sales in their shop
      allow read, write: if isShopOwner(resource.data.shop_id);
    }
    
    // Products Collection - CRITICAL FOR FIXING YOUR ERRORS
    match /products/{productId} {
      // All shop members can read products from their shop
      allow read: if belongsToShop(resource.data.shop_id);
      
      // Only managers and owners can create/update products
      allow create, update: if isAuthenticated() && 
                               (hasRole('manager') || hasRole('owner')) &&
                               belongsToShop(resource.data.shop_id);
      
      // Only owners can delete products
      allow delete: if isShopOwner(resource.data.shop_id);
    }
    
    // Daily Reports Collection
    match /daily_reports/{reportId} {
      // All shop members can read daily reports from their shop
      allow read: if belongsToShop(resource.data.shop_id);
      
      // Only owners can create daily reports
      allow create: if isShopOwner(resource.data.shop_id);
      
      // Only owners can update/delete daily reports
      allow update, delete: if isShopOwner(resource.data.shop_id);
    }
    
    // Inventory Collection (if needed)
    match /inventory/{inventoryId} {
      // All shop members can read inventory from their shop
      allow read: if belongsToShop(resource.data.shop_id);
      
      // Managers and owners can create/update inventory
      allow create, update: if isAuthenticated() && 
                               (hasRole('manager') || hasRole('owner')) &&
                               belongsToShop(resource.data.shop_id);
      
      // Only owners can delete inventory
      allow delete: if isShopOwner(resource.data.shop_id);
    }
    
    // Analytics and Reports (additional collections if needed)
    match /analytics/{analyticsId} {
      allow read, write: if belongsToShop(resource.data.shop_id);
    }
    
    // User Sessions (if tracking user activity)
    match /user_sessions/{sessionId} {
      allow read, write: if isAuthenticated() && 
                            resource.data.user_id == request.auth.uid;
    }
    
    // System Settings (read-only for all authenticated users)
    match /system_settings/{settingId} {
      allow read: if isAuthenticated();
    }
    
    // Notifications Collection
    match /notifications/{notificationId} {
      allow read: if isAuthenticated() && 
                     resource.data.user_id == request.auth.uid;
      allow create: if isAuthenticated();
      allow update: if isAuthenticated() && 
                       resource.data.user_id == request.auth.uid;
    }
  }
}
```

---

## ✅ After Deployment Verification

### 1. **Check Rules Status**
   - In Firebase Console, Rules tab should show **"Last published"** timestamp
   - Status should show **"✅ Published"**

### 2. **Test Your Application**
   - Refresh your Shop Sales Dashboard
   - Try accessing Product Management as a manager/owner
   - Errors should be resolved

### 3. **Monitor Debug Panel**
   - Watch for permission errors in your app's debug panel
   - Should see successful operations in console logs

---

## 🚨 Common Issues & Solutions

### Issue: "Syntax error in rules"
**Solution:** Make sure you copied the ENTIRE rules block exactly as shown above

### Issue: "Rules still not working"
**Solutions:**
1. Clear browser cache and reload
2. Wait 1-2 minutes for rules to propagate
3. Check user role assignment in debug panel

### Issue: "Still getting permission denied"
**Check:**
1. User has correct role (manager/owner for products)
2. User is assigned to a shop (`shop_id` is not null)
3. Rules were published successfully

---

## 📊 Role Permissions Summary

| Role | Products | Sales | Users | Reports |
|------|----------|-------|-------|---------|
| **Owner** | ✅ Full Access | ✅ Full Access | ✅ Full Access | ✅ Full Access |
| **Manager** | ✅ Create/Update | ✅ Create/Update | ❌ No Access | ✅ Read Only |
| **Seller** | ✅ Read Only | ✅ Create/Update Own | ❌ No Access | ✅ Read Only |

---

## 🎯 Next Steps

1. **Deploy the rules** using the steps above
2. **Test product management** in your app
3. **Verify all operations** work without permission errors
4. **Monitor the debug panel** for any remaining issues

⚠️ **IMPORTANT:** Your app will not function properly until these rules are deployed to Firebase Console!