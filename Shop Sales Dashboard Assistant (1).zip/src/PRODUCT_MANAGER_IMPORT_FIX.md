# Product Manager Import Permission Fix

## Problem
Users with the `product_manager` role were getting permission denied errors when trying to import products, with the error message:
```
"Required roles: manager, owner, admin"
```

## Solution Applied
Updated all permission checking layers to include `product_manager` role:

### 1. Updated Firestore Rules
- ✅ Updated `canManageProducts()` helper function to include `product_manager`
- ✅ Updated `canPerformSales()` helper function to include `product_manager`  
- ✅ Updated `canAccessReports()` helper function to include `product_manager`
- ✅ Removed references to old `manager` role throughout rules
- ✅ Added explicit `product_manager` permissions for all product operations

### 2. Updated Client-Side Code
- ✅ Added `canImportProducts()` function in app-constants.ts
- ✅ Added `canManageProducts()` function in app-constants.ts
- ✅ Updated Firebase service to use standardized permission functions
- ✅ Added client-side permission validation in import dialog
- ✅ Added permission checking to import button in ProductManager

### 3. Updated Permission Constants
- ✅ Added standardized permission functions in app-constants.ts
- ✅ Imported and used consistent permission checking across components

## Deployment Instructions

### Step 1: Deploy Firestore Rules
```bash
# Navigate to project root
cd /path/to/pharmacy-management-system

# Deploy the updated rules
./scripts/deploy-product-manager-rules.sh

# OR manually deploy
firebase deploy --only firestore:rules
```

### Step 2: Verify Rules Deployment
```bash
# Check current rules
firebase firestore:rules get

# Should show updated rules with product_manager role included
```

### Step 3: Clear Browser Cache
- Clear browser cache to ensure no cached validation logic
- Hard refresh the application (Ctrl+F5 or Cmd+Shift+R)
- Sign out and sign back in to refresh user profile

### Step 4: Test Import Functionality
1. Log in as a user with `product_manager` role
2. Navigate to Product Management
3. Click "Import from File" button
4. Should open import dialog without permission error
5. Test the actual import process with a CSV file

## Troubleshooting

### If Error Persists:

1. **Check User Profile Role:**
   ```javascript
   // In browser console
   console.log(userProfile.role); // Should show 'product_manager'
   ```

2. **Verify Rules Deployment:**
   ```bash
   firebase firestore:rules get | grep -A5 -B5 "product_manager"
   ```

3. **Clear All Cache:**
   - Clear browser cache and cookies
   - Sign out completely and sign back in
   - Try in incognito/private browsing mode

4. **Check Firebase Console:**
   - Go to Firebase Console → Firestore → Rules
   - Verify the rules show `product_manager` role
   - Check the deployment timestamp

### If Import Still Fails:

The error might be coming from a different validation layer. Check:
- Network tab for actual API errors
- Browser console for detailed error messages
- Firebase Console → Authentication → Users (verify user role)

## Updated Permissions Summary

### product_manager Role Can Now:
- ✅ Import products from CSV/Excel files
- ✅ Create new products manually
- ✅ Update existing products
- ✅ Delete products
- ✅ Manage product batches
- ✅ Handle stock movements
- ✅ Process sales transactions
- ✅ Manage customers
- ✅ Handle prescriptions
- ✅ Access inventory reports
- ✅ Manage suppliers
- ✅ Handle returns and refunds

### Roles Hierarchy (Updated):
1. **super_admin** - Full system access
2. **admin** - Full pharmacy management
3. **owner** - Business oversight and user management
4. **product_manager** - Complete operational management
5. **salesman** - Customer-facing sales operations

## Files Modified:
- `/firestore.rules` - Updated all permission functions
- `/lib/app-constants.ts` - Added standardized permission functions
- `/lib/firebase.ts` - Updated to use new permission functions
- `/components/FileImportDialog.tsx` - Added client-side validation
- `/components/ProductManager.tsx` - Added button permission checking
- `/scripts/deploy-product-manager-rules.sh` - New deployment script

## Next Steps:
1. Deploy the updated rules using the script above
2. Clear browser cache and test import functionality
3. If issues persist, check troubleshooting section above
4. Contact support with specific error messages if problems continue