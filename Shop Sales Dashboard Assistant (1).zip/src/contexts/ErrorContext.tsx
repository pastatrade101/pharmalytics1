import React, { createContext, useContext, useState, ReactNode, useCallback, useMemo } from 'react';

// Enhanced error types with more specific categorization
export type ErrorType = 'error' | 'warning' | 'info' | 'success';
export type ErrorCategory = 'permission' | 'index' | 'network' | 'validation' | 'auth' | 'general';

export interface AppError {
  id: string;
  type: ErrorType;
  category: ErrorCategory;
  title: string;
  message: string;
  context?: string;
  timestamp: number;
  originalError?: any;
  action?: string;
  instructions?: string;
}

interface ErrorContextType {
  errors: AppError[];
  addError: (error: any, context?: string, customMessage?: string) => void;
  addWarning: (title: string, context?: string, message?: string) => void;
  addInfo: (title: string, context?: string, message?: string) => void;
  addSuccess: (title: string, context?: string, message?: string) => void;
  removeError: (id: string) => void;
  clearErrors: () => void;
  clearErrorsByType: (type: ErrorType) => void;
  clearErrorsByContext: (context: string) => void;
  clearErrorsByCategory: (category: ErrorCategory) => void;
  hasErrors: () => boolean;
  hasErrorsOfType: (type: ErrorType) => boolean;
  hasErrorsOfCategory: (category: ErrorCategory) => boolean;
  hasErrorsInContext: (context: string) => boolean;
  getLatestError: () => AppError | null;
  getPermissionErrors: () => AppError[];
  getIndexErrors: () => AppError[];
  getErrorsByContext: (context: string) => AppError[];
}

const ErrorContext = createContext<ErrorContextType | undefined>(undefined);

// Helper function to categorize errors
function categorizeError(error: any, context?: string): ErrorCategory {
  const errorMessage = error?.message || String(error) || '';
  const contextLower = context?.toLowerCase() || '';
  
  // Permission errors
  if (errorMessage.includes('permission-denied') || 
      errorMessage.includes('Missing or insufficient permissions') ||
      errorMessage.includes('FirebaseError: Missing or insufficient permissions') ||
      contextLower.includes('permission')) {
    return 'permission';
  }
  
  // Index errors
  if (errorMessage.includes('requires an index') || 
      errorMessage.includes('composite index') ||
      errorMessage.includes('The query requires a index') ||
      contextLower.includes('index')) {
    return 'index';
  }
  
  // Network errors
  if (errorMessage.includes('network') || 
      errorMessage.includes('fetch') ||
      errorMessage.includes('timeout') ||
      errorMessage.includes('connection') ||
      contextLower.includes('network')) {
    return 'network';
  }
  
  // Validation errors
  if (errorMessage.includes('validation') || 
      errorMessage.includes('invalid') ||
      errorMessage.includes('required') ||
      contextLower.includes('validation')) {
    return 'validation';
  }
  
  // Auth errors
  if (contextLower.includes('auth') || 
      errorMessage.includes('auth') ||
      errorMessage.includes('authentication') ||
      errorMessage.includes('unauthorized')) {
    return 'auth';
  }
  
  return 'general';
}

// Helper function to generate error instructions
function generateErrorInstructions(category: ErrorCategory, error: any): string {
  switch (category) {
    case 'permission':
      return 'Deploy Firebase security rules using the deployment modal or check the Firebase console.';
    case 'index':
      return 'Create required Firestore indexes by clicking the provided links or check the Firebase console.';
    case 'network':
      return 'Check your internet connection and try again. If the problem persists, try refreshing the page.';
    case 'validation':
      return 'Check the input data format and ensure all required fields are properly filled.';
    case 'auth':
      return 'Try signing out and signing back in. If the problem persists, clear your browser cache.';
    default:
      return 'Review the error details and try refreshing the page. Contact support if the issue persists.';
  }
}

export function ErrorProvider({ children }: { children: ReactNode }) {
  const [errors, setErrors] = useState<AppError[]>([]);

  // Memoized helper functions to prevent unnecessary re-renders
  const addError = useCallback((error: any, context?: string, customMessage?: string) => {
    const category = categorizeError(error, context);
    const errorMessage = error?.message || String(error) || 'Unknown error';
    
    const newError: AppError = {
      id: `error-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: 'error',
      category,
      title: customMessage || `${context || 'System'} Error`,
      message: customMessage || errorMessage,
      context,
      timestamp: Date.now(),
      originalError: error,
      action: 'Review Error Details',
      instructions: generateErrorInstructions(category, error)
    };

    console.error(`[${context || 'ERROR'}] ${newError.type.toUpperCase()}:`, {
      message: newError.message,
      type: newError.type,
      action: newError.action,
      instructions: newError.instructions,
      originalError: error
    });

    setErrors(prev => [newError, ...prev.slice(0, 49)]); // Keep last 50 errors
  }, []);

  const addWarning = useCallback((title: string, context?: string, message?: string) => {
    const newError: AppError = {
      id: `warning-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: 'warning',
      category: 'general',
      title,
      message: message || title,
      context,
      timestamp: Date.now(),
      action: 'Review Warning Details',
      instructions: 'This is a warning that may require your attention but does not prevent normal operation.'
    };

    console.warn(`[${context || 'WARNING'}] ${newError.type.toUpperCase()}:`, {
      message: newError.message,
      type: newError.type,
      action: newError.action,
      instructions: newError.instructions
    });

    setErrors(prev => [newError, ...prev.slice(0, 49)]);
  }, []);

  const addInfo = useCallback((title: string, context?: string, message?: string) => {
    const newError: AppError = {
      id: `info-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: 'info',
      category: 'general',
      title,
      message: message || title,
      context,
      timestamp: Date.now(),
      action: 'Information',
      instructions: 'This is an informational message to keep you updated on system status.'
    };

    console.info(`[${context || 'INFO'}] ${newError.type.toUpperCase()}:`, {
      message: newError.message,
      type: newError.type,
      action: newError.action,
      instructions: newError.instructions
    });

    setErrors(prev => [newError, ...prev.slice(0, 49)]);
  }, []);

  const addSuccess = useCallback((title: string, context?: string, message?: string) => {
    const newError: AppError = {
      id: `success-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: 'success',
      category: 'general',
      title,
      message: message || title,
      context,
      timestamp: Date.now(),
      action: 'Success',
      instructions: 'Operation completed successfully.'
    };

    console.log(`[${context || 'SUCCESS'}] ${newError.type.toUpperCase()}:`, {
      message: newError.message,
      type: newError.type,
      action: newError.action,
      instructions: newError.instructions
    });

    setErrors(prev => [newError, ...prev.slice(0, 49)]);
  }, []);

  const removeError = useCallback((id: string) => {
    setErrors(prev => prev.filter(error => error.id !== id));
  }, []);

  const clearErrors = useCallback(() => {
    setErrors([]);
  }, []);

  const clearErrorsByType = useCallback((type: ErrorType) => {
    setErrors(prev => prev.filter(error => error.type !== type));
  }, []);

  const clearErrorsByContext = useCallback((context: string) => {
    setErrors(prev => prev.filter(error => error.context !== context));
  }, []);

  const clearErrorsByCategory = useCallback((category: ErrorCategory) => {
    setErrors(prev => prev.filter(error => error.category !== category));
  }, []);

  // Memoized getter functions
  const hasErrors = useCallback(() => errors.length > 0, [errors.length]);
  
  const hasErrorsOfType = useCallback((type: ErrorType) => 
    errors.some(error => error.type === type), [errors]);
  
  const hasErrorsOfCategory = useCallback((category: ErrorCategory) => 
    errors.some(error => error.category === category), [errors]);
  
  const getLatestError = useCallback(() => 
    errors.length > 0 ? errors[0] : null, [errors]);
  
  const getPermissionErrors = useCallback(() => 
    errors.filter(error => error.category === 'permission'), [errors]);
  
  const getIndexErrors = useCallback(() => 
    errors.filter(error => error.category === 'index'), [errors]);

  const hasErrorsInContext = useCallback((context: string) => 
    errors.some(error => error.context === context), [errors]);
  
  const getErrorsByContext = useCallback((context: string) => 
    errors.filter(error => error.context === context), [errors]);

  // Memoize the context value to prevent unnecessary re-renders
  const contextValue = useMemo(() => ({
    errors,
    addError,
    addWarning,
    addInfo,
    addSuccess,
    removeError,
    clearErrors,
    clearErrorsByType,
    clearErrorsByContext,
    clearErrorsByCategory,
    hasErrors,
    hasErrorsOfType,
    hasErrorsOfCategory,
    hasErrorsInContext,
    getLatestError,
    getPermissionErrors,
    getIndexErrors,
    getErrorsByContext
  }), [
    errors,
    addError,
    addWarning,
    addInfo,
    addSuccess,
    removeError,
    clearErrors,
    clearErrorsByType,
    clearErrorsByContext,
    clearErrorsByCategory,
    hasErrors,
    hasErrorsOfType,
    hasErrorsOfCategory,
    hasErrorsInContext,
    getLatestError,
    getPermissionErrors,
    getIndexErrors,
    getErrorsByContext
  ]);

  return (
    <ErrorContext.Provider value={contextValue}>
      {children}
    </ErrorContext.Provider>
  );
}

export function useError() {
  const context = useContext(ErrorContext);
  if (context === undefined) {
    throw new Error('useError must be used within an ErrorProvider');
  }
  return context;
}