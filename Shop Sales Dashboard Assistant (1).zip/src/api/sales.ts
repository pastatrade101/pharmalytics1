// MOVED TO APP ROUTER: /app/api/sales/route.ts
// This file has been removed to prevent routing conflicts