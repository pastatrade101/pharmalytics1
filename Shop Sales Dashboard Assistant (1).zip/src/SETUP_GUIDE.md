# Shop Sales Dashboard - Setup Guide

## Quick Start

### 1. Firebase Setup

1. **Create Firebase Project**
   - Go to [Firebase Console](https://console.firebase.google.com/)
   - Click "Add project" or select existing project
   - Follow the setup wizard

2. **Enable Required Services**
   - **Authentication**: Go to Authentication > Sign-in method > Enable "Email/Password"
   - **Firestore**: Go to Firestore Database > Create database > Start in test mode

3. **Get Configuration**
   - Go to Project Settings (gear icon) > General tab
   - Scroll to "Your apps" section
   - Add a web app or find existing web app
   - Copy the config object

4. **Environment Variables**
   - Copy `.env.example` to `.env.local`
   - Fill in your Firebase configuration values
   - Make sure all `VITE_FIREBASE_*` variables are set (Vite requires the VITE_ prefix)

### 2. Application Features

#### User Roles & Access:

**Shop Owner** (Self-Registration)
- Complete business dashboard access
- Team member creation and management
- Analytics and reporting
- Strategic oversight

**Product Manager** (Created by Owner)
- Full product catalog management
- Inventory control and pricing
- Secondary sales recording capability
- Operational product lifecycle management

**Salesman** (Created by Owner)
- Primary sales transaction recording
- Customer interaction management
- Daily sales activities
- Transaction tracking and processing

### 3. Getting Started

1. **Owner Registration**
   - Use the signup form to register as a shop owner
   - Complete shop information and business settings
   - Your account gets immediate access to all owner features

2. **Team Creation**
   - Access User Management from the owner dashboard
   - Create accounts for Product Managers and Salesmen
   - Each created user gets instant login credentials
   - Team members can log in immediately with provided credentials

3. **Daily Operations**
   - **Salesmen**: Record sales transactions
   - **Product Managers**: Manage inventory and product catalog
   - **Owners**: Monitor analytics and manage team

### 4. Troubleshooting

**Firebase Connection Issues:**
- Verify all environment variables are set correctly with `VITE_` prefix
- Check that Authentication and Firestore are enabled
- Ensure Firebase project has the web app configured

**Authentication Errors:**
- Make sure Email/Password is enabled in Firebase Authentication
- Check that user accounts exist and passwords are correct
- Verify Firebase configuration values are accurate

**User Access Issues:**
- Owners: Can access all features immediately after registration
- Team Members: Must be created by shop owner through User Management
- Check that user roles are assigned correctly

**Environment Variable Issues:**
- This project uses Vite, so all variables must be prefixed with `VITE_`
- Variables without the `VITE_` prefix will not be available in the browser
- Make sure your `.env.local` file uses the correct naming convention

### 5. Environment Variables Reference

```bash
# Required Firebase Configuration (Vite format)
VITE_FIREBASE_API_KEY=your_api_key_here
VITE_FIREBASE_AUTH_DOMAIN=your_project_id.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your_project_id
VITE_FIREBASE_STORAGE_BUCKET=your_project_id.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
VITE_FIREBASE_APP_ID=your_app_id

# Optional AI Features
VITE_OPENAI_API_KEY=your_openai_api_key_here
GEMINI_API_KEY=your_gemini_api_key_here
```

**Important Notes:**
- Frontend variables (Firebase config) must be prefixed with `VITE_` for Vite to expose them to the browser
- Backend variables (API keys) like `GEMINI_API_KEY` should NOT have the `VITE_` prefix for security
- Variables without the proper prefix will be undefined and cause configuration errors
- Never commit your `.env.local` file - it contains sensitive API keys

**AI Business Intelligence:**
- The GEMINI_API_KEY enables AI-powered business insights for pharmacy owners
- Get your Gemini API key from [Google AI Studio](https://makersuite.google.com/app/apikey)
- This feature provides intelligent analysis of sales, inventory, and business trends

## Support

For setup issues:
1. Check the Firebase Console for proper service enablement
2. Verify all environment variables are correctly configured with `VITE_` prefix
3. Ensure your Firebase project has proper permissions
4. Check browser console for specific error messages
5. Make sure `.env.local` file exists in the project root

The application will show clear error messages if Firebase is not properly configured, helping you identify and resolve setup issues quickly.