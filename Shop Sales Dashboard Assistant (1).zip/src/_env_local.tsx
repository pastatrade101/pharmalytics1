# Firebase Configuration
NEXT_PUBLIC_FIREBASE_API_KEY=AIzaSyCwvoeRHE_So4WRllf7D8WJvI974REDVMY
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=shopsalesai.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=shopsalesai
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=shopsalesai.firebasestorage.app
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=665172496842
NEXT_PUBLIC_FIREBASE_APP_ID=1:665172496842:web:your-app-id-here

# Application Settings
NEXT_PUBLIC_APP_URL=http://localhost:3000
NEXT_PUBLIC_SHOP_NAME="Shop Sales AI"
NODE_ENV=development

# OpenAI Configuration (Optional - for enhanced AI features)
OPENAI_API_KEY=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
OPENAI_MODEL=gpt-4o-mini
OPENAI_FALLBACK_MODEL=gpt-3.5-turbo
OPENAI_TEMPERATURE=0.7

# Email Configuration (Optional - for notifications)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_SECURE=false
EMAIL_USER=your-email@gmail.com
EMAIL_APP_PASSWORD=your-gmail-app-password
OWNER_EMAIL=owner@shopsalesai.com
MANAGER_EMAIL=manager@shopsalesai.com

# WhatsApp Business API Configuration (Optional)
WHATSAPP_BUSINESS_ACCOUNT_ID=your-business-account-id
WHATSAPP_ACCESS_TOKEN=your-whatsapp-access-token
WHATSAPP_PHONE_NUMBER_ID=your-phone-number-id
OWNER_PHONE=+1234567890

# Google Sheets API Configuration (Optional)
GOOGLE_SHEETS_API_KEY=your-google-sheets-api-key
GOOGLE_SHEETS_SPREADSHEET_ID=your-master-spreadsheet-id
GOOGLE_SERVICE_ACCOUNT_EMAIL=your-service-account@shopsalesai.iam.gserviceaccount.com

# Security Configuration
JWT_SECRET=your-jwt-secret-key

# Development Settings
DEBUG_MODE=false
LOG_LEVEL=info

# Feature Flags
ENABLE_REAL_TIME_UPDATES=true
ENABLE_EMAIL_NOTIFICATIONS=true
ENABLE_WHATSAPP_NOTIFICATIONS=true
ENABLE_AI_INSIGHTS=true
ENABLE_AUTOMATIC_REPORTS=true